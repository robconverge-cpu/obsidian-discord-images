obsidian.onStart(() => {
  obsidian.log("My first plugin is running!");
});
