// ─────────────────────────────────────────────────────────────────────────────
// GENERATED FILE — DO NOT EDIT.
//
// Regenerate with:  python tools/gen_obsidian_dts.py
//
// Function declarations are generated from the OBS_JS_FN(...) bindings in
// plugins/supporter/plugin_maker/src/js_bindings.cpp — each binding carries its own
// TypeScript signature, so this file can never drift from what is actually bound.
// To add or change a function, edit the binding.
//
// Types and constants come from obsidian.handwritten.d.ts.
// ─────────────────────────────────────────────────────────────────────────────

// ─────────────────────────────────────────────────────────────────────────
// HAND-WRITTEN. Everything here is a TYPE or a CONSTANT — none of it can be
// derived from js_bindings.cpp, so it lives here and is included verbatim in
// the generated obsidian.d.ts.
//
// FUNCTIONS DO NOT BELONG IN THIS FILE. Every obsidian.<domain>.<fn> is
// generated from the OBS_JS_FN(...) binding that defines it — add the binding
// and the declaration follows. See tools/gen_obsidian_dts.py.
// ─────────────────────────────────────────────────────────────────────────

/**
 * Obsidian Plugin API — TypeScript declarations for the JS scripting runtime.
 * Generated from js_bindings.cpp. Do not hand-edit — regenerate from bindings.
 *
 * Event handlers and overlays are script-lifetime: registered on start,
 * automatically cleared when the script unloads. No manual unsubscribe needed.
 */

// ── Data Shapes ────────────────────────────────────────────────────────────
// All types live inside the `obsidian` namespace (merged with the API block
// below) — reference them as obsidian.WorldPoint, obsidian.NpcInfo, etc.

declare namespace obsidian {

interface WorldPoint {
  x: number;
  y: number;
  plane: number;
}

/** Fine-local position (128 units per tile) — interpolated visual position. */
interface LocalPoint {
  x: number;
  y: number;
}

/** Scene tile (0..103) of the currently loaded scene — world tile minus the live base. */
interface ScenePoint {
  x: number;
  y: number;
}

interface LocalPlayerInfo {
  /** Player-list index — use to verify interactions against an actor index. */
  index: number;
  /** Validated target slot (-1 = not interacting; stale game values filtered). */
  interactingIndex: number;
  /** 0 = not interacting, 1 = target is an NPC, 2 = target is a player. */
  interactingType: number;
  /** True if currently interacting (interactingType !== 0). */
  isInteracting: boolean;
  location: WorldPoint;
  animation: number;
  moving: boolean;
  name: string;
  combatLevel: number;
  healthPercent: number;
  animating: boolean;
  inCombat: boolean;
  /** Direction facing (0-2047). */
  orientation: number;
  /** Overhead prayer icon: -1 = none, else an OverheadIcon value (0 = Protect from Melee). */
  overheadIcon: number;
  /** Skull icon: -1 = none. */
  skullIcon: number;
  /** Attached spot anims in slot order (first = RuneLite getGraphic()). */
  spotAnims: SpotAnim[];
}

/** An attached spot anim (graphic) on an actor. */
interface SpotAnim {
  id: number;
  /** Height above the tile. */
  height: number;
  /** Client cycle it starts (cast + delay); compare with client.gameCycle(). */
  startCycle: number;
}

interface NpcInfo {
  index: number;
  id: number;
  name: string;
  location: WorldPoint;
  /** Interpolated fine-local position (drifts each render frame during walks). */
  localLocation: LocalPoint;
  /** WorldView this NPC belongs to (0 = overworld). */
  worldViewId: number;
  combatLevel: number;
  healthPercent: number;
  healthRatio: number;
  healthScale: number;
  animation: number;
  /** Current frame within the action animation. */
  animationFrame: number;
  /** Current pose animation (walk / idle / run state). */
  poseAnimation: number;
  /** Validated target slot (-1 = not interacting; stale game values filtered). */
  interactingIndex: number;
  /** 0 = not interacting, 1 = target is an NPC, 2 = target is a player. */
  interactingType: number;
  /** True if currently interacting (interactingType !== 0). */
  isInteracting: boolean;
  orientation: number;
  /** Overridden face angle (-1 = not overriding orientation). */
  faceAngle: number;
  /** Overhead chat text (empty = none). */
  overheadText: string;
  /** Overhead prayer icon: -1 = none, else an OverheadIcon value (0 = Protect from Melee). */
  overheadIcon: number;
  size: number;
  interactable: boolean;
  dead: boolean;
  /** Attached spot anims in slot order (first = RuneLite getGraphic()). */
  spotAnims: SpotAnim[];
  /** Most recently applied hitsplat (check hitsplat.active). */
  hitsplat: Hitsplat;
  actions: string[];
}

interface PlayerInfo {
  index: number;
  name: string;
  location: WorldPoint;
  /** Interpolated fine-local position (drifts each render frame during walks). */
  localLocation: LocalPoint;
  /** WorldView this player belongs to (0 = overworld). */
  worldViewId: number;
  combatLevel: number;
  healthPercent: number;
  healthRatio: number;
  healthScale: number;
  animation: number;
  /** Direction facing (0-2047). */
  orientation: number;
  /** Validated target slot (-1 = not interacting; stale game values filtered). */
  interactingIndex: number;
  /** 0 = not interacting, 1 = target is an NPC, 2 = target is a player. */
  interactingType: number;
  /** True if currently interacting (interactingType !== 0). */
  isInteracting: boolean;
  /** Overhead chat text (empty = none). */
  overheadText: string;
  skullIcon: number;
  /** Overhead prayer icon: -1 = none, else an OverheadIcon value (0 = Protect from Melee). */
  overheadIcon: number;
  /** Friends-list status (0 = not a friend). */
  friendStatus: number;
  /** Friends-chat membership status. */
  fcStatus: number;
  /** Clan membership status. */
  clanStatus: number;
  /** Most recently applied hitsplat (check hitsplat.active). */
  hitsplat: Hitsplat;
  /** Attached spot anims in slot order (first = RuneLite getGraphic()). */
  spotAnims: SpotAnim[];
  /** Worn item id per KitType slot, -1 = none: 0 HEAD, 1 CAPE, 2 AMULET,
   *  3 WEAPON, 4 TORSO, 5 SHIELD, 6 ARMS, 7 LEGS, 8 HAIR, 9 HANDS, 10 BOOTS, 11 JAW. */
  equipment: number[];
}

/** Scene object type: 0=Game, 1=Wall, 2=Decorative, 3=Ground. */
const enum SceneObjectType { Game = 0, Wall = 1, Decorative = 2, Ground = 3 }

interface ObjectInfo {
  id: number;
  /** Definition name ("" if unknown). For a multiloc (transform/impostor) this is the
   *  child currently selected by its varbit/varp, e.g. a farming patch's crop state. */
  name: string;
  /** Source type (Game/Wall/Decorative/Ground). */
  type: SceneObjectType;
  location: WorldPoint;
  sceneX: number;
  sceneY: number;
  /** WorldView this object belongs to (0 = overworld). */
  worldViewId: number;
  /** Object orientation (0-2047). */
  orientation: number;
  /** Fine-local anchor X (1/128 tile units). */
  localX: number;
  /** Fine-local anchor Y (1/128 tile units). */
  localY: number;
  /** Current animation (sequence) id, -1 when static or a one-shot animation
   *  has finished (RuneLite DynamicObject.getAnimation()). Game objects only. */
  animationId: number;
  /** Current frame of animationId, -1 when not animating. */
  animationFrame: number;
}

interface GroundItemInfo {
  id: number;
  quantity: number;
  sceneX: number;
  sceneY: number;
  /** Absolute world tile (use this for distance/radius math). */
  location: WorldPoint;
  plane: number;
  /** Ownership: 0=NONE, 1=SELF (yours), 2=OTHER, 3=GROUP. */
  ownership: number;
  /** TileItem+0x24 — owner flag (1 when owned by you, else 0). */
  ownerFlag: number;
  /** True when ownership == SELF. */
  isMine: boolean;
  /** WorldView this item belongs to (0 = overworld). */
  worldViewId: number;
}

interface ContainerItem {
  id: number;
  quantity: number;
  /** True container slot index (0-based; -1 if unknown). A bank placeholder
   *  occupies its slot with quantity 0 — check quantity === 0 or
   *  obsidian.definitions.item(id).placeholder to detect one. */
  slot: number;
}

/**
 * A resolved interaction target.
 * The targeted actor's full info object plus an `isPlayer` discriminator:
 *   const t = obsidian.localPlayer.getInteracting();
 *   if (t && !t.isPlayer) obsidian.log("fighting NPC " + t.name);
 */
type InteractingTarget =
  | (NpcInfo & { isPlayer: false })
  | (PlayerInfo & { isPlayer: true });

interface WidgetInfo {
  valid: boolean;
  id: number;
  parentId: number;
  type: number;
  text: string;
  itemId: number;
  itemQuantity: number;
  spriteId: number;
  width: number;
  height: number;
  hidden: boolean;
  name: string;
  /** This widget's index within its parent (dynamic children). */
  childIndex: number;
  /** Number of dynamic children under this widget. */
  dynamicChildCount: number;
  /** Right-click action strings (up to 10). */
  actions: string[];
}

interface HealthInfo {
  current: number;
  max: number;
  percent: number;
}

interface PrayerInfo {
  current: number;
  max: number;
}

interface Hitsplat {
  /** HitsplatType constant (damage/heal/poison/venom/block etc). */
  type: number;
  /** Damage or heal value. */
  amount: number;
  /** Game cycle the splat appeared. */
  cycle: number;
  /** Currently visible on screen. */
  active: boolean;
  /** Splat belongs to the local player. */
  isMine: boolean;
  /** Splat belongs to another source. */
  isOthers: boolean;
}

/** One entry from the server's world list — see obsidian.world.getWorldList(). */
interface WorldInfo {
  /** World number, e.g. 301. Pass this to world.hopTo(). */
  id: number;
  playerCount: number;
  /** Server region: 0=US, 1=UK, 7=AU/DE. */
  location: number;
  /** Description, e.g. "Trade - Members". */
  activity: string;
  address: string;
  /** Raw world-type bitmask (RuneLite WorldType bits: 1=MEMBERS, 1<<2=PVP,
   *  1<<7=SKILL_TOTAL, 1<<10=HIGH_RISK, 1<<29=DEADMAN, 1<<30=SEASONAL, ...). */
  types: number;
  isMembers: boolean;
  isPvp: boolean;
  isHighRisk: boolean;
  isSkillTotal: boolean;
  isDeadman: boolean;
  isSeasonal: boolean;
  isBeta: boolean;
  /** True when the world is none of PvP / high-risk / deadman / seasonal / beta /
   *  tournament / fresh-start — i.e. safe to hop to for ordinary play. */
  isSafe: boolean;
}

interface GeOffer {
  slot: number;
  /** 0=empty, 1=pending, 2=active, 5=finished (completed or cancelled — compare quantityTraded to totalQuantity; awaiting collection). */
  state: number;
  /** 0=buy, 1=sell. */
  type: number;
  itemId: number;
  /** Price per item. */
  price: number;
  /** Total quantity requested. */
  totalQuantity: number;
  /** Quantity traded so far. */
  quantityTraded: number;
  /** Gold spent (buy) / received (sell) so far. */
  spent: number;
}

interface ItemDefinition {
  id: number;
  name: string;
  /** True if the item stacks (noted items are always stackable). */
  stackable: boolean;
  members: boolean;
  /** True if this item is a bank note. */
  noted: boolean;
  /** Cross-link to the noted/unnoted counterpart (set on both versions). */
  notedId: number;
  /** True if this item is a bank placeholder (empty-slot marker). */
  placeholder: boolean;
  /** The real item this placeholder represents (-1 if none). */
  placeholderId: number;
  cost: number;
  weightGrams: number;
  /** Inventory options, 5 entries in option order ("" where there is none),
   *  e.g. ["Eat", "", "", "", "Drop"]. */
  actions: string[];
}

interface NpcDefinition {
  id: number;
  name: string;
  combatLevel: number;
  actions: string[];
  size: number;
  models: number[];
  /** NPC ids this can transform into (RuneLite getConfigs). */
  configs: number[];
  transformVarbit: number;
  transformVarp: number;
  interactible: boolean;
  minimapVisible: boolean;
  visible: boolean;
  follower: boolean;
  widthScale: number;
  heightScale: number;
  colorToReplace: number[];
  colorToReplaceWith: number[];
  footprintSize: number;
  /** [Attack, Defence, Strength, Hitpoints, Ranged, Magic]. */
  stats: number[];
}

interface ObjectDefinition {
  id: number;
  name: string;
  sizeX: number;
  sizeY: number;
  actions: string[];
  configs: number[];
  transformVarbit: number;
  transformVarp: number;
  mapSceneId: number;
  interactType: number;
  animation: number;
  category: number;
  wallOrDoor: number;
  blocksProjectile: boolean;
}

/** definitions.enumDef(id). Keys of intValues / stringValues are the enum keys as strings. */
interface EnumDefinition {
  id: number;
  /** CS2 type char code of the key / value type. */
  keyType: number;
  valueType: number;
  defaultString: string;
  defaultInt: number;
  intValues: { [key: string]: number };
  stringValues: { [key: string]: string };
}

/** definitions.structDef(id). Keys of intParams / stringParams are param ids as strings. */
interface StructDefinition {
  id: number;
  intParams: { [paramId: string]: number };
  stringParams: { [paramId: string]: string };
}

/** walker.walkToOpts options. Any omitted flag inherits the tab's walker settings. */
interface WalkOptions {
  useTeleports?: boolean;
  useTransports?: boolean;
  avoidWilderness?: boolean;
  usePoh?: boolean;
  useMinigameTeleports?: boolean;
  bankForTeleports?: boolean;
  /** Tiles from the destination that count as arrived. */
  arrivalRadius?: number;
}

/** One transport the current path routes through (walker.pathTransports()). */
interface PathTransport {
  /** -1 None, 0 Object, 1 Npc, 2 ItemUse, 3 SlashWeb, 4 Dig, 5 Walk, 6 FairyRing,
   *  7 SpiritTree, 8 GnomeGlider, 9 CharterShip, 10 Minecart, 11 Obelisk,
   *  12 Mushtree, 13 BirdTravel, 100 Teleport. */
  kind: number;
  name: string;
  action: string;
  objectId: number;
  goldCost: number;
  /** Boarding tile. Zeroed for Teleport (a teleport is cast from anywhere). */
  from: WorldPoint;
  to: WorldPoint;
}

/** The teleport the walker is about to use (walker.pendingTeleport()). */
interface PendingTeleport {
  name: string;
  cost: number;
  isPoh: boolean;
  isMinigame: boolean;
  destination: WorldPoint;
}

interface EntityHandle {
  index: number;
  generation: number;
  type: string;
}

interface PanelRect {
  x: number;
  y: number;
  w: number;
  h: number;
}

type PanelPosition = "TOP_LEFT" | "TOP_CENTER" | "TOP_RIGHT" | "BOTTOM_LEFT" | "BOTTOM_RIGHT" | "ABOVE_CHATBOX_RIGHT" | "CANVAS_TOP_RIGHT";

interface Panel {
  width(w: number): Panel;
  minWidth(w: number): Panel;
  padding(p: number): Panel;
  lineHeight(h: number): Panel;
  background(color: number): Panel;
  borderColor(color: number): Panel;
  titleColor(color: number): Panel;
  textColor(color: number): Panel;
  labelColor(color: number): Panel;
  /** Background of non-leading title bars. */
  headerBg(color: number): Panel;
  /** Item-row have/missing indicator colors (applies to itemRows added after). */
  itemColors(have: number, missing: number): Panel;
  /** Raw PanelStyleFlags: 1=no shadow, 2=flat bg, 4=no glass, 8=simple title, 16=zebra. */
  styleFlags(flags: number): Panel;
  /** Classic flat look: no shadow, solid background, no glass, plain underlined title. */
  basic(): Panel;
  /** Faint alternating tint behind data rows for easier tracking. */
  zebra(on?: boolean): Panel;
  /** Evenly-spaced table row. `aligns` is one char per column: 'l' | 'r' | 'c'. */
  tableRow(cells: (string | number)[], colors?: number[], aligns?: string): Panel;
  /** Title bar. Optional `right` renders right-aligned in the bar (e.g. a session clock). */
  title(text: string, color?: number, right?: string): Panel;
  row(label: string, value: string | number, labelColor?: number, valueColor?: number): Panel;
  label(text: string, color?: number): Panel;
  /** Progress bar; bars >= 9px tall show the percent inside the bar. */
  progress(label: string, percent: number, barColor?: number, bgColor?: number, barHeight?: number): Panel;
  separator(color?: number): Panel;
  spacer(height?: number): Panel;
  header(text: string, color?: number): Panel;
  /** Item row. Pass `itemId` to render the item's inventory icon (cache-rendered); omit for a colour chip. */
  itemRow(name: string, qtyHave: number, qtyNeed: number, hasItem: boolean, itemId?: number): Panel;
  iconText(icon: string, text: string, color?: number): Panel;
  /** Large value over a small caption; two consecutive stat tiles render side by side. */
  statTile(value: string | number, caption: string, tint?: number): Panel;
  /** Radial countdown/progress ring (percent 0-100) with center text and optional label. */
  timerRing(percent: number, centerText: string, label?: string, color?: number): Panel;
  /** Mini line chart. Values are min-max normalised; up to 64 samples. */
  sparkline(values: number[], color?: number): Panel;
  /** Render at a managed position with auto-stacking and ALT+drag support. */
  render(position: PanelPosition): PanelRect;
  /** Render at manual screen coordinates (backward compatible). */
  render(x: number, y: number): PanelRect;
}

/**
 * Shared terminal methods for the fluent scene queries. Chainable filter
 * methods return the same builder; terminals evaluate it. Obtain a builder
 * via obsidian.npcs.query() / players.query() / objects.query() / groundItems.query().
 */
interface QueryTerminals<T> {
  first(): T | null;
  toArray(): T[];
  count(): number;
  any(): boolean;
  /** Nearest match to the local player. */
  nearest(): T | null;
  nearestTo(origin: { x: number; y: number; plane?: number }): T | null;
  forEach(fn: (e: T) => void): void;
}

interface NpcQuery extends QueryTerminals<NpcInfo> {
  /** Add a custom predicate filter. */
  where(fn: (e: NpcInfo) => boolean): NpcQuery;
  nameEquals(name: string): NpcQuery;
  nameContains(substr: string): NpcQuery;
  id(id: number): NpcQuery;
  /** Match any of the given ids. */
  ids(...ids: number[]): NpcQuery;
  hasAction(action: string): NpcQuery;
  isAlive(): NpcQuery;
  isDead(): NpcQuery;
  isAnimating(): NpcQuery;
  notAnimating(): NpcQuery;
  animation(animationId: number): NpcQuery;
  interactable(): NpcQuery;
  /** Keep NPCs within Chebyshev `radius` of the local player tile. */
  within(radius: number): NpcQuery;
}

interface PlayerQuery extends QueryTerminals<PlayerInfo> {
  /** Add a custom predicate filter. */
  where(fn: (e: PlayerInfo) => boolean): PlayerQuery;
  nameEquals(name: string): PlayerQuery;
  nameContains(substr: string): PlayerQuery;
  isSkulled(): PlayerQuery;
  animation(animationId: number): PlayerQuery;
  isAnimating(): PlayerQuery;
  notAnimating(): PlayerQuery;
  /** Keep players within Chebyshev `radius` of the local player tile. */
  within(radius: number): PlayerQuery;
}

/**
 * Object queries scan by id or name — you MUST call id() or nameEquals()
 * before a terminal, otherwise the result set is empty (there is no
 * unfiltered scene-object enumeration).
 */
interface ObjectQuery extends QueryTerminals<ObjectInfo> {
  /** Add a custom predicate filter. */
  where(fn: (e: ObjectInfo) => boolean): ObjectQuery;
  id(id: number): ObjectQuery;
  nameEquals(name: string): ObjectQuery;
  /** Keep objects within Chebyshev `radius` of the local player tile. */
  within(radius: number): ObjectQuery;
}

interface GroundItemQuery extends QueryTerminals<GroundItemInfo> {
  /** Add a custom predicate filter. */
  where(fn: (e: GroundItemInfo) => boolean): GroundItemQuery;
  id(id: number): GroundItemQuery;
  /** Match any of the given item ids. */
  ids(...ids: number[]): GroundItemQuery;
  /** Keep items within Chebyshev `radius` of the local player tile. */
  within(radius: number): GroundItemQuery;
}

// ── Event Names ────────────────────────────────────────────────────────────

type ObsidianEvent =
  | "gameTick"
  | "clientTick"
  | "npcSpawned"
  | "npcDespawned"
  | "npcChanged"
  | "chatMessage"
  | "varbitChanged"
  | "gameStateChanged"
  | "menuOptionClicked"
  | "menuEntryAdded"
  | "statChanged"
  | "xpGained"
  | "containerChanged"
  | "animationChanged"
  | "playerSpawned"
  | "playerDespawned"
  | "itemSpawned"
  | "itemDespawned"
  | "gameObjectSpawned"
  | "gameObjectDespawned"
  | "widgetLoaded"
  | "widgetClosed"
  | "widgetUnloaded"
  | "hitsplatApplied"
  | "projectileSpawned"
  | "projectileDespawned"
  | "projectileMoved"
  | "interactingChanged"
  | "beforeRender"
  | "actorDeath"
  | "graphicChanged"
  | "spotAnimChanged"
  | "overheadTextChanged"
  | "playerChanged"
  | "wallObjectSpawned"
  | "wallObjectDespawned"
  | "decorativeObjectSpawned"
  | "decorativeObjectDespawned"
  | "groundObjectSpawned"
  | "groundObjectDespawned"
  | "graphicsObjectSpawned"
  | "graphicsObjectDespawned"
  | "itemQuantityChanged"
  | "canvasSizeChanged"
  | "worldChanged"
  | "worldEntitySpawned"
  | "worldEntityDespawned"
  | "focusChanged"
  | "commandExecuted"
  | "varClientIntChanged"
  | "varClientStrChanged"
  | "grandExchangeOfferChanged"
  | "accountHashChanged"
  | "usernameChanged"
  | "removedFriend"
  | "addedFriend"
  | "soundEffectPlayed"
  | "areaSoundEffectPlayed"
  | "postClientTick"
  | "afterRender"
  | "resizeableChanged"
  | "menuOpened"
  | "postMenuSort"
  | "widgetDrag"
  | "preMapLoad"
  | "mapLoaded"
  | "worldViewLoaded"
  | "worldViewUnloaded"
  | "worldListLoad"
  /** CS2 named script callback. Payload:
   *  { eventName: string, intStack: number[], stringStack: string[],
   *    intStackSize: number, stringStackSize: number }. The LAST element of
   *  intStack/stringStack is the TOP of stack (intStack[intStack.length-1] ==
   *  getIntStack()[getIntStackSize()-1]); *StackSize are the live depths (the
   *  arrays hold up to the top 20 ints / 3 strings). Read-only snapshot. */
  | "scriptCallback"
  | "fakeXpDrop"
  /** obsidian.shared.set() changed a value (any script, any tab). Payload: { key, value }. */
  | "sharedChanged"
  /** Fired when a config value is edited in the script's settings panel —
   *  ImGui config editor, a Button item click, or a custom panel's
   *  obsidianPanel.config.set(). Payload: { key, value, script }. */
  | "configChanged"
  /** Fired when the script's custom panel calls obsidianPanel.send(data).
   *  Payload: { data } — the sent value, JSON round-tripped. */
  | "panelMessage"
  /** Break Handler consumer lifecycle. Every payload has { plugin }; plus:
   *  breakScheduled { at }, breakStarted { until, logout },
   *  breakSessionStopped { reason }. */
  | "breakScheduled"
  | "breakStarted"
  | "breakEnded"
  | "breakSessionStopped";

// ── Event Payloads ─────────────────────────────────────────────────────────
// obsidian.on(name, cb) types cb's argument from this map. gameTick passes the
// tick count as a bare number; `void` events pass no argument.

/** Shared actor fields (js_actor). */
interface ActorEventBase {
  index: number;
  localX: number; localY: number;
  tileX: number; tileY: number;
  worldX: number; worldY: number;
  orientation: number;
  animation: number;
  poseAnimation: number;
  interactingIndex: number;
  /** 0 = none, 1 = NPC, 2 = player. */
  interactingType: number;
  isInteracting: boolean;
  healthRatio: number;
  healthScale: number;
  isDead: boolean;
  overheadText: string;
  graphic: number;
}
interface ActorEventWithKind extends ActorEventBase { isNpc: boolean; }
interface NpcEventData extends ActorEventBase { npcId: number; name: string; combatLevel: number; size: number; }
interface PlayerEventData extends ActorEventBase { name: string; combatLevel: number; skullIcon: number; overheadIcon: number; }

/** Tile the object or item event happened on (js_tile). */
interface EventTile { sceneX: number; sceneY: number; worldX: number; worldY: number; plane: number; }
/** Shared shape for wall, decorative and ground objects. */
interface EventSceneObject { id: number; sceneX: number; sceneY: number; worldX: number; worldY: number; plane: number; }
interface EventGameObject extends EventSceneObject {
  orientation: number; fineX: number; fineY: number;
  startTileX: number; startTileY: number; endTileX: number; endTileY: number;
}
interface EventWallObject extends EventSceneObject { orientation: number; }
interface EventTileItem extends EventSceneObject { quantity: number; }
interface ProjectileEventData {
  id: number; sourceX: number; sourceY: number; targetX: number; targetY: number;
  startCycle: number; endCycle: number; targetActorIndex: number; plane: number;
}
interface GraphicsObjectEventData {
  id: number;
  /** localX >> 7 */ sceneX: number;
  /** localY >> 7 */ sceneY: number;
  localX: number; localY: number; height: number; startCycle: number;
  animFrame: number; animationId: number; plane: number;
}
interface MenuEntryEventData {
  type: number; identifier: number; actionParam0: number; actionParam1: number;
  itemId: number; option: string; target: string;
}

interface EventMap {
  /** Bare tick count, not an object. */
  gameTick: number;
  clientTick: void;
  postClientTick: void;
  beforeRender: void;
  afterRender: void;
  worldChanged: void;
  widgetDrag: void;
  worldListLoad: void;

  /** Every Break Handler payload carries the consumer plugin name. `at` is epoch ms. */
  breakScheduled: { plugin: string; at: number };
  /** `until` is epoch ms. `logout` is true for a logout break, false for an AFK break. */
  breakStarted: { plugin: string; until: number; logout: boolean };
  breakEnded: { plugin: string };
  breakSessionStopped: { plugin: string; reason: string };

  npcSpawned: NpcEventData;
  npcDespawned: NpcEventData;
  npcChanged: NpcEventData & { oldNpcId: number };
  playerSpawned: PlayerEventData;
  playerDespawned: PlayerEventData;
  playerChanged: PlayerEventData;
  actorDeath: ActorEventWithKind;
  animationChanged: ActorEventWithKind & { oldAnimation: number; newAnimation: number };
  /** New target is in the base fields `interactingIndex` and `interactingType`. */
  interactingChanged: ActorEventWithKind;
  overheadTextChanged: ActorEventWithKind & { text: string };
  hitsplatApplied: ActorEventWithKind & { hitsplat: Pick<Hitsplat, "type" | "amount" | "cycle" | "active"> };
  graphicChanged: ActorEventWithKind & { oldGraphic: number; newGraphic: number; height: number; startCycle: number };
  spotAnimChanged: ActorEventWithKind & { spotAnimId: number; height: number; startCycle: number };

  /** `type` is a ChatMessageType value. */
  chatMessage: { type: number; name: string; sender: string; message: string };
  commandExecuted: { command: string; args: string };

  /** `longValue` is int64 (long varps, e.g. GE price varp 5753). */
  varbitChanged: { varpId: number; varbitId: number; value: number; longValue: number };
  statChanged: { skill: number; oldLevel: number; newLevel: number; oldXp: number; newXp: number };
  xpGained: { skill: number; xpGained: number; totalXp: number };
  /** Index only. Read the new value with the VarC getters. */
  varClientIntChanged: { index: number };
  varClientStrChanged: { index: number };
  /** RuneLite FakeXpDrop: drop shown without an XP change (e.g. skill at 200m). */
  fakeXpDrop: { skill: number; xp: number };
  /** Delivered to every script in every tab, at most one client tick after the set().
   *  A key set several times in between arrives once, with its newest value. */
  sharedChanged: { key: string; value: string };

  gameStateChanged: { oldState: number; newState: number };
  focusChanged: { focused: boolean };
  canvasSizeChanged: { oldWidth: number; oldHeight: number; newWidth: number; newHeight: number };
  resizeableChanged: { resized: boolean };

  /** Set `consumed = true` in a handler to consume the click. */
  menuOptionClicked: {
    actionParam0: number; actionParam1: number; menuAction: number; identifier: number;
    itemId: number; option: string; target: string; consumed: boolean;
  };
  menuEntryAdded: MenuEntryEventData;
  menuOpened: { entryCount: number };
  /** Snapshot of the menu after sorting. */
  postMenuSort: { entries: MenuEntryEventData[] };

  /** `items` holds no `slot`; the array index is the slot. */
  containerChanged: { containerId: number; items: Omit<ContainerItem, "slot">[] };

  gameObjectSpawned: { tile: EventTile; gameObject: EventGameObject };
  gameObjectDespawned: { tile: EventTile; gameObject: EventGameObject };
  wallObjectSpawned: { tile: EventTile; wallObject: EventWallObject };
  wallObjectDespawned: { tile: EventTile; wallObject: EventWallObject };
  decorativeObjectSpawned: { tile: EventTile; decorativeObject: EventSceneObject };
  decorativeObjectDespawned: { tile: EventTile; decorativeObject: EventSceneObject };
  groundObjectSpawned: { tile: EventTile; groundObject: EventSceneObject };
  groundObjectDespawned: { tile: EventTile; groundObject: EventSceneObject };
  graphicsObjectSpawned: GraphicsObjectEventData;
  graphicsObjectDespawned: GraphicsObjectEventData;

  itemSpawned: { tile: EventTile; item: EventTileItem };
  itemDespawned: { tile: EventTile; item: EventTileItem };
  itemQuantityChanged: { tile: EventTile; item: EventTileItem; oldQuantity: number; newQuantity: number };

  projectileSpawned: ProjectileEventData;
  projectileDespawned: ProjectileEventData;
  projectileMoved: ProjectileEventData;

  widgetLoaded: { groupId: number };
  widgetClosed: { groupId: number; unload: boolean };
  widgetUnloaded: { groupId: number };

  /** `price` and `spent` are int64 values passed as JS numbers. */
  grandExchangeOfferChanged: {
    slot: number; state: number; type: number; itemId: number;
    quantityTraded: number; totalQuantity: number; price: number; spent: number;
  };

  /** Decimal string, because the hash is larger than 2^53. */
  accountHashChanged: { accountHash: string };
  usernameChanged: { username: string };
  addedFriend: { name: string };
  removedFriend: { name: string };

  soundEffectPlayed: { soundId: number; delay: number };
  areaSoundEffectPlayed: { soundId: number; sceneX: number; sceneY: number; range: number; delay: number };

  worldEntitySpawned: { entityId: number };
  worldEntityDespawned: { entityId: number };
  preMapLoad: { baseX: number; baseY: number };
  mapLoaded: { baseX: number; baseY: number };
  /** `worldViewPtr` is a raw pointer stored as a double. Treat it as an opaque id. */
  worldViewLoaded: { worldViewPtr: number };
  worldViewUnloaded: { worldViewPtr: number };

  /** CS2 callback snapshot. The last element of each stack array is the top of the
   *  stack. The arrays hold at most the top 20 ints and 3 strings. `*StackSize`
   *  gives the live depth. */
  scriptCallback: {
    eventName: string; intStack: number[]; stringStack: string[];
    intStackSize: number; stringStackSize: number;
  };

  /** The value is always a string. The ImGui editor path broadcasts to ALL scripts,
   *  so check `script`. The custom-panel path targets the owning script only. */
  configChanged: { key: string; value: string; script: string };
  /** Sent only to the owning script. `data` went through a JSON round trip and is
   *  null if parsing failed. */
  panelMessage: { data: unknown };
}

} // declare namespace obsidian (data shapes)

declare namespace obsidian {

  namespace CollisionFlag {
    const BLOCK_MOVEMENT_NW: number;
    const BLOCK_MOVEMENT_N: number;
    const BLOCK_MOVEMENT_NE: number;
    const BLOCK_MOVEMENT_E: number;
    const BLOCK_MOVEMENT_SE: number;
    const BLOCK_MOVEMENT_S: number;
    const BLOCK_MOVEMENT_SW: number;
    const BLOCK_MOVEMENT_W: number;
    const BLOCK_MOVEMENT_OBJECT: number;
    const BLOCK_MOVEMENT_FLOOR_DECO: number;
    const BLOCK_MOVEMENT_FLOOR: number;
    const BLOCK_MOVEMENT_FULL: number;
    const BLOCK_LOS_N: number;
    const BLOCK_LOS_E: number;
    const BLOCK_LOS_S: number;
    const BLOCK_LOS_W: number;
    const BLOCK_LOS_FULL: number;
  }
  interface TileCollision {
    flags: number;
    blocked: boolean;
    object: boolean;
    wall: { n: boolean; e: boolean; s: boolean; w: boolean; ne: boolean; se: boolean; sw: boolean; nw: boolean };
    los: { n: boolean; e: boolean; s: boolean; w: boolean; full: boolean };
  }
  // These functions ONLY work inside a registerOverlay callback.
  const QuestState: {
    readonly NOT_STARTED: 0;
    readonly IN_PROGRESS: 1;
    readonly FINISHED: 2;
  };

  /** Values of client.accountType() (varbit 1777). */
  const AccountType: {
    readonly NORMAL: 0;
    readonly IRONMAN: 1;
    readonly HARDCORE_IRONMAN: 2;
    readonly ULTIMATE_IRONMAN: 3;
    readonly GROUP_IRONMAN: 4;
    readonly HARDCORE_GROUP_IRONMAN: 5;
    readonly UNRANKED_GROUP_IRONMAN: 6;
  };
  // Pure math helpers. Pass an obsidian.Skill value for name()/isMembers().
  interface ConfigItemDef {
    key: string;
    label: string;
    type: "boolean" | "number" | "text" | "string" | "select" | "slider" | "color" | "colour" | "button" | "separator" | "header";
    default?: string;
    options?: string[];
    min?: number;
    max?: number;
    step?: number;
  }
  // opType values for menu.createEntry / interaction.invokeAction.
  const MenuAction: {
    readonly WIDGET_TARGET_ON_GAME_OBJECT: 2;
    readonly GAME_OBJECT_FIRST_OPTION: 3;
    readonly GAME_OBJECT_SECOND_OPTION: 4;
    readonly GAME_OBJECT_THIRD_OPTION: 5;
    readonly GAME_OBJECT_FOURTH_OPTION: 6;
    readonly GAME_OBJECT_FIFTH_OPTION: 1001;
    readonly WIDGET_TARGET_ON_NPC: 8;
    readonly NPC_FIRST_OPTION: 9;
    readonly NPC_SECOND_OPTION: 10;
    readonly NPC_THIRD_OPTION: 11;
    readonly NPC_FOURTH_OPTION: 12;
    readonly NPC_FIFTH_OPTION: 13;
    readonly WIDGET_TARGET_ON_PLAYER: 15;
    readonly PLAYER_FIRST_OPTION: 44;
    readonly PLAYER_SECOND_OPTION: 45;
    readonly PLAYER_THIRD_OPTION: 46;
    readonly PLAYER_FOURTH_OPTION: 47;
    readonly PLAYER_FIFTH_OPTION: 48;
    readonly WIDGET_TARGET_ON_GROUND_ITEM: 17;
    readonly GROUND_ITEM_FIRST_OPTION: 18;
    readonly GROUND_ITEM_SECOND_OPTION: 19;
    readonly GROUND_ITEM_THIRD_OPTION: 20;
    readonly GROUND_ITEM_FOURTH_OPTION: 21;
    readonly GROUND_ITEM_FIFTH_OPTION: 22;
    readonly WALK: 23;
    readonly WIDGET_TYPE_1: 24;
    readonly WIDGET_TARGET: 25;
    readonly WIDGET_CLOSE: 26;
    readonly WIDGET_CONTINUE: 30;
    readonly NATIVE_WALK_DIRECT: 31;
    readonly WIDGET_FIRST_OPTION: 39;
    readonly WIDGET_SECOND_OPTION: 40;
    readonly WIDGET_THIRD_OPTION: 41;
    readonly WIDGET_FOURTH_OPTION: 42;
    readonly WIDGET_FIFTH_OPTION: 43;
    readonly CC_OP: 57;
    readonly WIDGET_TARGET_ON_WIDGET: 58;
    readonly WORLD_ENTITY_FIRST_OPTION: 63;
    readonly WORLD_ENTITY_SECOND_OPTION: 64;
    readonly WORLD_ENTITY_THIRD_OPTION: 65;
    readonly WORLD_ENTITY_FOURTH_OPTION: 66;
    readonly WORLD_ENTITY_FIFTH_OPTION: 67;
    readonly EXAMINE_OBJECT: 1002;
    readonly EXAMINE_NPC: 1003;
    readonly EXAMINE_ITEM_GROUND: 1004;
    readonly CANCEL: 1006;
    readonly CC_OP_LOW_PRIORITY: 1007;
    readonly OBSIDIAN: 1500;
  };
  const EquipmentSlot: {
    readonly HEAD: 0;
    readonly CAPE: 1;
    readonly AMULET: 2;
    readonly WEAPON: 3;
    readonly BODY: 4;
    readonly SHIELD: 5;
    readonly LEGS: 7;
    readonly HANDS: 9;
    readonly FEET: 10;
    readonly RING: 12;
    readonly AMMO: 13;
  };
  const ContainerId: {
    readonly INVENTORY: 93;
    readonly EQUIPMENT: 94;
    readonly BANK: 95;
    readonly TRADE: 90;
  };
  const Prayer: {
    readonly THICK_SKIN: 0;
    readonly BURST_OF_STRENGTH: 1;
    readonly CLARITY_OF_THOUGHT: 2;
    readonly SHARP_EYE: 3;
    readonly MYSTIC_WILL: 4;
    readonly ROCK_SKIN: 5;
    readonly SUPERHUMAN_STRENGTH: 6;
    readonly IMPROVED_REFLEXES: 7;
    readonly RAPID_RESTORE: 8;
    readonly RAPID_HEAL: 9;
    readonly PROTECT_ITEM: 10;
    readonly HAWK_EYE: 11;
    readonly MYSTIC_LORE: 12;
    readonly STEEL_SKIN: 13;
    readonly ULTIMATE_STRENGTH: 14;
    readonly INCREDIBLE_REFLEXES: 15;
    readonly PROTECT_FROM_MAGIC: 16;
    readonly PROTECT_FROM_MISSILES: 17;
    readonly PROTECT_FROM_MELEE: 18;
    readonly EAGLE_EYE: 19;
    readonly MYSTIC_MIGHT: 20;
    readonly RETRIBUTION: 21;
    readonly REDEMPTION: 22;
    readonly SMITE: 23;
    readonly PRESERVE: 24;
    readonly CHIVALRY: 25;
    readonly PIETY: 26;
    readonly RIGOUR: 27;
    readonly AUGURY: 28;
  };
  const Skill: {
    readonly ATTACK: 0;
    readonly DEFENCE: 1;
    readonly STRENGTH: 2;
    readonly HITPOINTS: 3;
    readonly RANGED: 4;
    readonly PRAYER: 5;
    readonly MAGIC: 6;
    readonly COOKING: 7;
    readonly WOODCUTTING: 8;
    readonly FLETCHING: 9;
    readonly FISHING: 10;
    readonly FIREMAKING: 11;
    readonly CRAFTING: 12;
    readonly SMITHING: 13;
    readonly MINING: 14;
    readonly HERBLORE: 15;
    readonly AGILITY: 16;
    readonly THIEVING: 17;
    readonly SLAYER: 18;
    readonly FARMING: 19;
    readonly RUNECRAFT: 20;
    readonly HUNTER: 21;
    readonly CONSTRUCTION: 22;
    readonly SAILING: 23;
  };
  const Spell: {
    // Standard spellbook
    readonly HOME_TELEPORT: "HOME_TELEPORT";
    readonly WIND_STRIKE: "WIND_STRIKE";
    readonly CONFUSE: "CONFUSE";
    readonly ENCHANT_CROSSBOW_BOLT: "ENCHANT_CROSSBOW_BOLT";
    readonly WATER_STRIKE: "WATER_STRIKE";
    readonly JEWELLERY_ENCHANT: "JEWELLERY_ENCHANT";
    readonly LVL1_ENCHANT: "LVL1_ENCHANT";
    readonly EARTH_STRIKE: "EARTH_STRIKE";
    readonly WEAKEN: "WEAKEN";
    readonly FIRE_STRIKE: "FIRE_STRIKE";
    readonly BONES_TO_BANANAS: "BONES_TO_BANANAS";
    readonly WIND_BOLT: "WIND_BOLT";
    readonly CURSE: "CURSE";
    readonly BIND: "BIND";
    readonly LOW_LEVEL_ALCHEMY: "LOW_LEVEL_ALCHEMY";
    readonly WATER_BOLT: "WATER_BOLT";
    readonly VARROCK_TELEPORT: "VARROCK_TELEPORT";
    readonly LVL2_ENCHANT: "LVL2_ENCHANT";
    readonly EARTH_BOLT: "EARTH_BOLT";
    readonly LUMBRIDGE_TELEPORT: "LUMBRIDGE_TELEPORT";
    readonly TELEKINETIC_GRAB: "TELEKINETIC_GRAB";
    readonly FIRE_BOLT: "FIRE_BOLT";
    readonly FALADOR_TELEPORT: "FALADOR_TELEPORT";
    readonly CRUMBLE_UNDEAD: "CRUMBLE_UNDEAD";
    readonly TELEPORT_TO_HOUSE: "TELEPORT_TO_HOUSE";
    readonly WIND_BLAST: "WIND_BLAST";
    readonly SUPERHEAT_ITEM: "SUPERHEAT_ITEM";
    readonly CAMELOT_TELEPORT: "CAMELOT_TELEPORT";
    readonly WATER_BLAST: "WATER_BLAST";
    readonly KOUREND_CASTLE_TELEPORT: "KOUREND_CASTLE_TELEPORT";
    readonly LVL3_ENCHANT: "LVL3_ENCHANT";
    readonly IBAN_BLAST: "IBAN_BLAST";
    readonly SNARE: "SNARE";
    readonly MAGIC_DART: "MAGIC_DART";
    readonly ARDOUGNE_TELEPORT: "ARDOUGNE_TELEPORT";
    readonly EARTH_BLAST: "EARTH_BLAST";
    readonly CIVITAS_ILLI_FORTIS_TELEPORT: "CIVITAS_ILLI_FORTIS_TELEPORT";
    readonly HIGH_LEVEL_ALCHEMY: "HIGH_LEVEL_ALCHEMY";
    readonly CHARGE_WATER_ORB: "CHARGE_WATER_ORB";
    readonly LVL4_ENCHANT: "LVL4_ENCHANT";
    readonly WATCHTOWER_TELEPORT: "WATCHTOWER_TELEPORT";
    readonly FIRE_BLAST: "FIRE_BLAST";
    readonly CHARGE_EARTH_ORB: "CHARGE_EARTH_ORB";
    readonly BONES_TO_PEACHES: "BONES_TO_PEACHES";
    readonly SARADOMIN_STRIKE: "SARADOMIN_STRIKE";
    readonly CLAWS_OF_GUTHIX: "CLAWS_OF_GUTHIX";
    readonly FLAMES_OF_ZAMORAK: "FLAMES_OF_ZAMORAK";
    readonly TROLLHEIM_TELEPORT: "TROLLHEIM_TELEPORT";
    readonly WIND_WAVE: "WIND_WAVE";
    readonly CHARGE_FIRE_ORB: "CHARGE_FIRE_ORB";
    readonly APE_ATOLL_TELEPORT: "APE_ATOLL_TELEPORT";
    readonly WATER_WAVE: "WATER_WAVE";
    readonly CHARGE_AIR_ORB: "CHARGE_AIR_ORB";
    readonly VULNERABILITY: "VULNERABILITY";
    readonly LVL5_ENCHANT: "LVL5_ENCHANT";
    readonly EARTH_WAVE: "EARTH_WAVE";
    readonly ENFEEBLE: "ENFEEBLE";
    readonly TELEOTHER_LUMBRIDGE: "TELEOTHER_LUMBRIDGE";
    readonly FIRE_WAVE: "FIRE_WAVE";
    readonly ENTANGLE: "ENTANGLE";
    readonly STUN: "STUN";
    readonly CHARGE: "CHARGE";
    readonly WIND_SURGE: "WIND_SURGE";
    readonly TELEOTHER_FALADOR: "TELEOTHER_FALADOR";
    readonly WATER_SURGE: "WATER_SURGE";
    readonly TELE_BLOCK: "TELE_BLOCK";
    readonly TELEPORT_TO_TARGET: "TELEPORT_TO_TARGET";
    readonly LVL6_ENCHANT: "LVL6_ENCHANT";
    readonly TELEOTHER_CAMELOT: "TELEOTHER_CAMELOT";
    readonly EARTH_SURGE: "EARTH_SURGE";
    readonly LVL7_ENCHANT: "LVL7_ENCHANT";
    readonly FIRE_SURGE: "FIRE_SURGE";
    // Standard diary variants
    readonly GRAND_EXCHANGE_TELEPORT: "GRAND_EXCHANGE_TELEPORT";
    readonly SEERS_TELEPORT: "SEERS_TELEPORT";
    readonly YANILLE_TELEPORT: "YANILLE_TELEPORT";
    // Ancient spellbook
    readonly EDGEVILLE_HOME_TELEPORT: "EDGEVILLE_HOME_TELEPORT";
    readonly SMOKE_RUSH: "SMOKE_RUSH";
    readonly SHADOW_RUSH: "SHADOW_RUSH";
    readonly PADDEWWA_TELEPORT: "PADDEWWA_TELEPORT";
    readonly BLOOD_RUSH: "BLOOD_RUSH";
    readonly ICE_RUSH: "ICE_RUSH";
    readonly SENNTISTEN_TELEPORT: "SENNTISTEN_TELEPORT";
    readonly SMOKE_BURST: "SMOKE_BURST";
    readonly SHADOW_BURST: "SHADOW_BURST";
    readonly KHARYRLL_TELEPORT: "KHARYRLL_TELEPORT";
    readonly BLOOD_BURST: "BLOOD_BURST";
    readonly ICE_BURST: "ICE_BURST";
    readonly LASSAR_TELEPORT: "LASSAR_TELEPORT";
    readonly SMOKE_BLITZ: "SMOKE_BLITZ";
    readonly SHADOW_BLITZ: "SHADOW_BLITZ";
    readonly DAREEYAK_TELEPORT: "DAREEYAK_TELEPORT";
    readonly BLOOD_BLITZ: "BLOOD_BLITZ";
    readonly ICE_BLITZ: "ICE_BLITZ";
    readonly CARRALLANGAR_TELEPORT: "CARRALLANGAR_TELEPORT";
    readonly SMOKE_BARRAGE: "SMOKE_BARRAGE";
    readonly SHADOW_BARRAGE: "SHADOW_BARRAGE";
    readonly ANNAKARL_TELEPORT: "ANNAKARL_TELEPORT";
    readonly BLOOD_BARRAGE: "BLOOD_BARRAGE";
    readonly ICE_BARRAGE: "ICE_BARRAGE";
    readonly GHORROCK_TELEPORT: "GHORROCK_TELEPORT";
    // Lunar spellbook
    readonly LUNAR_HOME_TELEPORT: "LUNAR_HOME_TELEPORT";
    readonly BAKE_PIE: "BAKE_PIE";
    readonly GEOMANCY: "GEOMANCY";
    readonly CURE_PLANT: "CURE_PLANT";
    readonly MONSTER_EXAMINE: "MONSTER_EXAMINE";
    readonly NPC_CONTACT: "NPC_CONTACT";
    readonly CURE_OTHER: "CURE_OTHER";
    readonly HUMIDIFY: "HUMIDIFY";
    readonly MOONCLAN_TELEPORT: "MOONCLAN_TELEPORT";
    readonly TELE_GROUP_MOONCLAN: "TELE_GROUP_MOONCLAN";
    readonly CURE_ME: "CURE_ME";
    readonly OURANIA_TELEPORT: "OURANIA_TELEPORT";
    readonly HUNTER_KIT: "HUNTER_KIT";
    readonly WATERBIRTH_TELEPORT: "WATERBIRTH_TELEPORT";
    readonly TELE_GROUP_WATERBIRTH: "TELE_GROUP_WATERBIRTH";
    readonly CURE_GROUP: "CURE_GROUP";
    readonly STAT_SPY: "STAT_SPY";
    readonly BARBARIAN_TELEPORT: "BARBARIAN_TELEPORT";
    readonly TELE_GROUP_BARBARIAN: "TELE_GROUP_BARBARIAN";
    readonly SPIN_FLAX: "SPIN_FLAX";
    readonly SUPERGLASS_MAKE: "SUPERGLASS_MAKE";
    readonly TAN_LEATHER: "TAN_LEATHER";
    readonly KHAZARD_TELEPORT: "KHAZARD_TELEPORT";
    readonly TELE_GROUP_KHAZARD: "TELE_GROUP_KHAZARD";
    readonly DREAM: "DREAM";
    readonly STRING_JEWELLERY: "STRING_JEWELLERY";
    readonly STAT_RESTORE_POT_SHARE: "STAT_RESTORE_POT_SHARE";
    readonly MAGIC_IMBUE: "MAGIC_IMBUE";
    readonly FERTILE_SOIL: "FERTILE_SOIL";
    readonly BOOST_POTION_SHARE: "BOOST_POTION_SHARE";
    readonly FISHING_GUILD_TELEPORT: "FISHING_GUILD_TELEPORT";
    readonly TELE_GROUP_FISHING_GUILD: "TELE_GROUP_FISHING_GUILD";
    readonly PLANK_MAKE: "PLANK_MAKE";
    readonly CATHERBY_TELEPORT: "CATHERBY_TELEPORT";
    readonly TELE_GROUP_CATHERBY: "TELE_GROUP_CATHERBY";
    readonly RECHARGE_DRAGONSTONE: "RECHARGE_DRAGONSTONE";
    readonly ICE_PLATEAU_TELEPORT: "ICE_PLATEAU_TELEPORT";
    readonly TELE_GROUP_ICE_PLATEAU: "TELE_GROUP_ICE_PLATEAU";
    readonly ENERGY_TRANSFER: "ENERGY_TRANSFER";
    readonly HEAL_OTHER: "HEAL_OTHER";
    readonly VENGEANCE_OTHER: "VENGEANCE_OTHER";
    readonly VENGEANCE: "VENGEANCE";
    readonly HEAL_GROUP: "HEAL_GROUP";
    readonly SPELLBOOK_SWAP: "SPELLBOOK_SWAP";
    // Arceuus spellbook
    readonly ARCEUUS_HOME_TELEPORT: "ARCEUUS_HOME_TELEPORT";
    readonly ARCEUUS_LIBRARY_TELEPORT: "ARCEUUS_LIBRARY_TELEPORT";
    readonly BASIC_REANIMATION: "BASIC_REANIMATION";
    readonly DRAYNOR_MANOR_TELEPORT: "DRAYNOR_MANOR_TELEPORT";
    readonly BATTLEFRONT_TELEPORT: "BATTLEFRONT_TELEPORT";
    readonly MIND_ALTAR_TELEPORT: "MIND_ALTAR_TELEPORT";
    readonly RESPAWN_TELEPORT: "RESPAWN_TELEPORT";
    readonly GHOSTLY_GRASP: "GHOSTLY_GRASP";
    readonly RESURRECT_LESSER_GHOST: "RESURRECT_LESSER_GHOST";
    readonly RESURRECT_LESSER_SKELETON: "RESURRECT_LESSER_SKELETON";
    readonly RESURRECT_LESSER_ZOMBIE: "RESURRECT_LESSER_ZOMBIE";
    readonly SALVE_GRAVEYARD_TELEPORT: "SALVE_GRAVEYARD_TELEPORT";
    readonly ADEPT_REANIMATION: "ADEPT_REANIMATION";
    readonly INFERIOR_DEMONBANE: "INFERIOR_DEMONBANE";
    readonly SHADOW_VEIL: "SHADOW_VEIL";
    readonly FENKENSTRAINS_CASTLE_TELEPORT: "FENKENSTRAINS_CASTLE_TELEPORT";
    readonly DARK_LURE: "DARK_LURE";
    readonly SKELETAL_GRASP: "SKELETAL_GRASP";
    readonly RESURRECT_SUPERIOR_GHOST: "RESURRECT_SUPERIOR_GHOST";
    readonly RESURRECT_SUPERIOR_SKELETON: "RESURRECT_SUPERIOR_SKELETON";
    readonly RESURRECT_SUPERIOR_ZOMBIE: "RESURRECT_SUPERIOR_ZOMBIE";
    readonly MARK_OF_DARKNESS: "MARK_OF_DARKNESS";
    readonly WEST_ARDOUGNE_TELEPORT: "WEST_ARDOUGNE_TELEPORT";
    readonly LESSER_CORRUPTION: "LESSER_CORRUPTION";
    readonly HARMONY_ISLAND_TELEPORT: "HARMONY_ISLAND_TELEPORT";
    readonly VILE_VIGOUR: "VILE_VIGOUR";
    readonly DEGRIME: "DEGRIME";
    readonly CEMETERY_TELEPORT: "CEMETERY_TELEPORT";
    readonly EXPERT_REANIMATION: "EXPERT_REANIMATION";
    readonly WARD_OF_ARCEUUS: "WARD_OF_ARCEUUS";
    readonly RESURRECT_GREATER_GHOST: "RESURRECT_GREATER_GHOST";
    readonly RESURRECT_GREATER_SKELETON: "RESURRECT_GREATER_SKELETON";
    readonly RESURRECT_GREATER_ZOMBIE: "RESURRECT_GREATER_ZOMBIE";
    readonly RESURRECT_CROPS: "RESURRECT_CROPS";
    readonly UNDEAD_GRASP: "UNDEAD_GRASP";
    readonly DEATH_CHARGE: "DEATH_CHARGE";
    readonly DARK_DEMONBANE: "DARK_DEMONBANE";
    readonly BARROWS_TELEPORT: "BARROWS_TELEPORT";
    readonly DEMONIC_OFFERING: "DEMONIC_OFFERING";
    readonly GREATER_CORRUPTION: "GREATER_CORRUPTION";
    readonly APE_ATOLL_TELEPORT_ARCEUUS: "APE_ATOLL_TELEPORT_ARCEUUS";
    readonly MASTER_REANIMATION: "MASTER_REANIMATION";
    readonly SUPERIOR_DEMONBANE: "SUPERIOR_DEMONBANE";
    readonly SINISTER_OFFERING: "SINISTER_OFFERING";
  };
  const Rune: {
    readonly AIR: 556;
    readonly WATER: 555;
    readonly EARTH: 557;
    readonly FIRE: 554;
    readonly MIND: 558;
    readonly BODY: 559;
    readonly DEATH: 560;
    readonly NATURE: 561;
    readonly CHAOS: 562;
    readonly LAW: 563;
    readonly COSMIC: 564;
    readonly BLOOD: 565;
    readonly SOUL: 566;
    readonly ASTRAL: 9075;
    readonly WRATH: 21880;
    readonly MIST: 4695;
    readonly MUD: 4696;
    readonly DUST: 4697;
    readonly STEAM: 4698;
    readonly LAVA: 4699;
    readonly SMOKE: 4701;
    readonly SUNFIRE: 28929;
    readonly AETHER: 30843;
  };

  /** Action category for humaniser reaction timing. */
  type ActionCategory =
    | 'CLICK_WIDGET'
    | 'INTERACT_NPC'
    | 'INTERACT_OBJECT'
    | 'WALK'
    | 'PRAYER_SWITCH'
    | 'EAT_DRINK'
    | 'EQUIP'
    | 'DROP'
    | 'DIALOGUE'
    | 'SPELL_CAST'
    | 'BANK_OP'
    | 'CUSTOM';

  const ActionCategory: {
    readonly CLICK_WIDGET: 'CLICK_WIDGET';
    readonly INTERACT_NPC: 'INTERACT_NPC';
    readonly INTERACT_OBJECT: 'INTERACT_OBJECT';
    readonly WALK: 'WALK';
    readonly PRAYER_SWITCH: 'PRAYER_SWITCH';
    readonly EAT_DRINK: 'EAT_DRINK';
    readonly EQUIP: 'EQUIP';
    readonly DROP: 'DROP';
    readonly DIALOGUE: 'DIALOGUE';
    readonly SPELL_CAST: 'SPELL_CAST';
    readonly BANK_OP: 'BANK_OP';
    readonly CUSTOM: 'CUSTOM';
  };
}


declare namespace obsidian {

  // ── Root-level: Logging ──
  /** Log a message to the Plugin Maker console. Accepts variadic arguments. */
  function log(...args: any[]): void;
  // ── Root-level: Lifecycle ──
  /** Register a callback invoked when the script starts. */
  function onStart(fn: () => void): void;
  /** Register a callback invoked when the script stops. */
  function onStop(fn: () => void): void;
  // ── Root-level: Events ──
  /** Subscribe to a game event. Callback is called each time the event fires. */
  function on<K extends keyof EventMap>(event: K, callback: (e: EventMap[K]) => void): void;
  // ── Root-level: Overlay Registration ──
  /** Register an overlay callback. Returns a handle for unregistration. */
  function registerOverlay(fn: () => void): number;
  function unregisterOverlay(handle: number): void;
  /**
   * Terminate THIS script. The stop is deferred until the current handler /
   * overlay / tick callback returns, so it's safe to call from anywhere
   * (including inside the callback that calls it). Your `onStop` handler still
   * runs, and the editor reflects the script as stopped. Code after this call in
   * the same callback continues to execute until the callback returns.
   */
  function stopScript(): void;
  /**
   * Create a new overlay panel. Use render("TOP_LEFT") for managed positioning,
   * or render(x, y) for manual.
   */
  function panel(): Panel;

  namespace client {
    function gameState(): number;
    function gameCycle(): number;
    function gameTick(): number;
    /**
     * Ironman mode of the account: 0=normal,1=ironman,2=hardcore,3=ultimate,
     * 4=group,5=hardcore group,6=unranked group. Compare with obsidian.AccountType.
     */
    function accountType(): number;
    /** True if the ACCOUNT is subscribed — independent of the current world's type. */
    function isMembersAccount(): boolean;
    /** True if the current WORLD is a members world (same as world.isMembers()). */
    function isMembersWorld(): boolean;
    /** Raw native worldType bitmask (bit0=MEMBERS). */
    function worldType(): number;
    function world(): number;
    function plane(): number;
    function baseX(): number;
    /**
     * Loaded scene dimensions in tiles (standard = 104×104; instances/extended
     * scenes may differ). Falls back to 104×104 before the first tick.
     */
    function sceneSize(): { width: number; height: number };
    function baseY(): number;
    /** World tile → scene tile (0..103) of the loaded scene, using the live base. */
    function worldToScene(worldX: number, worldY: number): ScenePoint;
    /** worldToScene for a WorldPoint. */
    function worldToScene(point: WorldPoint): ScenePoint;
    /**
     * Scene tile → world tile using the live base. Plane defaults to the current
     * plane. Only meaningful for the scene loaded NOW — inside an instance the
     * base moves between visits, so keep the scene offset and convert on use.
     */
    function sceneToWorld(sceneX: number, sceneY: number, plane?: number): WorldPoint;
    /** sceneToWorld for a ScenePoint (current plane). */
    function sceneToWorld(point: ScenePoint): WorldPoint;
    /**
     * Fine-local point (128 units per tile) → the world tile it falls in, using
     * the live base. Plane defaults to the current plane. Same caveat as
     * sceneToWorld. Lets an actor's `localLocation` chain into any world-tile API.
     */
    function localToWorld(localX: number, localY: number, plane?: number): WorldPoint;
    /** localToWorld for a LocalPoint (current plane). */
    function localToWorld(point: LocalPoint): WorldPoint;
    /** World tile → fine-local point at the tile's centre. */
    function worldToLocal(worldX: number, worldY: number): LocalPoint;
    /** worldToLocal for a WorldPoint. */
    function worldToLocal(point: WorldPoint): LocalPoint;
    /**
     * Fine-local point → the TEMPLATE world tile: the real-map tile this spot of
     * the instance was copied from, resolved through instanceTemplateChunks
     * (RuneLite WorldPoint.fromLocalInstance). Constant for a given instance
     * type regardless of where the server placed it or how the chunk is rotated,
     * so it is the form to persist. Outside an instance it equals localToWorld.
     */
    function fromLocalInstance(localX: number, localY: number, plane?: number): WorldPoint;
    /** fromLocalInstance for a LocalPoint (current plane). */
    function fromLocalInstance(point: LocalPoint): WorldPoint;
    /**
     * World tile of the loaded scene → its template world tile (see
     * fromLocalInstance). Use on any `location` read this session to get the
     * persistent form; walk back to it later with movement.walkToTemplate.
     */
    function worldToTemplate(x: number, y: number, plane?: number): WorldPoint;
    /** worldToTemplate for a WorldPoint. */
    function worldToTemplate(point: WorldPoint): WorldPoint;
    /**
     * Template world tile → every place it occurs in the current instance, as
     * world tiles of the loaded scene (a template chunk can be copied more than
     * once; RuneLite WorldPoint.toLocalInstance). Outside an instance, or when
     * the tile is not in the loaded scene, returns the input unchanged.
     */
    function toLocalInstance(x: number, y: number, plane?: number): WorldPoint[];
    /** toLocalInstance for a WorldPoint. */
    function toLocalInstance(point: WorldPoint): WorldPoint[];
    function isInInstance(): boolean;
    /** Loaded map region IDs (up to 4). */
    function mapRegions(): number[];
    /**
     * RuneLite-packed instanceTemplateChunks, flat [plane*169 + chunkX*13 + chunkY]
     * (4*13*13 = 676 entries). Each value is the packed chunk (-1 = void); decode:
     * rotation = v>>1 & 0x3; srcChunkY = v>>3 & 0x7FF; srcChunkX = v>>14 & 0x3FF;
     * srcPlane = v>>24 & 0x3. Empty array when not in an instance.
     */
    function instanceTemplateChunks(): number[];
    function mouseCanvas(): { x: number; y: number };
    function varp(id: number): number;
    /** 64-bit varp (v241+), e.g. GE offer-setup price = varpLong(5753). */
    function varpLong(id: number): number;
    function varbit(id: number): number;
    /** VarClient integer value by id, or -1 if unset. */
    function varcInt(id: number): number;
    /** VarClient 64-bit value (v241 long varcs), or -1 if unset. */
    function varcLong(id: number): number;
    /** VarClient string value by id, or "" if unset. */
    function varcStr(id: number): string;
    function setVarcInt(id: number, value: number): void;
    function setVarcStr(id: number, value: string): void;
    function setVarbit(id: number, value: number): void;
    function skillLevel(skill: number): number;
    function boostedLevel(skill: number): number;
    function skillXp(skill: number): number;
    function runEnergy(): number;
    function isBankOpen(): boolean;
    function isShopOpen(): boolean;
    function isTradeOpen(): boolean;
    /** Get items in a container. 93=Inventory, 94=Equipment, 95=Bank. Default is 93. */
    function containerItems(containerId?: number): ContainerItem[];
    function hasItem(id: number, qty?: number): boolean;
    function countItem(id: number): number;
    function addChatMessage(type: number, sender: string, message: string): void;
    /** Account hash as a decimal string (exceeds 2^53 — a JS number would lose precision). */
    function accountHash(): string;
    function accountName(): string;
    function actionBudget(): number;
    function hasPendingActions(): boolean;
    function health(): HealthInfo;
    function prayer(): PrayerInfo;
    function isPoisoned(): boolean;
    function specPercent(): number;
    function regionId(): number;
    function canvasWidth(): number;
    function canvasHeight(): number;
    /** World tile currently under the mouse cursor. */
    function mouseTile(): WorldPoint;
    /** Packed group id of the active top-level interface. */
    function topLevelInterface(): number;
    /** Request a clean logout. */
    function logout(): void;
    function minimizeWindow(): void;
    function mouseIdleTicks(): number;
    function keyboardIdleTicks(): number;
    function weight(): number;
    function loginIndex(): number;
    function isFocused(): boolean;
  }

  namespace localPlayer {
    /** True when a local player is available (logged in). */
    function exists(): boolean;
    /** Get the full local player info object, or null when not logged in. */
    function get(): LocalPlayerInfo | null;
    /** Get the local player's world coordinates. */
    function worldLocation(): WorldPoint;
    /**
     * Interpolated fine-local position (128 units per tile; drifts each render
     * frame mid-step). Feed straight into movement.walkToLocal or client.localToWorld.
     */
    function localLocation(): LocalPoint;
    /**
     * Server tile as a scene offset (0..103) of the loaded scene — the value to
     * store for fixed-layout instances and replay with movement.walkToScene.
     */
    function sceneLocation(): ScenePoint;
    function isIdle(): boolean;
    /** True if currently targeting another entity. */
    function isInteracting(): boolean;
    /** The actor being targeted, or null when idle / target left the scene. */
    function getInteracting(): InteractingTarget | null;
  }

  namespace npcs {
    /** Find all NPCs in the scene. */
    function findAll(): NpcInfo[];
    /** Find NPCs by definition ID. */
    function find(id: number): NpcInfo[];
    /** Find NPCs by name. */
    function findByName(name: string): NpcInfo[];
    /** Find the nearest NPC by definition ID. */
    function findNearest(id: number): NpcInfo | null;
    /** Find the nearest NPC by name. */
    function findNearestByName(name: string): NpcInfo | null;
    /** Find nearest alive, non-interacting NPC by name. */
    function findNearestAlive(name: string): NpcInfo | null;
    /**
     * Interact with an NPC by slot index.
     * @param index NPC slot index from NpcInfo.index.
     * @param optionOrAction Option number (1-5) or action string (e.g. "Attack").
     */
    function interact(index: number, optionOrAction: number | string): void;
    function interactByAction(index: number, menuAction: number): void;
    /** Find nearest alive non-interacting NPC by name and perform an action. */
    function interactNearest(name: string, action: string): boolean;
    /** Attack the nearest alive non-interacting NPC by name. */
    function attack(name: string): boolean;
    /** Check if an NPC with the given name exists in the scene. */
    function exists(name: string): boolean;
    function useItemOn(itemSlot: number, itemId: number, npcIndex: number, delayTicks?: number): void;
    function castSpellOn(packedWidgetId: number, npcIndex: number, delayTicks?: number): void;
    function handle(index: number): EntityHandle;
    function resolveHandle(handle: EntityHandle): NpcInfo | null;
    function isHandleValid(handle: EntityHandle): boolean;
    /** The actor this NPC is targeting (use NpcInfo.index), or null. */
    function getInteracting(npcIndex: number): InteractingTarget | null;
    /** Start a fluent query over all NPCs in the scene. */
    function query(): NpcQuery;
  }

  namespace objects {
    /** Find all game objects in the scene. (game objects only; for other types use findAllWall/Decorative) */
    function findAll(): ObjectInfo[];
    /** Find objects by definition ID — searches ALL types (game + wall + decorative + ground). */
    function find(id: number): ObjectInfo[];
    /** Find objects by name — searches ALL types (game + wall + decorative + ground). */
    function findByName(name: string): ObjectInfo[];
    /** Find the nearest object by definition ID — searches ALL types (game + wall + decorative + ground). */
    function findNearest(id: number): ObjectInfo | null;
    /** Find the nearest object by name — searches ALL types (game + wall + decorative + ground). */
    function findNearestByName(name: string): ObjectInfo | null;
    /**
     * Interact with a scene object.
     * @param id Object definition ID.
     * @param optionOrAction Option number (1-5) or action string.
     * @param worldX World X coordinate.
     * @param worldY World Y coordinate.
     */
    function interact(id: number, optionOrAction: number | string, worldX: number, worldY: number): void;
    function interactByAction(id: number, action: string, worldX: number, worldY: number): boolean;
    /** Find nearest object by name and perform an action. */
    function interactNearest(name: string, action: string): boolean;
    /** Check if an object with the given name exists in the scene. */
    function exists(name: string): boolean;
    /** Find nearest object by name. */
    function findNearestAlive(name: string): ObjectInfo | null;
    function useItemOn(itemSlot: number, itemId: number, objectId: number, worldX: number, worldY: number, delayTicks?: number): void;
    function castSpellOn(packedWidgetId: number, objectId: number, worldX: number, worldY: number, delayTicks?: number): void;
    function findAllWall(): ObjectInfo[];
    function findWall(id: number): ObjectInfo[];
    function findWallByName(name: string): ObjectInfo[];
    function findNearestWall(id: number): ObjectInfo | null;
    function findNearestWallByName(name: string): ObjectInfo | null;
    function findAllDecorative(): ObjectInfo[];
    function findDecorative(id: number): ObjectInfo[];
    function findDecorativeByName(name: string): ObjectInfo[];
    function findNearestDecorative(id: number): ObjectInfo | null;
    function findNearestDecorativeByName(name: string): ObjectInfo | null;
    /** Every ground object in the scene. */
    function findAllGround(): ObjectInfo[];
    /** All ground objects with the given definition ID. */
    function findGround(id: number): ObjectInfo[];
    function findNearestGround(id: number): ObjectInfo | null;
    /**
     * Start a fluent query over scene objects. You MUST call id() or nameEquals()
     * before a terminal — there is no unfiltered object scan.
     */
    function query(): ObjectQuery;
  }

  namespace players {
    function findAll(): PlayerInfo[];
    function findByName(name: string): PlayerInfo[];
    function findNearest(): PlayerInfo | null;
    function findNearestByName(name: string): PlayerInfo | null;
    /**
     * Interact with a player by right-click option: its number (1..8) or its
     * text (case-insensitive, e.g. "Attack", "Follow", "Trade with"). Returns
     * false if the text matches no current option (see options()).
     */
    function interact(index: number, option: number | string): boolean;
    /**
     * The client's player right-click options: 8 entries, entry i is option
     * i+1, "" where unset. Server-set per area (e.g. "Attack" only in PvP).
     */
    function options(): string[];
    /**
     * Interact with the nearest player matching `name` by option number or text
     * (same as interact()).
     */
    function interactNearest(name: string, option: number | string): boolean;
    function handle(index: number): EntityHandle;
    /** The actor this player is targeting (use PlayerInfo.index), or null. */
    function getInteracting(playerIndex: number): InteractingTarget | null;
    /** Start a fluent query over all players in the scene. */
    function query(): PlayerQuery;
  }

  namespace groundItems {
    /**
     * Interact with the nearest reachable ground item matching `name` whose
     * item definition has `action` as a ground action (e.g. "Take", "Light").
     * Same-named items lacking the action are skipped.
     */
    function interactNearest(name: string, action: string): boolean;
    function findAll(): GroundItemInfo[];
    /** Find ground items by ID, or all visible ground items if no ID given. */
    function find(id?: number): GroundItemInfo[];
    function findByName(name: string): GroundItemInfo[];
    function findNearest(id: number): GroundItemInfo | null;
    function findNearestByName(name: string): GroundItemInfo | null;
    function pickup(id: number, sceneX: number, sceneY: number): void;
    function pickupNearest(itemId: number): boolean;
    function pickupNearestByName(name: string): boolean;
    /** Start a fluent query over all visible ground items. */
    function query(): GroundItemQuery;
  }

  namespace movement {
    /**
     * Walk to absolute world coordinates — a single click-to-walk on the loaded
     * scene (no pathfinding; use walker.walkTo for cross-region travel). Works
     * inside instances for any tile read THIS session; the instance base moves
     * between visits, so never persist an in-instance world tile — store the
     * scene offset (walkToScene) or the template tile (walkToTemplate) instead.
     */
    function walkTo(x: number, y: number): boolean;
    /** Walk to a WorldPoint — the `location` of any NPC/player/object/item. */
    function walkTo(point: WorldPoint): boolean;
    /**
     * Walk to a scene tile (0..103) of the CURRENTLY loaded scene, resolved
     * against the live base at call time. This is the instance-safe form for
     * fixed-layout instances: the same scene offset lands on the same spot
     * every visit, whatever world base the server allocated.
     */
    function walkToScene(sceneX: number, sceneY: number): boolean;
    /** Walk to a scene tile given as a ScenePoint (e.g. localPlayer.sceneLocation()). */
    function walkToScene(point: ScenePoint): boolean;
    /**
     * Walk to the tile containing a fine-local point (128 units per tile) —
     * pass an actor's `localLocation` straight in. Scene-relative like
     * walkToScene, so it works identically in any instance placement.
     */
    function walkToLocal(localX: number, localY: number): boolean;
    /** Walk to the tile containing a LocalPoint (e.g. npc.localLocation). */
    function walkToLocal(point: LocalPoint): boolean;
    /**
     * Walk to a TEMPLATE world tile — the real-map tile the instance was copied
     * from (what client.fromLocalInstance / worldToTemplate return). Resolves
     * every occurrence of that tile in the current instance, prefers the nearest
     * reachable one, and walks there. Survives chunk rotation, so this is the
     * form to persist across visits. Outside an instance it is plain walkTo.
     * Plane defaults to the current plane.
     */
    function walkToTemplate(x: number, y: number, plane?: number): boolean;
    /** Walk to a template WorldPoint (see the numeric form). */
    function walkToTemplate(point: WorldPoint): boolean;
    /** True if the world tile can be stood on. Plane defaults to the current plane. */
    function isWalkable(x: number, y: number, plane?: number): boolean;
    /** isWalkable for a WorldPoint. */
    function isWalkable(point: WorldPoint): boolean;
    /**
     * True if a path exists from the player to the world tile (8-directional
     * flood-fill of the live collision map). The flood fill always runs on the
     * current plane's map; plane is accepted but not used to reject a target
     * (bridge objects report the plane above), same as C++ can_reach.
     */
    function canReach(x: number, y: number, plane?: number): boolean;
    /** canReach for a WorldPoint. */
    function canReach(point: WorldPoint): boolean;
    /** All tiles reachable from the local player via flood-fill of the collision map. */
    function reachableTiles(): WorldPoint[];
    /** Unblocked tiles within `radius` (default 5) of the given center tile. */
    function walkableTiles(x: number, y: number, plane: number, radius?: number): WorldPoint[];
    /** Nearest reachable tile from a candidate list, or null if none reachable. */
    function closestReachableTile(tiles: WorldPoint[]): WorldPoint | null;
    /** Clear any queued synthetic-movement commands. */
    function clearSynthQueue(): void;
    /**
     * Raw collision bitfield for a world tile from the live native collision map
     * (updated each game tick). Returns 0xFFFFFFFF if the tile is outside the
     * loaded scene. Decode with the {@link CollisionFlag} constants.
     * A tile on another plane than the player's reads as off-scene (only the
     * current plane's map is live). Plane defaults to the current plane.
     */
    function collisionFlag(x: number, y: number, plane?: number): number;
    /** collisionFlag for a WorldPoint. */
    function collisionFlag(point: WorldPoint): number;
    /**
     * Line of sight between two tiles (RuneLite WorldArea.hasLineOfSightTo) over
     * the live collision map — any two tiles in the loaded scene, not only from
     * the local player. False when either tile is off-scene, the tiles are on
     * different planes or not the current plane, or the areas overlap (RuneLite
     * rule: a tile has no line of sight to itself). `opts` sizes the source /
     * target footprints (e.g. a large NPC's size as fromWidth/fromHeight; the
     * point is its SW tile).
     */
    function hasLineOfSight(fromX: number, fromY: number, toX: number, toY: number, plane?: number, opts?: { fromWidth?: number; fromHeight?: number; toWidth?: number; toHeight?: number }): boolean;
    /** hasLineOfSight between two WorldPoints. */
    function hasLineOfSight(from: WorldPoint, to: WorldPoint, opts?: { fromWidth?: number; fromHeight?: number; toWidth?: number; toHeight?: number }): boolean;
    /**
     * True iff a single step between two ADJACENT tiles is possible right now,
     * honouring directional walls/doors and diagonal corner rules. Unlike
     * reachableTiles()/canReach(), this does NOT path around obstacles — use it to
     * tell whether a wall sits between you and a neighbouring tile (e.g. dodging
     * boss mechanics). Returns false if the tiles aren't adjacent.
     */
    function canStep(fromX: number, fromY: number, toX: number, toY: number): boolean;
    /**
     * Decoded collision flags for a world tile — the ergonomic form of
     * collisionFlag(). Returns null if the tile is outside the loaded scene.
     */
    function tileFlags(x: number, y: number, plane?: number): TileCollision | null;
    /** tileFlags for a WorldPoint. */
    function tileFlags(point: WorldPoint): TileCollision | null;
    /** True if a world tile cannot be stood on (solid/object). Inverse of isWalkable. */
    function isBlocked(x: number, y: number, plane?: number): boolean;
    function pathCost(fromX: number, fromY: number, toX: number, toY: number): number;
    function interactionCostNpc(npcIndex: number): number;
    function interactionCostObject(objectId: number, sceneX: number, sceneY: number): number;
  }

  namespace magic {
    /** Check if the player can cast a spell (level + runes + quest). */
    function canCast(spellName: string): boolean;
    /** Inventory slot of a staff that, wielded, would make the spell castable (-1: castable already / none helps). */
    function staffFor(spellName: string): number;
    /** Check if the player has the magic level for a spell. */
    function hasLevel(spellName: string): boolean;
    /** Count available runes of a type (inventory + rune pouch + combo runes + staff/tome). Returns INT32_MAX if staff provides. */
    function runeCount(runeItemId: number): number;
    /** Check if the player has at least qty of a rune type. */
    function hasRunes(runeItemId: number, qty: number): boolean;
    /** Check if the player is currently autocasting. */
    function isAutocasting(): boolean;
    /** Check if a spell is currently selected for targeting. */
    function isSpellSelected(): boolean;
    /** Get the current spellbook (0=Standard, 1=Ancient, 2=Lunar, 3=Arceuus). */
    function spellbook(): number;
    /**
     * Cast a spell by name. Every spellName arg accepts the obsidian.Spell key
     * ("ICE_BARRAGE") or the display name ("Ice Barrage"), case-insensitive.
     */
    function cast(spellName: string): void;
    /** Cast a spell on an NPC. delayTicks (default 1) defers the target click a tick; 0 sends spell + target in the same frame. */
    function castOnNpc(spellName: string, npcIndex: number, delayTicks?: number): void;
    /** Cast a spell on a player. */
    function castOnPlayer(spellName: string, playerId: number, delayTicks?: number): void;
    /** Cast a spell on a scene object. */
    function castOnObject(spellName: string, objectId: number, sceneX: number, sceneY: number): void;
    /** Cast a spell on an inventory item. */
    function castOnItem(spellName: string, itemSlot: number, itemId: number): void;
    /** Cast a spell on a ground item. */
    function castOnGroundItem(spellName: string, itemId: number, sceneX: number, sceneY: number): void;
    /** Select a spell for use-on targeting. */
    function selectSpell(spellName: string): void;
  }

  namespace camera {
    function x(): number;
    function y(): number;
    function z(): number;
    function yaw(): number;
    function pitch(): number;
    function targetX(): number;
    function targetY(): number;
  }

  namespace definitions {
    function item(id: number): ItemDefinition | null;
    function npc(id: number): NpcDefinition | null;
    function object(id: number): ObjectDefinition | null;
    function enumDef(id: number): EnumDefinition | null;
    function structDef(id: number): StructDefinition | null;
  }

  namespace plugins {
    function list(): Array<{ key: string; name: string; version: string; author: string; enabled: boolean }>;
    /**
     * Enable or disable a host plugin (by `key` from list()) in this tab. Applied on
     * the next host frame, so list() still shows the old state until then.
     * @returns false if this tab has no plugin with that key.
     */
    function setEnabled(key: string, enabled: boolean): boolean;
    /**
     * This script's own entry in the list() shape. Scripts aren't host plugins:
     * key/name are the script name, version/author are empty, enabled is true.
     */
    function self(): { key: string; name: string; version: string; author: string; enabled: boolean } | null;
  }

  namespace shared {
    /** Value stored under `key` in the store shared by every tab, or null. */
    function get(key: string): string | null;
    /**
     * Store a string (JSON.stringify objects) visible to scripts in every tab. Fires
     * `sharedChanged` in every script of every tab (including this one) if it changed.
     */
    function set(key: string, value: string): void;
    function keys(): string[];
  }

  namespace login {
    /**
     * Fill the login form for a regular (non-Jagex) account. Applied by the client
     * on the login screen (waits there if logged in). Jagex accounts unsupported.
     */
    function setCredentials(username: string, password: string): boolean;
    /** Submit the login form (~1s after setCredentials). False unless on the login screen. */
    function submit(): boolean;
    /** True while the authenticator (6-digit code) screen is showing. */
    function isAuthenticatorScreen(): boolean;
    /**
     * Enter and submit a 6-digit authenticator code; `trust` (default true) ticks
     * "trust this computer for 30 days". False unless on the authenticator screen
     * and the code is 6 digits. A wrong code comes back to the same screen.
     */
    function submitOtp(code: string, trust?: boolean): boolean;
  }

  namespace logs {
    function recent(count?: number): Array<{ timestamp: number; level: number; module: string; message: string }>;
  }

  namespace world {
    function getWorld(): number;
    function hopTo(worldId: number): void;
    function isMembers(): boolean;
    /** Every world on the server list, with its type flags. */
    function getWorldList(): WorldInfo[];
    /**
     * Last ICMP round-trip to a world's server in ms, or -1 if not measured yet /
     * unreachable. Never blocks: a missing or >30s-old reading starts a background
     * ping, so call again ~1s later (e.g. poll on gameTick) for a fresh value.
     */
    function ping(worldId: number): number;
    function isWorldSwitcherOpen(): boolean;
    function openWorldSwitcher(): void;
    function isInPoh(): boolean;
  }

  namespace dialogue {
    function isOpen(): boolean;
    /** Continue/advance the current dialogue. Named continue_ to avoid JS reserved word. */
    function continue_(): void;
    function selectOption(indexOrText: number | string): boolean;
    function type(): number;
    function text(): string;
    function name(): string;
    function options(): string[];
    function enterText(text: string): void;
    function enterNumber(num: number): void;
  }

  namespace make {
    function isOpen(): boolean;
    function products(): number[];
    function offers(itemId: number): boolean;
    function select(itemId: number): boolean;
    function selectSlot(slot: number): boolean;
    function setQuantity(qty: number): boolean;
    function quantity(): number;
    function make(itemId: number, qty: number): boolean;
  }

  namespace depositBox {
    function isOpen(): boolean;
    function depositInventory(): boolean;
    function depositAll(itemId: number): boolean;
    function close(): boolean;
  }

  namespace tabs {
    function current(): number;
    function isOpen(tab: number): boolean;
    function keyFor(tab: number): number;
    function open(tab: number, method?: number): boolean;
    function hoverSkill(skill: number): boolean;
    function glanceStart(cfg: { skill?: number; method?: number; settleMin?: number; settleMax?: number; holdMin?: number; holdMax?: number; returnMin?: number; returnMax?: number; neighbourChance?: number; equipmentChance?: number; timeoutTicks?: number }): boolean;
    function glanceActive(): boolean;
    function glanceFinish(): void;
    function glanceCancel(): void;
  }

  namespace widgets {
    function isGroupLoaded(groupId: number): boolean;
    function get(groupId: number, childId: number): WidgetInfo | null;
    /** Packed-id form: packedId = (groupId << 16) | childId. */
    function get(packedId: number): WidgetInfo | null;
    function getDynamicChildren(groupId: number, childId: number): WidgetInfo[];
    /** Packed-id form: packedId = (groupId << 16) | childId. */
    function getDynamicChildren(packedId: number): WidgetInfo[];
    function getChild(groupId: number, childId: number, childIndex: number): WidgetInfo | null;
    /** Packed-id form: packedId = (groupId << 16) | childId. */
    function getChild(packedId: number, childIndex: number): WidgetInfo | null;
    function findByText(groupId: number, text: string): WidgetInfo[];
    function click(slot: number, groupId: number, childId: number, actionIndex: number): boolean;
    /** Packed-id form: packedId = (groupId << 16) | childId. */
    function click(slot: number, packedId: number, actionIndex: number): boolean;
    function clickItem(slot: number, groupId: number, childId: number, actionIndex: number, itemId: number): boolean;
    /** Packed-id form: packedId = (groupId << 16) | childId. */
    function clickItem(slot: number, packedId: number, actionIndex: number, itemId: number): boolean;
    function screenPos(groupId: number, childId: number): { x: number; y: number; width: number; height: number } | null;
    /** Packed-id form: packedId = (groupId << 16) | childId. */
    function screenPos(packedId: number): { x: number; y: number; width: number; height: number } | null;
    function setText(groupId: number, childId: number, text: string): void;
    /** Packed-id form: packedId = (groupId << 16) | childId. */
    function setText(packedId: number, text: string): void;
    /** Create a dynamic child widget on a parent (parent must be Type LAYER=0). Index -1 appends. */
    function createChild(parentPackedId: number, index: number, type: number): void;
    /** Delete all dynamic children of a widget. */
    function deleteAllChildren(parentPackedId: number): void;
    /** Set dynamic child hidden state. */
    function setChildHidden(parentPackedId: number, childIndex: number, hidden: boolean): void;
    /** Set dynamic child sprite ID. */
    function setChildSprite(parentPackedId: number, childIndex: number, spriteId: number): void;
    /** Set dynamic child position. */
    function setChildPosition(parentPackedId: number, childIndex: number, x: number, y: number): void;
    /** Set dynamic child size. */
    function setChildSize(parentPackedId: number, childIndex: number, width: number, height: number): void;
    /** Set dynamic child text. */
    function setChildText(parentPackedId: number, childIndex: number, text: string): void;
    /** Set dynamic child color (RGB). */
    function setChildColor(parentPackedId: number, childIndex: number, rgb: number): void;
    /** Set dynamic child opacity (0-255). */
    function setChildOpacity(parentPackedId: number, childIndex: number, opacity: number): void;
    /** Set dynamic child right-click action. */
    function setChildAction(parentPackedId: number, childIndex: number, actionSlot: number, text: string): void;
    /** Set dynamic child item display. */
    function setChildItem(parentPackedId: number, childIndex: number, itemId: number, quantity: number): void;
  }

  namespace hintArrow {
    function set(x: number, y: number, plane: number): void;
    function setNpc(index: number): void;
    function clear(): void;
  }

  namespace menu {
    /**
     * Create a custom right-click menu entry.
     * If the last argument is a function, it's called when the entry is clicked
     * (no need to watch menuOptionClicked separately).
     */
    function createEntry( index: number, option: string, target: string, type?: number, identifier?: number, p0?: number, p1?: number, itemId?: number, onClick?: () => void ): void;
    /**
     * Remove all custom entries of the given type from the persistent
     * registry (entries created via createEntry stay until removed).
     */
    function removeEntries( type?: number ): void;
    /** Read current menu entries (available inside postMenuSort handler). */
    function getEntries(): Array<{ type: number; identifier: number; actionParam0: number; actionParam1: number; itemId: number; forceLeftClick: boolean; option: string; target: string; }>;
  }

  namespace interaction {
    function invokeAction(p0: number, p1: number, opType: number, identifier: number, itemId?: number, opts?: { skipClick?: boolean }): void;
    function useItemOnItem(sourceSlot: number, sourceItemId: number, targetSlot: number, targetItemId: number, delayTicks?: number): void;
    function openNearestBank(): boolean;
  }

  namespace projectiles {
    function findAll(): Array<{ id: number; startCycle: number; endCycle: number; /** Vertical slope/arc of the projectile. */ slope: number; startHeight: number; endHeight: number; /** Origin tile. */ startLocation: WorldPoint; /** Destination tile. */ targetLocation: WorldPoint; /** Slot index of the target actor (-1 if none). */ interactingIndex: number; /** Interpolated fine X position. */ x: number; /** Interpolated fine Y position. */ y: number; /** Interpolated height. */ z: number; }>;
  }

  namespace graphicsObjects {
    /** All active ground graphics objects (SpotAnims: campfires, spell impacts, etc.). */
    function findAll(): Array<{ id: number; sceneX: number; sceneY: number; localX: number; localY: number; height: number; startCycle: number; animFrame: number; animationId: number; plane: number; }>;
  }

  namespace grandExchange {
    /** All 8 Grand Exchange offer slots (empty slots have state 0). */
    function getOffers(): GeOffer[];
  }

  namespace walker {
    function walkTo(x: number, y: number, plane?: number): boolean;
    function walkToBank(): boolean;
    function stop(): void;
    function isWalking(): boolean;
    function calculatePath(x: number, y: number, plane?: number): Array<{ x: number; y: number; plane: number }>;
    /** The live path currently being followed (empty when idle). */
    function currentPath(): Array<{ x: number; y: number; plane: number }>;
    /** Per-call routing. Omitted flags inherit the tab's walker settings. */
    function walkToOpts(x: number, y: number, plane?: number, options?: WalkOptions): boolean;
    /** Why a walk stalled — the pathfinder's own explanation. */
    function status(): string;
    function statusOk(): boolean;
    function isCalculating(): boolean;
    function isLoading(): boolean;
    function pathStep(): number;
    function destination(): { x: number; y: number; plane: number };
    /**
     * Which transports the live route intends to use, in order. A
     * teleport leads the list with kind 100.
     */
    function pathTransports(): PathTransport[];
    /**
     * The teleport the route opens with, or null. Same hop that leads
     * pathTransports(), with cost + POH/minigame detail.
     */
    function pendingTeleport(): PendingTeleport | null;
    function loadedTransportCount(): number;
  }

  namespace actions {
    function pending(): number;
    function droppedCount(): number;
    function capacity(): number;
    function clientAttached(): boolean;
    function queueHealthy(): boolean;
  }

  namespace breaks {
    /** Register this script as a break consumer (by a stable name). configurable=false hides it from the panel editor. */
    function registerConsumer(name: string, configurable?: boolean): void;
    function unregisterConsumer(name: string): void;
    function isRegistered(name: string): boolean;
    /** Start a session: begins the play timer and schedules the first break. */
    function startSession(name: string): void;
    function stopSession(name: string): void;
    /** True once a scheduled break is due — call startBreak at a safe point. */
    function shouldBreak(name: string): boolean;
    /** True while a break is active — gate all your actions on this being false. */
    function isBreakActive(name: string): boolean;
    function startBreak(name: string): void;
    function breakNow(name: string): void;
    /** Set timing ranges in MINUTES: play-before-break [from,to], break duration [from,to]. */
    function setTiming(name: string, thresholdFrom: number, thresholdTo: number, breakFrom: number, breakTo: number): void;
    /** Logout policy: mode 0=Never (AFK), 1=Always, 2=Random(percent). */
    function setLogoutMode(name: string, mode: number, percent?: number): void;
    function setExtraData(name: string, key: string, value: string): void;
    function enabled(): boolean;
    function totalBreaksTaken(): number;
    function requestLogin(): boolean;
  }

  namespace humaniser {
    /** Get reaction delay in game ticks for a given action category. */
    function reactionTicks(category?: ActionCategory): number;
    /** Get reaction delay in milliseconds for sub-tick granularity. */
    function reactionMs(category?: ActionCategory): number;
    /** Get inter-action delay in milliseconds for multi-step sequences. */
    function interActionMs(): number;
    /** Current fatigue level (0.0 = fresh, 1.0 = exhausted). */
    function fatigueLevel(): number;
    /** True if the humaniser suggests a micro-AFK pause right now. */
    function shouldMicroAfk(): boolean;
    /** Random tick delay with center-biased distribution. */
    function randomTicks(min: number, max: number): number;
    /** Random integer biased toward the center of the range. */
    function randomWeighted(min: number, max: number): number;
    /** Reset the humaniser session (clears fatigue, learning curves, etc.). */
    function resetSession(): void;
    /** Manually set fatigue level (0.0-1.0). */
    function setFatigue(level: number): void;
  }

  namespace inventory {
    function getItemAt(slot: number): ContainerItem;
    function getAll(): ContainerItem[];
    function findSlot(itemId: number): number;
    function freeSlots(): number;
    function usedSlots(): number;
    function isEmpty(): boolean;
    function isFull(): boolean;
    function hasSpace(): boolean;
    function count(itemId: number): number;
    function contains(itemId: number, qty?: number): boolean;
    function interact(slot: number, actionIndex: number): void;
    function drop(slot: number): boolean;
    function eat(itemId: number): boolean;
    function drink(itemId: number): boolean;
    function use(itemId: number, action: string): boolean;
    function interactItem(itemId: number, action: string): void;
    function interactItemByName(itemName: string, action: string): void;
    function eatFood(): boolean;
    function drinkPrayerPot(): boolean;
    function drinkStaminaPot(): boolean;
    function drinkAntipoison(): boolean;
    function drinkAntifire(): boolean;
    /** Return every inventory slot index holding the given item id. */
    function findAllSlots(itemId: number): number[];
    /** True if the inventory contains at least one of every listed item id. */
    function containsAll(itemIds: number[]): boolean;
    /** True if the inventory contains any of the listed item ids. */
    function containsAny(itemIds: number[]): boolean;
  }

  namespace equipment {
    /** Get equipped item by slot enum. Slots: 0=Head, 1=Cape, 2=Amulet, 3=Weapon, 4=Body, 5=Shield, 7=Legs, 9=Gloves, 10=Boots, 12=Ring, 13=Ammo. */
    function getItem(slot: number): ContainerItem;
    function getAll(): ContainerItem[];
    function isWearing(itemId: number): boolean;
    function interact(itemId: number, action: string): void;
    function interactByName(itemName: string, action: string): void;
    /** Equipped weapon (slot 3), or an empty item if none. */
    function weapon(): ContainerItem;
    /** Equipped shield (slot 5). */
    function shield(): ContainerItem;
    /** Equipped helm (slot 0). */
    function head(): ContainerItem;
    /** Equipped body (slot 4). */
    function body(): ContainerItem;
    /** Equipped legs (slot 7). */
    function legs(): ContainerItem;
  }

  namespace bank {
    function deposit(slot: number, action?: string): boolean;
    function depositInventory(): boolean;
    function depositEquipment(): boolean;
    /** Withdraw by item id, or by name (case-insensitive; skips placeholders). */
    function withdraw(itemIdOrName: number | string, action?: string): boolean;
    function withdrawX(itemId: number, quantity: number): boolean;
    function depositX(slot: number, quantity: number): boolean;
    function size(): number;
    function close(): void;
    function isOpen(): boolean;
    /** Walk to and open the nearest bank booth/chest. */
    function open(): boolean;
    /**
     * Guard every bank read with this — with the bank shut, getAll()/count()/
     * contains() answer from a persisted snapshot, not the live bank.
     */
    function isCached(): boolean;
    function cacheAgeSeconds(): number;
    function contains(itemId: number, qty?: number): boolean;
    function count(itemId: number): number;
    function getAll(): ContainerItem[];
  }

  namespace combat {
    function toggleSpec(): boolean;
    function enableSpec(): boolean;
    function disableSpec(): boolean;
    function isSpecEnabled(): boolean;
    function togglePrayer(prayerId: number): boolean;
    /**
     * Idempotent prayer setters — no-op returning true when already in
     * the requested state; enabling at 0 prayer points returns false.
     */
    function setPrayer(prayerId: number, enabled: boolean): boolean;
    function enablePrayer(prayerId: number): boolean;
    function disablePrayer(prayerId: number): boolean;
    function toggleQuickPrayers(): boolean;
    /** Quick-prayer state + idempotent setter (clicks the prayer orb). */
    function isQuickPrayersActive(): boolean;
    function setQuickPrayers(enabled: number): boolean;
    function isPrayerActive(prayerId: number): boolean;
    function isProtectionPrayerActive(): boolean;
    function toggleRun(): boolean;
    function setRun(enabled: number): boolean;
    function isRunEnabled(): boolean;
    function attackStyle(): number;
    /**
     * Select an attack style (0-3). REQUIRES THE COMBAT TAB TO BE OPEN —
     * returns false if it is closed or the weapon has no such style.
     */
    function setAttackStyle(style: number): boolean;
    /** Both retaliate toggles require the combat tab to be open. */
    function toggleAutoRetaliate(): boolean;
    function setAutoRetaliate(enabled: number): boolean;
    function getSpellbook(): number;
    function isInMulti(): boolean;
    function isVenomed(): boolean;
    function isSkulled(): boolean;
    function isInWilderness(): boolean;
    function wildernessLevel(): number;
    function hasStaminaEffect(): boolean;
    function hasAntifire(): boolean;
    function hasSuperAntifire(): boolean;
    function isInCombat(): boolean;
    function interactingIndex(): number;
    /** Toggle a prayer by display name (e.g. "Protect from Melee"). */
    function togglePrayerByName(name: string): boolean;
    /** True if auto-retaliate is enabled. */
    function isAutoRetaliate(): boolean;
    /** True if immune to poison (antipoison active). */
    function isPoisonImmune(): boolean;
    /** True if diseased. */
    function isDiseased(): boolean;
    /** True if the prayer-regeneration potion effect is active. */
    function hasPrayerRegen(): boolean;
    /** True if the goading potion effect is active. */
    function hasGoading(): boolean;
    /** True if the imbued heart cooldown is active. */
    function hasImbuedHeartEffect(): boolean;
    /** True if the saturated heart cooldown is active. */
    function hasSaturatedHeartEffect(): boolean;
    /** True if any heart effect (imbued or saturated) is active. */
    function hasHeartEffect(): boolean;
  }

  namespace skill {
    /** Display name of a skill id (e.g. "Attack"). */
    function name(skill: number): string;
    /** True for members-only skills. */
    function isMembers(skill: number): boolean;
    /** Total XP required to reach a level (1-99). */
    function xpForLevel(level: number): number;
    /** Level for a given total XP. */
    function levelForXp(xp: number): number;
    /** XP remaining until the next level. */
    function xpToNextLevel(currentXp: number): number;
  }

  namespace quest {
    /** Quest state: 0=NOT_STARTED, 1=IN_PROGRESS, 2=FINISHED. */
    function state(questId: number): number;
    function isComplete(questId: number): boolean;
    /** Look up a quest id by display name (case-sensitive). Returns -1 if not found. */
    function findId(name: string): number;
  }

  namespace highlight {
    function npcOn(npcId: number, creationCycle: number, channel: number): void;
    function npcOff(npcId: number, channel: number): void;
    function tileOn(worldX: number, worldY: number, channel: number): void;
    function tileOff(worldX: number, worldY: number, channel: number): void;
    function objectOn(objectId: number, worldX: number, worldY: number, channel: number): void;
    function objectOff(objectId: number, worldX: number, worldY: number, channel: number): void;
    /**
     * Configure a highlight channel.
     * @param category 0=NPC, 1=NPC_TYPE, 2=OBJ, 3=OBJ_TYPE, 4=TILE, 5=PLAYER
     * @param channel Channel ID.
     * @param colorRgb 0xRRGGBB color.
     * @param outlineWidth Outline width (default 2).
     */
    function configure(category: number, channel: number, colorRgb: number, outlineWidth?: number): void;
    function getNpcCreationCycle(npcIndex: number): number;
  }

  namespace itemHelpers {
    function hasPickaxe(): boolean;
    function hasPickaxeInBank(): boolean;
    function hasAxe(): boolean;
    function hasAxeInBank(): boolean;
    function hasBow(): boolean;
    function hasBowInBank(): boolean;
    function hasCrossbow(): boolean;
    function hasCrossbowInBank(): boolean;
    function hasHarpoon(): boolean;
    function hasHarpoonInBank(): boolean;
    function hasMetalArrows(): boolean;
    function hasMetalArrowsInBank(): boolean;
    function hasAntipoison(): boolean;
    function hasAntipoisonInBank(): boolean;
    function hasAntivenom(): boolean;
    function hasAntivenomInBank(): boolean;
    function hasStaminaPotion(): boolean;
    function hasStaminaPotionInBank(): boolean;
    function hasPrayerPotion(): boolean;
    function hasPrayerPotionInBank(): boolean;
    function hasSuperRestore(): boolean;
    function hasSuperRestoreInBank(): boolean;
  }

  namespace config {
    function get(key: string, defaultValue?: string): string;
    function set(key: string, value: string): void;
    function remove(key: string): void;
    function getAll(): Record<string, string>;
    function define(items: ConfigItemDef[]): void;
  }

  namespace panel {
    /**
     * Send a JSON-serialisable value to the panel (obsidianPanel.onMessage).
     * Dropped silently if the panel window is closed.
     */
    function post(data: any): void;
    function isOpen(): boolean;
    function open(): void;
    function close(): void;
  }

  namespace keyboard {
    /** Send a virtual key. mode: 0=press+release (default), 1=down, 2=up. */
    function sendKey(vkCode: number, mode?: number): void;
    /** Type a string character-by-character through the synthetic keyboard. */
    function typeString(text: string): void;
  }

  namespace mouseSynth {
    /** Enable (non-zero) or disable (0) synthetic mouse movement for interactions. */
    function setEnabled(enabled: number): void;
    function isEnabled(): boolean;
    /**
     * Run a callback whose actions skip the synthetic mouse move/click: every action
     * queued inside fn (invokeAction and the interact helpers built on it) is sent
     * bypassed. Same as invokeAction(..., { skipClick: true }). Returns false if fn threw.
     */
    function bypass(fn: () => void): boolean;
    function moveTo(x: number, y: number): void;
    function moveToWidget(groupId: number, childId: number): void;
  }

  namespace overlay {
    /** Draw a tile highlight at scene coordinates. */
    function drawTile(sceneX: number, sceneY: number, fill: number, outline: number, thickness?: number): void;
    /** Draw text at a local tile position. */
    function drawText(localX: number, localY: number, text: string, color: number, heightOffset?: number): void;
    /** Draw a line between two local positions. */
    function drawLine(localX1: number, localY1: number, localX2: number, localY2: number, color: number, thickness?: number): void;
    /** Highlight an NPC tile by slot index. */
    function drawNpcTile(npcIndex: number, fill: number, outline: number, thickness?: number): void;
    /** Highlight a player tile by slot index. */
    function drawPlayerTile(playerIndex: number, fill: number, outline: number, thickness?: number): void;
    /** Draw text at screen coordinates. */
    function drawTextScreen(x: number, y: number, text: string, color: number): void;
    /** Draw a rectangle outline at screen coordinates. */
    function drawRectScreen(x: number, y: number, w: number, h: number, color: number, thickness?: number): void;
    /** Draw a filled rectangle at screen coordinates. */
    function drawRectFilledScreen(x: number, y: number, w: number, h: number, color: number): void;
    /** Highlight a multi-tile actor area at local fine coordinates. */
    function drawActorHighlight(localX: number, localY: number, size: number, fill: number, outline: number): void;
    /** Highlight a world tile (current plane). Colors are ImGui-style ABGR (0xAABBGGRR); fill/outline with 0 alpha are skipped. */
    function drawTileAt(worldX: number, worldY: number, fill: number, outline: number, thickness?: number): void;
    /** Outline a footprint of `sizeX`×`sizeY` tiles anchored at a tile (current plane). */
    function drawObjectBounds(tileX: number, tileY: number, sizeX: number, sizeY: number, fill: number, outline: number, thickness?: number): void;
    /** Draw text floating above a world tile (current plane). heightOffset in model units (0=ground, 200=head height). */
    function drawTextAtTile(worldX: number, worldY: number, text: string, color: number, heightOffset?: number): void;
    /** Draw a bobbing arrow above a world tile (current plane). `heightOffset` raises it. */
    function drawArrowWorld(worldX: number, worldY: number, color: number, heightOffset?: number): void;
    function drawNpcHull(npcIndex: number, fill: number, outline: number, thickness?: number): void;
    function drawNpcClickbox(npcIndex: number, fill: number, outline: number, thickness?: number): void;
    function drawNpcClickboxHover(npcIndex: number, fill: number, outline: number, hoverFill: number, hoverOutline: number, thickness?: number): void;
    function drawNpcOutline(npcIndex: number, color: number, thickness: number, glow?: number): void;
    function drawNpcTileTrue(npcIndex: number, fill: number, outline: number, thickness?: number): void;
    /** Hull overlay on all NPCs with the given composition ID. */
    function drawNpcHullById(npcId: number, fill: number, outline: number, thickness?: number): void;
    /** Clickbox overlay on all NPCs with the given composition ID. */
    function drawNpcClickboxById(npcId: number, fill: number, outline: number, thickness?: number): void;
    /** Tile overlay on all NPCs with the given composition ID. */
    function drawNpcTileById(npcId: number, fill: number, outline: number, thickness?: number): void;
    /** True-tile overlay on all NPCs with the given composition ID. */
    function drawNpcTileTrueById(npcId: number, fill: number, outline: number, thickness?: number): void;
    /** GPU outline on all NPCs with the given composition ID. */
    function drawNpcOutlineById(npcId: number, color: number, thickness: number, glow?: number): void;
    /** Model hull overlay on all scene objects with the given definition ID. */
    function drawObjectHull(objectId: number, fill: number, outline: number, thickness?: number): void;
    function drawPlayerTileTrue(playerIndex: number, fill: number, outline: number, thickness?: number): void;
    function drawLineScreen(x1: number, y1: number, x2: number, y2: number, color: number, thickness?: number): void;
    function getTileHeight(sceneX: number, sceneY: number): number;
    function fillFromOutline(outlineColor: number, alpha: number): number;
    function worldToScreen(localX: number, localY: number, plane: number): { x: number; y: number } | null;
  }
}
