HELLO OBSIDIAN - JAVASCRIPT STARTER

1. Put this complete hello-obsidian folder inside:
   %USERPROFILE%\.obsidian\scripts\
2. Edit index.js in your code editor and save it.
3. In Obsidian, open Plugin Maker, select Scripts, click Rescan, and enable Hello Obsidian.
4. Check the Plugin Maker console for: My first plugin is running!

Files:
- index.js: your JavaScript code.
- package.json: script name and entry point.
- obsidian.d.ts: the supplied JavaScript API reference; do not run it as a script.

Start small, use the declared obsidian API, and test each change.
This example only logs a greeting; it performs no game actions.
The reference was supplied on 12 October 2026 and is not automatically updated.
This package was checked for JavaScript syntax and exercised against a mocked logging/lifecycle API, not run in a live Obsidian client.
