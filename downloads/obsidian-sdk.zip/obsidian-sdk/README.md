# Obsidian Plugin Development — C++

Write Obsidian plugins in C++. Your plugin compiles to a `.dll` that the host loads
through its sealed API, so you get the full game surface without touching the host's
internals.

## What's in this kit

```
obsidian-sdk/
  include/          the SDK headers — #include <obsidian/...>
  lib/              obsidian_sdk.lib — link against this
  template/         a minimal starter plugin — copy this to begin
  README.md         this file
```

The `template` plugin does one thing — prints a configurable greeting when you log in —
so you can see the whole shape of a plugin at a glance, then replace its body with your
own. Everything below shows how to reach further into the API.

## Quick Start

1. **Prerequisites**: Visual Studio 2022 (or Build Tools) and CMake 3.20+, with MSVC
   toolset **v14.40** installed — the exact version matters, see
   [Matching the host's toolset](#matching-the-hosts-toolset).
2. **Copy the template**: duplicate `template/` to your workspace. Keep the SDK folder
   around — the template's `CMakeLists.txt` points `OBSIDIAN_SDK_DIR` back at it.
3. **Write your plugin** in `src/my_plugin.cpp` (see below).
4. **Build**:
   ```
   cmake -B build -G "Visual Studio 17 2022" -A x64 -T version=14.40
   cmake --build build --config Release
   ```
   The build auto-copies the `.dll` to your plugins folder
   (`%USERPROFILE%\.obsidian\plugins\`) — no manual step.
5. **Run**: launch Obsidian. A sidebar entry appears; enable it.

### Requirements

- The **developer flag** must be enabled on your Obsidian account (contact an admin).
- Build in **Release** (or RelWithDebInfo) — a debug core build is unstable against the
  live client.
- Link the **dynamic CRT** (`/MD`) — CMake's default. The SDK lib is built `/MD`; a
  static-CRT plugin won't link.
- Build with MSVC toolset **v14.40** — the version this host was built
  with. A plugin built with any other version (older *or* newer) compiles fine but is
  refused at load. See [Matching the host's toolset](#matching-the-hosts-toolset).

## Using your IDE

The project is plain CMake, so any CMake-aware IDE works. The one hard rule is the
**compiler**, not the editor: you must build with **MSVC toolset
v14.40** — not MinGW/Clang/GCC, and not a different MSVC version
either (see the next section). The host stamps every plugin with a toolchain
fingerprint and rejects any mismatched build — it will compile but won't load.

- **Visual Studio 2022** — `File → Open → Folder` and pick the plugin folder. It detects
  `CMakeLists.txt` and configures automatically. VS defaults to its *latest* installed
  toolset — if that isn't v14.40, set the toolset version in
  *Project → CMake Settings* (or use a CMakePresets.json with
  `"toolset": "version=14.40"`).
- **CLion** — open the folder, then in *Settings → Build, Execution, Deployment →
  Toolchains* select the **Visual Studio** toolchain. CLion defaults to MinGW on Windows,
  which builds a DLL the host won't load — this step is required.
- **VS Code** — install the *CMake Tools* and *C/C++* extensions, open the folder, and when
  prompted for a kit choose **"Visual Studio 2022 - amd64"** (not a MinGW/Clang kit).

From a terminal it's just:

```
cmake -B build -A x64 -T version=14.40
cmake --build build --config Release
```

## Matching the host's toolset

A native C++ plugin passes STL types (`std::string`, `std::vector`, …) across the DLL
boundary, so the host only loads plugins built with its **exact** compiler — a layout
mismatch there would be silent memory corruption, so it is checked up front instead.

This kit's host was built with MSVC toolset **v14.40**
(cl 19.40.33812.0). To build with it:

1. **Install it** (it coexists with newer toolsets): Visual Studio Installer → *Modify* →
   *Individual components* → search "14.40" and tick the
   **MSVC v143 … (v14.40)** side-by-side build tools.
2. **Select it**: pass `-T version=14.40` when configuring (the Quick
   Start command already does), or set the equivalent toolset option in your IDE.

If the versions don't match, your plugin builds fine but the host refuses to load it and
logs `toolchain fingerprint 0x… != host 0x… — refusing to load` in the Log window. A
host update may move to a newer toolset — the README in each SDK kit always states the
version that host requires.

## Plugin structure

Subclass `obsidian::sdk::Plugin`, override the hooks you need, and declare the three
export functions the host looks for. This is the whole template:

```cpp
#include <obsidian/sdk/plugin.h>
#include <obsidian/api/client.h>

namespace client = obsidian::api::client;
namespace api = obsidian::api;

class MyPlugin : public obsidian::sdk::Plugin {
public:
    bool on_start() override {
        // GameState 30 = LOGGED_IN. Print a message each time we log in.
        subscribe<api::GameStateChangedEvent>([](const api::GameStateChangedEvent& e) {
            if (e.new_state == 30)
                client::add_chat_message(0, "", "My Plugin started!");
        });
        return true;
    }
    void on_stop() override {}   // subscriptions + overlays are cleaned up for you
};

// The host resolves these by name when it loads your DLL.
OBSIDIAN_PLUGIN_EXPORT obsidian::sdk::PluginInfo get_plugin_info() {
    return { "my_plugin", "My Plugin", "A starter plugin.", "1.0", "your-name" };
}
OBSIDIAN_PLUGIN_EXPORT obsidian::sdk::Plugin* create_plugin() { return new MyPlugin(); }
OBSIDIAN_PLUGIN_EXPORT void destroy_plugin(obsidian::sdk::Plugin* p) { delete p; }

OBSIDIAN_DECLARE_PLUGIN_ABI()
```

## The API

Each domain is a namespace under `obsidian::api`. Include the header you need and call it:

```cpp
namespace client       // game state, varps/varbits, world/account type, chat, scripts
namespace local_player // your player's position, animation, stats
namespace npcs         // scene NPCs — find_all / find / find_nearest
namespace players      // other players
namespace objects      // scene objects (game / wall / decoration / ground)
namespace ground_items // items on the floor
namespace inventory    // your inventory; also equipment, bank
namespace combat       // hp, prayer, special, target
namespace magic        // spellbook, cast helpers
namespace walker       // pathing: walk_to, is_walking
namespace movement     // low-level movement
namespace interaction  // menu-action invocation
namespace dialogue     // NPC dialogue
namespace quest        // quest state
namespace world        // world list, hop, members world
namespace definitions  // item / npc / object defs
namespace menu         // add custom right-click entries
```

For example, walk somewhere and read state:

```cpp
#include <obsidian/api/world.h>
#include <obsidian/api/walker.h>

if (world::is_members_world())                        // members WORLD?
    walker::walk_to({3164, 3478, 0});                 // Grand Exchange

bool members_account = client::is_members_account();  // account subscribed?
int  account_type    = client::account_type();        // 0=normal, 1=ironman, …
```

## Events

Subscribe inside `on_start`. Subscriptions unsubscribe automatically on `on_stop`, so
there's no bookkeeping.

```cpp
subscribe<api::GameTickEvent>([](const auto& e) { /* e.tick_count */ });
subscribe<api::NpcSpawnedEvent>([](const auto& e) { /* e.npc */ });
subscribe<api::HitsplatAppliedEvent>([](const auto& e) { /* e.actor, e.hitsplat */ });
subscribe<api::VarbitChangedEvent>([](const auto& e) { /* e.varp_id, e.new_value */ });
subscribe<api::StatChangedEvent>([](const auto& e) { /* e.skill, e.new_level */ });
subscribe<api::MenuOptionClickedEvent>([](const auto& e) { /* e.menu_action */ });
```

Every event type is in `include/obsidian/api/events.h` — spawns/despawns, animation,
combat, containers, GE, game state, and more.

## Overlays

Subclass `api::Overlay`, draw in `render`, and register it in `on_start` with
`register_overlay(&overlay_)` (the plugin owns the object):

```cpp
#include <obsidian/api/overlay.h>
#include <obsidian/api/npcs.h>
#include <obsidian/api/local_player.h>

class MyOverlay : public api::Overlay {
    void render(api::OverlayContext& ctx) override {
        ctx.render_tile_at(local_player::world_location(), 0x3000FF00, 0xFF00FF00);
        for (auto& npc : npcs::find_all())
            ctx.render_npc_tile(npc, 0x3000FFFF, 0xFF00FFFF);   // ARGB fill, outline
    }
};
```

## Panels

Override `has_custom_panel()` to return `true` and build a sidebar panel with a
`PanelBuilder` (labels, key/value rows, progress bars, item rows, buttons). See
`include/obsidian/api/panel.h` for the builder API.

## Config

Subclass `sdk::Config`, declare your settings with the `OBS_CFG_*` macros, and expose it
through `config()` / `config_mut()`. The host renders it in the plugin's config (cog) UI
and persists each value; read a value straight off the member.

```cpp
class MyConfig : public obsidian::sdk::Config {
public:
    bool enabled = true;                              // also: int, std::string, colour
    const char* group() const override { return "my_plugin"; }
    const std::vector<obsidian::sdk::ConfigItemDesc>& items() const override {
        static const std::vector<obsidian::sdk::ConfigItemDesc> k = {
            OBS_CFG_BOOL(MyConfig, enabled, "Enabled"),
        };
        return k;
    }
};

// in your plugin:
const obsidian::sdk::Config* config() const override { return &cfg_; }
obsidian::sdk::Config* config_mut() override { return &cfg_; }
// ... read it: if (cfg_.enabled) { ... }
```

`config.h` has the full macro set: `OBS_CFG_BOOL / INT / SLIDER / STRING / COLOR`.

## ABI compatibility

`OBSIDIAN_DECLARE_PLUGIN_ABI()` stamps your DLL with an ABI version and a toolchain
fingerprint, and the host rejects a plugin built against an incompatible SDK or a
mismatched compiler. This kit's host requires MSVC toolset
**v14.40** (see [Matching the host's
toolset](#matching-the-hosts-toolset)). If your plugin fails to load after a host update,
rebuild it against the new SDK kit — its README states the toolset that host requires.
