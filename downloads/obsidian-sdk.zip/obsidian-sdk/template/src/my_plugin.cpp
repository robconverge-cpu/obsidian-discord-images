/// @file my_plugin.cpp
/// @brief Minimal Obsidian plugin — copy this and start building.
///
/// It does one thing: prints a configurable greeting to the chatbox when you log in.
/// That's the whole plugin. Add your own logic in the marked spots.
///
/// Build:   cmake -B build -G "Visual Studio 17 2022" -A x64
///          cmake --build build --config Release
/// Install: the .dll auto-copies to %USERPROFILE%\.obsidian\plugins\ on build.
/// Requires: the developer flag enabled on your Obsidian account.

#include <obsidian/sdk/plugin.h>
#include <obsidian/api/client.h>

namespace {

namespace client = obsidian::api::client;
namespace api = obsidian::api;

// ── Config ────────────────────────────────────────────────────────────────
// One setting: a greeting string. The host renders it in the plugin's config UI and
// persists it. OBS_CFG_STRING wires the member to a persisted key of the same name;
// config.h has the rest (OBS_CFG_BOOL / INT / SLIDER / COLOR).
class MyConfig : public obsidian::sdk::Config {
public:
    std::string greeting = "Hello, world!";

    const char* group() const override { return "my_plugin"; }
    const std::vector<obsidian::sdk::ConfigItemDesc>& items() const override {
        static const std::vector<obsidian::sdk::ConfigItemDesc> k = {
            OBS_CFG_STRING(MyConfig, greeting, "Greeting"),
        };
        return k;
    }
};

class MyPlugin : public obsidian::sdk::Plugin {
public:
    bool on_start() override {
        // Print the greeting each time we finish logging in. GameState 30 = LOGGED_IN.
        subscribe<api::GameStateChangedEvent>([this](const api::GameStateChangedEvent& e) {
            if (e.new_state == 30) {
                client::add_chat_message(0, "", "My Plugin says: " + cfg_.greeting);
            }
        });
        return true;
    }

    // Persistence needs both accessors.
    const obsidian::sdk::Config* config() const override { return &cfg_; }
    obsidian::sdk::Config* config_mut() override { return &cfg_; }

private:
    MyConfig cfg_;
};

} // anonymous namespace

// ── Plugin exports (the host looks for these by name) ───────────────────────
OBSIDIAN_PLUGIN_EXPORT obsidian::sdk::PluginInfo get_plugin_info() {
    return {
        "my_plugin",              // key — unique, snake_case
        "My Plugin",              // display name
        "A minimal example.",     // description
        "1.0",                    // version
        "Your Name",              // author
    };
}

OBSIDIAN_PLUGIN_EXPORT obsidian::sdk::Plugin* create_plugin() { return new MyPlugin(); }
OBSIDIAN_PLUGIN_EXPORT void destroy_plugin(obsidian::sdk::Plugin* p) { delete p; }

OBSIDIAN_DECLARE_PLUGIN_ABI()
