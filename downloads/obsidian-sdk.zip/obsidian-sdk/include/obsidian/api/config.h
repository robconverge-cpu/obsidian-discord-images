#pragma once
/// @file config.h
/// @brief Plugin configuration access — persistent key/value storage via host IPC.
/// @ingroup core
// ═══════════════════════════════════════════════════════════════════════════
// CONFIG API — Plugin configuration access (core-side)
// ═══════════════════════════════════════════════════════════════════════════
// Plugins call config_get/config_set to read/write persistent settings.
// The actual storage is on the host side (JSON file). Reads are synchronous
// (blocking until the host responds).
//
// Usage in plugins:
//   std::string val = api::config::get("my_plugin", "highlight_color", "#FF0000");
//   api::config::set("my_plugin", "highlight_color", "#00FF00");
// ═══════════════════════════════════════════════════════════════════════════

#include <string>
#include <cstdint>

namespace obsidian::api::config {

/// Returns a stored config value, or @p default_value if not found.
/// @note Blocks briefly while waiting for the host to respond over IPC.
std::string get(const std::string& group, const std::string& key,
                const std::string& default_value = "");

/// Persists a config value. The host writes it to its JSON store.
void set(const std::string& group, const std::string& key,
         const std::string& value);

/// Convenience integer getter — parses the stored string value.
int get_int(const std::string& group, const std::string& key, int default_value = 0);

/// Convenience boolean getter — treats "true"/"1" as true, anything else as false.
bool get_bool(const std::string& group, const std::string& key, bool default_value = false);

} // namespace obsidian::api::config
