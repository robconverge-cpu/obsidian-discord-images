#pragma once
/// @file perspective.h
/// @brief World-to-screen projection, minimap conversion, and tile corner helpers.
/// @ingroup scene
// ═══════════════════════════════════════════════════════════════════════════
// PERSPECTIVE — World-to-screen projection and 3D tile math
// ═══════════════════════════════════════════════════════════════════════════
// Mirrors RuneLite's Perspective.java utility class.
// Uses the native client's camera state and projection math for accurate
// world-to-screen conversion. `local_to_canvas` reproduces the game's
// canonical projection so plugins can project a point without crossing the
// SEH boundary into game code.
// ═══════════════════════════════════════════════════════════════════════════


#include <obsidian/api/coords.h>
#include <cstdint>
#include <optional>
#include <cmath>
#include <vector>

namespace obsidian::api {

/// A 2D screen-space coordinate. x/y == -1 indicates an off-screen or clipped point.
struct ScreenPoint {
    int32_t x = -1;
    int32_t y = -1;
    /// True if the point is on-screen (both coordinates >= 0).
    bool valid() const { return x >= 0 && y >= 0; }
};

/// Pure projection utilities — no function hooking required.
/// Camera state is read directly from the Client struct.
/// Mirrors RuneLite Perspective.java.
namespace perspective {

    // Sine/cosine tables (RuneLite Perspective.java SINE/COSINE)
    // OSRS uses 2048 entries, fixed-point with 16-bit fraction.
    constexpr int UNIT = 65536;
    constexpr int TABLE_SIZE = 2048;

    /// Fixed-point sine (16-bit fraction) for a JAU angle, matching the client's table.
    inline int32_t sin_table(int angle) {
        // Native client has the same sin/cos table at a fixed RVA.
        // For portability, compute inline (matches Java client exactly).
        double rad = (angle & (TABLE_SIZE - 1)) * (2.0 * 3.14159265358979323846 / TABLE_SIZE);
        return static_cast<int32_t>(std::sin(rad) * UNIT);
    }

    /// Fixed-point cosine (16-bit fraction) for a JAU angle, matching the client's table.
    inline int32_t cos_table(int angle) {
        double rad = (angle & (TABLE_SIZE - 1)) * (2.0 * 3.14159265358979323846 / TABLE_SIZE);
        return static_cast<int32_t>(std::cos(rad) * UNIT);
    }

    // Float versions (for model vertex rotation)
    /// Float sine for a JAU angle (for model vertex rotation).
    inline float sinf_table(int angle) {
        double rad = (angle & (TABLE_SIZE - 1)) * (2.0 * 3.14159265358979323846 / TABLE_SIZE);
        return static_cast<float>(std::sin(rad));
    }
    /// Float cosine for a JAU angle (for model vertex rotation).
    inline float cosf_table(int angle) {
        double rad = (angle & (TABLE_SIZE - 1)) * (2.0 * 3.14159265358979323846 / TABLE_SIZE);
        return static_cast<float>(std::cos(rad));
    }

    // ── World to screen projection ──────────────────────────────────
    // Equivalent to RuneLite's Perspective.localToCanvas().
    // Projects a local (fine) coordinate to screen space using camera state.
    //
    // Parameters read from Client struct:
    //   camera_x/y/z: Client+CameraX/Z/Y (note: Z is vertical in OSRS)
    //   camera_pitch/yaw: Client+CameraPitch/CameraYaw
    //   viewport_x/y/w/h: Client+ViewportX1/Y1/Width/Height
    //   viewport_scale: Client+ViewportScale
    //
    // Returns nullopt if the point is behind the camera or outside viewport.

    /// Snapshot of the camera registers needed for projection. Populate with CameraState::read().
    struct CameraState {
        int32_t x, y, z;          // camera position (fine coords)
        int32_t pitch, yaw;       // rotation
        int32_t vp_x, vp_y;      // viewport top-left (currently always 0)
        int32_t vp_width, vp_height;
        int32_t scale;            // SW renderer scale (ViewportHeight3D)
        int32_t rd_scale = 0;     // RenderDevice viewport scale
        int32_t center_x;         // Projection center X
        int32_t center_y;         // Projection center Y
        float zoom;               // render device zoom factor

        // ── Mesh path ───────────────────────────────────────────────────
        // The per-frame projection matrix the GPU/software mesh renderer
        // actually consumes. When `have_mesh_matrix` is true, prefer
        // local_to_canvas_mesh() / model_to_canvas_mesh() for pixel-perfect
        // alignment with the rendered mesh; the fixed-point local_to_canvas
        // path drifts a few pixels because it uses a different math path.
        bool      have_mesh_matrix = false;
        bool      nested_projection = false;  // true = use perspective divide (nested WorldView)
        float     mesh_matrix[16] = {};       // column-major float[16]
        int32_t   scene_origin_x = 0;
        int32_t   scene_origin_y = 0;         // height axis
        int32_t   scene_origin_z = 0;
        // The renderer's per-frame cached float sin/cos. The software
        // renderer uses these directly in float multiplies, so reading them
        // mirrors the renderer's exact rounding chain without sub-pixel
        // drift from the int sin_table approximation.
        bool  have_render_sincos = false;
        float sin_pitch_f = 0.f;
        float cos_pitch_f = 0.f;
        float sin_yaw_f   = 0.f;
        float cos_yaw_f   = 0.f;

    };

    /// Projects a local (fine-coord) position to screen space.
    /// Equivalent to RuneLite Perspective.localToCanvas().
    /// @return nullopt if the point is behind the camera or outside the viewport.
    inline std::optional<ScreenPoint> local_to_canvas(
        const CameraState& cam,
        int32_t local_x, int32_t local_y, int32_t height)
    {
        // Reproduces the game's canonical world->screen projection exactly.
        //   dx = localX - camX
        //   dz = localY - camY
        //   dy = height - camZ
        // then a yaw rotation followed by a pitch rotation (see below).

        int32_t dx = local_x - cam.x;
        int32_t dy = height - cam.z;
        int32_t dz = local_y - cam.y;

        int32_t sin_pitch = sin_table(cam.pitch);
        int32_t cos_pitch = cos_table(cam.pitch);
        int32_t sin_yaw = sin_table(cam.yaw);
        int32_t cos_yaw = cos_table(cam.yaw);

        // Yaw rotation: iVar7 = cos_yaw * dz - sin_yaw * dx >> 16
        int32_t yaw_rot = (cos_yaw * dz - sin_yaw * dx) >> 16;

        // Depth: iVar8 = cos_pitch * yaw_rot + sin_pitch * dy >> 16
        int32_t depth = (cos_pitch * yaw_rot + sin_pitch * dy) >> 16;

        if (depth < 50) return std::nullopt;

        double inv_depth = 1.0 / static_cast<double>(depth);
        double inv_zoom = (cam.zoom > 0.001f) ? (1.0 / static_cast<double>(cam.zoom)) : 1.0;

        // screenY component: scale * (cos_pitch * dy - sin_pitch * yaw_rot >> 16)
        int32_t vert = (cos_pitch * dy - sin_pitch * yaw_rot) >> 16;
        int32_t screen_y = static_cast<int32_t>(
            static_cast<double>(cam.scale * vert) * inv_depth * inv_zoom)
            + cam.center_y;

        // screenX component: scale * (cos_yaw * dx + sin_yaw * dz >> 16)
        int32_t horiz = (cos_yaw * dx + sin_yaw * dz) >> 16;
        int32_t screen_x = static_cast<int32_t>(
            static_cast<double>(cam.scale * horiz) * inv_depth * inv_zoom)
            + cam.center_x;

        return ScreenPoint{screen_x, screen_y};
    }

    // Convenience: project a LocalPoint at a given height
    inline std::optional<ScreenPoint> local_to_canvas(
        const CameraState& cam, const LocalPoint& lp, int32_t height)
    {
        return local_to_canvas(cam, lp.x, lp.y, height);
    }

    /// Projects a model-space vertex to screen coordinates.
    /// Applies the actor's orientation rotation first, then standard camera projection.
    /// @param cam          Camera state snapshot.
    /// @param model_x      Model-space X vertex coordinate.
    /// @param model_y      Model-space Y vertex coordinate (vertical axis).
    /// @param model_z      Model-space Z vertex coordinate.
    /// @param local_x      Actor's fine-coord X world position.
    /// @param local_y      Actor's fine-coord Y world position.
    /// @param height       Tile height at the actor's location.
    /// @param orientation  JAU angle (0–2047).
    inline std::optional<ScreenPoint> model_to_canvas(
        const CameraState& cam,
        int32_t model_x, int32_t model_y, int32_t model_z,
        int32_t local_x, int32_t local_y, int32_t height,
        int32_t orientation)
    {
        // Step 1: Rotate vertex by actor orientation
        float rot_sin = sinf_table(orientation);
        float rot_cos = cosf_table(orientation);
        float rx = static_cast<float>(model_x) * rot_cos + static_cast<float>(model_z) * rot_sin;
        float rz = static_cast<float>(model_z) * rot_cos - static_cast<float>(model_x) * rot_sin;

        // Step 2: Translate to world position (fine coords)
        int32_t world_x = local_x + static_cast<int32_t>(rx);
        int32_t world_y = local_y + static_cast<int32_t>(rz);
        int32_t world_h = height + model_y;  // model_y is height (negative = up in OSRS)

        // Step 3: Standard camera projection
        return local_to_canvas(cam, world_x, world_y, world_h);
    }

    // ── Software-path projection ─────────────────────────────────────
    // Mirrors the leaf per-vertex projection the software rasterizer
    // actually uses.
    //
    // It does INTEGER fixed-point math identical to local_to_canvas:
    //   yaw_rot = (cos_yaw_int * dz - sin_yaw_int * dx) >> 16
    //   depth   = (cos_pitch_int * yaw_rot + sin_pitch_int * dy) >> 16
    //   horiz   = (cos_yaw_int * dx + sin_yaw_int * dz) >> 16
    //   vert    = (cos_pitch_int * dy - sin_pitch_int * yaw_rot) >> 16
    //   sx      = (horiz * scale) / depth + center_x   -- INTEGER divide
    //   sy      = (vert  * scale) / depth + center_y
    //
    // Differences from the legacy local_to_canvas:
    //   1. Subtracts the captured scene origin (camera position at render
    //      time) instead of the live camera, which mixes next-frame state
    //      with this frame's render and produces rotation-dependent drift.
    //   2. Uses INTEGER divide to match the rasterizer, not float divide.
    //   3. No zoom division — the renderer's scale is already post-zoom.
    inline std::optional<ScreenPoint> local_to_canvas_sw(
        const CameraState& cam,
        int32_t local_x, int32_t local_y, int32_t height)
    {
        if (!cam.have_render_sincos) {
            return local_to_canvas(cam, local_x, local_y, height);
        }
        const int32_t dx = local_x - cam.scene_origin_x;
        const int32_t dy = height  - cam.scene_origin_y;
        const int32_t dz = local_y - cam.scene_origin_z;

        constexpr float SCALE = 65535.0f;
        const int32_t sin_pitch = static_cast<int32_t>(cam.sin_pitch_f * SCALE);
        const int32_t cos_pitch = static_cast<int32_t>(cam.cos_pitch_f * SCALE);
        const int32_t sin_yaw   = static_cast<int32_t>(cam.sin_yaw_f * SCALE);
        const int32_t cos_yaw   = static_cast<int32_t>(cam.cos_yaw_f * SCALE);

        const int32_t yaw_rot = (cos_yaw * dz - sin_yaw * dx) >> 16;
        const int32_t depth   = (cos_pitch * yaw_rot + sin_pitch * dy) >> 16;
        if (depth < 50) return std::nullopt;

        const int32_t horiz = (cos_yaw * dx + sin_yaw * dz) >> 16;
        const int32_t vert  = (cos_pitch * dy - sin_pitch * yaw_rot) >> 16;

        // Integer divide — matches the rasterizer exactly. No zoom div
        // because cam.scale already comes from the renderer's viewport
        // and is post-zoom.
        const int32_t screen_x = (horiz * cam.scale) / depth + cam.center_x;
        const int32_t screen_y = (vert  * cam.scale) / depth + cam.center_y;
        return ScreenPoint{screen_x, screen_y};
    }

    // ── Mesh-path projection ─────────────────────────────────────────
    // Uses the per-frame projection matrix that the GPU/software mesh
    // renderer actually consumes. This is what you want for pixel-perfect
    // overlay alignment with the rendered mesh — the local_to_canvas path
    // drifts ~10 px because it uses a different math path entirely. In
    // software mode (no float matrix), routes through local_to_canvas_sw
    // which mirrors the software rasterizer's math exactly.

    /// Mesh-path equivalent of local_to_canvas. Multiplies (world_x,
    /// height, world_y, 1) by the per-frame mesh matrix, perspective-
    /// divides, and maps to canvas pixels.
    inline std::optional<ScreenPoint> local_to_canvas_mesh(
        const CameraState& cam,
        int32_t local_x, int32_t local_y, int32_t height)
    {
        if (!cam.have_mesh_matrix) {
            // Software mode — use the renderer's exact float math.
            return local_to_canvas_sw(cam, local_x, local_y, height);
        }

        if (cam.nested_projection) {
            // Nested WorldView: the mesh matrix expects RAW local coords
            // (not origin-subtracted). The scene origin is in overworld
            // space for nested scenes, not in the nested scene's local
            // space. This matches RuneLite: projection.project(localX,
            // height, localY) with no origin subtraction.
            const float fx = static_cast<float>(local_x);
            const float fy = static_cast<float>(height);
            const float fz = static_cast<float>(local_y);
            const float* m = cam.mesh_matrix;
            const float cx = m[0]*fx + m[4]*fy + m[8] *fz + m[12];
            const float cy = m[1]*fx + m[5]*fy + m[9] *fz + m[13];
            const float cz = m[2]*fx + m[6]*fy + m[10]*fz + m[14];
            if (cz < 50.0f) return std::nullopt;
            // Use the stable per-tick viewport scale (cam.scale), not the
            // render-device scale (rd_scale) which flickers at close zoom.
            const float scale_f = static_cast<float>(cam.scale);
            const int32_t sx = cam.center_x + static_cast<int32_t>(cx * scale_f / cz);
            const int32_t sy = cam.center_y + static_cast<int32_t>(cy * scale_f / cz);
            return ScreenPoint{sx, sy};
        }

        // Overworld: subtract scene origin (camera position). The matrix's
        // translation column accounts for camera offset after subtraction;
        // the renderer's entity dispatch subtracts the scene origin from
        // raw entity coords before passing them through.
        const float fx = static_cast<float>(local_x - cam.scene_origin_x);
        const float fy = static_cast<float>(height  - cam.scene_origin_y);
        const float fz = static_cast<float>(local_y - cam.scene_origin_z);

        // Column-major 4x4 * (fx, fy, fz, 1)
        const float* m = cam.mesh_matrix;
        const float cx = m[0]*fx + m[4]*fy + m[8] *fz + m[12];
        const float cy = m[1]*fx + m[5]*fy + m[9] *fz + m[13];
        const float cz = m[2]*fx + m[6]*fy + m[10]*fz + m[14];
        const float cw = m[3]*fx + m[7]*fy + m[11]*fz + m[15];

        // Overworld: NDC projection (matrix produces clip-space coords)
        (void)cz;
        if (cw < 0.001f) return std::nullopt;
        const float inv_w = 1.0f / cw;
        const float ndc_x = cx * inv_w;
        const float ndc_y = cy * inv_w;
        const float half_w = static_cast<float>(cam.vp_width)  * 0.5f;
        const float half_h = static_cast<float>(cam.vp_height) * 0.5f;
        const int32_t sx = static_cast<int32_t>(ndc_x * half_w) + cam.center_x;
        const int32_t sy = static_cast<int32_t>(-ndc_y * half_h) + cam.center_y;
        return ScreenPoint{sx, sy};
    }

    /// Mesh-path equivalent of model_to_canvas. Rotates the vertex by
    /// the actor's orientation, translates to world coords, then runs
    /// the mesh matrix.
    ///
    /// The rotation here uses INTEGER fixed-point math with `>> 16` to
    /// match the renderer's per-vertex code exactly — it uses the same
    /// integer sin/cos lookup tables that our sin_table() inline
    /// computation reproduces bit-for-bit. Doing the rotation in float
    /// gave sub-pixel rounding drift that compounded visibly on the
    /// silhouette outline.
    inline std::optional<ScreenPoint> model_to_canvas_mesh(
        const CameraState& cam,
        int32_t model_x, int32_t model_y, int32_t model_z,
        int32_t local_x, int32_t local_y, int32_t height,
        int32_t orientation)
    {
        const int32_t rot_sin = sin_table(orientation);
        const int32_t rot_cos = cos_table(orientation);
        // (vx_new, vz_new) = R(orient) * (vx, vz)
        // Matches the software per-vertex projection.
        const int32_t rx = (model_z * rot_sin + model_x * rot_cos) >> 16;
        const int32_t rz = (model_z * rot_cos - model_x * rot_sin) >> 16;

        const int32_t world_x = local_x + rx;
        const int32_t world_y = local_y + rz;
        const int32_t world_h = height + model_y;

        return local_to_canvas_mesh(cam, world_x, world_y, world_h);
    }

    // ── Get tile height ─────────────────────────────────────────────
    // Reads tile height from the scene's height map.
    // Equivalent to RuneLite's Perspective.getTileHeight().
    // Returns negative values (height increases downward in OSRS).
    // For a flat approximation without the native function call,
    // use height = 0 for ground level.

    /// Converts a local point to minimap screen coordinates.
    /// The minimap rotates with camera yaw. Returns nullopt if the point is beyond minimap range.
    inline std::optional<ScreenPoint> local_to_minimap(
        const CameraState& cam,
        const LocalPoint& lp,
        int32_t player_local_x, int32_t player_local_y,
        int32_t minimap_x, int32_t minimap_y)
    {
        int32_t dx = lp.x - player_local_x;
        int32_t dy = lp.y - player_local_y;

        // Minimap uses a fixed zoom
        int32_t dist = dx * dx + dy * dy;
        if (dist > 6400 * 128 * 128) return std::nullopt; // too far

        int32_t sin_yaw = sin_table(cam.yaw);
        int32_t cos_yaw = cos_table(cam.yaw);

        int32_t mx = (dx * cos_yaw + dy * sin_yaw) >> 16;
        int32_t my = (dy * cos_yaw - dx * sin_yaw) >> 16;

        // Scale to minimap pixels (4 local units = 1 pixel roughly)
        int32_t sx = minimap_x + (mx >> 5);
        int32_t sy = minimap_y - (my >> 5);

        return ScreenPoint{sx, sy};
    }

    /// The four screen corners of a scene tile, useful for tile markers and area highlights.
    struct TileCorners {
        ScreenPoint nw, ne, sw, se;
        /// True when all four corners projected on-screen.
        bool valid() const { return nw.valid() && ne.valid() && sw.valid() && se.valid(); }
    };

    /// Returns the projected screen corners of a scene tile, or nullopt if any corner is clipped.
    inline std::optional<TileCorners> get_tile_corners(
        const CameraState& cam,
        int32_t scene_x, int32_t scene_y, int32_t height)
    {
        int32_t lx = scene_x * LOCAL_TILE_SIZE;
        int32_t ly = scene_y * LOCAL_TILE_SIZE;

        auto sw_pt = local_to_canvas(cam, lx, ly, height);
        auto se_pt = local_to_canvas(cam, lx + LOCAL_TILE_SIZE, ly, height);
        auto nw_pt = local_to_canvas(cam, lx, ly + LOCAL_TILE_SIZE, height);
        auto ne_pt = local_to_canvas(cam, lx + LOCAL_TILE_SIZE, ly + LOCAL_TILE_SIZE, height);

        if (!sw_pt || !se_pt || !nw_pt || !ne_pt) return std::nullopt;

        return TileCorners{*nw_pt, *ne_pt, *sw_pt, *se_pt};
    }

    /// Returns a screen point above an actor's head for overhead text or icons.
    /// @p model_height is typically ~180 for NPCs, ~240 for players.
    inline std::optional<ScreenPoint> get_actor_text_location(
        const CameraState& cam,
        int32_t local_x, int32_t local_y,
        int32_t model_height, int32_t z_offset = 0)
    {
        return local_to_canvas(cam, local_x, local_y, -(model_height + z_offset));
    }

} // namespace perspective

} // namespace obsidian::api
