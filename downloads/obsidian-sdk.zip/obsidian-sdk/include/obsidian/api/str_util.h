#pragma once
/// @file str_util.h
/// @brief Case-insensitive string matching helpers for API name/action lookups.
///
/// All API functions that match by name or menu action (find_by_name,
/// interact_by_action, interact_nearest, withdraw-by-name, etc.) route their
/// comparisons through these so callers never have to worry about casing.

#include <string_view>
#include <cctype>

namespace obsidian::api {

/// Case-insensitive equality. Accepts std::string, const char*, char[].
inline bool iequals(std::string_view a, std::string_view b) {
    if (a.size() != b.size()) return false;
    for (size_t i = 0; i < a.size(); ++i) {
        if (std::tolower(static_cast<unsigned char>(a[i])) !=
            std::tolower(static_cast<unsigned char>(b[i])))
            return false;
    }
    return true;
}

/// Case-insensitive substring test — true if @p needle occurs in @p hay.
/// An empty needle matches anything.
inline bool icontains(std::string_view hay, std::string_view needle) {
    if (needle.empty()) return true;
    if (needle.size() > hay.size()) return false;
    auto lc = [](char c) { return static_cast<char>(std::tolower(static_cast<unsigned char>(c))); };
    for (size_t i = 0; i + needle.size() <= hay.size(); ++i) {
        bool match = true;
        for (size_t j = 0; j < needle.size(); ++j) {
            if (lc(hay[i + j]) != lc(needle[j])) { match = false; break; }
        }
        if (match) return true;
    }
    return false;
}

/// Strip game markup tags (`<col=RRGGBB>`, `</col>`, `<br>`, `<img=N>` etc.)
/// from a string, returning the visible text only.
inline std::string strip_tags(std::string_view s) {
    std::string out;
    out.reserve(s.size());
    size_t i = 0;
    while (i < s.size()) {
        if (s[i] == '<') {
            auto end = s.find('>', i);
            if (end != std::string_view::npos) { i = end + 1; continue; }
        }
        out.push_back(s[i++]);
    }
    return out;
}

/// Case-insensitive equality after stripping game markup tags.
inline bool iequals_stripped(std::string_view a, std::string_view b) {
    return iequals(strip_tags(a), strip_tags(b));
}

/// Case-insensitive substring test after stripping game markup tags.
inline bool icontains_stripped(std::string_view hay, std::string_view needle) {
    return icontains(strip_tags(hay), strip_tags(needle));
}

} // namespace obsidian::api
