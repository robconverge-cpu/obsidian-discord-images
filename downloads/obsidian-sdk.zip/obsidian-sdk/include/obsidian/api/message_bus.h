#pragma once
/// @file message_bus.h
/// @brief String-keyed inter-plugin message bus for custom events.
///
/// Complements the typed EventBus. Plugins (DLL or JS) can fire and
/// subscribe to arbitrary named events with JSON string payloads.
/// Subscriptions are RAII — they auto-unsubscribe on destruction.
///
/// ### C++ usage
/// @code
/// auto& bus = obsidian::api::get_message_bus();
/// auto sub = bus.subscribe("quest-helper:step-changed",
///     [](const std::string& payload) { /* JSON string */ });
/// bus.fire("quest-helper:step-changed", R"({"step":5})");
/// sub.cancel();  // or let RAII handle it
/// @endcode

#include <cstdint>
#include <functional>
#include <string>
#include <vector>
#include <algorithm>
#include <unordered_map>

namespace obsidian::api {

class MessageBus;

class MessageSubscription {
    friend class MessageBus;
    MessageBus* bus_ = nullptr;
    uint64_t id_ = 0;
    std::string event_;

    MessageSubscription(MessageBus* bus, uint64_t id, std::string event)
        : bus_(bus), id_(id), event_(std::move(event)) {}

public:
    MessageSubscription() = default;
    MessageSubscription(MessageSubscription&& o) noexcept
        : bus_(o.bus_), id_(o.id_), event_(std::move(o.event_)) { o.bus_ = nullptr; }
    MessageSubscription& operator=(MessageSubscription&& o) noexcept {
        if (this != &o) { cancel(); bus_ = o.bus_; id_ = o.id_; event_ = std::move(o.event_); o.bus_ = nullptr; }
        return *this;
    }
    MessageSubscription(const MessageSubscription&) = delete;
    MessageSubscription& operator=(const MessageSubscription&) = delete;

    ~MessageSubscription() { cancel(); }
    void cancel();

    bool valid() const { return bus_ != nullptr; }
    uint64_t id() const { return id_; }
};

class MessageBus {
    struct HandlerEntry {
        uint64_t id;
        int priority;
        std::function<void(const std::string&)> handler;
    };

    using GlobalListener = std::function<void(const std::string& event, const std::string& payload)>;

    std::unordered_map<std::string, std::vector<HandlerEntry>> handlers_;
    std::vector<GlobalListener> global_listeners_;
    uint64_t next_id_ = 1;

public:
    void add_global_listener(GlobalListener listener) {
        global_listeners_.push_back(std::move(listener));
    }
    MessageSubscription subscribe(const std::string& event,
                                  std::function<void(const std::string&)> handler,
                                  int priority = 0) {
        uint64_t id = next_id_++;
        auto& vec = handlers_[event];
        vec.push_back({id, priority, std::move(handler)});
        std::stable_sort(vec.begin(), vec.end(),
            [](const HandlerEntry& a, const HandlerEntry& b) { return a.priority < b.priority; });
        return MessageSubscription(this, id, event);
    }

    void fire(const std::string& event, const std::string& payload = {}) {
        auto it = handlers_.find(event);
        if (it != handlers_.end()) {
            auto handlers_copy = it->second;
            for (auto& entry : handlers_copy) {
                entry.handler(payload);
            }
        }
        for (auto& listener : global_listeners_) {
            listener(event, payload);
        }
    }

    void remove(const std::string& event, uint64_t id) {
        auto it = handlers_.find(event);
        if (it == handlers_.end()) return;
        auto& vec = it->second;
        vec.erase(std::remove_if(vec.begin(), vec.end(),
            [id](const HandlerEntry& e) { return e.id == id; }), vec.end());
    }

    void clear() { handlers_.clear(); }

    size_t subscriber_count(const std::string& event) const {
        auto it = handlers_.find(event);
        return (it != handlers_.end()) ? it->second.size() : 0;
    }
};

inline void MessageSubscription::cancel() {
    if (bus_) {
        bus_->remove(event_, id_);
        bus_ = nullptr;
    }
}

inline MessageBus*& message_bus_ptr() { static MessageBus* p = nullptr; return p; }

inline MessageBus& get_message_bus() {
    auto* p = message_bus_ptr();
    if (!p) {
        static MessageBus fallback;
        message_bus_ptr() = &fallback;
        return fallback;
    }
    return *p;
}

inline void set_message_bus(MessageBus* bus) { message_bus_ptr() = bus; }

} // namespace obsidian::api
