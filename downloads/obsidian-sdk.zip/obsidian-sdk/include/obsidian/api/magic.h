#pragma once
/// @file magic.h
/// @brief Spell casting, spellbook queries, and rune availability.
///
/// Rune availability checks account for: inventory, rune pouch (varbits),
/// combo rune substitution (mist/dust/smoke/steam/mud/lava/sunfire/aether),
/// and equipped staff/tome infinite rune provision.
///
/// Usage:
/// @code
///   using namespace obsidian::api;
///   if (magic::can_cast(Spell::VARROCK_TELEPORT))
///       magic::cast(Spell::VARROCK_TELEPORT);
///   int32_t laws = magic::rune_count(Rune::LAW);
/// @endcode

#include <obsidian/api/combat.h>
#include <obsidian/api/rune.h>
#include <obsidian/api/spell.h>
#include <cstdint>
#include <string_view>

namespace obsidian::api::magic {

// ── Spellbook ──────────────────────────────────────────────────────────
combat::Spellbook spellbook();                                          ///< Current active spellbook.

/// Spell by name: the Spell:: key ("ICE_BARRAGE") or the display name
/// ("Ice Barrage"), case-insensitive. nullptr if unknown.
///   if (auto* s = magic::find_spell("Ice Barrage")) magic::cast_on_npc(*s, idx);
const SpellDef* find_spell(std::string_view name);

// ── Spell checks (SpellDef overloads) ──────────────────────────────────
bool can_cast(const SpellDef& spell);                                   ///< Level + runes + quest.
bool has_level(const SpellDef& spell);                                  ///< Magic level check only.

// ── Spell checks (raw widget — backward compat) ───────────────────────
bool has_level(int32_t spell_packed_widget);
bool can_cast(int32_t spell_packed_widget);                             ///< Level + runes + quest (action index 1).
bool can_cast(int32_t spell_packed_widget, int32_t action_index);       ///< Same, for diary variants (action index 2 = diary dest).

/// Inventory slot of a staff that, wielded, would make `spell` castable when it
/// isn't now (e.g. a fire staff for High Alchemy with no fire runes), or -1
/// (castable already, or no staff in the inventory helps). Wield it with
/// inventory::interact(slot, "Wield").
int32_t staff_for(const SpellDef& spell);
int32_t staff_for(int32_t spell_packed_widget, int32_t action_index);

// ── Rune availability (inventory + rune pouch + combo runes + staff/tome) ──
int32_t rune_count(Rune rune);                                          ///< By Rune enum.
int32_t rune_count(int32_t rune_item_id);                               ///< By item ID. INT32_MAX if staff provides.
bool has_runes(Rune rune, int32_t qty);                                 ///< Shorthand for rune_count >= qty.
bool has_runes(int32_t rune_item_id, int32_t qty);                      ///< By item ID.

// ── State ──────────────────────────────────────────────────────────────
bool is_autocasting();                              ///< Varp 108 != 0.
bool is_spell_selected();                           ///< A spell is currently selected for targeting.

// ── Casting (SpellDef overloads) ───────────────────────────────────────
void cast(const SpellDef& spell);                                                            ///< Cast a spell that requires no target.
void select_spell(const SpellDef& spell);                                                    ///< Select a spell for use-on targeting.
void cast_on_item(const SpellDef& spell, int32_t item_slot, int32_t item_id);                ///< Cast a spell on an inventory item.
void cast_on_npc(const SpellDef& spell, int32_t npc_index);                                  ///< Cast a spell on an NPC by index.
void cast_on_player(const SpellDef& spell, int32_t player_id);                               ///< Cast a spell on a player.
void cast_on_object(const SpellDef& spell, int32_t object_id, int32_t scene_x, int32_t scene_y);      ///< Cast a spell on a scene object.
void cast_on_ground_item(const SpellDef& spell, int32_t item_id, int32_t scene_x, int32_t scene_y);   ///< Cast a spell on a ground item.

// ── Casting (raw widget — backward compat) ─────────────────────────────
void cast(int32_t spell_packed_widget);                                 ///< Cast (action index 1).
void cast(int32_t spell_packed_widget, int32_t action_index);           ///< Cast with explicit action index.
void select_spell(int32_t spell_packed_widget);                         ///< Select spell for use-on targeting.
void cast_on_item(int32_t spell_packed_widget, int32_t item_slot, int32_t item_id);                    ///< Cast a spell on an inventory item (raw widget).
void cast_on_npc(int32_t spell_packed_widget, int32_t npc_index);                                      ///< Cast a spell on an NPC by index (raw widget).
void cast_on_player(int32_t spell_packed_widget, int32_t player_id);                                   ///< Cast a spell on a player (raw widget).
void cast_on_object(int32_t spell_packed_widget, int32_t object_id, int32_t scene_x, int32_t scene_y); ///< Cast a spell on a scene object (raw widget).
void cast_on_ground_item(int32_t spell_packed_widget, int32_t item_id, int32_t scene_x, int32_t scene_y); ///< Cast a spell on a ground item (raw widget).

} // namespace obsidian::api::magic
