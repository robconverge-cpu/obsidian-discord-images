#pragma once
/// @file ground_items.h
/// @brief Ground item queries and pickup.

#include <obsidian/api/scene_api.h>  // GroundItem (from tile.h via scene_api.h)
#include <obsidian/api/coords.h>
#include <cstdint>
#include <optional>
#include <string>
#include <vector>

namespace obsidian::api::ground_items {

/// Returns every ground item currently in the scene.
std::vector<GroundItem> find_all();
/// Returns all ground items with the given item ID.
std::vector<GroundItem> find(int32_t item_id);
/// Returns all ground items whose name matches @p name.
std::vector<GroundItem> find_by_name(const std::string& name);
/// Returns all ground items on the given world tile.
std::vector<GroundItem> find_at(const WorldPoint& tile);
/// Returns the nearest ground item with the given ID, or nullopt if none.
std::optional<GroundItem> find_nearest(int32_t item_id);
/// Returns the nearest ground item matching @p name, or nullopt if none.
std::optional<GroundItem> find_nearest_by_name(const std::string& name);
/// Pick up the ground item with the given ID at the given scene tile.
void pickup(int32_t item_id, int32_t scene_x, int32_t scene_y);
/// Pick up the nearest ground item with the given ID; true if dispatched.
bool pickup_nearest(int32_t item_id);
/// Pick up the nearest ground item matching @p name; true if dispatched.
bool pickup_nearest_by_name(const std::string& name);

/// Interact with the nearest reachable ground item matching @p item_name whose
/// item definition carries @p action as one of its ground actions (e.g. "Take",
/// "Light"). Same-named items lacking the action are skipped.
/// @return true if a matching item was found and the action dispatched.
bool interact_nearest(const std::string& item_name, const std::string& action);

/// Highlight tiles containing ground items with this ID.
/// Uses the native GPU tile highlight system on the given channel.
/// Call each frame/tick to keep highlights in sync with spawns.
void highlight(int32_t item_id, int32_t channel);

/// Remove tile highlights for ground items with this ID.
void clear_highlight(int32_t item_id, int32_t channel);

} // namespace obsidian::api::ground_items
