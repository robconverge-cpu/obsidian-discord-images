#pragma once
/// @file objects_api.h
/// @brief Scene object queries and interactions — searches ALL types by default.
///
/// `objects::find_nearest(id)` searches game objects, wall objects, decorative
/// objects, and ground objects. Use `find_nearest_game_object(id)` (or the
/// other type-specific variants) if you need one category specifically.
///
/// Usage:
/// @code
///   namespace objects = obsidian::api::objects;
///   auto obj = objects::find_nearest_by_name("Bank booth");
///   if (obj) objects::interact_by_action(obj->id, "Bank", obj->scene_x, obj->scene_y);
/// @endcode

#include <obsidian/api/scene_api.h>  // SceneObject, SceneWallObject, SceneDecorativeObject
#include <obsidian/api/action_types.h>
#include <cstdint>
#include <optional>
#include <string>
#include <vector>

namespace obsidian::api::objects {

/// One-instant snapshot of every scene-object query path, for diagnosing
/// disagreements between the combined and typed queries. All counts are taken
/// back-to-back in a single call, so unlike separate calls from a script they
/// cannot straddle a tick boundary and disagree for that reason alone.
///
/// `capi_version` is the host's C-ABI version (0 when running in-tree, where
/// the API reads game state directly and no C-ABI is involved). The
/// `has_*` flags say whether this host actually exposes the v6.8 category
/// slots; when false, `type` is not transported and every record reads Game.
struct Diagnostics {
    uint32_t capi_version      = 0;  ///< version the HOST reports
    /// C-ABI version this SDK build was compiled against. The kit does not
    /// ship the C-ABI header, so a plugin cannot determine this itself —
    /// compare it with capi_version to detect a host/SDK mismatch, which is
    /// silently harmful (appended slots read past the older side's table).
    uint32_t sdk_capi_version  = 0;
    bool     has_find_all_typed = false;
    bool     has_find_all_game  = false;
    int32_t  n_all        = -1;  ///< records available from find_all
    int32_t  n_all_typed  = -1;  ///< records available from the typed all-query
    int32_t  n_game       = -1;  ///< records available from the game-only query
    int32_t  n_wall       = -1;
    int32_t  n_deco       = -1;
    int32_t  n_ground     = -1;
    int32_t  seen_game    = 0;   ///< categories actually observed in find_all()
    int32_t  seen_wall    = 0;
    int32_t  seen_deco    = 0;
    int32_t  seen_ground  = 0;
};
/// Sample every query path at one instant (see Diagnostics).
Diagnostics diagnostics();

// ── All-Types Queries (DEFAULT — searches game + wall + deco + ground) ──

/// Returns every scene object in the scene (all 4 types). Each entry's
/// `type` field indicates Game/Wall/Decorative/Ground origin.
std::vector<SceneObject> find_all();
/// Returns all scene objects (any type) with the given ID.
std::vector<SceneObject> find_objects(int32_t object_id);
/// Returns all scene objects (any type) whose name matches @p name.
std::vector<SceneObject> find_objects_by_name(const std::string& name);
/// Returns the nearest scene object (any type) with the given ID, or nullopt.
std::optional<SceneObject> find_nearest(int32_t object_id);
/// Returns the nearest scene object (any type) matching @p name, or nullopt.
std::optional<SceneObject> find_nearest_by_name(const std::string& name);
/// True if any scene object with the given name exists in the scene.
bool exists(const std::string& name);

// ── Game Object Queries (explicit game-objects-only) ───────────────────

/// Returns every game object in the scene.
std::vector<SceneObject> find_all_game_objects();
/// Returns all game objects with the given ID.
std::vector<SceneObject> find_game_objects(int32_t object_id);
/// Returns all game objects whose name matches @p name.
std::vector<SceneObject> find_game_objects_by_name(const std::string& name);
/// Returns the nearest game object with the given ID, or nullopt.
std::optional<SceneObject> find_nearest_game_object(int32_t object_id);
/// Returns the nearest game object matching @p name, or nullopt.
std::optional<SceneObject> find_nearest_game_object_by_name(const std::string& name);

// ── Wall Object Queries ────────────────────────────────────────────────

/// Returns every wall object in the scene.
std::vector<SceneWallObject> find_all_wall_objects();
/// Returns all wall objects with the given ID.
std::vector<SceneWallObject> find_wall_objects(int32_t object_id);
/// Returns all wall objects whose name matches @p name.
std::vector<SceneWallObject> find_wall_objects_by_name(const std::string& name);
/// Returns the nearest wall object with the given ID, or nullopt.
std::optional<SceneWallObject> find_nearest_wall_object(int32_t object_id);
/// Returns the nearest wall object matching @p name, or nullopt.
std::optional<SceneWallObject> find_nearest_wall_object_by_name(const std::string& name);

// ── Decorative Object Queries ──────────────────────────────────────────

/// Returns every decorative object in the scene.
std::vector<SceneDecorativeObject> find_all_decorative_objects();
/// Returns all decorative objects with the given ID.
std::vector<SceneDecorativeObject> find_decorative_objects(int32_t object_id);
/// Returns all decorative objects whose name matches @p name.
std::vector<SceneDecorativeObject> find_decorative_objects_by_name(const std::string& name);
/// Returns the nearest decorative object with the given ID, or nullopt.
std::optional<SceneDecorativeObject> find_nearest_decorative_object(int32_t object_id);
/// Returns the nearest decorative object matching @p name, or nullopt.
std::optional<SceneDecorativeObject> find_nearest_decorative_object_by_name(const std::string& name);

// ── Ground Object Queries (ground decorations: manholes, trapdoors, …) ──

/// Returns every ground object in the scene.
std::vector<SceneGroundObject> find_all_ground_objects();
/// Returns all ground objects with the given ID.
std::vector<SceneGroundObject> find_ground_objects(int32_t object_id);
/// Returns all ground objects whose name matches @p name.
std::vector<SceneGroundObject> find_ground_objects_by_name(const std::string& name);
/// Returns the nearest ground object with the given ID, or nullopt.
std::optional<SceneGroundObject> find_nearest_ground_object(int32_t object_id);
/// Returns the nearest ground object matching @p name, or nullopt.
std::optional<SceneGroundObject> find_nearest_ground_object_by_name(const std::string& name);

// ── Interactions ───────────────────────────────────────────────────────

/// Interact with the object at the given scene tile using a typed action.
bool interact(int32_t object_id, ObjectAction action, int32_t scene_x, int32_t scene_y, int32_t world_view_id = -1);
/// Interact with the object at the given scene tile using a right-click option index.
bool interact(int32_t object_id, int32_t option, int32_t scene_x, int32_t scene_y, int32_t world_view_id = -1);
/// Interact with the object by action text; returns true if dispatched.
bool interact_by_action(int32_t object_id, const std::string& action, int32_t scene_x, int32_t scene_y, int32_t world_view_id = -1);
/// Interact with the nearest object named @p object_name via action text; true if dispatched.
bool interact_nearest(const std::string& object_name, const std::string& action);
/// Use an inventory item on the object after an optional tick delay.
void use_item_on(int32_t item_slot, int32_t item_id, int32_t object_id, int32_t scene_x, int32_t scene_y, int32_t delay_ticks = 1);
/// Cast a spell (by packed widget) on the object after an optional tick delay.
void cast_spell_on(int32_t spell_packed_widget, int32_t object_id, int32_t scene_x, int32_t scene_y, int32_t delay_ticks = 1);

} // namespace obsidian::api::objects
