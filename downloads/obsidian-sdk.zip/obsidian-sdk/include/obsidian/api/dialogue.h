/// @file dialogue.h
/// @brief Dialogue API — read and interact with NPC/player/option dialogues.
///
/// Pure widget-state wrappers over existing widgets::get() / widgets::click().
/// No RE needed — all dialogue state is derived from widget visibility
/// and text content using the standard OSRS cache-defined widget groups.
///
/// Usage:
/// @code
///   if (dialogue::is_open()) {
///       if (dialogue::can_continue()) {
///           dialogue::continue_dialogue();
///       } else if (dialogue::type() == dialogue::Type::Options) {
///           auto opts = dialogue::get_options();
///           dialogue::select_option("Yes");
///       }
///   }
/// @endcode
#pragma once

#include <cstdint>
#include <string>
#include <vector>

namespace obsidian::api::dialogue {

// ── Widget group IDs (from game cache, same for Java and native) ─────

// Widget group IDs (from game cache, same for Java and native).
namespace widget {
    constexpr int32_t NPC_DIALOG      = 231;
    constexpr int32_t PLAYER_DIALOG   = 217;
    constexpr int32_t MESSAGE_BOX     = 229;
    constexpr int32_t OPTIONS         = 219;
    constexpr int32_t SPRITE_DIALOG   = 193;
    constexpr int32_t DOUBLE_SPRITE   = 11;
    constexpr int32_t DESTROY_CONFIRM = 584;
    constexpr int32_t LEVEL_UP        = 233;
    constexpr int32_t CHATBOX         = 162;
    constexpr int32_t SKILL_MULTI     = 270;
    constexpr int32_t GRAPHICAL_MULTI = 140;
}

// Packed widget IDs (group << 16 | child) for direct use with
// widgets::get(packed) and widgets::click(slot, packed, action).
namespace packed {
    constexpr int32_t NPC_NAME           = (231 << 16) | 4;
    constexpr int32_t NPC_CONTINUE       = (231 << 16) | 5;
    constexpr int32_t NPC_TEXT           = (231 << 16) | 6;
    constexpr int32_t PLAYER_NAME        = (217 << 16) | 4;
    constexpr int32_t PLAYER_CONTINUE    = (217 << 16) | 5;
    constexpr int32_t PLAYER_TEXT        = (217 << 16) | 6;
    // Messagebox (229): UNIVERSE 0, SAFEZONE 1, CONTENT 2, TEXT 3, CONTINUE 4
    // (current gamevals). The old 229:1 pointed at the SAFEZONE layer — no
    // text — so every plain message box ("Teleport to Castle Wars?", "You
    // make your way up the steps...") was invisible to type() and its
    // continue click hit the wrong child. Field-reported twice.
    constexpr int32_t MESSAGE_TEXT       = (229 << 16) | 3;
    constexpr int32_t MESSAGE_CONTINUE   = (229 << 16) | 4;
    constexpr int32_t SPRITE_TEXT        = (193 << 16) | 2;
    constexpr int32_t OPTIONS_PARENT     = (219 << 16) | 1;
    constexpr int32_t CHATBOX_INPUT      = (162 << 16) | 5;
    constexpr int32_t LEVEL_UP_TEXT      = (233 << 16) | 1;
}

/// Header text filtered from options lists.
constexpr const char* OPTIONS_HEADER_TEXT = "Select an option";

/// @brief Type of dialogue currently displayed.
enum class Type {
    None,           ///< No dialogue open.
    NpcDialog,      ///< NPC speaking (head on left).
    PlayerDialog,   ///< Player speaking (head on right).
    TextMessage,    ///< Plain text message (group 229).
    Options,        ///< Multiple-choice options.
    SpriteDialog,   ///< Item/object display with text.
    DoubleSpriteDialog, ///< Two-item display.
    DestroyConfirm, ///< "Destroy this item?" confirmation.
    LevelUp,        ///< Level up notification.
    Input,          ///< Text/number input prompt.
    SkillMulti,     ///< Skill selection ("What to cook?").
    GraphicalMulti, ///< Graphical multi-choice with icons.
};

/// @brief Check if any dialogue widget is currently visible.
bool is_open();

/// @brief Get the type of the currently visible dialogue.
Type type();

/// @brief Get the main text content of the current dialogue.
/// Returns empty string if no dialogue is open.
std::string get_text();

/// @brief Get the NPC/player name in the current dialogue.
/// Returns empty string if the dialogue has no name field.
std::string get_name();

/// @brief Check if the current dialogue has a "Click here to continue" button.
bool can_continue();

/// @brief Continue the dialogue. Sends space key by default (keyboard mode)
/// or clicks the continue widget (click mode).
/// @param use_keyboard If true (default), sends VK_SPACE. If false, clicks the widget.
void continue_dialogue(bool use_keyboard = true);

/// @brief Get the list of options in a multi-choice dialogue.
/// Returns empty vector if the current dialogue is not Type::Options.
std::vector<std::string> get_options();

/// @brief Select an option by its 0-based index.
/// @param index 0-based index into the options list.
/// @param use_keyboard If true (default), sends the number key (1-5). If false, clicks the widget.
/// @return true if the option was selected, false if index out of range or not in options dialogue.
bool select_option(int32_t index, bool use_keyboard = true);

/// @brief Select an option by matching its text (case-insensitive substring).
/// @param text Substring to match against option text.
/// @param use_keyboard If true (default), sends the number key. If false, clicks the widget.
/// @return true if a matching option was found and selected.
bool select_option(const std::string& text, bool use_keyboard = true);

/// @brief Find the first dialogue option with a non-default text color.
/// Returns the 0-based option index, or -1 if no option is colored.
/// Used to detect Quest Helper highlighted options.
int32_t find_colored_option();

/// @brief Check if a text/number input prompt is active.
bool is_input_open();

/// @brief Type text into the chatbox input and submit it.
/// Works for bank search, shop search, text entry prompts, etc.
void enter_text(const std::string& text);

/// @brief Type a number into the chatbox input and submit it.
/// Works for bank withdraw-X, quantity prompts, etc.
void enter_number(int32_t number);

} // namespace obsidian::api::dialogue
