#pragma once
/// @file action_types.h
/// @brief Typed enums for interaction options and highlight categories.
///
/// Replaces raw int32_t magic numbers in interaction and highlight APIs.

#include <cstdint>

namespace obsidian::api {

/// NPC interaction option (1-5 maps to NPC_FIRST through NPC_FIFTH).
enum class NpcAction : int32_t {
    First  = 1,
    Second = 2,
    Third  = 3,
    Fourth = 4,
    Fifth  = 5,
};

/// Object interaction option (1-5 maps to GAME_OBJECT_FIRST through FIFTH).
enum class ObjectAction : int32_t {
    First  = 1,
    Second = 2,
    Third  = 3,
    Fourth = 4,
    Fifth  = 5,
};

} // namespace obsidian::api
