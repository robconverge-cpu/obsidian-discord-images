#pragma once
/// @file spell.h
/// @brief Spell definitions with widget ID, action index, level, and spellbook.
///
/// Usage:
/// @code
///   using namespace obsidian::api;
///   if (magic::can_cast(Spell::VARROCK_TELEPORT))
///       magic::cast(Spell::VARROCK_TELEPORT);
///   // Diary variant:
///   magic::cast(Spell::GRAND_EXCHANGE_TELEPORT);
/// @endcode

#include <cstdint>

namespace obsidian::api {

/// Spell definition.  Carries everything needed to cast: widget ID, action
/// index (1 = default, 2 = diary variant), magic level, and spellbook.
struct SpellDef {
    int32_t widget;        ///< Packed widget ID (group << 16 | child).
    int32_t action_index;  ///< 1 = default cast, 2 = diary variant.
    int32_t level;         ///< Magic level required.
    int32_t spellbook;     ///< 0 = Standard, 1 = Ancient, 2 = Lunar, 3 = Arceuus.
};

/// Named spell constants.  Widget IDs from ids/interface_id.h Magic_Spellbook.
namespace Spell {

    // ── Standard spellbook (spellbook = 0) ─────────────────────────────────

    constexpr SpellDef HOME_TELEPORT             = {0x00da0006, 1,  0, 0};  // TELEPORT_HOME_STANDARD
    constexpr SpellDef WIND_STRIKE               = {0x00da000b, 1,  1, 0};
    constexpr SpellDef CONFUSE                   = {0x00da000c, 1,  3, 0};
    constexpr SpellDef ENCHANT_CROSSBOW_BOLT     = {0x00da000d, 1,  4, 0};  // XBOWS_ENCHANT
    constexpr SpellDef WATER_STRIKE              = {0x00da000e, 1,  5, 0};
    constexpr SpellDef JEWELLERY_ENCHANT         = {0x00da000f, 1,  7, 0};  // ENCHANT_JEWELLERY
    constexpr SpellDef LVL1_ENCHANT              = {0x00da0010, 1,  7, 0};  // ENCHANT_1
    constexpr SpellDef EARTH_STRIKE              = {0x00da0011, 1,  9, 0};
    constexpr SpellDef WEAKEN                    = {0x00da0012, 1, 11, 0};
    constexpr SpellDef FIRE_STRIKE               = {0x00da0013, 1, 13, 0};
    constexpr SpellDef BONES_TO_BANANAS          = {0x00da0014, 1, 15, 0};  // BONES_BANANAS
    constexpr SpellDef WIND_BOLT                 = {0x00da0015, 1, 17, 0};
    constexpr SpellDef CURSE                     = {0x00da0016, 1, 19, 0};
    constexpr SpellDef BIND                      = {0x00da0017, 1, 20, 0};
    constexpr SpellDef LOW_LEVEL_ALCHEMY         = {0x00da0018, 1, 21, 0};  // LOW_ALCHEMY
    constexpr SpellDef WATER_BOLT                = {0x00da0019, 1, 23, 0};
    constexpr SpellDef VARROCK_TELEPORT          = {0x00da001a, 1, 25, 0};
    constexpr SpellDef LVL2_ENCHANT              = {0x00da001b, 1, 27, 0};  // ENCHANT_2
    constexpr SpellDef EARTH_BOLT                = {0x00da001c, 1, 29, 0};
    constexpr SpellDef LUMBRIDGE_TELEPORT        = {0x00da001d, 1, 31, 0};
    constexpr SpellDef TELEKINETIC_GRAB          = {0x00da001e, 1, 33, 0};  // TELEGRAB
    constexpr SpellDef FIRE_BOLT                 = {0x00da001f, 1, 35, 0};
    constexpr SpellDef FALADOR_TELEPORT          = {0x00da0020, 1, 37, 0};
    constexpr SpellDef CRUMBLE_UNDEAD            = {0x00da0021, 1, 39, 0};
    constexpr SpellDef TELEPORT_TO_HOUSE         = {0x00da0022, 1, 40, 0};  // TELEPORT_TO_YOUR_HOUSE
    constexpr SpellDef WIND_BLAST                = {0x00da0023, 1, 41, 0};
    constexpr SpellDef SUPERHEAT_ITEM            = {0x00da0024, 1, 43, 0};  // SUPERHEAT
    constexpr SpellDef CAMELOT_TELEPORT          = {0x00da0025, 1, 45, 0};
    constexpr SpellDef WATER_BLAST               = {0x00da0026, 1, 47, 0};
    constexpr SpellDef KOUREND_CASTLE_TELEPORT   = {0x00da0027, 1, 48, 0};  // KOUREND_TELEPORT
    constexpr SpellDef LVL3_ENCHANT              = {0x00da0028, 1, 49, 0};  // ENCHANT_3
    constexpr SpellDef IBAN_BLAST                = {0x00da0029, 1, 50, 0};
    constexpr SpellDef SNARE                     = {0x00da002a, 1, 50, 0};
    constexpr SpellDef MAGIC_DART                = {0x00da002b, 1, 50, 0};
    constexpr SpellDef ARDOUGNE_TELEPORT         = {0x00da002c, 1, 51, 0};
    constexpr SpellDef EARTH_BLAST               = {0x00da002d, 1, 53, 0};
    constexpr SpellDef CIVITAS_ILLI_FORTIS_TELEPORT = {0x00da002e, 1, 54, 0};  // FORTIS_TELEPORT
    constexpr SpellDef HIGH_LEVEL_ALCHEMY        = {0x00da002f, 1, 55, 0};  // HIGH_ALCHEMY
    constexpr SpellDef CHARGE_WATER_ORB          = {0x00da0030, 1, 56, 0};
    constexpr SpellDef LVL4_ENCHANT              = {0x00da0031, 1, 57, 0};  // ENCHANT_4
    constexpr SpellDef WATCHTOWER_TELEPORT       = {0x00da0032, 1, 58, 0};
    constexpr SpellDef FIRE_BLAST                = {0x00da0033, 1, 59, 0};
    constexpr SpellDef CHARGE_EARTH_ORB          = {0x00da0034, 1, 60, 0};
    constexpr SpellDef BONES_TO_PEACHES          = {0x00da0035, 1, 60, 0};  // BONES_PEACHES
    constexpr SpellDef SARADOMIN_STRIKE          = {0x00da0036, 1, 60, 0};
    constexpr SpellDef CLAWS_OF_GUTHIX           = {0x00da0037, 1, 60, 0};
    constexpr SpellDef FLAMES_OF_ZAMORAK         = {0x00da0038, 1, 60, 0};
    constexpr SpellDef TROLLHEIM_TELEPORT        = {0x00da0039, 1, 61, 0};
    constexpr SpellDef WIND_WAVE                 = {0x00da003a, 1, 62, 0};
    constexpr SpellDef CHARGE_FIRE_ORB           = {0x00da003b, 1, 63, 0};
    constexpr SpellDef APE_ATOLL_TELEPORT        = {0x00da003c, 1, 64, 0};  // APE_TELEPORT
    constexpr SpellDef WATER_WAVE                = {0x00da003d, 1, 65, 0};
    constexpr SpellDef CHARGE_AIR_ORB            = {0x00da003e, 1, 66, 0};
    constexpr SpellDef VULNERABILITY             = {0x00da003f, 1, 66, 0};
    constexpr SpellDef LVL5_ENCHANT              = {0x00da0040, 1, 68, 0};  // ENCHANT_5
    constexpr SpellDef EARTH_WAVE                = {0x00da0041, 1, 70, 0};
    constexpr SpellDef ENFEEBLE                  = {0x00da0042, 1, 73, 0};
    constexpr SpellDef TELEOTHER_LUMBRIDGE       = {0x00da0043, 1, 74, 0};
    constexpr SpellDef FIRE_WAVE                 = {0x00da0044, 1, 75, 0};
    constexpr SpellDef ENTANGLE                  = {0x00da0045, 1, 79, 0};
    constexpr SpellDef STUN                      = {0x00da0046, 1, 80, 0};
    constexpr SpellDef CHARGE                    = {0x00da0047, 1, 80, 0};
    constexpr SpellDef WIND_SURGE                = {0x00da0048, 1, 81, 0};
    constexpr SpellDef TELEOTHER_FALADOR         = {0x00da0049, 1, 82, 0};
    constexpr SpellDef WATER_SURGE               = {0x00da004a, 1, 85, 0};
    constexpr SpellDef TELE_BLOCK                = {0x00da004b, 1, 85, 0};  // TELEPORT_BLOCK
    constexpr SpellDef TELEPORT_TO_TARGET        = {0x00da004c, 1, 85, 0};  // BOUNTY_TARGET
    constexpr SpellDef LVL6_ENCHANT              = {0x00da004d, 1, 87, 0};  // ENCHANT_6
    constexpr SpellDef TELEOTHER_CAMELOT         = {0x00da004e, 1, 90, 0};
    constexpr SpellDef EARTH_SURGE               = {0x00da004f, 1, 90, 0};
    constexpr SpellDef LVL7_ENCHANT              = {0x00da0050, 1, 93, 0};  // ENCHANT_7
    constexpr SpellDef FIRE_SURGE                = {0x00da0051, 1, 95, 0};

    // ── Standard spellbook diary variants (action_index = 2) ───────────────

    constexpr SpellDef GRAND_EXCHANGE_TELEPORT   = {0x00da001a, 2, 25, 0};  // Varrock widget, diary action 2
    constexpr SpellDef SEERS_TELEPORT            = {0x00da0025, 2, 45, 0};  // Camelot widget, diary action 2
    constexpr SpellDef YANILLE_TELEPORT          = {0x00da0032, 2, 58, 0};  // Watchtower widget, diary action 2

    // ── Ancient spellbook (spellbook = 1) ──────────────────────────────────

    constexpr SpellDef EDGEVILLE_HOME_TELEPORT   = {0x00da006c, 1,  0, 1};  // TELEPORT_HOME_ZAROS

    // Combat
    constexpr SpellDef SMOKE_RUSH                = {0x00da005c, 1, 50, 1};
    constexpr SpellDef SHADOW_RUSH               = {0x00da0060, 1, 52, 1};
    constexpr SpellDef PADDEWWA_TELEPORT         = {0x00da0064, 1, 54, 1};  // ZAROSTELEPORT1
    constexpr SpellDef BLOOD_RUSH                = {0x00da0058, 1, 56, 1};
    constexpr SpellDef ICE_RUSH                  = {0x00da0054, 1, 58, 1};
    constexpr SpellDef SENNTISTEN_TELEPORT       = {0x00da0065, 1, 60, 1};  // ZAROSTELEPORT2
    constexpr SpellDef SMOKE_BURST               = {0x00da005e, 1, 62, 1};
    constexpr SpellDef SHADOW_BURST              = {0x00da0062, 1, 64, 1};
    constexpr SpellDef KHARYRLL_TELEPORT         = {0x00da0066, 1, 66, 1};  // ZAROSTELEPORT3
    constexpr SpellDef BLOOD_BURST               = {0x00da005a, 1, 68, 1};
    constexpr SpellDef ICE_BURST                 = {0x00da0056, 1, 70, 1};
    constexpr SpellDef LASSAR_TELEPORT           = {0x00da0067, 1, 72, 1};  // ZAROSTELEPORT4
    constexpr SpellDef SMOKE_BLITZ               = {0x00da005d, 1, 74, 1};
    constexpr SpellDef SHADOW_BLITZ              = {0x00da0061, 1, 76, 1};
    constexpr SpellDef DAREEYAK_TELEPORT         = {0x00da0068, 1, 78, 1};  // ZAROSTELEPORT5
    constexpr SpellDef BLOOD_BLITZ               = {0x00da0059, 1, 80, 1};
    constexpr SpellDef ICE_BLITZ                 = {0x00da0055, 1, 82, 1};
    constexpr SpellDef CARRALLANGAR_TELEPORT     = {0x00da0069, 1, 84, 1};  // ZAROSTELEPORT6
    constexpr SpellDef SMOKE_BARRAGE             = {0x00da005f, 1, 86, 1};
    constexpr SpellDef SHADOW_BARRAGE            = {0x00da0063, 1, 88, 1};
    constexpr SpellDef ANNAKARL_TELEPORT         = {0x00da006a, 1, 90, 1};  // ZAROSTELEPORT7
    constexpr SpellDef BLOOD_BARRAGE             = {0x00da005b, 1, 92, 1};
    constexpr SpellDef ICE_BARRAGE               = {0x00da0057, 1, 94, 1};
    constexpr SpellDef GHORROCK_TELEPORT         = {0x00da006b, 1, 96, 1};  // ZAROSTELEPORT8

    // ── Lunar spellbook (spellbook = 2) ────────────────────────────────────

    constexpr SpellDef LUNAR_HOME_TELEPORT       = {0x00da006d, 1,  0, 2};  // TELEPORT_HOME_LUNAR
    constexpr SpellDef BAKE_PIE                  = {0x00da006e, 1, 65, 2};
    constexpr SpellDef GEOMANCY                  = {0x00da0096, 1, 65, 2};
    constexpr SpellDef CURE_PLANT                = {0x00da006f, 1, 66, 2};
    constexpr SpellDef MONSTER_EXAMINE           = {0x00da0070, 1, 66, 2};
    constexpr SpellDef NPC_CONTACT               = {0x00da0071, 1, 67, 2};
    constexpr SpellDef CURE_OTHER                = {0x00da0072, 1, 68, 2};
    constexpr SpellDef HUMIDIFY                  = {0x00da0073, 1, 68, 2};
    constexpr SpellDef MOONCLAN_TELEPORT         = {0x00da0074, 1, 69, 2};  // TELE_MOONCLAN
    constexpr SpellDef TELE_GROUP_MOONCLAN       = {0x00da0075, 1, 70, 2};
    constexpr SpellDef CURE_ME                   = {0x00da0076, 1, 71, 2};
    constexpr SpellDef OURANIA_TELEPORT          = {0x00da0098, 1, 71, 2};
    constexpr SpellDef HUNTER_KIT                = {0x00da0077, 1, 71, 2};
    constexpr SpellDef WATERBIRTH_TELEPORT       = {0x00da0078, 1, 72, 2};  // TELE_WATERBIRTH
    constexpr SpellDef TELE_GROUP_WATERBIRTH     = {0x00da0079, 1, 73, 2};
    constexpr SpellDef CURE_GROUP                = {0x00da007a, 1, 74, 2};
    constexpr SpellDef STAT_SPY                  = {0x00da007b, 1, 75, 2};
    constexpr SpellDef BARBARIAN_TELEPORT        = {0x00da007c, 1, 75, 2};  // TELE_BARB_OUT
    constexpr SpellDef TELE_GROUP_BARBARIAN      = {0x00da007d, 1, 76, 2};
    constexpr SpellDef SPIN_FLAX                 = {0x00da0097, 1, 76, 2};
    constexpr SpellDef SUPERGLASS_MAKE           = {0x00da007e, 1, 77, 2};  // SUPERGLASS
    constexpr SpellDef TAN_LEATHER               = {0x00da007f, 1, 78, 2};
    constexpr SpellDef KHAZARD_TELEPORT          = {0x00da0080, 1, 78, 2};  // TELE_KHAZARD
    constexpr SpellDef TELE_GROUP_KHAZARD        = {0x00da0081, 1, 79, 2};
    constexpr SpellDef DREAM                     = {0x00da0082, 1, 79, 2};
    constexpr SpellDef STRING_JEWELLERY          = {0x00da0083, 1, 80, 2};  // STRING_JEWEL
    constexpr SpellDef STAT_RESTORE_POT_SHARE   = {0x00da0084, 1, 81, 2};  // REST_POT_SHARE
    constexpr SpellDef MAGIC_IMBUE               = {0x00da0085, 1, 82, 2};
    constexpr SpellDef FERTILE_SOIL              = {0x00da0086, 1, 83, 2};
    constexpr SpellDef BOOST_POTION_SHARE        = {0x00da0087, 1, 84, 2};  // STREN_POT_SHARE
    constexpr SpellDef FISHING_GUILD_TELEPORT    = {0x00da0088, 1, 85, 2};  // TELE_FISH
    constexpr SpellDef TELE_GROUP_FISHING_GUILD  = {0x00da0089, 1, 86, 2};
    constexpr SpellDef PLANK_MAKE                = {0x00da008a, 1, 86, 2};
    constexpr SpellDef CATHERBY_TELEPORT         = {0x00da008b, 1, 87, 2};  // TELE_CATHER
    constexpr SpellDef TELE_GROUP_CATHERBY       = {0x00da008c, 1, 88, 2};
    constexpr SpellDef RECHARGE_DRAGONSTONE      = {0x00da008d, 1, 89, 2};
    constexpr SpellDef ICE_PLATEAU_TELEPORT      = {0x00da008e, 1, 89, 2};  // TELE_GHORROCK
    constexpr SpellDef TELE_GROUP_ICE_PLATEAU    = {0x00da008f, 1, 90, 2};  // TELE_GROUP_GHORROCK
    constexpr SpellDef ENERGY_TRANSFER           = {0x00da0090, 1, 91, 2};  // ENERGY_TRANS
    constexpr SpellDef HEAL_OTHER                = {0x00da0091, 1, 92, 2};
    constexpr SpellDef VENGEANCE_OTHER           = {0x00da0092, 1, 93, 2};
    constexpr SpellDef VENGEANCE                 = {0x00da0093, 1, 94, 2};
    constexpr SpellDef HEAL_GROUP                = {0x00da0094, 1, 95, 2};
    constexpr SpellDef SPELLBOOK_SWAP            = {0x00da0095, 1, 96, 2};

    // ── Arceuus spellbook (spellbook = 3) ──────────────────────────────────

    constexpr SpellDef ARCEUUS_HOME_TELEPORT     = {0x00da0099, 1,  1, 3};  // TELEPORT_HOME_ARCEUUS
    constexpr SpellDef ARCEUUS_LIBRARY_TELEPORT  = {0x00da009b, 1,  6, 3};  // TELEPORT_ARCEUUS_LIBRARY
    constexpr SpellDef BASIC_REANIMATION         = {0x00da009a, 1, 16, 3};  // REANIMATION_BASIC
    constexpr SpellDef DRAYNOR_MANOR_TELEPORT    = {0x00da009f, 1, 17, 3};  // TELEPORT_DRAYNOR_MANOR
    constexpr SpellDef BATTLEFRONT_TELEPORT      = {0x00da00ab, 1, 23, 3};  // TELEPORT_BATTLEFRONT
    constexpr SpellDef MIND_ALTAR_TELEPORT       = {0x00da00a1, 1, 28, 3};  // TELEPORT_MIND_ALTAR
    constexpr SpellDef RESPAWN_TELEPORT          = {0x00da00a2, 1, 34, 3};  // TELEPORT_RESPAWN
    constexpr SpellDef GHOSTLY_GRASP             = {0x00da00b0, 1, 35, 3};
    constexpr SpellDef RESURRECT_LESSER_GHOST    = {0x00da00bd, 1, 38, 3};
    constexpr SpellDef RESURRECT_LESSER_SKELETON = {0x00da00be, 1, 38, 3};
    constexpr SpellDef RESURRECT_LESSER_ZOMBIE   = {0x00da00bf, 1, 38, 3};
    constexpr SpellDef SALVE_GRAVEYARD_TELEPORT  = {0x00da00a3, 1, 40, 3};  // TELEPORT_SALVE_GRAVEYARD
    constexpr SpellDef ADEPT_REANIMATION         = {0x00da009c, 1, 41, 3};  // REANIMATION_ADEPT
    constexpr SpellDef INFERIOR_DEMONBANE        = {0x00da00ac, 1, 44, 3};
    constexpr SpellDef SHADOW_VEIL               = {0x00da00b9, 1, 47, 3};
    constexpr SpellDef FENKENSTRAINS_CASTLE_TELEPORT = {0x00da00a4, 1, 48, 3};  // TELEPORT_FENKENSTRAIN_CASTLE
    constexpr SpellDef DARK_LURE                 = {0x00da00bb, 1, 50, 3};
    constexpr SpellDef SKELETAL_GRASP            = {0x00da00b1, 1, 56, 3};
    constexpr SpellDef RESURRECT_SUPERIOR_GHOST  = {0x00da00c0, 1, 57, 3};
    constexpr SpellDef RESURRECT_SUPERIOR_SKELETON = {0x00da00c1, 1, 57, 3};
    constexpr SpellDef RESURRECT_SUPERIOR_ZOMBIE = {0x00da00c2, 1, 57, 3};
    constexpr SpellDef MARK_OF_DARKNESS          = {0x00da00af, 1, 59, 3};
    constexpr SpellDef WEST_ARDOUGNE_TELEPORT    = {0x00da00a5, 1, 61, 3};  // TELEPORT_WEST_ARDOUGNE
    constexpr SpellDef LESSER_CORRUPTION         = {0x00da00b4, 1, 64, 3};
    constexpr SpellDef HARMONY_ISLAND_TELEPORT   = {0x00da00a6, 1, 65, 3};  // TELEPORT_HARMONY_ISLAND
    constexpr SpellDef VILE_VIGOUR               = {0x00da00ba, 1, 66, 3};
    constexpr SpellDef DEGRIME                   = {0x00da00b8, 1, 70, 3};
    constexpr SpellDef CEMETERY_TELEPORT         = {0x00da00a7, 1, 71, 3};  // TELEPORT_CEMETERY
    constexpr SpellDef EXPERT_REANIMATION        = {0x00da009d, 1, 72, 3};  // REANIMATION_EXPERT
    constexpr SpellDef WARD_OF_ARCEUUS           = {0x00da00b3, 1, 73, 3};
    constexpr SpellDef RESURRECT_GREATER_GHOST   = {0x00da00c3, 1, 76, 3};
    constexpr SpellDef RESURRECT_GREATER_SKELETON = {0x00da00c4, 1, 76, 3};
    constexpr SpellDef RESURRECT_GREATER_ZOMBIE  = {0x00da00c5, 1, 76, 3};
    constexpr SpellDef RESURRECT_CROPS           = {0x00da00a8, 1, 78, 3};
    constexpr SpellDef UNDEAD_GRASP              = {0x00da00b2, 1, 79, 3};
    constexpr SpellDef DEATH_CHARGE              = {0x00da00bc, 1, 80, 3};
    constexpr SpellDef DARK_DEMONBANE            = {0x00da00ae, 1, 82, 3};
    constexpr SpellDef BARROWS_TELEPORT          = {0x00da00a9, 1, 83, 3};  // TELEPORT_BARROWS
    constexpr SpellDef DEMONIC_OFFERING          = {0x00da00b6, 1, 84, 3};
    constexpr SpellDef GREATER_CORRUPTION        = {0x00da00b5, 1, 85, 3};
    constexpr SpellDef APE_ATOLL_TELEPORT_ARCEUUS = {0x00da00aa, 1, 90, 3};  // TELEPORT_APE_ATOLL_DUNGEON
    constexpr SpellDef MASTER_REANIMATION        = {0x00da009e, 1, 90, 3};  // REANIMATION_MASTER
    constexpr SpellDef SUPERIOR_DEMONBANE        = {0x00da00ad, 1, 92, 3};
    constexpr SpellDef SINISTER_OFFERING         = {0x00da00b7, 1, 92, 3};

} // namespace Spell

} // namespace obsidian::api
