#pragma once
/// @file walker.h
/// @brief World pathfinding and navigation API.
///
/// Usage:
/// @code
///   namespace walker = obsidian::api::walker;
///   walker::walk_to({3164, 3487, 0}); // Grand Exchange
///   walker::walk_to_bank();
///   if (!walker::is_walking()) { /* arrived */ }
/// @endcode
///
/// The walk itself is asynchronous: the path is calculated on a background
/// thread and then followed one step per game tick. `walk_to` only reports
/// whether the request was accepted, so anything that wants to know how the
/// trip is going reads `status()`, `is_calculating()`, `path_step()` and
/// `path_transports()`.

#include <obsidian/api/coords.h>
#include <cstdint>
#include <string>
#include <vector>

namespace obsidian::api::walker {

// ── Routing options ─────────────────────────────────────────────────────

/// Tri-state override for a per-call routing flag.
///
/// `Inherit` uses the tab's walker settings (what the Obsidian config UI
/// writes); `Yes`/`No` override them for this walk only and never persist.
enum class Tri : int8_t {
    Inherit = -1,
    No      = 0,
    Yes     = 1,
};

/// Per-call routing configuration for `walk_to`.
///
/// Everything defaults to `Inherit`, so a default-constructed `WalkOptions`
/// behaves exactly like the no-options overload.
struct WalkOptions {
    Tri use_teleports           = Tri::Inherit;
    Tri use_transports          = Tri::Inherit;
    Tri avoid_wilderness        = Tri::Inherit;
    Tri use_poh                 = Tri::Inherit;
    Tri use_minigame_teleports  = Tri::Inherit;
    Tri bank_for_teleports      = Tri::Inherit;

    /// How close counts as arrived, in tiles.
    ///
    /// The default of 3 is the walker's long-standing behaviour. Raise it to
    /// stop early (e.g. "get me near the bank"), or set it to 0 to insist on
    /// the exact destination tile.
    ///
    /// **0 is strict.** It also disables the "within two nodes of the path
    /// end" fallback that normally ends a walk, so if the final tile cannot
    /// actually be stood on the walker will keep trying rather than settling
    /// nearby. Use it only for tiles you know are reachable.
    int32_t arrival_radius = 3;
};

// ── Transports ──────────────────────────────────────────────────────────

/// What kind of transport a path hop uses. Mirrors the engine's transport
/// graph; `None` means an ordinary walking step.
enum class TransportKind : int32_t {
    None         = -1,
    Object       = 0,   ///< Door, staircase, ladder — interact with a scene object.
    Npc,                ///< Talk to an NPC (boat captain, …).
    ItemUse,            ///< Use an item on something.
    SlashWeb,           ///< Slash a web (needs a slashing weapon).
    Dig,                ///< Dig with a spade.
    Walk,               ///< Collision override (quest barriers).
    FairyRing,          ///< Dial a code and confirm.
    SpiritTree,         ///< Pick the destination from the tree's menu.
    GnomeGlider,        ///< Talk to the pilot, click the destination.
    CharterShip,        ///< Talk to a crewmember, pick the port. Costs gold.
    Minecart,           ///< Lovakengj minecart.
    Obelisk,            ///< Wilderness obelisk.
    Mushtree,           ///< Fossil Island mushtree.
    BirdTravel,         ///< Varlamore quetzal.

    /// A teleport (spell, tab, jewellery, POH, minigame).
    ///
    /// Deliberately far from the values above: everything else mirrors the
    /// engine's transport graph 1:1, but a teleport is not a graph edge — it is
    /// a path START POINT, cast from wherever you happen to be. The gap keeps
    /// the graph values free to grow without colliding.
    Teleport = 100,
};

/// One transport the current path routes through.
struct PathTransport {
    TransportKind kind = TransportKind::None;
    /// Where the transport is boarded. **Zeroed for `Teleport`** — a teleport is
    /// cast from wherever you are, so it has no fixed source tile.
    WorldPoint  from{};
    WorldPoint  to{};            ///< Where it lands.
    std::string name;            ///< Human-readable label from the transport graph.
    std::string action;          ///< Action or destination string ("Climb-up", "BKR", …).
    int32_t     object_id = -1;  ///< Object/NPC id interacted with, or -1.
    int32_t     gold_cost = 0;   ///< Charter ships only; 0 otherwise.
};

/// The teleport a route opens with, if any.
///
/// A route that teleports does so FIRST — the teleport is the path's start
/// point — so this is the hop that happens before any walking.
struct TeleportInfo {
    /// False when the current route uses no teleport. Every other field is then
    /// meaningless.
    bool        pending = false;
    std::string name;             ///< "Varrock Teleport", "Glory (Edgeville)", …
    WorldPoint  destination{};    ///< Where it lands.
    int32_t     cost = 0;         ///< Planner's cost estimate, in ticks.
    bool        is_poh = false;       ///< Routes via the player-owned house.
    bool        is_minigame = false;  ///< Minigame teleport (grouping/cooldown rules).
};

// ── Walking ─────────────────────────────────────────────────────────────

/// Walk to a world tile. Calculates path asynchronously, then walks
/// step-by-step on each game tick. Call once — the walker handles execution.
///
/// @return Whether the walk was accepted. **False means nothing was started**,
///         for one of two reasons: no walker engine is bound to this tab, or
///         the engine refused because a path calculation is already in flight
///         (or world data is still loading) — `status()` says which.
///
///         Issuing a second `walk_to` before the first has finished
///         calculating is the common case: the second is dropped and returns
///         false. Check the return rather than assuming the newest call wins.
///
///         True says the walk was accepted, not that it will succeed — it says
///         nothing about whether a path exists or the destination is
///         reachable. Poll `is_walking()`, `status()` and `current_path()`.
bool walk_to(const WorldPoint& destination);

/// Walk to a world tile with per-call routing options.
///
/// The options apply to this walk only; the tab's saved settings are left
/// alone. Same return contract as the plain overload.
///
/// @code
///   walker::WalkOptions opts;
///   opts.use_teleports  = walker::Tri::No;   // stay on foot
///   opts.arrival_radius = 8;                 // near enough
///   walker::walk_to({3164, 3487, 0}, opts);
/// @endcode
bool walk_to(const WorldPoint& destination, const WalkOptions& options);

/// Walk to the nearest bank.
/// @return Same contract as `walk_to`.
bool walk_to_bank();

/// Stop walking and clear the current path.
void stop();

/// True if the walker is currently following a path.
bool is_walking();

/// Current calculated path (empty if not walking).
std::vector<WorldPoint> current_path();

/// Calculate a path without walking it. Blocks until complete.
/// Returns empty vector if no path found.
std::vector<WorldPoint> calculate_path(const WorldPoint& destination);

// ── Progress and diagnostics ────────────────────────────────────────────

/// Last thing the walker did or failed to do, as human-readable text. Empty
/// before the first walk. This is the single most useful thing to log when a
/// walk misbehaves.
///
/// It tracks execution, not just pathfinding, so it names what the walker is
/// currently stuck on:
/// - `"Path: 63 tiles, cost 62, 36ms"` — a route was found
/// - `"No path to (x,y,p) after Nms"` — none exists
/// - `"Using fairy ring DKR..."` — a transport is being performed
/// - `"fairy ring DKR did not complete - rerouting"` — it timed out
/// - `"Fairy ring: no Dramen/Lunar staff"` — why it could not be performed
/// - `"Teleporting: Varrock Teleport"` / `"... failed - routing on foot"`
/// - `"Off-path - recalculating"` — ended up somewhere the path does not go
/// - `"Arrived"` — finished
///
/// Pair it with `status_ok()`: the failure lines above report false, and a
/// false status while `!is_walking()` means the walk gave up.
std::string status();

/// Whether the last status was a success rather than a failure.
/// `!status_ok()` with `!is_walking()` means the walk gave up; `status()` says why.
bool status_ok();

/// True while a path is being computed on the background thread. A walk that
/// has been accepted but has not started moving yet is normally just this.
bool is_calculating();

/// True while the shared collision map / transport graph is still loading.
/// The first walk of a session waits on this.
bool is_loading();

/// How far along `current_path()` the walker is, as an index into it.
/// 0 when not walking.
int32_t path_step();

/// The tile the walker is currently heading for. Zeroed before the first walk.
WorldPoint destination();

/// Everything non-walking the current route does, in the order it happens.
/// Empty for a path that is pure walking, and empty when not walking.
///
/// Use this to see *how* the walker intends to cross a region — whether it is
/// about to spend gold on a charter ship, needs a Dramen staff for a fairy
/// ring, or is walking a route you would rather it teleported.
///
/// If the route teleports, that hop is the FIRST entry, with
/// `kind == TransportKind::Teleport` and a zeroed `from` (it is cast from
/// wherever you are). `pending_teleport()` returns the same hop with the extra
/// detail — cost, POH/minigame flags — that does not fit this struct.
std::vector<PathTransport> path_transports();

/// The teleport the current route opens with, if any.
///
/// `pending` is false when the route is transports-and-walking only. This is
/// the same hop that leads `path_transports()`, with more detail.
TeleportInfo pending_teleport();

/// Number of transports in the loaded transport graph. A sanity check that the
/// walker's world data actually loaded; 0 means it has not (see `is_loading()`).
int32_t loaded_transport_count();

} // namespace obsidian::api::walker
