#pragma once
/// @file highlight_channels.h
/// @brief Central allocation of native GPU highlight channels.
///
/// The native highlight system (see api::highlight_channel_configure) lets
/// up to 32 channels render simultaneously per category (NPC/Obj/Tile).
/// Each entry's `channels` bitmask can set multiple bits, so multiple
/// plugins can highlight the same entity on different channels and the
/// GPU will draw ALL of them at once.
///
/// To prevent plugin collisions, each plugin must use its own dedicated
/// channel. This file is the single source of truth.
///
/// **Game-reserved channels (DO NOT USE):** 2, 4, 10, 11, 12 — the game
/// itself configures these for quest markers, bounty hints, agility
/// course highlights, etc.

#include <cstdint>

namespace obsidian::api {

/// Channel allocation for built-in plugins. User plugins that need their
/// own channel should pick from the USER_PLUGIN_* range below.
enum class HighlightChannel : int32_t {
    QUEST_HELPER   = 1,
    NPC_HIGHLIGHT  = 3,

    // Reserved for future built-in plugins (stay clear of 2/4/10/11/12).
    USER_PLUGIN_1  = 5,
    USER_PLUGIN_2  = 6,
    USER_PLUGIN_3  = 7,
    USER_PLUGIN_4  = 8,
    USER_PLUGIN_5  = 9,
    USER_PLUGIN_6  = 13,
    USER_PLUGIN_7  = 14,
    USER_PLUGIN_8  = 15,
};

/// Category indexes for highlight_channel_configure.
enum class HighlightCategory : int32_t {
    NPC      = 0,
    NPC_TYPE = 1,
    OBJ      = 2,
    OBJ_TYPE = 3,
    TILE     = 4,
    PLAYER   = 5,
    // 6/7/8 exist in the manager (Reg1/Reg2/Reg3) but aren't typically
    // end-user addressable.
};

constexpr int32_t to_int(HighlightChannel c) { return static_cast<int32_t>(c); }
constexpr int32_t to_int(HighlightCategory c) { return static_cast<int32_t>(c); }

/// Convert an ImGui ImU32 (ABGR: R in low byte) to the 0xRRGGBB format
/// `highlight_channel_configure` expects (R in top byte). Without this
/// swap, cyan renders as yellow, red as blue, etc.
constexpr uint32_t imu32_to_rgb(uint32_t abgr) {
    return ((abgr & 0xFFu) << 16)       // R: low byte → top of 24
         |  (abgr & 0xFF00u)             // G stays
         | ((abgr >> 16) & 0xFFu);       // B: top byte → bottom
}

} // namespace obsidian::api
