#pragma once
/// @file world_map.h
/// @brief World map viewport queries — screen <-> world conversion.
///
/// The world->screen direction has existed core-side for a while (it positions the quest
/// helper's marker on the map). This exposes the same viewport to host-side callers and
/// adds the inverse, so a click on the map can be turned into a destination:
///
/// @code
///   if (auto p = obsidian::api::world_map::screen_to_world(mouse_x, mouse_y))
///       obsidian::api::walker::walk_to(*p);
/// @endcode
///
/// Every function returns nullopt / false when the map is shut or its state is not
/// readable. Callers MUST honour that: the underlying centre is only refreshed while the
/// map is open, so acting on a stale reading would walk to wherever the map was last
/// looking rather than where the player clicked.

#include <obsidian/api/coords.h>
#include <cstdint>
#include <optional>

namespace obsidian::api::world_map {

/// Live viewport, as published by core each tick.
struct Viewport {
    WorldPoint centre;              ///< World tile at the centre of the map view.
    float      zoom = 0.f;          ///< Pixels per tile.
    int32_t    x = 0, y = 0;        ///< Map widget rect, screen space.
    int32_t    w = 0, h = 0;
};


} // namespace obsidian::api::world_map
