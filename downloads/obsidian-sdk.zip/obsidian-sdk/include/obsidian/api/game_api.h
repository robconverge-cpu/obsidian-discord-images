#pragma once
/// @file game_api.h
/// @brief High-level game access — the primary API surface for plugin authors.
/// @ingroup core
// ═══════════════════════════════════════════════════════════════════════════
// GAME API — High-level game access for plugins
// ═══════════════════════════════════════════════════════════════════════════
// Provides RuneLite Client-equivalent methods for plugins to read game state.
// All methods are safe to call from any thread (uses cached/atomic reads).
//
// This is a facade header — it includes all domain-specific sub-headers so
// existing consumers that #include <obsidian/api/game_api.h> continue to
// compile unchanged. New code can include just the domain it needs.
// ═══════════════════════════════════════════════════════════════════════════

// Domain-specific sub-headers (split from this file)
#include <obsidian/api/client.h>
#include <obsidian/api/local_player.h>
#include <obsidian/api/npcs.h>
#include <obsidian/api/objects_api.h>
#include <obsidian/api/players.h>
#include <obsidian/api/ground_items.h>
#include <obsidian/api/movement.h>
#include <obsidian/api/magic.h>
#include <obsidian/api/widgets.h>
#include <obsidian/api/projectiles.h>
#include <obsidian/api/walker.h>
#include <obsidian/api/menu.h>
#include <obsidian/api/local_player_api.h>
#include <obsidian/api/scene_api.h>
#include <obsidian/api/interaction_api.h>
#include <obsidian/api/container_api.h>
#include <obsidian/api/camera_api.h>
#include <obsidian/api/definitions_api.h>
#include <obsidian/api/highlight_api.h>
#include <obsidian/api/config.h>
#include <obsidian/api/model_api.h>
#include <obsidian/api/item_helpers_api.h>
#include <obsidian/api/entity_handle.h>

// Types and functions that remain in game_api.h because they don't
// fit cleanly into a single domain or are too tightly coupled to move.

#include <cstdint>
#include <string>
#include <vector>
#include <functional>

namespace obsidian::api {

/// @name Widgets
/// Widget addresses are returned as raw pointers. Use WidgetRef for safe field access.
/// @{

/// Lightweight widget accessor returned by widgets::get().
/// Works from both core (reads via ptr) and host (reads from stored data).
struct WidgetRef {
    uintptr_t ptr = 0;

    // Stored data (populated from IPC for host-side plugins)
    struct {
        bool populated = false;
        int32_t id = 0, parent_id = 0, type = 0, child_index = 0;
        int32_t relative_x = 0, relative_y = 0, width = 0, height = 0;
        bool is_hidden = false;
        char text[64] = {};
        char name[32] = {};
        int32_t item_id = -1, item_quantity = 0, sprite_id = -1, model_id = -1;
        int32_t content_type = 0;
        int32_t opacity = 0;
        int32_t color = 0;
        int32_t font_id = 0;
        bool text_shadowed = false;
        int32_t text_x_align = 0, text_y_align = 0, text_line_height = 0;
        int32_t model_type = -1;
        int32_t model_zoom = 0;
        int32_t model_angle_x = 0, model_angle_y = 0, model_angle_z = 0;
        int32_t sequence_id = -1;
        int32_t x_alignment = 0, y_alignment = 0;
        int32_t raw_x = 0, raw_y = 0, raw_width = 0, raw_height = 0;
        int32_t scroll_width = 0, scroll_height = 0;
        int32_t button_type = 0;
        bool is_if3 = false;
        int32_t dyn_child_count = 0;
        char actions[10][24] = {};
    } data;

    /// True if this ref points at a real widget (live ptr or populated IPC data).
    bool valid() const { return ptr > 0x10000 || data.populated; }

    // Field accessors (core reads from ptr, host reads from data)
    /// Packed widget ID (group << 16 | child).
    int32_t id() const;
    /// Parent widget's packed ID (-1 = root/top-level).
    int32_t parent_id() const;
    /// Widget type code.
    int32_t type() const;
    /// Index of this widget within its parent's child array.
    int32_t child_index() const;
    /// X position relative to the parent widget.
    int32_t relative_x() const;
    /// Y position relative to the parent widget.
    int32_t relative_y() const;
    /// Widget width in pixels.
    int32_t width() const;
    /// Widget height in pixels.
    int32_t height() const;
    /// True if the widget is currently hidden.
    bool is_hidden() const;
    /// Widget text content.
    std::string text() const;
    /// Item definition ID shown in the widget (-1 = none).
    int32_t item_id() const;
    /// Item stack size shown in the widget.
    int32_t item_quantity() const;
    /// Sprite/graphic ID shown in the widget (-1 = none).
    int32_t sprite_id() const;
    /// Model ID shown in the widget (-1 = none).
    int32_t model_id() const;

    // New accessors
    std::string name() const;               ///< Widget name / DataText (EASTL string).
    int32_t content_type() const;           ///< Content type field.
    int32_t opacity() const;                ///< Widget opacity (0 = opaque, 255 = transparent).
    int32_t color() const;                  ///< Widget text/fill color (RGB packed).
    int32_t font_id() const;                ///< Font ID for text widgets.
    bool text_shadowed() const;             ///< Whether text has a shadow.
    int32_t text_x_align() const;           ///< Horizontal text alignment.
    int32_t text_y_align() const;           ///< Vertical text alignment.
    int32_t text_line_height() const;       ///< Line height for multi-line text.
    int32_t model_type() const;             ///< Model type (NPC/player/item model source).
    int32_t model_zoom() const;             ///< Model zoom level.
    int32_t model_angle_x() const;          ///< Model rotation around X axis.
    int32_t model_angle_y() const;          ///< Model rotation around Y axis.
    int32_t model_angle_z() const;          ///< Model rotation around Z axis.
    int32_t sequence_id() const;            ///< Animation sequence playing on the widget model.
    int32_t x_alignment() const;            ///< Horizontal position mode (0=abs, 1=prop, etc.).
    int32_t y_alignment() const;            ///< Vertical position mode.
    int32_t raw_x() const;                  ///< Original X before layout.
    int32_t raw_y() const;                  ///< Original Y before layout.
    int32_t raw_width() const;              ///< Original width before layout.
    int32_t raw_height() const;             ///< Original height before layout.
    int32_t scroll_width() const;           ///< Scrollable content width.
    int32_t scroll_height() const;          ///< Scrollable content height.
    int32_t button_type() const;            ///< Button type field.
    bool is_if3() const;                    ///< True if this is an IF3 widget (modern interface).
    bool no_click_through() const;          ///< True if clicks don't pass through this widget.
    int32_t dynamic_child_count() const;    ///< Number of dynamic children.
    std::vector<std::string> actions() const; ///< Up to 10 right-click action strings.

    // Navigation
    WidgetRef get_parent() const;                         ///< Resolve parent widget from parent_id().
    std::vector<WidgetRef> get_dynamic_children() const;  ///< All dynamic children of this widget.
    int32_t absolute_x() const;                           ///< X position accumulated through parent chain.
    int32_t absolute_y() const;                           ///< Y position accumulated through parent chain.

    // Children
    /// Resolve a direct child widget by its child index.
    WidgetRef get_child(int32_t child_index) const;
};

/// Widget lookups, clicks, screen positions and text live in
/// <obsidian/api/widgets.h> (namespace widgets::). Chat is
/// client::add_chat_message; menu entries are menu::create_entry.
/// @}

} // namespace obsidian::api
