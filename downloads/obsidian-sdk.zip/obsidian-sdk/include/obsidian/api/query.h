/// @file query.h
/// @brief Fluent query builders for NPCs, objects, players, and ground items.
///
/// Mirrors the cuell-plugins query pattern. Each query starts from a
/// snapshot of all visible entities and chains filters until a terminal
/// (first/nearest/all/count) is called.
///
/// Usage:
/// @code
///   auto banker = npcs().named("Banker").within(10).alive().nearest();
///   auto tree   = objects().named("Oak tree").action("Chop down").nearest();
///   auto loot   = ground_items().within(5).all();
///   auto enemy  = npcs().id(3162).alive().not_interacting().first();
/// @endcode
#pragma once

#include <obsidian/api/game_api.h>
#include <obsidian/api/npcs.h>
#include <obsidian/api/objects_api.h>
#include <obsidian/api/players.h>
#include <obsidian/api/ground_items.h>
#include <obsidian/api/local_player.h>
#include <algorithm>
#include <cstdint>
#include <functional>
#include <optional>
#include <string>
#include <vector>

namespace obsidian::api {

// ════════════════════════════════════════════════════════════════════════
// NpcQuery
// ════════════════════════════════════════════════════════════════════════

class NpcQuery {
    std::vector<SceneNpc> npcs_;
public:
    explicit NpcQuery(std::vector<SceneNpc> npcs) : npcs_(std::move(npcs)) {}

    /// Filter by NPC definition ID.
    NpcQuery& id(int32_t npc_id) {
        npcs_.erase(std::remove_if(npcs_.begin(), npcs_.end(),
            [npc_id](const SceneNpc& n) { return n.npc_id != npc_id; }), npcs_.end());
        return *this;
    }

    /// Filter by multiple IDs (match any).
    NpcQuery& id(std::initializer_list<int32_t> ids) {
        npcs_.erase(std::remove_if(npcs_.begin(), npcs_.end(),
            [&ids](const SceneNpc& n) {
                for (int32_t id : ids) if (n.npc_id == id) return false;
                return true;
            }), npcs_.end());
        return *this;
    }

    /// Filter by name (case-insensitive substring).
    NpcQuery& named(const std::string& name) {
        npcs_.erase(std::remove_if(npcs_.begin(), npcs_.end(),
            [&name](const SceneNpc& n) {
                return n.name.find(name) == std::string::npos &&
                    std::search(n.name.begin(), n.name.end(), name.begin(), name.end(),
                        [](char a, char b) {
                            return std::tolower(static_cast<unsigned char>(a)) ==
                                   std::tolower(static_cast<unsigned char>(b));
                        }) == n.name.end();
            }), npcs_.end());
        return *this;
    }

    /// Filter: only alive NPCs (health_percent > 0 or no health bar).
    NpcQuery& alive() {
        npcs_.erase(std::remove_if(npcs_.begin(), npcs_.end(),
            [](const SceneNpc& n) { return n.health_percent == 0.0f; }), npcs_.end());
        return *this;
    }

    /// Filter: within N tiles of the local player.
    NpcQuery& within(int32_t distance) {
        auto loc = local_player::world_location();
        npcs_.erase(std::remove_if(npcs_.begin(), npcs_.end(),
            [&loc, distance](const SceneNpc& n) {
                return n.location.distance_to(loc) > distance;
            }), npcs_.end());
        return *this;
    }

    /// Filter: within N tiles of a specific point.
    NpcQuery& within(const WorldPoint& point, int32_t distance) {
        npcs_.erase(std::remove_if(npcs_.begin(), npcs_.end(),
            [&point, distance](const SceneNpc& n) {
                return n.location.distance_to(point) > distance;
            }), npcs_.end());
        return *this;
    }

    /// Filter: NPC has a specific action.
    NpcQuery& action(const std::string& action_name) {
        npcs_.erase(std::remove_if(npcs_.begin(), npcs_.end(),
            [&action_name](const SceneNpc& n) {
                auto* def = definitions::npc(n.npc_id);
                if (!def) return true;
                for (auto& a : def->actions)
                    if (!a.empty() && a.find(action_name) != std::string::npos) return false;
                return true;
            }), npcs_.end());
        return *this;
    }

    /// Filter: NPC is interacting with something.
    NpcQuery& interacting() {
        npcs_.erase(std::remove_if(npcs_.begin(), npcs_.end(),
            [](const SceneNpc& n) { return n.interacting_index < 0; }), npcs_.end());
        return *this;
    }

    /// Filter: NPC is NOT interacting.
    NpcQuery& not_interacting() {
        npcs_.erase(std::remove_if(npcs_.begin(), npcs_.end(),
            [](const SceneNpc& n) { return n.interacting_index >= 0; }), npcs_.end());
        return *this;
    }

    /// Filter: NPC has a combat level.
    NpcQuery& has_combat_level() {
        npcs_.erase(std::remove_if(npcs_.begin(), npcs_.end(),
            [](const SceneNpc& n) { return n.combat_level <= 0; }), npcs_.end());
        return *this;
    }

    /// Filter by custom predicate.
    NpcQuery& filter(std::function<bool(const SceneNpc&)> pred) {
        npcs_.erase(std::remove_if(npcs_.begin(), npcs_.end(),
            [&pred](const SceneNpc& n) { return !pred(n); }), npcs_.end());
        return *this;
    }

    // ── Terminals ───────────────────────────────────────────────────

    /// Get the first matching NPC.
    std::optional<SceneNpc> first() const {
        return npcs_.empty() ? std::nullopt : std::optional<SceneNpc>(npcs_.front());
    }

    /// Get the nearest matching NPC to the local player.
    std::optional<SceneNpc> nearest() const {
        if (npcs_.empty()) return std::nullopt;
        auto loc = local_player::world_location();
        auto it = std::min_element(npcs_.begin(), npcs_.end(),
            [&loc](const SceneNpc& a, const SceneNpc& b) {
                return a.location.distance_to(loc) < b.location.distance_to(loc);
            });
        return *it;
    }

    /// Get the nearest matching NPC to a specific point.
    std::optional<SceneNpc> nearest(const WorldPoint& point) const {
        if (npcs_.empty()) return std::nullopt;
        auto it = std::min_element(npcs_.begin(), npcs_.end(),
            [&point](const SceneNpc& a, const SceneNpc& b) {
                return a.location.distance_to(point) < b.location.distance_to(point);
            });
        return *it;
    }

    /// Get all matching NPCs.
    const std::vector<SceneNpc>& all() const { return npcs_; }

    /// Count matching NPCs.
    int32_t count() const { return static_cast<int32_t>(npcs_.size()); }

    /// True if any NPC matches.
    bool exists() const { return !npcs_.empty(); }
};

// ════════════════════════════════════════════════════════════════════════
// ObjectQuery
// ════════════════════════════════════════════════════════════════════════

class ObjectQuery {
    std::vector<SceneObject> objects_;
public:
    explicit ObjectQuery(std::vector<SceneObject> objects) : objects_(std::move(objects)) {}

    ObjectQuery& id(int32_t obj_id) {
        objects_.erase(std::remove_if(objects_.begin(), objects_.end(),
            [obj_id](const SceneObject& o) { return o.id != obj_id; }), objects_.end());
        return *this;
    }

    ObjectQuery& id(std::initializer_list<int32_t> ids) {
        objects_.erase(std::remove_if(objects_.begin(), objects_.end(),
            [&ids](const SceneObject& o) {
                for (int32_t id : ids) if (o.id == id) return false;
                return true;
            }), objects_.end());
        return *this;
    }

    ObjectQuery& named(const std::string& name) {
        objects_.erase(std::remove_if(objects_.begin(), objects_.end(),
            [&name](const SceneObject& o) {
                auto* def = definitions::object(o.id);
                if (!def) return true;
                return std::search(def->name.begin(), def->name.end(), name.begin(), name.end(),
                    [](char a, char b) {
                        return std::tolower(static_cast<unsigned char>(a)) ==
                               std::tolower(static_cast<unsigned char>(b));
                    }) == def->name.end();
            }), objects_.end());
        return *this;
    }

    ObjectQuery& action(const std::string& action_name) {
        objects_.erase(std::remove_if(objects_.begin(), objects_.end(),
            [&action_name](const SceneObject& o) {
                auto* def = definitions::object(o.id);
                if (!def) return true;
                for (auto& a : def->actions)
                    if (!a.empty() && a.find(action_name) != std::string::npos) return false;
                return true;
            }), objects_.end());
        return *this;
    }

    ObjectQuery& within(int32_t distance) {
        auto loc = local_player::world_location();
        objects_.erase(std::remove_if(objects_.begin(), objects_.end(),
            [&loc, distance](const SceneObject& o) {
                return o.location.distance_to(loc) > distance;
            }), objects_.end());
        return *this;
    }

    ObjectQuery& within(const WorldPoint& point, int32_t distance) {
        objects_.erase(std::remove_if(objects_.begin(), objects_.end(),
            [&point, distance](const SceneObject& o) {
                return o.location.distance_to(point) > distance;
            }), objects_.end());
        return *this;
    }

    ObjectQuery& filter(std::function<bool(const SceneObject&)> pred) {
        objects_.erase(std::remove_if(objects_.begin(), objects_.end(),
            [&pred](const SceneObject& o) { return !pred(o); }), objects_.end());
        return *this;
    }

    std::optional<SceneObject> first() const {
        return objects_.empty() ? std::nullopt : std::optional<SceneObject>(objects_.front());
    }

    std::optional<SceneObject> nearest() const {
        if (objects_.empty()) return std::nullopt;
        auto loc = local_player::world_location();
        auto it = std::min_element(objects_.begin(), objects_.end(),
            [&loc](const SceneObject& a, const SceneObject& b) {
                return a.location.distance_to(loc) < b.location.distance_to(loc);
            });
        return *it;
    }

    const std::vector<SceneObject>& all() const { return objects_; }
    int32_t count() const { return static_cast<int32_t>(objects_.size()); }
    bool exists() const { return !objects_.empty(); }
};

// ════════════════════════════════════════════════════════════════════════
// PlayerQuery
// ════════════════════════════════════════════════════════════════════════

class PlayerQuery {
    std::vector<ScenePlayer> players_;
public:
    explicit PlayerQuery(std::vector<ScenePlayer> players) : players_(std::move(players)) {}

    PlayerQuery& named(const std::string& name) {
        players_.erase(std::remove_if(players_.begin(), players_.end(),
            [&name](const ScenePlayer& p) {
                return std::search(p.name.begin(), p.name.end(), name.begin(), name.end(),
                    [](char a, char b) {
                        return std::tolower(static_cast<unsigned char>(a)) ==
                               std::tolower(static_cast<unsigned char>(b));
                    }) == p.name.end();
            }), players_.end());
        return *this;
    }

    PlayerQuery& within(int32_t distance) {
        auto loc = local_player::world_location();
        players_.erase(std::remove_if(players_.begin(), players_.end(),
            [&loc, distance](const ScenePlayer& p) {
                return p.location.distance_to(loc) > distance;
            }), players_.end());
        return *this;
    }

    PlayerQuery& friends_only() {
        players_.erase(std::remove_if(players_.begin(), players_.end(),
            [](const ScenePlayer& p) { return p.friend_status == 0; }), players_.end());
        return *this;
    }

    PlayerQuery& non_friends() {
        players_.erase(std::remove_if(players_.begin(), players_.end(),
            [](const ScenePlayer& p) { return p.friend_status != 0; }), players_.end());
        return *this;
    }

    PlayerQuery& fc_members() {
        players_.erase(std::remove_if(players_.begin(), players_.end(),
            [](const ScenePlayer& p) { return p.fc_status != 1; }), players_.end());
        return *this;
    }

    PlayerQuery& clan_members() {
        players_.erase(std::remove_if(players_.begin(), players_.end(),
            [](const ScenePlayer& p) { return p.clan_status != 1; }), players_.end());
        return *this;
    }

    PlayerQuery& filter(std::function<bool(const ScenePlayer&)> pred) {
        players_.erase(std::remove_if(players_.begin(), players_.end(),
            [&pred](const ScenePlayer& p) { return !pred(p); }), players_.end());
        return *this;
    }

    std::optional<ScenePlayer> first() const {
        return players_.empty() ? std::nullopt : std::optional<ScenePlayer>(players_.front());
    }

    std::optional<ScenePlayer> nearest() const {
        if (players_.empty()) return std::nullopt;
        auto loc = local_player::world_location();
        auto it = std::min_element(players_.begin(), players_.end(),
            [&loc](const ScenePlayer& a, const ScenePlayer& b) {
                return a.location.distance_to(loc) < b.location.distance_to(loc);
            });
        return *it;
    }

    const std::vector<ScenePlayer>& all() const { return players_; }
    int32_t count() const { return static_cast<int32_t>(players_.size()); }
    bool exists() const { return !players_.empty(); }
};

// ════════════════════════════════════════════════════════════════════════
// GroundItemQuery
// ════════════════════════════════════════════════════════════════════════

class GroundItemQuery {
    std::vector<GroundItem> items_;
public:
    explicit GroundItemQuery(std::vector<GroundItem> items) : items_(std::move(items)) {}

    GroundItemQuery& id(int32_t item_id) {
        items_.erase(std::remove_if(items_.begin(), items_.end(),
            [item_id](const GroundItem& g) { return g.id != item_id; }), items_.end());
        return *this;
    }

    GroundItemQuery& within(int32_t distance) {
        auto loc = local_player::world_location();
        items_.erase(std::remove_if(items_.begin(), items_.end(),
            [&loc, distance](const GroundItem& g) {
                WorldPoint wp{g.scene_x, g.scene_y, 0};
                return wp.distance_to(loc) > distance;
            }), items_.end());
        return *this;
    }

    GroundItemQuery& filter(std::function<bool(const GroundItem&)> pred) {
        items_.erase(std::remove_if(items_.begin(), items_.end(),
            [&pred](const GroundItem& g) { return !pred(g); }), items_.end());
        return *this;
    }

    std::optional<GroundItem> first() const {
        return items_.empty() ? std::nullopt : std::optional<GroundItem>(items_.front());
    }

    const std::vector<GroundItem>& all() const { return items_; }
    int32_t count() const { return static_cast<int32_t>(items_.size()); }
    bool exists() const { return !items_.empty(); }
};

// ════════════════════════════════════════════════════════════════════════
// Factory functions — entry points for queries
// ════════════════════════════════════════════════════════════════════════

/// Start an NPC query from all visible NPCs.
inline NpcQuery npcs() { return NpcQuery(npcs::find_all()); }

/// Start an object query from all visible game objects.
inline ObjectQuery objects() { return ObjectQuery(objects::find_all_game_objects()); }

/// Start a player query from all visible players (excluding local).
inline PlayerQuery players() { return PlayerQuery(players::find_all()); }

/// Start a ground item query from all visible ground items.
inline GroundItemQuery ground_items() { return GroundItemQuery(ground_items::find_all()); }

} // namespace obsidian::api
