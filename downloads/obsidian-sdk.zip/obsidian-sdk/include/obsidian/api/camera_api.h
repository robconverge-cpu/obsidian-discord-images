#pragma once
/// @file camera_api.h
/// @brief Camera position and rotation queries.
/// @ingroup core
///
/// Split from game_api.h — camera state is independent of entities/interactions.

#include <cstdint>

namespace obsidian::api::camera {

int32_t x();              ///< Camera X position (scene/local coordinate space).
int32_t y();              ///< Camera Y position (scene/local coordinate space).
int32_t z();              ///< Camera Z (height).
int32_t yaw();            ///< Camera horizontal rotation (0-2047).
int32_t pitch();          ///< Camera vertical angle (0-2047).
int32_t target_x();       ///< Camera focus target X.
int32_t target_y();       ///< Camera focus target Y.
float yaw_degrees();      ///< Camera horizontal rotation in degrees (0-360).
float pitch_degrees();    ///< Camera vertical angle in degrees (0-360).

} // namespace obsidian::api::camera
