#pragma once
/// @file coords.h
/// @brief Coordinate system types: WorldPoint, LocalPoint, ScenePoint, WorldArea.
/// @ingroup core
///
/// Mirrors RuneLite's coordinate classes (coords/WorldPoint.java, etc.)
/// with C++ value semantics. Header-only, no dependencies on game memory.
///
/// Conversions between types require a base_x/base_y context (from WorldView).
/// Use the free functions or the convenience methods that take a WorldView ref.

#include <cstdint>
#include <cstdlib>
#include <vector>
#include <optional>

namespace obsidian::api {

// Forward declarations
struct WorldPoint;
struct LocalPoint;
struct ScenePoint;
struct WorldArea;

/// @name Constants
/// @{
constexpr int LOCAL_COORD_BITS   = 7;
constexpr int LOCAL_TILE_SIZE    = 1 << LOCAL_COORD_BITS;  ///< 128 fine units per tile
constexpr int LOCAL_HALF_TILE    = LOCAL_TILE_SIZE / 2;    ///< 64 fine units (tile center offset)
constexpr int SCENE_SIZE         = 104;                    ///< tiles per scene dimension
constexpr int CHUNK_SIZE         = 8;                      ///< tiles per chunk
constexpr int REGION_SIZE        = 64;                     ///< tiles per region
constexpr int CHUNKS_PER_SCENE   = SCENE_SIZE / CHUNK_SIZE; ///< 13 chunks per scene dimension
/// @}

/// @name Instance template chunk — packed int32 bit layout (RuneLite parity)
/// A populated entry encodes the source of a scene chunk: a rotation, the
/// source chunk X/Y (in CHUNK units), and the source plane. Empty == -1.
/// These are the canonical shifts/masks shared by the packer
/// and the decoder (WorldPoint::from/to_local_instance).
/// @{
constexpr int TEMPLATE_ROTATION_SHIFT = 1;
constexpr int TEMPLATE_ROTATION_MASK  = 0x3;
constexpr int TEMPLATE_CHUNK_Y_SHIFT  = 3;
constexpr int TEMPLATE_CHUNK_Y_MASK   = 0x7FF;
constexpr int TEMPLATE_CHUNK_X_SHIFT  = 14;
constexpr int TEMPLATE_CHUNK_X_MASK   = 0x3FF;
constexpr int TEMPLATE_PLANE_SHIFT    = 24;
constexpr int TEMPLATE_PLANE_MASK     = 0x3;

/// @brief Pack decoded chunk fields (chunk units) into the RuneLite packed int32.
constexpr int32_t pack_template_chunk(int32_t chunk_x, int32_t chunk_y,
                                      int32_t plane, int32_t rotation) {
    return ((rotation & TEMPLATE_ROTATION_MASK) << TEMPLATE_ROTATION_SHIFT)
         | ((chunk_y  & TEMPLATE_CHUNK_Y_MASK)  << TEMPLATE_CHUNK_Y_SHIFT)
         | ((chunk_x  & TEMPLATE_CHUNK_X_MASK)  << TEMPLATE_CHUNK_X_SHIFT)
         | ((plane    & TEMPLATE_PLANE_MASK)    << TEMPLATE_PLANE_SHIFT);
}
/// @}

/// @name WorldPoint
/// @{

/// @brief Absolute world tile coordinate plus plane. Equivalent to RuneLite WorldPoint.
struct WorldPoint {
    int32_t x     = 0; ///< World tile X coordinate
    int32_t y     = 0; ///< World tile Y coordinate
    int32_t plane = 0; ///< Map plane (0-3)

    /// @brief Default-construct at origin.
    constexpr WorldPoint() = default;
    /// @brief Construct from explicit coordinates.
    constexpr WorldPoint(int32_t x_, int32_t y_, int32_t plane_ = 0) : x(x_), y(y_), plane(plane_) {}

    /// @brief Return a point offset by @p d tiles along the X axis.
    constexpr WorldPoint dx(int32_t d) const { return {x + d, y, plane}; }
    /// @brief Return a point offset by @p d tiles along the Y axis.
    constexpr WorldPoint dy(int32_t d) const { return {x, y + d, plane}; }
    /// @brief Return a point offset by @p d planes along the Z axis.
    constexpr WorldPoint dz(int32_t d) const { return {x, y, plane + d}; }

    /// @brief Compute Chebyshev distance (max of dx, dy) to another point.
    /// @return Distance in tiles, or -1 if planes differ.
    int32_t distance_to(const WorldPoint& other) const {
        if (plane != other.plane) return -1;
        return std::max(std::abs(x - other.x), std::abs(y - other.y));
    }

    /// @brief Compute 2D Chebyshev distance, ignoring plane.
    int32_t distance_to_2d(const WorldPoint& other) const {
        return std::max(std::abs(x - other.x), std::abs(y - other.y));
    }

    /// @brief Get the packed region ID for this point.
    int32_t region_id() const { return ((x >> 6) << 8) | (y >> 6); }
    /// @brief Get the region X index.
    int32_t region_x() const { return x >> 6; }
    /// @brief Get the region Y index.
    int32_t region_y() const { return y >> 6; }

    /// @brief Get the chunk X index.
    int32_t chunk_x() const { return x >> 3; }
    /// @brief Get the chunk Y index.
    int32_t chunk_y() const { return y >> 3; }

    /// @brief Check whether this point lies within the current scene.
    bool is_in_scene(int32_t base_x, int32_t base_y) const {
        int sx = x - base_x, sy = y - base_y;
        return sx >= 0 && sx < SCENE_SIZE && sy >= 0 && sy < SCENE_SIZE;
    }

    /// @brief Convert this point to a 1x1 WorldArea.
    WorldArea to_world_area() const; // defined after WorldArea

    /// @brief Equality comparison.
    constexpr bool operator==(const WorldPoint& o) const { return x == o.x && y == o.y && plane == o.plane; }
    /// @brief Inequality comparison.
    constexpr bool operator!=(const WorldPoint& o) const { return !(*this == o); }

    /// @brief Convert to scene tile coordinates given the scene base.
    inline ScenePoint to_scene(int32_t base_x, int32_t base_y) const;

    /// @brief Construct a WorldPoint from scene tile coordinates plus base.
    static constexpr WorldPoint from_scene(int32_t scene_x, int32_t scene_y, int32_t base_x, int32_t base_y, int32_t plane = 0) {
        return {base_x + scene_x, base_y + scene_y, plane};
    }

    /// @brief Construct a WorldPoint from local (fine) coordinates plus base.
    static constexpr WorldPoint from_local(int32_t local_x, int32_t local_y, int32_t base_x, int32_t base_y, int32_t plane = 0) {
        return {base_x + (local_x >> LOCAL_COORD_BITS), base_y + (local_y >> LOCAL_COORD_BITS), plane};
    }

    /// @brief Construct a WorldPoint from a region ID plus local position within the region.
    static constexpr WorldPoint from_region(int32_t region_id, int32_t region_local_x, int32_t region_local_y, int32_t plane = 0) {
        int rx = (region_id >> 8) & 0xFF;
        int ry = region_id & 0xFF;
        return {rx * REGION_SIZE + region_local_x, ry * REGION_SIZE + region_local_y, plane};
    }

    /// @brief Construct a WorldPoint from a packed coordinate (used in some protocol messages).
    static constexpr WorldPoint from_coord(int32_t packed) {
        return {(packed >> 14) & 0x3FFF, packed & 0x3FFF, (packed >> 28) & 0x3};
    }

    /// @brief Resolve a local point to a world point accounting for instances.
    /// In instanced areas, the scene is built from copied template chunks —
    /// this maps the local position back to the template's real world coordinates.
    /// In non-instanced areas, behaves identically to from_local().
    /// @param local_x Fine X coordinate in scene.
    /// @param local_y Fine Y coordinate in scene.
    /// @param plane   Plane level.
    /// @param base_x  Scene base X (world tiles).
    /// @param base_y  Scene base Y (world tiles).
    /// @param instance_template_chunks  4×13×13 chunk template array (nullptr if not instanced).
    ///        Layout: [plane][chunkX][chunkY], each entry is a packed template:
    ///        bits 1-2 = rotation, bits 3-13 = templateChunkY, bits 14-23 = templateChunkX,
    ///        bits 24-25 = templatePlane.
    static WorldPoint from_local_instance(int32_t local_x, int32_t local_y, int32_t plane,
                                          int32_t base_x, int32_t base_y,
                                          const int32_t* instance_template_chunks);

    /// @brief Find all scene occurrences of a world point in an instanced area.
    /// A template chunk can appear multiple times in the scene — this returns
    /// all matching positions. Returns a single-element vector in non-instanced areas.
    static std::vector<WorldPoint> to_local_instance(const WorldPoint& world_point,
                                                     int32_t base_x, int32_t base_y,
                                                     const int32_t* instance_template_chunks);

    /// @brief Convenience: resolve local to world accounting for instances.
    /// Automatically fetches base coords and instance chunks from the API.
    static WorldPoint from_local_instance(const LocalPoint& lp, int32_t plane = 0);

    /// @brief Convenience: find all scene occurrences of a world point.
    /// Automatically fetches base coords and instance chunks from the API.
    static std::vector<WorldPoint> to_local_instance(const WorldPoint& wp);

private:
    /// @brief Rotate a point within its chunk by the given rotation (0-3).
    static constexpr WorldPoint rotate_in_chunk(const WorldPoint& point, int32_t rotation) {
        int32_t cx = point.x & ~(CHUNK_SIZE - 1);
        int32_t cy = point.y & ~(CHUNK_SIZE - 1);
        int32_t lx = point.x & (CHUNK_SIZE - 1);
        int32_t ly = point.y & (CHUNK_SIZE - 1);
        switch (rotation) {
        case 1:  return {cx + ly, cy + (CHUNK_SIZE - 1 - lx), point.plane};
        case 2:  return {cx + (CHUNK_SIZE - 1 - lx), cy + (CHUNK_SIZE - 1 - ly), point.plane};
        case 3:  return {cx + (CHUNK_SIZE - 1 - ly), cy + lx, point.plane};
        default: return point;
        }
    }
};

/// @}

/// @name LocalPoint
/// @{

/// @brief Fine coordinates within the current scene (128 units per tile). Equivalent to RuneLite LocalPoint.
struct LocalPoint {
    int32_t x = 0; ///< Local fine X coordinate
    int32_t y = 0; ///< Local fine Y coordinate

    /// @brief Default-construct at origin.
    constexpr LocalPoint() = default;
    /// @brief Construct from explicit fine coordinates.
    constexpr LocalPoint(int32_t x_, int32_t y_) : x(x_), y(y_) {}

    /// @brief Return a point offset by @p d fine units along the X axis.
    constexpr LocalPoint dx(int32_t d) const { return {x + d, y}; }
    /// @brief Return a point offset by @p d fine units along the Y axis.
    constexpr LocalPoint dy(int32_t d) const { return {x, y + d}; }
    /// @brief Return a point offset by the given fine deltas.
    constexpr LocalPoint plus(int32_t dx_, int32_t dy_) const { return {x + dx_, y + dy_}; }

    /// @brief Get the scene tile X index.
    int32_t scene_x() const { return x >> LOCAL_COORD_BITS; }
    /// @brief Get the scene tile Y index.
    int32_t scene_y() const { return y >> LOCAL_COORD_BITS; }

    /// @brief Compute Chebyshev distance in fine units to another local point.
    int32_t distance_to(const LocalPoint& other) const {
        return std::max(std::abs(x - other.x), std::abs(y - other.y));
    }

    /// @brief Check whether this point lies within the scene bounds.
    bool is_in_scene() const {
        int sx = x >> LOCAL_COORD_BITS, sy = y >> LOCAL_COORD_BITS;
        return sx >= 0 && sx < SCENE_SIZE && sy >= 0 && sy < SCENE_SIZE;
    }

    /// @brief Equality comparison.
    constexpr bool operator==(const LocalPoint& o) const { return x == o.x && y == o.y; }
    /// @brief Inequality comparison.
    constexpr bool operator!=(const LocalPoint& o) const { return !(*this == o); }

    /// @brief Construct a LocalPoint from world coordinates plus base.
    static constexpr LocalPoint from_world(int32_t world_x, int32_t world_y, int32_t base_x, int32_t base_y) {
        return {(world_x - base_x) * LOCAL_TILE_SIZE + LOCAL_HALF_TILE,
                (world_y - base_y) * LOCAL_TILE_SIZE + LOCAL_HALF_TILE};
    }

    /// @brief Construct a LocalPoint from a WorldPoint plus base.
    static constexpr LocalPoint from_world(const WorldPoint& wp, int32_t base_x, int32_t base_y) {
        return from_world(wp.x, wp.y, base_x, base_y);
    }

    /// @brief Construct a LocalPoint from scene tile coordinates (centers on tile).
    static constexpr LocalPoint from_scene(int32_t scene_x, int32_t scene_y) {
        return {scene_x * LOCAL_TILE_SIZE + LOCAL_HALF_TILE,
                scene_y * LOCAL_TILE_SIZE + LOCAL_HALF_TILE};
    }
};

/// @}

/// @name ScenePoint
/// @{

/// @brief Tile coordinates within the scene (0-103). Not in RuneLite but useful for scene indexing.
struct ScenePoint {
    int32_t x = 0; ///< Scene tile X coordinate (0-103)
    int32_t y = 0; ///< Scene tile Y coordinate (0-103)

    /// @brief Default-construct at origin.
    constexpr ScenePoint() = default;
    /// @brief Construct from explicit scene tile coordinates.
    constexpr ScenePoint(int32_t x_, int32_t y_) : x(x_), y(y_) {}

    /// @brief Check whether the coordinates are within the valid scene range.
    constexpr bool is_valid() const { return x >= 0 && x < SCENE_SIZE && y >= 0 && y < SCENE_SIZE; }

    /// @brief Convert to a LocalPoint centered on this tile.
    LocalPoint to_local() const { return LocalPoint::from_scene(x, y); }
    /// @brief Convert to a WorldPoint given the scene base coordinates.
    WorldPoint to_world(int32_t base_x, int32_t base_y, int32_t plane = 0) const {
        return WorldPoint::from_scene(x, y, base_x, base_y, plane);
    }

    /// @brief Construct a ScenePoint from a LocalPoint.
    static constexpr ScenePoint from_local(const LocalPoint& lp) {
        return {lp.x >> LOCAL_COORD_BITS, lp.y >> LOCAL_COORD_BITS};
    }

    /// @brief Construct a ScenePoint from a WorldPoint given the scene base.
    static constexpr ScenePoint from_world(const WorldPoint& wp, int32_t base_x, int32_t base_y) {
        return {wp.x - base_x, wp.y - base_y};
    }

    /// @brief Equality comparison.
    constexpr bool operator==(const ScenePoint& o) const { return x == o.x && y == o.y; }
    /// @brief Inequality comparison.
    constexpr bool operator!=(const ScenePoint& o) const { return !(*this == o); }
};

inline ScenePoint WorldPoint::to_scene(int32_t base_x, int32_t base_y) const {
    return {x - base_x, y - base_y};
}

/// @}

/// @name WorldArea
/// @{

/// @brief Rectangular area in world coordinates. Equivalent to RuneLite WorldArea.
struct WorldArea {
    int32_t x      = 0; ///< Southwest corner X coordinate
    int32_t y      = 0; ///< Southwest corner Y coordinate
    int32_t width  = 1; ///< Width in tiles
    int32_t height = 1; ///< Height in tiles
    int32_t plane  = 0; ///< Map plane (0-3)

    /// @brief Default-construct a 1x1 area at origin.
    constexpr WorldArea() = default;
    /// @brief Construct from explicit position, size, and plane.
    constexpr WorldArea(int32_t x_, int32_t y_, int32_t w, int32_t h, int32_t p = 0)
        : x(x_), y(y_), width(w), height(h), plane(p) {}
    /// @brief Construct from a WorldPoint with optional width and height.
    constexpr WorldArea(const WorldPoint& wp, int32_t w = 1, int32_t h = 1)
        : x(wp.x), y(wp.y), width(w), height(h), plane(wp.plane) {}

    /// @brief Get the center point of this area.
    WorldPoint to_world_point() const { return {x + width / 2, y + height / 2, plane}; }

    /// @brief Check whether a world point is contained within this area (plane-sensitive).
    bool contains(const WorldPoint& wp) const {
        return wp.plane == plane && wp.x >= x && wp.x < x + width && wp.y >= y && wp.y < y + height;
    }
    /// @brief Check whether a world point is contained within this area (ignoring plane).
    bool contains_2d(const WorldPoint& wp) const {
        return wp.x >= x && wp.x < x + width && wp.y >= y && wp.y < y + height;
    }

    /// @brief Check whether this area intersects another area.
    bool intersects(const WorldArea& other) const {
        if (plane != other.plane) return false;
        return x < other.x + other.width && x + width > other.x &&
               y < other.y + other.height && y + height > other.y;
    }

    /// @brief Compute Chebyshev distance from the closest edge to a world point.
    /// @return Distance in tiles, or -1 if planes differ.
    int32_t distance_to(const WorldPoint& wp) const {
        if (plane != wp.plane) return -1;
        int dx = 0, dy = 0;
        if (wp.x < x) dx = x - wp.x;
        else if (wp.x >= x + width) dx = wp.x - (x + width - 1);
        if (wp.y < y) dy = y - wp.y;
        else if (wp.y >= y + height) dy = wp.y - (y + height - 1);
        return std::max(dx, dy);
    }

    /// @brief Compute Chebyshev distance between closest edges of two areas.
    /// @return Distance in tiles, or -1 if planes differ.
    int32_t distance_to(const WorldArea& other) const {
        if (plane != other.plane) return -1;
        int dx = 0, dy = 0;
        if (other.x + other.width <= x) dx = x - (other.x + other.width - 1);
        else if (other.x >= x + width) dx = other.x - (x + width - 1);
        if (other.y + other.height <= y) dy = y - (other.y + other.height - 1);
        else if (other.y >= y + height) dy = other.y - (y + height - 1);
        return std::max(dx, dy);
    }

    /// @brief Compute 2D Chebyshev distance to a world point, ignoring plane.
    int32_t distance_to_2d(const WorldPoint& wp) const {
        int dx = 0, dy = 0;
        if (wp.x < x) dx = x - wp.x;
        else if (wp.x >= x + width) dx = wp.x - (x + width - 1);
        if (wp.y < y) dy = y - wp.y;
        else if (wp.y >= y + height) dy = wp.y - (y + height - 1);
        return std::max(dx, dy);
    }

    /// @brief Check whether a world point is within melee distance (1 tile of edge).
    bool is_in_melee_distance(const WorldPoint& wp) const {
        return distance_to(wp) <= 1;
    }
    /// @brief Check whether another area is within melee distance (1 tile between edges).
    bool is_in_melee_distance(const WorldArea& other) const {
        return distance_to(other) <= 1;
    }

    /// @brief Enumerate all tile positions within this area.
    std::vector<WorldPoint> to_world_point_list() const {
        std::vector<WorldPoint> pts;
        pts.reserve(width * height);
        for (int dy = 0; dy < height; dy++)
            for (int dx = 0; dx < width; dx++)
                pts.push_back({x + dx, y + dy, plane});
        return pts;
    }

    /// @brief Equality comparison.
    constexpr bool operator==(const WorldArea& o) const {
        return x == o.x && y == o.y && width == o.width && height == o.height && plane == o.plane;
    }
};

/// @}

/// @name Deferred definitions
/// @{

/// @brief Convert a WorldPoint to a 1x1 WorldArea.
inline WorldArea WorldPoint::to_world_area() const { return WorldArea(*this, 1, 1); }

/// @}

/// @name CanvasPoint
/// @{

/// @brief A 2D pixel coordinate on the game canvas (screen space).
///
/// Returned by mouse_canvas() / get_mouse_canvas(). Equivalent to the Java
/// `java.awt.Point` used in RuneLite for raw mouse pixel positions.
struct CanvasPoint {
    int32_t x = -1; ///< Pixel X (0 = left edge of canvas; -1 = unavailable)
    int32_t y = -1; ///< Pixel Y (0 = top edge of canvas; -1 = unavailable)

    constexpr CanvasPoint() = default;
    constexpr CanvasPoint(int32_t x_, int32_t y_) : x(x_), y(y_) {}

    /// @brief Returns true when the point holds a valid on-canvas coordinate.
    constexpr bool valid() const { return x >= 0 && y >= 0; }

    /// @brief Equality comparison.
    constexpr bool operator==(const CanvasPoint& o) const { return x == o.x && y == o.y; }
    /// @brief Inequality comparison.
    constexpr bool operator!=(const CanvasPoint& o) const { return !(*this == o); }
};

/// @}

/// @name Geometry utilities
/// @{

/// @brief Test whether a world tile lies inside a polygon defined by a list of world-tile vertices.
///
/// Uses the ray-casting algorithm (even-odd rule). Plane is ignored — the check is 2D (X/Y only).
/// Vertices should form a closed polygon in tile coordinates (last vertex implicitly connects to first).
///
/// @param point  The tile to test.
/// @param polygon  List of vertices defining the polygon (minimum 3).
/// @return true if the point is inside the polygon.
inline bool point_in_polygon(const WorldPoint& point, const std::vector<WorldPoint>& polygon) {
    const int n = static_cast<int>(polygon.size());
    if (n < 3) return false;
    bool inside = false;
    for (int i = 0, j = n - 1; i < n; j = i++) {
        float xi = static_cast<float>(polygon[i].x), yi = static_cast<float>(polygon[i].y);
        float xj = static_cast<float>(polygon[j].x), yj = static_cast<float>(polygon[j].y);
        float px = static_cast<float>(point.x),      py = static_cast<float>(point.y);
        bool cond = ((yi > py) != (yj > py)) &&
                    (px < (xj - xi) * (py - yi) / (yj - yi) + xi);
        if (cond) inside = !inside;
    }
    return inside;
}

/// @brief Test whether a WorldPoint lies inside a WorldArea.
///
/// Equivalent to WorldArea::contains() but provided as a free function for symmetry
/// with point_in_polygon().
inline bool point_in_area(const WorldPoint& point, const WorldArea& area) {
    return area.contains(point);
}

/// @brief Compute Chebyshev distance between two WorldPoints (ignores plane).
inline int32_t tile_distance(const WorldPoint& a, const WorldPoint& b) {
    return std::max(std::abs(a.x - b.x), std::abs(a.y - b.y));
}

/// @brief Check whether two WorldPoints are within @p max_distance tiles of each other.
inline bool within_distance(const WorldPoint& a, const WorldPoint& b, int32_t max_distance) {
    return tile_distance(a, b) <= max_distance;
}

/// @brief Check whether a WorldPoint is adjacent (within 1 tile) to another, same-plane.
inline bool is_adjacent(const WorldPoint& a, const WorldPoint& b) {
    return a.plane == b.plane && tile_distance(a, b) <= 1;
}

/// @brief Clamp a WorldPoint to lie within the given WorldArea (returns nearest tile inside).
inline WorldPoint clamp_to_area(const WorldPoint& point, const WorldArea& area) {
    int32_t cx = std::max(area.x, std::min(point.x, area.x + area.width  - 1));
    int32_t cy = std::max(area.y, std::min(point.y, area.y + area.height - 1));
    return {cx, cy, point.plane};
}

/// @}

} // namespace obsidian::api
