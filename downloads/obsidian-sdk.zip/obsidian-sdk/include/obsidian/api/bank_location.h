#pragma once
/// @file bank_location.h
/// @brief All known bank locations in OSRS with coordinates.
/// Ported from RLPL BankLocation.java.

#include <obsidian/api/coords.h>
#include <cstdint>
#include <vector>

namespace obsidian::api {

/// A named bank location and its world coordinates.
struct BankLocation {
    const char* name;
    WorldPoint location;
};

namespace banks {

// Alphabetical — matches RLPL BankLocation.java
constexpr BankLocation AL_KHARID                   = {"Al Kharid", {3269, 3167, 0}};
constexpr BankLocation ALDARIN                      = {"Aldarin", {1399, 2927, 0}};
constexpr BankLocation ALCHEMICAL_SOCIETY_CHEST     = {"Alchemical Society Chest", {1398, 9313, 0}};
constexpr BankLocation ANCIENT_PRISON               = {"Ancient Prison", {2904, 5205, 0}};
constexpr BankLocation APE_ATOLL                    = {"Ape Atoll", {2781, 2784, 0}};
constexpr BankLocation ARCEUUS                      = {"Arceuus", {1635, 3747, 0}};
constexpr BankLocation ARDOUGNE_NORTH               = {"Ardougne North", {2615, 3332, 0}};
constexpr BankLocation ARDOUGNE_SOUTH               = {"Ardougne South", {2655, 3283, 0}};
constexpr BankLocation AUBURNVALE                   = {"Auburnvale", {1416, 3356, 0}};
constexpr BankLocation BARBARIAN_OUTPOST            = {"Barbarian Outpost", {2536, 3573, 0}};
constexpr BankLocation BLAST_FURNACE                = {"Blast Furnace", {2931, 10195, 0}};
constexpr BankLocation BLAST_MINE_CHEST             = {"Blast Mine Chest", {1478, 3856, 0}};
constexpr BankLocation BURGH_DE_ROTT                = {"Burgh de Rott", {3495, 3211, 0}};
constexpr BankLocation CAM_TORUM                    = {"Cam Torum", {1451, 9568, 1}};
constexpr BankLocation CAMDOZAAL                    = {"Camdozaal", {2978, 5798, 0}};
constexpr BankLocation CANIFIS                      = {"Canifis", {3512, 3480, 0}};
constexpr BankLocation CASTLE_WARS                  = {"Castle Wars", {2443, 3083, 0}};
constexpr BankLocation CATHERBY                     = {"Catherby", {2809, 3441, 0}};
constexpr BankLocation CHARCOAL_BURNERS             = {"Charcoal Burners", {1719, 3465, 0}};
constexpr BankLocation CIVITAS_ILLA_FORTIS_WEST     = {"Civitas illa Fortis West", {1648, 3118, 0}};
constexpr BankLocation COOKS_GUILD                  = {"Cook's Guild", {3147, 3450, 0}};
constexpr BankLocation CORSAIR_COVE                 = {"Corsair Cove", {2569, 2864, 0}};
constexpr BankLocation CRAFTING_GUILD               = {"Crafting Guild", {2935, 3280, 0}};
constexpr BankLocation CULINAROMANCERS_CHEST        = {"Culinaromancer's Chest", {3218, 9623, 0}};
constexpr BankLocation DARKMEYER                    = {"Darkmeyer", {3605, 3367, 0}};
constexpr BankLocation DEEPFIN_POINT_CHEST          = {"Deepfin Point Chest", {1936, 2755, 0}};
constexpr BankLocation DORGESH_KAAN                 = {"Dorgesh-Kaan", {2701, 5350, 0}};
constexpr BankLocation DRAYNOR                      = {"Draynor Village", {3092, 3245, 0}};
constexpr BankLocation DUEL_ARENA                   = {"Duel Arena", {3381, 3268, 0}};
constexpr BankLocation EDGEVILLE                    = {"Edgeville", {3094, 3491, 0}};
constexpr BankLocation ENT_DUNGEON_CHEST            = {"Ent Dungeon Chest", {1551, 9873, 0}};
constexpr BankLocation ETCETERIA                    = {"Etceteria", {2620, 3895, 0}};
constexpr BankLocation FALADOR_EAST                 = {"Falador East", {3013, 3355, 0}};
constexpr BankLocation FALADOR_WEST                 = {"Falador West", {2946, 3368, 0}};
constexpr BankLocation FARMING_GUILD                = {"Farming Guild", {1249, 3761, 0}};
constexpr BankLocation FARMING_GUILD_CHEST          = {"Farming Guild Chest", {1253, 3741, 0}};
constexpr BankLocation FEROX_ENCLAVE                = {"Ferox Enclave", {3130, 3631, 0}};
constexpr BankLocation FISHING_GUILD                = {"Fishing Guild", {2586, 3418, 0}};
constexpr BankLocation FORTIS_COLOSSEUM_CHEST       = {"Fortis Colosseum Chest", {1804, 9501, 0}};
constexpr BankLocation FORTIS_EAST                  = {"Fortis East", {1780, 3096, 0}};
constexpr BankLocation FOSSIL_ISLAND                = {"Fossil Island", {3741, 3805, 0}};
constexpr BankLocation FOSSIL_ISLAND_ZIPLINE        = {"Fossil Island Zipline", {3766, 3899, 0}};
constexpr BankLocation GIANTS_FOUNDRY_CHEST         = {"Giant's Foundry Chest", {3374, 11493, 0}};
constexpr BankLocation GRAND_EXCHANGE               = {"Grand Exchange", {3166, 3487, 0}};
constexpr BankLocation GRAND_TREE_SOUTH             = {"Grand Tree South", {2449, 3482, 1}};
constexpr BankLocation GRAND_TREE_WEST              = {"Grand Tree West", {2442, 3488, 1}};
constexpr BankLocation GUARDIANS_OF_THE_RIFT_CHEST  = {"Guardians of the Rift", {3619, 9474, 0}};
constexpr BankLocation HALLOWED_SEPULCHRE_CHEST     = {"Hallowed Sepulchre", {2400, 5983, 0}};
constexpr BankLocation HOSIDIUS                     = {"Hosidius", {1748, 3599, 0}};
constexpr BankLocation HOSIDIUS_KITCHEN_CHEST       = {"Hosidius Kitchen Chest", {1676, 3616, 0}};
constexpr BankLocation HOSIDIUS_VINERY              = {"Hosidius Vinery", {1809, 3566, 0}};
constexpr BankLocation HUNTER_GUILD                 = {"Hunter Guild", {1542, 3040, 0}};
constexpr BankLocation JATIZSO                      = {"Jatizso", {2416, 3801, 0}};
constexpr BankLocation KELDAGRIM                    = {"Keldagrim", {2838, 10210, 0}};
constexpr BankLocation KOUREND_CASTLE               = {"Kourend Castle", {1612, 3682, 2}};
constexpr BankLocation LANDS_END_CHEST              = {"Land's End Chest", {1514, 3421, 0}};
constexpr BankLocation LEGENDS_GUILD                = {"Legends' Guild", {2732, 3379, 2}};
constexpr BankLocation LLETYA                       = {"Lletya", {2352, 3164, 0}};
constexpr BankLocation LOVAKENGJ                    = {"Lovakengj", {1526, 3739, 0}};
constexpr BankLocation LOVAKENGJ_SULFUR_1           = {"Lovakengj Sulfur 1", {1454, 3858, 0}};
constexpr BankLocation LOVAKENGJ_SULFUR_2           = {"Lovakengj Sulfur 2", {1436, 3822, 0}};
constexpr BankLocation LUMBRIDGE                    = {"Lumbridge", {3208, 3220, 2}};
constexpr BankLocation LUNAR_ISLE                   = {"Lunar Isle", {2098, 3919, 0}};
constexpr BankLocation MAGE_TRAINING_ARENA_CHEST    = {"Mage Training Arena", {3365, 3318, 1}};
constexpr BankLocation MINING_GUILD                 = {"Mining Guild", {3013, 9718, 0}};
constexpr BankLocation MISTROCK                     = {"Mistrock", {1382, 2866, 0}};
constexpr BankLocation MOS_LEHARMLESS               = {"Mos Le'Harmless", {3680, 2982, 0}};
constexpr BankLocation MOTHERLODE_MINE              = {"Motherlode Mine", {3760, 5666, 0}};
constexpr BankLocation MOUNT_KARUULM                = {"Mount Karuulm", {1324, 3824, 0}};
constexpr BankLocation MOUNT_QUIDAMORTEM            = {"Mount Quidamortem", {1254, 3571, 0}};
constexpr BankLocation MYTHS_GUILD_CHEST            = {"Myths' Guild Chest", {2463, 2848, 1}};
constexpr BankLocation NARDAH                       = {"Nardah", {3427, 2891, 0}};
constexpr BankLocation NEITIZNOT                    = {"Neitiznot", {2338, 3807, 0}};
constexpr BankLocation NEMUS_RETREAT                = {"Nemus Retreat", {1387, 3309, 0}};
constexpr BankLocation OURANIA                      = {"Ourania", {3016, 5625, 0}};
constexpr BankLocation PISCATORIS                   = {"Piscatoris", {2330, 3690, 0}};
constexpr BankLocation PORT_KHAZARD                 = {"Port Khazard", {2661, 3162, 0}};
constexpr BankLocation PORT_PHASMATYS               = {"Port Phasmatys", {3692, 3468, 0}};
constexpr BankLocation PORT_PISCARILIUS             = {"Port Piscarilius", {1804, 3790, 0}};
constexpr BankLocation PORT_ROBERTS                 = {"Port Roberts", {1882, 3315, 0}};
constexpr BankLocation PRIFDDINAS_NORTH             = {"Prifddinas North", {3257, 6108, 0}};
constexpr BankLocation PRIFDDINAS_SOUTH             = {"Prifddinas South", {3297, 6060, 0}};
constexpr BankLocation QUETZACALLI_GORGE            = {"Quetzacalli Gorge", {1521, 3229, 0}};
constexpr BankLocation ROGUES_DEN                   = {"Rogues' Den", {3043, 4972, 1}};
constexpr BankLocation SEERS_VILLAGE                = {"Seers' Village", {2727, 3493, 0}};
constexpr BankLocation SHANTAY_PASS                 = {"Shantay Pass", {3308, 3120, 0}};
constexpr BankLocation SHAYZIEN                     = {"Shayzien", {1487, 3594, 0}};
constexpr BankLocation SHAYZIEN_ENCAMPMENT_CHEST    = {"Shayzien Encampment", {1485, 3646, 0}};
constexpr BankLocation SHILO_VILLAGE                = {"Shilo Village", {2852, 2955, 0}};
constexpr BankLocation SOPHANEM                     = {"Sophanem", {2799, 5169, 0}};
constexpr BankLocation TAL_TEKLAN                   = {"Tal Teklan", {1243, 3121, 0}};
constexpr BankLocation THE_DARKFROST                = {"The Darkfrost", {1526, 3292, 0}};
constexpr BankLocation THE_GREAT_CONCH              = {"The Great Conch", {3182, 2419, 0}};
constexpr BankLocation THE_PANDEMONIUM              = {"The Pandemonium", {3039, 2999, 0}};
constexpr BankLocation TOMBS_OF_AMASCUT             = {"Tombs of Amascut", {3354, 9120, 0}};
constexpr BankLocation TREE_GNOME_STRONGHOLD        = {"Tree Gnome Stronghold", {2445, 3424, 1}};
constexpr BankLocation TROUBLE_BREWING_CHEST        = {"Trouble Brewing", {3810, 3021, 0}};
constexpr BankLocation TZHAAR_CITY                  = {"TzHaar City", {2446, 5179, 0}};
constexpr BankLocation UNKAH_CHEST                  = {"Unkah Chest", {3156, 2838, 0}};
constexpr BankLocation VARROCK_EAST                 = {"Varrock East", {3253, 3420, 0}};
constexpr BankLocation VARROCK_WEST                 = {"Varrock West", {3185, 3436, 0}};
constexpr BankLocation VER_SINHAZA                  = {"Ver Sinhaza", {3652, 3208, 0}};
constexpr BankLocation VOID_KNIGHTS_OUTPOST         = {"Void Knights' Outpost", {2667, 2653, 0}};
constexpr BankLocation VOLCANIC_MINE_CHEST          = {"Volcanic Mine", {3819, 3809, 0}};
constexpr BankLocation WARRIORS_GUILD               = {"Warriors' Guild", {2843, 3543, 0}};
constexpr BankLocation WINTERTODT_CHEST             = {"Wintertodt", {1640, 3944, 0}};
constexpr BankLocation WOODCUTTING_GUILD            = {"Woodcutting Guild", {1592, 3476, 0}};
constexpr BankLocation YANILLE                      = {"Yanille", {2613, 3091, 0}};
constexpr BankLocation ZANARIS                      = {"Zanaris", {2383, 4459, 0}};

/// All bank locations — no quest/skill filtering.
/// Use `valid_banks()` for filtered list based on player state.
inline const std::vector<BankLocation>& all() {
    static const std::vector<BankLocation> list = {
        AL_KHARID, ALDARIN, ANCIENT_PRISON, APE_ATOLL, ARCEUUS,
        ARDOUGNE_NORTH, ARDOUGNE_SOUTH, AUBURNVALE, BARBARIAN_OUTPOST,
        BLAST_FURNACE, BLAST_MINE_CHEST, BURGH_DE_ROTT, CAM_TORUM,
        CAMDOZAAL, CANIFIS, CASTLE_WARS, CATHERBY, CHARCOAL_BURNERS,
        CIVITAS_ILLA_FORTIS_WEST, COOKS_GUILD, CORSAIR_COVE, CRAFTING_GUILD,
        CULINAROMANCERS_CHEST, DARKMEYER, DORGESH_KAAN, DRAYNOR, DUEL_ARENA,
        EDGEVILLE, ETCETERIA, FALADOR_EAST, FALADOR_WEST, FARMING_GUILD,
        FARMING_GUILD_CHEST, FEROX_ENCLAVE, FISHING_GUILD, FORTIS_EAST,
        FOSSIL_ISLAND, GRAND_EXCHANGE, GRAND_TREE_SOUTH, GRAND_TREE_WEST,
        HOSIDIUS, HOSIDIUS_VINERY, HUNTER_GUILD, JATIZSO, KELDAGRIM,
        KOUREND_CASTLE, LANDS_END_CHEST, LEGENDS_GUILD, LLETYA, LOVAKENGJ,
        LUMBRIDGE, LUNAR_ISLE, MINING_GUILD, MISTROCK, MOS_LEHARMLESS,
        MOUNT_KARUULM, MOUNT_QUIDAMORTEM, NARDAH, NEITIZNOT, NEMUS_RETREAT,
        OURANIA, PISCATORIS, PORT_KHAZARD, PORT_PHASMATYS, PORT_PISCARILIUS,
        PRIFDDINAS_NORTH, PRIFDDINAS_SOUTH, ROGUES_DEN, SEERS_VILLAGE,
        SHANTAY_PASS, SHAYZIEN, SHILO_VILLAGE, SOPHANEM, TAL_TEKLAN,
        THE_DARKFROST, THE_GREAT_CONCH, THE_PANDEMONIUM, TOMBS_OF_AMASCUT,
        TREE_GNOME_STRONGHOLD, TZHAAR_CITY, UNKAH_CHEST, VARROCK_EAST,
        VARROCK_WEST, VER_SINHAZA, VOID_KNIGHTS_OUTPOST, WARRIORS_GUILD,
        WINTERTODT_CHEST, WOODCUTTING_GUILD, YANILLE, ZANARIS,
    };
    return list;
}

} // namespace banks
} // namespace obsidian::api
