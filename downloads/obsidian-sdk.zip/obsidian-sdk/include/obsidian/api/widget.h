#pragma once
/// @file widget.h
/// @brief Widget wrapper providing typed access to game interface components.
/// @ingroup ui
// ═══════════════════════════════════════════════════════════════════════════
// WIDGET — Extended widget API wrapper
// ═══════════════════════════════════════════════════════════════════════════
// Mirrors RuneLite Widget.java. Wraps raw widget pointers with typed
// accessors for all confirmed fields.
//
// Widget pointers come from the hash table at Client+WidgetTable or
// from dynamic children via DynChildArray on a parent widget.
// ═══════════════════════════════════════════════════════════════════════════


#include <cstdint>
#include <string>
#include <vector>

namespace obsidian::api {

/// Widget type constants from RuneLite WidgetType.java.
/// Check Widget::type() against these to determine how a widget is rendered.
namespace WidgetType {
    constexpr int LAYER       = 0;
    constexpr int RECTANGLE   = 3;
    constexpr int TEXT         = 4;
    constexpr int GRAPHIC     = 5;
    constexpr int MODEL        = 6;
    constexpr int TEXT_INVENTORY = 7;
    constexpr int IF1_HEADER   = 8;
    constexpr int LINE         = 9;
}


} // namespace obsidian::api
