#pragma once
/// @file entity_handle.h
/// @brief Generation-indexed entity handle for safe cross-tick references.
// ═══════════════════════════════════════════════════════════════════════════
// ENTITY HANDLE — stable reference to an NPC or Player entity
// ═══════════════════════════════════════════════════════════════════════════
// Wraps an entity index + generation counter. The generation increments
// on every despawn, so stale handles can be detected without raw pointers.
//
// Use resolve_npc() / resolve_player() to get a snapshot, or valid() to
// check if the entity is still alive. Never exposes raw game pointers.
// ═══════════════════════════════════════════════════════════════════════════

#include <obsidian/api/scene_api.h>
#include <cstdint>
#include <optional>

namespace obsidian::api {

/// Which entity table a handle refers to.
enum class EntityType : uint8_t { NPC = 0, PLAYER = 1 };

/// Stable, generation-checked reference to an NPC or Player entity.
struct EntityHandle {
    int32_t index = -1;
    uint32_t generation = 0;
    EntityType type = EntityType::NPC;

    /// True if this handle holds no entity (index < 0).
    bool is_null() const { return index < 0; }

    /// True if the referenced entity is still alive (generation matches).
    bool valid() const;
    /// Resolves to a current NPC snapshot, or nullopt if stale/not an NPC.
    std::optional<SceneNpc> resolve_npc() const;
    /// Resolves to a current player snapshot, or nullopt if stale/not a player.
    std::optional<ScenePlayer> resolve_player() const;

    /// Builds an NPC handle capturing the current generation for @p index.
    static EntityHandle npc(int32_t index);
    /// Builds a player handle capturing the current generation for @p index.
    static EntityHandle player(int32_t index);

    bool operator==(const EntityHandle& o) const {
        return index == o.index && generation == o.generation && type == o.type;
    }
    bool operator!=(const EntityHandle& o) const { return !(*this == o); }
};

// Generation tracking — called by DLL event dispatcher on despawn
void increment_npc_generation(int32_t index);
/// Bumps the player generation counter for a slot on despawn.
void increment_player_generation(int32_t index);
/// Returns the current NPC generation counter for the given slot.
uint32_t get_npc_generation(int32_t index);
/// Returns the current player generation counter for the given slot.
uint32_t get_player_generation(int32_t index);

} // namespace obsidian::api
