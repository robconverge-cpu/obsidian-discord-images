#pragma once
/// @file varp_ids.h
/// @brief Named constants for common VarPlayer (varp) and VarClient int IDs.
/// @ingroup core
// ═══════════════════════════════════════════════════════════════════════════
// VARP / VARC ID CONSTANTS
// ═══════════════════════════════════════════════════════════════════════════
// Mirrors RuneLite's VarPlayer.java and VarClientInt.java enums.
// Use with api::varp(id), api::varbit(id), and api::varc_int(id).
//
// Verified against OSRS v237.1 unless otherwise noted.
// ═══════════════════════════════════════════════════════════════════════════

#include <cstdint>

namespace obsidian::api {

/// @name VarPlayer IDs
/// Common VarPlayer (varp) constants. Use with api::varp(id).
/// @{

namespace VarPlayer {
    /// @brief Current special attack energy (0–100, divide by 10 for %).
    constexpr int32_t SPECIAL_ATTACK_PERCENT      = 300;

    /// @brief Accumulated special attack bar energy (0–1000, divide by 10 for %).
    constexpr int32_t SPECIAL_ATTACK_ENERGY       = 1000;

    /// @brief Whether the player is a member (1 = member, 0 = free).
    constexpr int32_t MEMBERSHIP_STATUS           = 1740;

    /// @brief Account type: 0=normal, 1=ironman, 2=hardcore, 3=ultimate ironman, 4=group ironman.
    constexpr int32_t ACCOUNT_TYPE                = 1777;

    /// @brief Attack style selection on the combat tab (0–3 depending on weapon).
    constexpr int32_t ATTACK_STYLE               = 43;

    /// @brief Auto-retaliate toggle: 0=off, 1=on.
    constexpr int32_t AUTO_RETALIATE             = 172;

    /// @brief Prayer quick-access slot assignment (for quick prayer orb).
    constexpr int32_t QUICK_PRAYER               = 83;

    /// @brief Whether quick prayer is currently active (1=active).
    constexpr int32_t QUICK_PRAYER_ACTIVE        = 4101;

    /// @brief Slayer task monster ID (0=no task).
    constexpr int32_t SLAYER_TASK_ID             = 2703;

    /// @brief Remaining slayer task count.
    constexpr int32_t SLAYER_TASK_REMAINING      = 2784;

    /// @brief Current quest step for Sheep Shearer (example usage pattern).
    constexpr int32_t QUEST_COOK_ASSISTANT       = 29;

    /// @brief Skull timer in game ticks (0=not skulled).
    constexpr int32_t SKULL_TIMER                = 184;

    /// @brief PvP skull type: 0=white skull, 1=red skull (-1 if not skulled via actor field).
    constexpr int32_t SKULL_TYPE                 = 183;

    /// @brief Bank PIN lock state: 0=unlocked, 1=locked.
    constexpr int32_t BANK_PIN                   = 1050;

    /// @brief Currently equipped weapon's interface item ID.
    constexpr int32_t EQUIPPED_ITEM_COMBAT       = 357;

    /// @brief Selected spellbook: 0=standard, 1=ancient, 2=lunar, 3=arceuus.
    constexpr int32_t SPELLBOOK                  = 439;

    /// @brief Current kingdom of Miscellania approval rating (0–100).
    constexpr int32_t KINGDOM_APPROVAL           = 72;

    /// @brief Boss kill count varps start here (each boss has a dedicated varp).
    /// Use the boss-specific varp ID for the target boss.
    constexpr int32_t BOSS_KILLS_BASE            = 825;

    /// @brief Cannon placed by the player (0=no cannon, 1=placed).
    constexpr int32_t CANNON_PLACED              = 4071; // same value as Varbits::CANNON_PLACED

    /// @brief Active prayer points (raw drain counter; not the displayed level).
    constexpr int32_t PRAYER_DRAIN_COUNTER       = 261;

    /// @brief NPC type currently being highlighted by the Slayer interface.
    constexpr int32_t SLAYER_REWARD_POINTS       = 2810;

    /// @brief Currently equipped ring slot item ID.
    constexpr int32_t EQUIPPED_RING              = 2656;
}

/// @}

/// @name Varbit IDs
/// Common varbit constants. Use with api::varbit(id).
/// @{

namespace Varbits {
    /// @brief Special attack is enabled / consuming on next attack (0=off, 1=on).
    constexpr int32_t SPECIAL_ATTACK_ENABLED     = 301;

    /// @brief Stamina potion effect active: 0=inactive, 1=active.
    constexpr int32_t STAMINA_EFFECT             = 25;

    /// @brief Antifire potion effect: 0=none, 1=super, 2=standard.
    constexpr int32_t ANTIFIRE_POTION            = 3981;

    /// @brief Cannon placed (0=no cannon, 1=placed).
    constexpr int32_t CANNON_PLACED              = 4071;

    /// @brief Cannon ammo remaining.
    constexpr int32_t CANNON_AMMO                = 4072;

    /// @brief Quick prayer orb state (0=off, 1=active).
    constexpr int32_t QUICK_PRAYER_ORB           = 4103;

    /// @brief Selected spellbook: 0=standard, 1=ancient, 2=lunar, 3=arceuus.
    constexpr int32_t SPELLBOOK                  = 4070;

    /// @brief Vengeance cooldown: 1=on cooldown.
    constexpr int32_t VENGEANCE_COOLDOWN         = 2879;

    /// @brief Absorption (NMZ) total points remaining.
    constexpr int32_t NMZ_ABSORPTION             = 3956;

    /// @brief Overload boost active (NMZ): 0=none.
    constexpr int32_t NMZ_OVERLOAD              = 3955;

    /// @brief Divine potion timer in ticks remaining.
    constexpr int32_t DIVINE_POTION_TIMER        = 3955; // shares slot with NMZ_OVERLOAD in some configs

    /// @brief Protect Item prayer active (0=off, 1=on).
    constexpr int32_t PROTECT_ITEM              = 3981; // alternate context

    /// @brief Smite prayer active (0=off, 1=on).
    constexpr int32_t PRAYER_SMITE              = 636;

    /// @brief Rigour prayer active (0=off, 1=on).
    constexpr int32_t PRAYER_RIGOUR             = 5451;

    /// @brief Augury prayer active (0=off, 1=on).
    constexpr int32_t PRAYER_AUGURY             = 5452;

    /// @brief Rune pouch slot 1 rune ID.
    constexpr int32_t RUNE_POUCH_RUNE1          = 29;
    /// @brief Rune pouch slot 2 rune ID.
    constexpr int32_t RUNE_POUCH_RUNE2          = 1622;
    /// @brief Rune pouch slot 3 rune ID.
    constexpr int32_t RUNE_POUCH_RUNE3          = 1623;
    /// @brief Rune pouch slot 1 quantity.
    constexpr int32_t RUNE_POUCH_AMOUNT1        = 1624;
    /// @brief Rune pouch slot 2 quantity.
    constexpr int32_t RUNE_POUCH_AMOUNT2        = 1625;
    /// @brief Rune pouch slot 3 quantity.
    constexpr int32_t RUNE_POUCH_AMOUNT3        = 1626;
}

/// @}

/// @name VarClient Int IDs
/// VarClient integer constants. Verified present in live varc memory and named
/// per the RuneLite gameval VarClientID table (IdeaProjects/runelite). Use with
/// api::varc_int(id).
///
/// NOTE: client-state flags people often expect here — bank open, attack option,
/// autocast spell, interface style, GE search — are NOT VarClientInts; they are
/// varbits / varps / widget state. Don't add guesses: confirm the key exists in
/// the live varc array (via api::varc_int(id)) before adding a new constant.
/// @{

namespace VarClientInt {
    /// @brief Selected top-level side panel / tab (gameval TOPLEVEL_PANEL).
    constexpr int32_t TOPLEVEL_PANEL              = 171;
    /// @brief Alias of TOPLEVEL_PANEL — the inventory/side-panel tab selector.
    constexpr int32_t INVENTORY_TAB               = 171;

    /// @brief Active message-layer / chat input mode (gameval MESLAYERMODE).
    constexpr int32_t MESLAYER_MODE               = 5;

    /// @brief Chat filter view mode (gameval CHAT_VIEW).
    constexpr int32_t CHAT_VIEW                   = 41;

    /// @brief Inside-wilderness flag: 0=no, 1=yes (gameval COMBAT_INSIDEWILDERNESS).
    constexpr int32_t IN_WILDERNESS               = 53;

    /// @brief Camera zoom, fixed viewport (gameval CAMERA_ZOOM_SMALL). Range 128..896.
    constexpr int32_t CAMERA_ZOOM_FIXED           = 73;
    /// @brief Camera zoom, resizable viewport (gameval CAMERA_ZOOM_BIG). Range 128..896.
    constexpr int32_t CAMERA_ZOOM_RESIZABLE       = 74;
    constexpr int32_t CAMERA_ZOOM_FIXED_MIN       = 1338;
    constexpr int32_t CAMERA_ZOOM_FIXED_MAX       = 1339;
    constexpr int32_t CAMERA_ZOOM_RESIZABLE_MIN   = 1340;
    constexpr int32_t CAMERA_ZOOM_RESIZABLE_MAX   = 1341;

    /// @brief Minimap zoom level, desktop (gameval MINIMAP_ZOOM_LEVEL_DESKTOP).
    constexpr int32_t MINIMAP_ZOOM_LEVEL          = 1146;
}

/// @}

/// @name VarClient String IDs
/// VarClient string constants (type-2 entries), named per gameval VarClientID.
/// Use with api::varc_str(id).
/// @{

namespace VarClientStr {
    /// @brief Current chatbox typed text (gameval CHATINPUT).
    constexpr int32_t CHATBOX_TYPED_TEXT          = 335;
    /// @brief Generic interface input text, e.g. search boxes (gameval MESLAYERINPUT).
    constexpr int32_t INPUT_TEXT                  = 359;
    /// @brief Target name for a private message being composed (gameval FRIENDTOMESSAGE).
    constexpr int32_t PM_TARGET                   = 360;
    /// @brief Local player's display name (gameval XPTRACKER_PLAYER_NAME).
    constexpr int32_t PLAYER_NAME                 = 564;
}

/// @}

/// @name Account Type Values
/// Constants for the ACCOUNT_TYPE varp. Compare with api::varp(VarPlayer::ACCOUNT_TYPE).
/// @{

namespace AccountType {
    constexpr int32_t NORMAL         = 0; ///< Standard account.
    constexpr int32_t IRONMAN        = 1; ///< Ironman.
    constexpr int32_t ULTIMATE       = 2; ///< Ultimate Ironman (no bank).
    constexpr int32_t HARDCORE       = 3; ///< Hardcore Ironman.
    constexpr int32_t GROUP_IRONMAN  = 4; ///< Group Ironman.
    constexpr int32_t HARDCORE_GROUP_IRONMAN = 5; ///< Hardcore Group Ironman.
    constexpr int32_t UNRANKED_GROUP_IRONMAN = 6; ///< Unranked Group Ironman.
}

/// @}

} // namespace obsidian::api
