#pragma once
/// @file item_helpers_api.h
/// @brief "Does the player have ANY X?" item category helpers.
/// @ingroup ui
///
/// Split from game_api.h — named item-category predicates backed by
/// the canonical ID lists from item_collections.h. The generic
/// `any_in_inventory` / `any_in_bank` primitives live here too so
/// plugins with custom category lists can use them directly.

#include <array>
#include <cstddef>
#include <cstdint>

namespace obsidian::api::item_helpers {

/// @name Item Category Helpers
/// @{
bool any_in_inventory(const int32_t* ids, size_t count);   ///< Does any listed id appear in the inventory / equipment?
bool any_in_bank(const int32_t* ids, size_t count);        ///< Does any listed id appear in the bank snapshot?

/// Does any id in the array appear in the inventory / equipment?
template<size_t N>
inline bool any_in_inventory(const std::array<int32_t, N>& ids) {
    return any_in_inventory(ids.data(), ids.size());
}
/// Does any id in the array appear in the bank snapshot?
template<size_t N>
inline bool any_in_bank(const std::array<int32_t, N>& ids) {
    return any_in_bank(ids.data(), ids.size());
}

bool has_pickaxe();           ///< Any pickaxe in inventory or equipped.
bool has_pickaxe_in_bank();   ///< Any pickaxe in bank (live or cached snapshot).
bool has_axe();               ///< Any woodcutting axe carried.
bool has_axe_in_bank();       ///< Any woodcutting axe in bank.
bool has_bow();               ///< Any bow carried (shortbow/longbow, not crossbow).
bool has_bow_in_bank();       ///< Any bow in bank.
bool has_crossbow();          ///< Any crossbow carried.
bool has_crossbow_in_bank();  ///< Any crossbow in bank.
bool has_harpoon();           ///< Any harpoon carried.
bool has_harpoon_in_bank();   ///< Any harpoon in bank.
bool has_metal_arrows();      ///< Any metal arrow variant carried.
bool has_metal_arrows_in_bank(); ///< Any metal arrow variant in bank.
bool has_antipoison();            ///< Any antipoison/antivenom/sanfew/relicym variant carried.
bool has_antipoison_in_bank();    ///< Same, in the bank snapshot.
bool has_antivenom();             ///< Antivenom / antivenom+ specifically (strict set).
bool has_antivenom_in_bank();     ///< Antivenom / antivenom+ in the bank snapshot.
bool has_stamina_potion();        ///< Any dose of stamina potion carried.
bool has_stamina_potion_in_bank(); ///< Any dose of stamina potion in the bank.
bool has_prayer_potion();         ///< Any dose of prayer potion OR super restore carried.
bool has_prayer_potion_in_bank(); ///< Any dose of prayer potion or super restore in the bank.
bool has_super_restore();         ///< Super restore only (not prayer potion).
bool has_super_restore_in_bank(); ///< Super restore only, in the bank.
bool has_agility_potion();        ///< Any dose of agility potion carried.
bool has_agility_potion_in_bank(); ///< Any dose of agility potion in the bank.
bool has_antifire();              ///< Any antifire potion carried.
bool has_antifire_in_bank();      ///< Any antifire potion in the bank.
/// Any edible food in inventory: GOOD_EATING_FOOD (incl. partially eaten
/// cakes/pizzas/pies) or any other item with an "Eat" action, minus FOOD_TRAPS.
bool has_food();
bool has_food_in_bank();          ///< Any GOOD_EATING_FOOD item in the bank.
/// @}

/// @name Consumable Actions
/// Convenience functions that find-and-use the first matching item from a
/// category. Return true if an item was found and the action was invoked.
/// These are the "do it" counterparts to the "has it" checks above.
/// @{
/// Eat the best food in inventory. Walks GOOD_EATING_FOOD in order (best
/// heal first, leftovers of multi-bite food before whole ones), then falls
/// back to any other item with an "Eat" action that is not in FOOD_TRAPS —
/// so newly released food works without a table update.
bool eat_food();
bool drink_prayer_pot();     ///< Drink the first prayer/restore pot found.
bool drink_antipoison();     ///< Drink the first anti-poison/venom pot found.
bool drink_stamina_pot();    ///< Drink the first stamina/energy pot found.
bool drink_antifire_pot();   ///< Drink the first antifire pot found.

/// Generic: drink the first item from a raw ID array.
/// @return true if an item was found and the drink action invoked.
bool drink_first_of(const int32_t* ids, size_t count);

/// Drink the first item from the array that is present in inventory.
template<size_t N>
inline bool drink_first_of(const std::array<int32_t, N>& ids) {
    return drink_first_of(ids.data(), ids.size());
}

/// Generic: eat the first item from a raw ID array (uses the "Eat" action —
/// pies, cakes, and pizzas are "Eat", not "Drink").
/// @return true if an item was found and the eat action invoked.
bool eat_first_of(const int32_t* ids, size_t count);

/// Eat the first item from the array that is present in inventory.
template<size_t N>
inline bool eat_first_of(const std::array<int32_t, N>& ids) {
    return eat_first_of(ids.data(), ids.size());
}
/// @}

} // namespace obsidian::api::item_helpers
