#pragma once
/// @file scene_api.h
/// @brief Scene entity structs and spatial queries — NPCs, objects, players, projectiles, ground items.
/// @ingroup scene
///
/// Split from game_api.h — scene queries are the largest domain and benefit
/// from a dedicated header. Includes all SceneXxx structs and every find_*
/// / find_nearest_* / find_all_* function.

#include <obsidian/api/coords.h>
#include <obsidian/api/definitions_api.h>
#include <obsidian/api/hitsplat.h>
#include <obsidian/api/tile.h>
#include <obsidian/api/local_player_api.h>  // SkullIcon, OverheadIcon
#include <cstdint>
#include <optional>
#include <string>
#include <vector>

namespace obsidian::api {

// SpotAnimData is defined in local_player_api.h (included above).

/// A visible NPC in the current scene.
/// @warning Entity pointers (`ptr`) are only valid during the current game tick.
/// Re-query each tick via find_npcs() or find_nearest_npc().
///
/// **Position fields:** `location` is the **snapped per-tick world
/// tile** — it changes once per game tick when the NPC walks.
/// `local_location` is the **interpolated visual position** in fine
/// local coordinates (1/128 tile units) — during walking it drifts
/// smoothly between tiles every render frame. Pass `local_location`
/// to `OverlayContext::render_actor_highlight` (or the
/// `render_npc_tile` convenience wrapper) for a highlight that
/// follows the visual position; use `location` for a tile that snaps
/// to the logical tile per game tick.
struct SceneNpc {
    uintptr_t ptr      = 0;    ///< Raw entity pointer (valid this tick only).
    int32_t index      = -1;   ///< Slot index in the NPC entity table.
    int32_t world_view_id = 0; ///< WorldView this entity belongs to (0=overworld).
    int32_t npc_id     = -1;   ///< Composition/definition ID.
    WorldPoint location;         ///< **Snapped** world tile (changes once per game tick).
    LocalPoint local_location;  ///< **Interpolated** fine-local position (visual position, drifts each render frame during walks).
    std::string name;           ///< Display name from composition (may be empty for unnamed NPCs).
    int32_t combat_level = -1; ///< Combat level from composition (-1 if not set).
    float health_percent = -1.0f; ///< Health bar fill [0,100], or -1 if no health bar visible.
    int32_t health_ratio = -1;  ///< Raw health bar green width (RuneLite getHealthRatio). -1 if no bar.
    int32_t health_scale = -1;  ///< Raw health bar max width (RuneLite getHealthScale). -1 if no bar.
    bool dead           = false; ///< True if health_percent == 0 (convenience for filtering).
    bool interactable  = true;  ///< False for non-interactable NPCs (e.g., ambiance NPCs).
    // Extended actor state
    int32_t orientation     = -1; ///< Direction the entity is facing (0-2047, -1 = unavailable).
    int32_t face_angle      = -1; ///< Overridden face angle (-1 = not overriding orientation).
    int32_t interacting_index = -1; ///< Validated slot index of the entity this NPC is targeting (-1 = not interacting; stale values filtered).
    int32_t interacting_type = 0;   ///< 0 = not interacting, 1 = target is NPC, 2 = target is player.
    std::string overhead_text;  ///< Overhead chat text (empty = none).
    int32_t animation       = -1; ///< Current action animation ID (-1 = idle).
    int32_t animation_frame = -1; ///< Current frame within the action animation.
    int32_t pose_animation  = -1; ///< Current pose animation (walk / idle / run state).
    int32_t entity_size     = 1;  ///< Footprint in tiles (1 for most NPCs; e.g. 3 for GWD bosses).
    OverheadIcon overhead_icon = OverheadIcon::NONE; ///< Overhead prayer icon (used by DemonicGorillas, etc).
    std::string actions[5];     ///< Right-click actions from composition (e.g. "Attack", "Talk-to").
    Hitsplat hitsplat;            ///< Most recently applied hitsplat (check hitsplat.active).
};

/// Which kind of scene tile object a SceneObject was sourced from.
enum class SceneObjectType : int32_t {
    Game       = 0,  ///< Standard game object (loc type 10/11/22).
    Wall       = 1,  ///< Wall object (door, fence, gate).
    Decorative = 2,  ///< Decorative object (floor decoration, wall-mounted).
    Ground     = 3,  ///< Ground object (manhole, trapdoor — rendered flat on tile).
};

/// A visible tile object in the current scene.
/// @warning `ptr` / `model_ptr` are valid for this game tick only;
/// re-query via `find_objects()` each frame if the object can be
/// removed (e.g. LocType transforms on varbit change).
struct SceneObject {
    uintptr_t ptr = 0;  ///< Raw pointer to the scene object (inner sub-object).
    int32_t id    = -1; ///< Object definition ID.
    SceneObjectType type = SceneObjectType::Game; ///< Source type (Game/Wall/Decorative/Ground).
    int32_t world_view_id = 0; ///< WorldView this object belongs to (0=overworld).
    WorldPoint location; ///< World tile of the object's anchor point.
    int32_t scene_x = 0; ///< Scene tile X (equivalent to getSceneMinLocation().getX()).
    int32_t scene_y = 0; ///< Scene tile Y (equivalent to getSceneMinLocation().getY()).
    /// Animated model pointer read from the scene object's stored
    /// RSPtr pair. 0 when the object has no animated model (rare;
    /// static geometry sometimes stores only bind-pose). Ready for
    /// direct vertex reads via model.h offsets.
    uintptr_t model_ptr = 0;
    /// Scene object orientation (0..2047) for model vertex rotation.
    int32_t orientation = 0;
    /// Fine-local position (1/128 tile units) — the object's anchor
    /// in local coordinates. Used for projecting model vertices.
    int32_t local_x = 0;
    int32_t local_y = 0;
    /// World Y of the object's anchor (the height the game uses when
    /// drawing the model). Read from scene_object::Height at +0xD8.
    /// Wall levers, elevated decorations etc. aren't at ground level
    /// so this must be used instead of `get_tile_height` for hull
    /// projection — otherwise the hull floats off the model.
    int32_t anchor_y = 0;
    /// Cached renderable model height (native getModelHeight equivalent,
    /// = -min(VerticesY)). Matches RuneLite's Renderable.getModelHeight
    /// since both clients load the same cache models. 0 when the object
    /// has no model. Only populated for game objects (wall/deco leave 0).
    int32_t model_height = 0;
    /// Current animation (sequence) id — RuneLite `DynamicObject.getAnimation()`.
    /// -1 when the object is static or a one-shot animation has finished.
    /// Only populated for game objects (wall/deco/ground leave -1).
    int32_t animation_id = -1;
    /// Current frame of `animation_id`, or -1 when not animating.
    int32_t animation_frame = -1;
    /// Definition name ("" if unnamed) — same as definitions::object(id)->name.
    std::string name() const { auto* d = definitions::object(id); return d ? d->name : std::string{}; }
};

/// A wall object (door, fence, etc.) in the current scene.
struct SceneWallObject {
    uintptr_t ptr = 0;     ///< Raw sub-struct pointer (valid this tick only).
    int32_t id    = -1;    ///< Object definition ID (from tag >> 20).
    int32_t world_view_id = 0; ///< WorldView this object belongs to (0=overworld).
    int32_t scene_x = 0;   ///< Scene tile X.
    int32_t scene_y = 0;   ///< Scene tile Y.
    WorldPoint location;    ///< World tile of the wall.
    int32_t orientation = 0; ///< Wall orientation / render direction when known.
    /// Definition name ("" if unnamed) — same as definitions::object(id)->name.
    std::string name() const { auto* d = definitions::object(id); return d ? d->name : std::string{}; }
};

/// A decorative object (floor decoration, wall-mounted item) in the current scene.
struct SceneDecorativeObject {
    uintptr_t ptr = 0;     ///< Raw sub-struct pointer (valid this tick only).
    int32_t id    = -1;    ///< Object definition ID (from tag >> 20).
    int32_t world_view_id = 0; ///< WorldView this object belongs to (0=overworld).
    int32_t scene_x = 0;   ///< Scene tile X.
    int32_t scene_y = 0;   ///< Scene tile Y.
    WorldPoint location;    ///< World tile of the decoration.
    /// Definition name ("" if unnamed) — same as definitions::object(id)->name.
    std::string name() const { auto* d = definitions::object(id); return d ? d->name : std::string{}; }
};

/// A ground object (decoration rendered flat on the tile, e.g. manhole,
/// trapdoor) in the current scene. These are locs — interact via the normal
/// objects::interact(id, option, scene_x, scene_y) game-object path.
struct SceneGroundObject {
    uintptr_t ptr = 0;     ///< Raw sub-struct pointer (valid this tick only).
    int32_t id    = -1;    ///< Object definition ID (from tag >> 20).
    int32_t world_view_id = 0; ///< WorldView this object belongs to (0=overworld).
    int32_t scene_x = 0;   ///< Scene tile X.
    int32_t scene_y = 0;   ///< Scene tile Y.
    WorldPoint location;    ///< World tile of the ground object.
    /// Definition name ("" if unnamed) — same as definitions::object(id)->name.
    std::string name() const { auto* d = definitions::object(id); return d ? d->name : std::string{}; }
};

/// A visible player in the current scene (other than the local player).
/// @warning Entity pointers (`ptr`) are only valid during the current game tick.
/// Re-query each tick via find_players() or find_nearest_player().
///
/// **Position fields:** see `SceneNpc` — `location` is the snapped
/// per-tick world tile; `local_location` is the interpolated visual
/// position in fine-local units.
struct ScenePlayer {
    uintptr_t ptr           = 0;    ///< Raw entity pointer (valid this tick only).
    int32_t index           = -1;   ///< Slot index in the player entity table.
    int32_t world_view_id   = 0;    ///< WorldView this player belongs to (0=overworld).
    WorldPoint location;             ///< **Snapped** world tile (changes once per game tick).
    LocalPoint local_location;       ///< **Interpolated** fine-local position (visual position).
    std::string name;                ///< Display name (empty if unavailable).
    int32_t combat_level    = -1;   ///< Combat level (-1 if unavailable).
    float health_percent    = -1.0f; ///< Health bar fill [0,100], or -1 if no bar visible.
    int32_t health_ratio    = -1;   ///< Raw health bar green width (RuneLite getHealthRatio). -1 if no bar.
    int32_t health_scale    = -1;   ///< Raw health bar max width (RuneLite getHealthScale). -1 if no bar.
    SkullIcon skull_icon        = SkullIcon::NONE;
    OverheadIcon overhead_icon  = OverheadIcon::NONE;
    int32_t orientation     = -1;   ///< Direction facing (0-2047).
    int32_t animation       = -1;   ///< Current animation ID (-1 = idle).
    int32_t interacting_index = -1; ///< Validated target entity slot (-1 = not interacting; stale values filtered).
    int32_t interacting_type = 0;   ///< 0 = not interacting, 1 = target is NPC, 2 = target is player.
    std::string overhead_text;       ///< Overhead chat text (empty = none).
    Hitsplat hitsplat;               ///< Most recently applied hitsplat.
    int32_t friend_status    = 0;   ///< 0=local/unchecked, 1=online friend, 2=not a friend.
    int32_t fc_status        = 0;   ///< 0=local/unchecked, 1=FC member, 2=not FC member.
    int32_t clan_status      = 0;   ///< 0=local/unchecked, 1=clan member, 2=not clan.
    /// Worn item id per KitType slot (HEAD=0, CAPE, AMULET, WEAPON, TORSO, SHIELD,
    /// ARMS, LEGS, HAIR, HANDS, BOOTS, JAW=11); -1 = no item. Appended last.
    int32_t equipment[12] = {-1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1};
};

/// A resolved interaction target (RuneLite Actor.getInteracting() parity).
/// Returned by scene::resolve_interacting and the per-domain get_interacting
/// helpers. Exactly one of npc/player is populated, selected by is_player.
struct InteractingTarget {
    bool is_player = false; ///< Selects which of npc/player is populated (true = player).
    SceneNpc npc;        ///< Valid when !is_player.
    ScenePlayer player;  ///< Valid when is_player.
};

/// A snapshot of an in-flight projectile (arrow, spell, cannonball, etc.).
struct SceneProjectile {
    uintptr_t ptr           = 0;   ///< Raw projectile node pointer.
    int32_t id              = -1;  ///< Projectile / spotanim ID.
    int32_t start_cycle     = 0;   ///< Game cycle when the projectile was fired.
    int32_t end_cycle       = 0;   ///< Game cycle when it will land.
    int32_t slope           = 0;   ///< Arc steepness.
    int32_t start_height    = 0;   ///< Launch height.
    int32_t end_height      = 0;   ///< Impact height.
    WorldPoint start_location;      ///< Origin tile (world coords).
    WorldPoint target_location;     ///< Target tile (world coords).
    int32_t interacting_index = -1; ///< Target entity index (negative=NPC index+1, positive=player index).
    double x = 0.0, y = 0.0, z = 0.0; ///< Current interpolated position (double precision).
};

/// Projectile queries live in <obsidian/api/projectiles.h> (projectiles::find_all).

/// A ground graphics object (SpotAnim on the ground, e.g. campfire, spell impact).
struct SceneGraphicsObject {
    int32_t id           = -1;  ///< SpotAnim ID.
    int32_t local_x      = 0;   ///< Fine local X (>>7 for scene tile).
    int32_t local_y      = 0;   ///< Fine local Y (>>7 for scene tile).
    int32_t height       = 0;   ///< Height above the tile.
    int32_t start_cycle  = 0;   ///< Game cycle the effect began.
    int32_t anim_frame   = 0;   ///< Current animation frame.
    int32_t anim_id      = -1;  ///< Animation sequence ID.
    int32_t plane        = 0;   ///< Plane/level.
};

/// @name Graphics objects (mirrors projectiles::find_all)
/// @{
namespace graphics_objects {
    /// Returns every ground graphics object (SpotAnim) in the scene.
    std::vector<SceneGraphicsObject> find_all();
}
/// @}

/// @name Actor data by entity pointer
/// @{
namespace scene {
    /// Returns the active spot animations (graphics) on the actor.
    std::vector<SpotAnimData> actor_spot_anims(uintptr_t actor_ptr);
    /// Returns the actor's queued movement path points.
    std::vector<ScenePoint>   actor_path(uintptr_t actor_ptr);

    /// Resolve a raw interacting index to the targeted actor.
    /// Encoding (same as InteractingChangedEvent): -1 = none,
    /// 0..0x7FFF = NPC slot index, 0x8000+ = player slot index + 0x8000.
    /// Returns nullopt when idle or when the target is no longer in the scene.
    std::optional<InteractingTarget> resolve_interacting(int32_t interacting_index);
}
/// @}

} // namespace obsidian::api
