#pragma once
/// @file skill.h
/// @brief Skill identifiers and utility functions.
/// @ingroup entities
// ═══════════════════════════════════════════════════════════════════════════
// SKILL ENUM — Mirrors RuneLite Skill.java
// ═══════════════════════════════════════════════════════════════════════════

#include <cstdint>
#include <cmath>

namespace obsidian::api {

/// All player skills, indexed to match the game's skill array order.
/// Values correspond to the skill slot index used in varp/experience arrays.
enum class Skill : int32_t {
    ATTACK       = 0,
    DEFENCE      = 1,
    STRENGTH     = 2,
    HITPOINTS    = 3,
    RANGED       = 4,
    PRAYER       = 5,
    MAGIC        = 6,
    COOKING      = 7,
    WOODCUTTING  = 8,
    FLETCHING    = 9,
    FISHING      = 10,
    FIREMAKING   = 11,
    CRAFTING     = 12,
    SMITHING     = 13,
    MINING       = 14,
    HERBLORE     = 15,
    AGILITY      = 16,
    THIEVING     = 17,
    SLAYER       = 18,
    FARMING      = 19,
    RUNECRAFT    = 20,
    HUNTER       = 21,
    CONSTRUCTION = 22,
    SAILING      = 23,
};

/// Total number of skills (including Sailing).
constexpr int32_t SKILL_COUNT = 24;

/// Returns the display name of a skill (e.g. "Attack", "Sailing").
inline const char* skill_name(Skill s) {
    switch (s) {
        case Skill::ATTACK:       return "Attack";
        case Skill::DEFENCE:      return "Defence";
        case Skill::STRENGTH:     return "Strength";
        case Skill::HITPOINTS:    return "Hitpoints";
        case Skill::RANGED:       return "Ranged";
        case Skill::PRAYER:       return "Prayer";
        case Skill::MAGIC:        return "Magic";
        case Skill::COOKING:      return "Cooking";
        case Skill::WOODCUTTING:  return "Woodcutting";
        case Skill::FLETCHING:    return "Fletching";
        case Skill::FISHING:      return "Fishing";
        case Skill::FIREMAKING:   return "Firemaking";
        case Skill::CRAFTING:     return "Crafting";
        case Skill::SMITHING:     return "Smithing";
        case Skill::MINING:       return "Mining";
        case Skill::HERBLORE:     return "Herblore";
        case Skill::AGILITY:      return "Agility";
        case Skill::THIEVING:     return "Thieving";
        case Skill::SLAYER:       return "Slayer";
        case Skill::FARMING:      return "Farming";
        case Skill::RUNECRAFT:    return "Runecraft";
        case Skill::HUNTER:       return "Hunter";
        case Skill::CONSTRUCTION: return "Construction";
        case Skill::SAILING:      return "Sailing";
        default:                  return "Unknown";
    }
}

/// Returns true for members-only skills (Herblore, Agility, Thieving, etc.).
inline bool is_members_skill(Skill s) {
    switch (s) {
        case Skill::ATTACK: case Skill::DEFENCE: case Skill::STRENGTH:
        case Skill::HITPOINTS: case Skill::RANGED: case Skill::PRAYER:
        case Skill::MAGIC: case Skill::COOKING: case Skill::WOODCUTTING:
        case Skill::FISHING: case Skill::FIREMAKING: case Skill::CRAFTING:
        case Skill::SMITHING: case Skill::MINING: case Skill::RUNECRAFT:
            return false;
        default:
            return true;
    }
}

// ── XP table ────────────────────────────────────────────────────────────

/// Total XP required to reach a given level (1-99).
inline int32_t xp_for_level(int32_t level) {
    if (level <= 1) return 0;
    if (level > 99) level = 99;
    double total = 0;
    for (int i = 1; i < level; i++)
        total += static_cast<int>(i + 300.0 * std::pow(2.0, i / 7.0)) / 4.0;
    return static_cast<int32_t>(total);
}

/// Determine the level for a given total XP amount.
inline int32_t level_for_xp(int32_t xp) {
    for (int32_t lvl = 99; lvl >= 1; lvl--)
        if (xp >= xp_for_level(lvl)) return lvl;
    return 1;
}

/// XP remaining until the next level.
inline int32_t xp_to_next_level(int32_t current_xp) {
    int32_t lvl = level_for_xp(current_xp);
    if (lvl >= 99) return 0;
    return xp_for_level(lvl + 1) - current_xp;
}

} // namespace obsidian::api
