#pragma once
/// @file widgets.h
/// @brief Widget queries, clicks, and text manipulation.
///
/// Usage:
/// @code
///   namespace widgets = obsidian::api::widgets;
///   auto w = widgets::get(12, 12); // bank items widget
///   if (w.valid()) { ... }
///   widgets::click(-1, packed_id, 1);
/// @endcode

#include <cstdint>
#include <string>
#include <vector>

namespace obsidian::api {
struct WidgetRef;  // defined in game_api.h
}

namespace obsidian::api::widgets {

/// Get a widget by (group, child) id. Check WidgetRef::valid() on the result.
WidgetRef get(int32_t group_id, int32_t child_id);
/// Get a widget by packed id (group<<16 | child).
WidgetRef get(int32_t packed_id);
/// Resolve a widget's live screen rectangle by packed id; false if not found.
bool screen_pos(int32_t packed_id, int32_t& out_x, int32_t& out_y, int32_t& out_w, int32_t& out_h);
/// Resolve a widget's live screen rectangle by raw widget pointer; false if not found.
bool screen_pos_by_ptr(uintptr_t widget_ptr, int32_t& out_x, int32_t& out_y, int32_t& out_w, int32_t& out_h);
/// True if the given interface group is currently loaded.
bool is_group_loaded(int32_t group_id);
/// Find all widgets in a group whose text matches the given string.
std::vector<WidgetRef> find_by_text(int32_t group_id, const std::string& text);

/// Direct children of a widget, by its packed id. Backs WidgetRef::get_dynamic_children()
/// and get_child(); dual-layer (host walks its widget tree, sealed asks the host over
/// the C-ABI). Rarely called directly — use the WidgetRef methods.
std::vector<WidgetRef> children_of(int32_t parent_packed_id);

/// Full-fidelity right-click action slots for a widget — up to 12 slots of up
/// to 63 UTF-8 bytes each, SPARSE (empty strings between populated slots are
/// preserved; the slot index is the action_index that click() expects; the
/// vector runs through the last populated slot). This is the authoritative
/// read: WidgetRef::actions() delegates here, because the WidgetRef data block
/// is frozen plugin ABI at 10x24 and TRUNCATES longer labels ("Enable
/// <col=ff9040>Notes" is 24 bytes) and cannot carry slots 10-11 (bank items
/// write operation 11 "Examine"). child_index -1 = the point widget; a dynamic
/// child (which shares its parent's packed id) is addressed by its index.
/// Dual-layer: host reads its widget tree; sealed asks the host (C-ABI
/// v6.7 get_actions_v2 — empty on older hosts, whereupon WidgetRef::actions()
/// falls back to the truncated data block).
std::vector<std::string> raw_actions(int32_t packed_id, int32_t child_index = -1);
/// Invoke a widget action (menu option) by packed id and action index.
/// @return Whether the click was accepted for dispatch — see
///         `interaction::invoke_action` for exactly what that guarantees on
///         each side. False always means the click definitely did not happen.
bool click(int32_t slot, int32_t packed_widget_id, int32_t action_index);
/// Invoke a widget action on a specific item slot by packed id.
/// @return Same contract as `click`.
bool click_item(int32_t slot, int32_t packed_widget_id, int32_t action_index, int32_t item_id);
/// Set a widget's text by (group, child) id.
void set_text(int32_t group_id, int32_t child_id, const char* text);
void set_text(int32_t packed_id, const char* text);  ///< Packed-id overload.

// ── Dynamic child widget creation (mirrors RuneLite Widget.createChild) ──
// Parent must be Type==LAYER (0). Index -1 appends to the end.
/// Create a dynamic child widget under a LAYER parent; index -1 appends.
void create_child(int32_t parent_packed_id, int32_t index, int32_t type);
/// Delete all dynamic children of a parent widget.
void delete_all_children(int32_t parent_packed_id);

// ── Dynamic child property setters (by parent + child index) ──
/// Show or hide a dynamic child widget.
void set_child_hidden(int32_t parent_packed_id, int32_t child_index, bool hidden);
/// Set a dynamic child's sprite id.
void set_child_sprite(int32_t parent_packed_id, int32_t child_index, int32_t sprite_id);
/// Set a dynamic child's position (relative to parent).
void set_child_position(int32_t parent_packed_id, int32_t child_index, int32_t x, int32_t y);
/// Set a dynamic child's width and height.
void set_child_size(int32_t parent_packed_id, int32_t child_index, int32_t width, int32_t height);
/// Set a dynamic child's text.
void set_child_text(int32_t parent_packed_id, int32_t child_index, const char* text);
/// Set a dynamic child's text color (RGB).
void set_child_color(int32_t parent_packed_id, int32_t child_index, int32_t rgb);
/// Set a dynamic child's opacity.
void set_child_opacity(int32_t parent_packed_id, int32_t child_index, int32_t opacity);
/// Set the text of a dynamic child's action (menu option) slot.
void set_child_action(int32_t parent_packed_id, int32_t child_index, int32_t action_slot, const char* text);
/// Set a dynamic child's displayed item id and quantity.
void set_child_item(int32_t parent_packed_id, int32_t child_index, int32_t item_id, int32_t quantity);
/// Set a dynamic child's widget type.
void set_child_type(int32_t parent_packed_id, int32_t child_index, int32_t type);
/// Set a dynamic child's model id and model type.
void set_child_model(int32_t parent_packed_id, int32_t child_index, int32_t model_id, int32_t model_type);
/// Set a dynamic child's font id.
void set_child_font(int32_t parent_packed_id, int32_t child_index, int32_t font_id);

// ── Direct widget property setters (by packed widget ID, works on any widget) ──
/// Set any widget's sprite id by packed id.
void set_sprite(int32_t packed_id, int32_t sprite_id);
/// Show or hide any widget by packed id.
void set_hidden(int32_t packed_id, bool hidden);

// ── Widget highlighting (rendered by core overlay) ──
/// Highlight a widget with a colored outline. Uses the core's widget
/// highlight renderer (shared with the widget inspector).
/// @param packed_id  Group<<16 | child
/// @param color      ABGR ImGui format (e.g. IM_COL32(0,255,255,180))
/// @param thickness  Outline width in pixels (default 2.0)
void highlight(int32_t packed_id, uint32_t color, float thickness = 2.0f);

/// Highlight a dynamic child widget.
void highlight_child(int32_t packed_id, int32_t child_index, uint32_t color, float thickness = 2.0f);

/// Clear all widget highlights set by this API.
void clear_highlights();

// ── (group, child) convenience overloads ────────────────────────────────
// Packed ids are canonical; these pack and delegate so callers never need
// the (group << 16) | child idiom inline.

/// Pack a (group, child) pair into a canonical widget id.
inline constexpr int32_t pack_id(int32_t group_id, int32_t child_id) {
    return (group_id << 16) | (child_id & 0xFFFF);
}

/// (group, child) convenience overload of screen_pos.
inline bool screen_pos(int32_t group_id, int32_t child_id,
                       int32_t& out_x, int32_t& out_y, int32_t& out_w, int32_t& out_h) {
    return screen_pos(pack_id(group_id, child_id), out_x, out_y, out_w, out_h);
}
/// (group, child) convenience overload of click.
inline bool click(int32_t slot, int32_t group_id, int32_t child_id, int32_t action_index) {
    return click(slot, pack_id(group_id, child_id), action_index);
}
/// (group, child) convenience overload of click_item.
inline bool click_item(int32_t slot, int32_t group_id, int32_t child_id,
                       int32_t action_index, int32_t item_id) {
    return click_item(slot, pack_id(group_id, child_id), action_index, item_id);
}
/// (group, child) convenience overload of set_sprite.
inline void set_sprite(int32_t group_id, int32_t child_id, int32_t sprite_id) {
    set_sprite(pack_id(group_id, child_id), sprite_id);
}
/// (group, child) convenience overload of set_hidden.
inline void set_hidden(int32_t group_id, int32_t child_id, bool hidden) {
    set_hidden(pack_id(group_id, child_id), hidden);
}
/// (group, child) convenience overload of highlight.
inline void highlight(int32_t group_id, int32_t child_id, uint32_t color, float thickness = 2.0f) {
    highlight(pack_id(group_id, child_id), color, thickness);
}

} // namespace obsidian::api::widgets
