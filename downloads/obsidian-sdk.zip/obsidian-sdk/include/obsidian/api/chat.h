#pragma once
/// @file chat.h
/// @brief Chat message types and the ChatMessage event struct.
/// @ingroup ui
// ═══════════════════════════════════════════════════════════════════════════
// CHAT — ChatMessageType enum and ChatMessage struct
// ═══════════════════════════════════════════════════════════════════════════
// Mirrors RuneLite ChatMessageType.java.
// Used by the ChatMessage event and chat message buffer reading.
// ═══════════════════════════════════════════════════════════════════════════

#include <cstdint>
#include <string>

namespace obsidian::api {

/// Internal message type IDs used by the game engine.
/// Mirrors RuneLite ChatMessageType.java. Carried in ChatMessage::type.
enum class ChatMessageType : int32_t {
    GAMEMESSAGE         = 0,
    MODCHAT             = 1,
    PUBLICCHAT          = 2,
    PRIVATECHAT         = 3,
    ENGINE              = 4,
    LOGINLOGOUTNOTIFICATION = 5,
    PRIVATECHATOUT      = 6,
    MODPRIVATECHAT      = 7,
    FRIENDSCHAT         = 9,
    FRIENDSCHATNOTIFICATION = 11,
    BROADCAST           = 14,
    SNAPSHOTFEEDBACK    = 26,
    ITEM_EXAMINE        = 27,
    NPC_EXAMINE         = 28,
    OBJECT_EXAMINE      = 29,
    FRIENDNOTIFICATION  = 30,
    IGNORENOTIFICATION  = 31,
    CLAN_CHAT           = 41,
    CLAN_MESSAGE        = 43,
    CLAN_GUEST_CHAT     = 44,
    CLAN_GUEST_MESSAGE  = 46,
    AUTOTYPER           = 90,
    MODAUTOTYPER        = 91,
    CONSOLE             = 99,
    TRADEREQ            = 101,
    TRADE               = 102,
    CHALREQ_TRADE       = 103,
    CHALREQ_FRIENDSCHAT = 104,
    SPAM                = 105,
    PLAYERRELATED       = 106,
    TENSECTIMEOUT       = 107,
    WELCOME             = 108,
    CLAN_CREATION_INVITATION = 109,
    CLAN_GIM_FORM_GROUP = 110,
    CLAN_GIM_GROUP_WITH = 111,
    UNKNOWN             = -1,
};

/// Returns a short human-readable label for a chat message type.
inline const char* chat_message_type_name(ChatMessageType t) {
    switch (t) {
        case ChatMessageType::GAMEMESSAGE:         return "Game";
        case ChatMessageType::MODCHAT:             return "Mod Chat";
        case ChatMessageType::PUBLICCHAT:          return "Public";
        case ChatMessageType::PRIVATECHAT:         return "Private";
        case ChatMessageType::ENGINE:              return "Engine";
        case ChatMessageType::LOGINLOGOUTNOTIFICATION: return "Login/Logout";
        case ChatMessageType::PRIVATECHATOUT:      return "Private Out";
        case ChatMessageType::MODPRIVATECHAT:      return "Mod Private";
        case ChatMessageType::FRIENDSCHAT:         return "Friends Chat";
        case ChatMessageType::FRIENDSCHATNOTIFICATION: return "FC Notification";
        case ChatMessageType::BROADCAST:           return "Broadcast";
        case ChatMessageType::ITEM_EXAMINE:        return "Item Examine";
        case ChatMessageType::NPC_EXAMINE:         return "NPC Examine";
        case ChatMessageType::OBJECT_EXAMINE:      return "Object Examine";
        case ChatMessageType::CLAN_CHAT:           return "Clan Chat";
        case ChatMessageType::CLAN_MESSAGE:        return "Clan Message";
        case ChatMessageType::CLAN_GUEST_CHAT:     return "Clan Guest Chat";
        case ChatMessageType::CLAN_GUEST_MESSAGE:  return "Clan Guest Message";
        case ChatMessageType::AUTOTYPER:           return "Autotyper";
        case ChatMessageType::CONSOLE:             return "Console";
        case ChatMessageType::TRADEREQ:            return "Trade Request";
        case ChatMessageType::TRADE:               return "Trade";
        case ChatMessageType::SPAM:                return "Spam";
        case ChatMessageType::WELCOME:             return "Welcome";
        default:                                   return "Unknown";
    }
}

/// A single chat message delivered via the ChatMessage event.
/// `name` is the sender; `sender` is the channel (clan/FC) name; `message` may
/// contain colour tags (e.g. `<col=ff0000>`).
struct ChatMessage {
    ChatMessageType type = ChatMessageType::UNKNOWN;
    std::string name;       // sender name (empty for game messages)
    std::string sender;     // clan/FC channel name
    std::string message;    // message text (may contain color tags)
    int32_t timestamp = 0;  // game cycle when received
};

} // namespace obsidian::api
