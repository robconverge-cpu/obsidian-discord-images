#pragma once
/// @file collision.h
/// @brief Tile collision flags and pathfinding helpers.
/// @ingroup scene
// ═══════════════════════════════════════════════════════════════════════════
// COLLISION DATA — Tile collision flags and pathfinding helpers
// ═══════════════════════════════════════════════════════════════════════════
// Mirrors RuneLite CollisionData.java + CollisionDataFlag constants.
// Reads collision flags from the Scene's CollisionMap structs with inset
// correction (XInset=-1, YInset=-1 in native client).
// ═══════════════════════════════════════════════════════════════════════════


#include <cstdint>

namespace obsidian::api {

/// Bitfield constants for collision flags on each scene tile.
/// Mirrors RuneLite CollisionDataFlag. Used with CollisionData::get_flag().
namespace CollisionFlag {
    constexpr uint32_t BLOCK_MOVEMENT_NW            = 0x1;
    constexpr uint32_t BLOCK_MOVEMENT_N             = 0x2;
    constexpr uint32_t BLOCK_MOVEMENT_NE            = 0x4;
    constexpr uint32_t BLOCK_MOVEMENT_E             = 0x8;
    constexpr uint32_t BLOCK_MOVEMENT_SE            = 0x10;
    constexpr uint32_t BLOCK_MOVEMENT_S             = 0x20;
    constexpr uint32_t BLOCK_MOVEMENT_SW            = 0x40;
    constexpr uint32_t BLOCK_MOVEMENT_W             = 0x80;
    constexpr uint32_t BLOCK_MOVEMENT_OBJECT        = 0x100;
    constexpr uint32_t BLOCK_MOVEMENT_FLOOR_DECO    = 0x40000;
    constexpr uint32_t BLOCK_MOVEMENT_FLOOR         = 0x200000;
    constexpr uint32_t BLOCK_MOVEMENT_FULL          = BLOCK_MOVEMENT_OBJECT | BLOCK_MOVEMENT_FLOOR_DECO | BLOCK_MOVEMENT_FLOOR;
    constexpr uint32_t BLOCK_MOVEMENT_DIRECTIONS    = 0xFF; // all 8 directional flags

    constexpr uint32_t BLOCK_LOS_N                  = 0x400;
    constexpr uint32_t BLOCK_LOS_E                  = 0x1000;
    constexpr uint32_t BLOCK_LOS_S                  = 0x4000;
    constexpr uint32_t BLOCK_LOS_W                  = 0x10000;
    constexpr uint32_t BLOCK_LOS_FULL               = 0x20000;
}


} // namespace obsidian::api
