#pragma once
/// @file tile.h
/// @brief Scene tile wrapper providing access to all objects on a tile.
/// @ingroup scene
// ═══════════════════════════════════════════════════════════════════════════
// TILE — Scene tile wrapper with typed object access
// ═══════════════════════════════════════════════════════════════════════════
// Mirrors RuneLite Tile.java. Wraps a TileDetail pointer and provides
// access to all objects on a tile: game objects, wall, decoration, ground
// items, and ground item layer.
//
// The data types (GroundItem, Tile) are public contract types.
// Host/plugin code uses these types via IPC snapshots; the direct
// memory-access implementations are compiled only into the core build.
// ═══════════════════════════════════════════════════════════════════════════


#include <obsidian/api/coords.h>
#include <obsidian/api/objects.h>
#include <cstdint>
#include <vector>
#include <optional>

namespace obsidian::api {

/// An individual item lying on the ground at a scene tile.
/// Read from the TileItemManager linked list (WorldView+0x160), not from tile_detail.
struct GroundItem {
    int32_t id       = -1;
    int32_t quantity = 0;
    int32_t scene_x  = 0;
    int32_t scene_y  = 0;
    int32_t plane    = 0;
    int32_t world_view_id = 0;
    int32_t world_x = 0;     ///< Absolute world X (base + scene).
    int32_t world_y = 0;     ///< Absolute world Y (base + scene).
    int32_t ownership  = 0;  ///< TileItem+0x20 — owner/state.
    int32_t owner_flag = 0;  ///< TileItem+0x24 — ownership flag.

    /// Absolute world location of this ground item, from the scene base.
    WorldPoint world_location(int32_t base_x, int32_t base_y) const {
        return WorldPoint::from_scene(scene_x, scene_y, base_x, base_y, plane);
    }
};

/// Wraps a TileDetail pointer and provides typed access to every object on the tile:
/// game objects, wall, decoration, ground object layer, and ground items.
/// Mirrors RuneLite Tile.java.
class Tile {
    uintptr_t detail_ = 0;
    int32_t scene_x_ = 0;
    int32_t scene_y_ = 0;
    int32_t plane_ = 0;

public:
    /// Construct an invalid (null) tile.
    Tile() = default;
    /// Construct a tile wrapping a TileDetail pointer at the given scene coords.
    Tile(uintptr_t detail, int32_t sx, int32_t sy, int32_t plane)
        : detail_(detail), scene_x_(sx), scene_y_(sy), plane_(plane) {}

    /// True if this tile wraps a non-null TileDetail pointer.
    bool valid() const { return detail_ != 0; }
    /// Raw TileDetail pointer.
    uintptr_t raw() const { return detail_; }

    /// Scene X coordinate of this tile.
    int32_t scene_x() const { return scene_x_; }
    /// Scene Y coordinate of this tile.
    int32_t scene_y() const { return scene_y_; }
    /// Plane (0-3) of this tile.
    int32_t plane() const { return plane_; }

    /// Scene-space location of this tile.
    ScenePoint scene_location() const { return {scene_x_, scene_y_}; }
    /// Absolute world location of this tile, from the scene base.
    WorldPoint world_location(int32_t base_x, int32_t base_y) const {
        return WorldPoint::from_scene(scene_x_, scene_y_, base_x, base_y, plane_);
    }
    /// Local (fine-coord) location of this tile.
    LocalPoint local_location() const { return LocalPoint::from_scene(scene_x_, scene_y_); }

};

} // namespace obsidian::api
