#pragma once
/// @file overlay_layout.h
/// @brief Panel layout manager — auto-stacking at anchors + ALT+drag repositioning.
///
/// Single instance per frame. Core instantiates it in the render loop.
/// Host-side panels arrive via IPC PANEL_* commands and go through the same
/// layout manager on core side, ensuring correct stacking across all sources.

#include <obsidian/api/overlay.h>
#include <obsidian/api/overlay_panel.h>
#include <cstdint>
#include <cstdlib>
#include <mutex>
#include <string>
#include <unordered_map>
#include <unordered_set>
#include <vector>

namespace obsidian::api {

class OverlayPanelLayout {
public:
    static constexpr int32_t MARGIN = 8;
    static constexpr int32_t STACK_GAP = 4;
    static constexpr int32_t MINIMAP_RESERVED = 170;

    void begin_frame(int32_t canvas_w, int32_t canvas_h) {
        std::lock_guard<std::recursive_mutex> lk(mtx_);
        canvas_w_ = canvas_w;
        canvas_h_ = canvas_h;
        for (auto& a : anchors_) a = {};
        frame_panels_.clear();
    }

    struct Position { int32_t x, y; };

    Position compute_position(const char* id, OverlayPosition pos,
                              int32_t panel_w, int32_t panel_h) {
        std::lock_guard<std::recursive_mutex> lk(mtx_);
        auto& a = anchor_state(pos);
        Position base = anchor_origin(pos, panel_w, panel_h, a);

        auto it = panels_.find(id);
        if (it != panels_.end()) {
            base.x += it->second.drag_offset_x;
            base.y += it->second.drag_offset_y;
        }

        advance(pos, panel_w, panel_h);
        return base;
    }

    OverlayPanel::RenderResult render_panel(OverlayContext& ctx, const OverlayPanel& panel,
                                             const char* id, OverlayPosition pos) {
        std::lock_guard<std::recursive_mutex> lk(mtx_);
        const bool collapsed = collapsed_.count(id) > 0;
        int32_t w = panel.calc_width();
        int32_t h = collapsed ? panel.calc_height_collapsed() : panel.calc_height();
        auto p = compute_position(id, pos, w, h);
        auto result = collapsed ? panel.render_collapsed(ctx, p.x, p.y)
                                : panel.render(ctx, p.x, p.y);
        register_panel_bounds(id, result.x, result.y, result.w, result.h);
        return result;
    }

    /// True if the panel with this id is collapsed to its title bar.
    bool is_collapsed(const char* id) const {
        std::lock_guard<std::recursive_mutex> lk(mtx_);
        return collapsed_.count(id) > 0;
    }

    // ── Persistence (drag offsets + collapse survive restarts) ──────────

    struct PersistEntry { std::string id; int32_t dx = 0, dy = 0; bool collapsed = false; };

    /// Snapshot every panel with a non-default offset or collapsed state.
    std::vector<PersistEntry> persist_snapshot() const {
        std::lock_guard<std::recursive_mutex> lk(mtx_);
        std::vector<PersistEntry> out;
        for (const auto& [id, drag] : panels_) {
            if (drag.drag_offset_x == 0 && drag.drag_offset_y == 0 &&
                collapsed_.count(id) == 0)
                continue;
            out.push_back({id, drag.drag_offset_x, drag.drag_offset_y,
                           collapsed_.count(id) > 0});
        }
        for (const auto& id : collapsed_)
            if (panels_.find(id) == panels_.end())
                out.push_back({id, 0, 0, true});
        return out;
    }

    /// Restore one persisted panel state (startup load).
    void restore_entry(const std::string& id, int32_t dx, int32_t dy, bool collapsed) {
        std::lock_guard<std::recursive_mutex> lk(mtx_);
        auto& ps = panels_[id];
        ps.drag_offset_x = dx;
        ps.drag_offset_y = dy;
        if (collapsed) collapsed_.insert(id);
    }

    /// True once after any drag/collapse change since the last call.
    bool take_layout_dirty() {
        std::lock_guard<std::recursive_mutex> lk(mtx_);
        const bool d = dirty_;
        dirty_ = false;
        return d;
    }

    // ── ALT+drag input handling ─────────────────────────────────────────

    void on_mouse_down(int32_t mx, int32_t my, bool alt_held) {
        if (!alt_held) return;
        std::lock_guard<std::recursive_mutex> lk(mtx_);
        for (auto& [id, bounds] : frame_panels_) {
            if (mx >= bounds.x && mx < bounds.x + bounds.w &&
                my >= bounds.y && my < bounds.y + bounds.h) {
                dragging_ = true;
                drag_id_ = id;
                drag_start_mx_ = mx;
                drag_start_my_ = my;
                // ALT+click (no movement) on the title zone toggles collapse.
                drag_title_zone_ = (my < bounds.y + TITLE_CLICK_ZONE);
                auto& ps = panels_[id];
                drag_orig_ox_ = ps.drag_offset_x;
                drag_orig_oy_ = ps.drag_offset_y;
                return;
            }
        }
    }

    void on_mouse_move(int32_t mx, int32_t my) {
        std::lock_guard<std::recursive_mutex> lk(mtx_);
        if (!dragging_) return;
        auto& ps = panels_[drag_id_];
        ps.drag_offset_x = drag_orig_ox_ + (mx - drag_start_mx_);
        ps.drag_offset_y = drag_orig_oy_ + (my - drag_start_my_);
    }

    void on_mouse_up() {
        std::lock_guard<std::recursive_mutex> lk(mtx_);
        if (dragging_ && drag_title_zone_ && !drag_id_.empty()) {
            auto& ps = panels_[drag_id_];
            const int32_t dx = ps.drag_offset_x - drag_orig_ox_;
            const int32_t dy = ps.drag_offset_y - drag_orig_oy_;
            if (std::abs(dx) < 4 && std::abs(dy) < 4) {
                // Click, not a drag — toggle collapse and undo the jitter.
                ps.drag_offset_x = drag_orig_ox_;
                ps.drag_offset_y = drag_orig_oy_;
                if (!collapsed_.erase(drag_id_)) collapsed_.insert(drag_id_);
            }
            dirty_ = true;
        } else if (dragging_ && !drag_id_.empty()) {
            dirty_ = true;   // completed body drag
        }
        dragging_ = false;
        drag_title_zone_ = false;
        drag_id_.clear();
    }

    bool is_dragging() const {
        std::lock_guard<std::recursive_mutex> lk(mtx_);
        return dragging_;
    }

    void register_panel_bounds(const char* id, int32_t x, int32_t y, int32_t w, int32_t h) {
        std::lock_guard<std::recursive_mutex> lk(mtx_);
        frame_panels_[id] = {x, y, w, h};
    }

private:
    struct AnchorState {
        int32_t cursor = 0;
    };

    struct PanelDrag {
        int32_t drag_offset_x = 0;
        int32_t drag_offset_y = 0;
    };

    struct PanelBounds {
        int32_t x, y, w, h;
    };

    AnchorState& anchor_state(OverlayPosition pos) {
        int idx = static_cast<int>(pos);
        if (idx < 0 || idx >= MAX_ANCHORS) idx = 0;
        return anchors_[idx];
    }

    void advance(OverlayPosition pos, int32_t /*panel_w*/, int32_t panel_h) {
        auto& a = anchor_state(pos);
        a.cursor += panel_h + STACK_GAP;
    }

    Position anchor_origin(OverlayPosition pos, int32_t panel_w, int32_t panel_h,
                           const AnchorState& a) const {
        switch (pos) {
        case OverlayPosition::TOP_LEFT:
            return {MARGIN, MARGIN + a.cursor};

        case OverlayPosition::TOP_CENTER:
            return {(canvas_w_ - panel_w) / 2, MARGIN + a.cursor};

        case OverlayPosition::TOP_RIGHT:
            return {canvas_w_ - MARGIN - panel_w, MARGIN + a.cursor};

        case OverlayPosition::BOTTOM_LEFT:
            return {MARGIN, canvas_h_ - MARGIN - panel_h - a.cursor};

        case OverlayPosition::BOTTOM_RIGHT:
            return {canvas_w_ - MARGIN - panel_w, canvas_h_ - MARGIN - panel_h - a.cursor};

        case OverlayPosition::ABOVE_CHATBOX_RIGHT:
            return {canvas_w_ - MARGIN - panel_w, canvas_h_ - 165 - panel_h - a.cursor};

        case OverlayPosition::CANVAS_TOP_RIGHT:
            return {canvas_w_ - MARGIN - panel_w, MINIMAP_RESERVED + a.cursor};

        case OverlayPosition::TOOLTIP:
            return {canvas_w_ / 2 - panel_w / 2, canvas_h_ / 2 - panel_h / 2};

        case OverlayPosition::DYNAMIC:
        default:
            return {MARGIN, MARGIN + a.cursor};
        }
    }

    static constexpr int MAX_ANCHORS = 9;
    static constexpr int32_t TITLE_CLICK_ZONE = 32;  ///< px from panel top that counts as the title

    int32_t canvas_w_ = 0;
    int32_t canvas_h_ = 0;
    AnchorState anchors_[MAX_ANCHORS] = {};

    std::unordered_map<std::string, PanelDrag> panels_;
    std::unordered_map<std::string, PanelBounds> frame_panels_;
    std::unordered_set<std::string> collapsed_;

    // The layout is mutated from the SwapBuffers render path AND the GameDraw
    // overlay path (which may be distinct threads), plus drag input applied on
    // the render thread. Concurrent mutation of the maps double-frees their node
    // lists (0xC0000374, caught by PageHeap in begin_frame's frame_panels_.clear).
    // recursive_mutex: render_panel locks then calls compute_position +
    // register_panel_bounds, which lock again. Uncontended when single-threaded.
    mutable std::recursive_mutex mtx_;

    bool dragging_ = false;
    bool dirty_ = false;
    bool drag_title_zone_ = false;
    std::string drag_id_;
    int32_t drag_start_mx_ = 0;
    int32_t drag_start_my_ = 0;
    int32_t drag_orig_ox_ = 0;
    int32_t drag_orig_oy_ = 0;
};

// ── Convenience: render a panel through the context's layout or recorder ────
/// Plugins call this from Overlay::render(). Handles both paths:
///   - Host side (recorder set): serializes as IPC PANEL_* commands
///   - Core side (layout set): computes stacked position and renders
inline OverlayPanel::RenderResult render_panel(OverlayContext& ctx,
                                                const OverlayPanel& panel,
                                                const char* id,
                                                OverlayPosition pos) {
    auto* rec = ctx.recorder();
    if (rec) {
        rec->record_panel_begin(id, static_cast<int32_t>(pos),
            panel.get_background(), panel.get_border(),
            panel.get_title_color(), panel.get_label_color(),
            panel.get_text_color(), panel.get_accent(),
            panel.get_border_radius(), panel.get_padding(),
            panel.get_line_height(),
            panel.get_header_bg(), panel.get_item_have(),
            panel.get_item_missing(), panel.get_style_flags());

        for (auto& item : panel.items()) {
            switch (item.type) {
            case OverlayElementType::Title:
                rec->record_panel_title(item.left.c_str(), item.color,
                                        item.right.empty() ? nullptr : item.right.c_str());
                break;
            case OverlayElementType::StatTile:
                rec->record_panel_stat_tile(item.left.c_str(), item.right.c_str(),
                                            item.color);
                break;
            case OverlayElementType::TimerRing:
                rec->record_panel_timer_ring(item.left.c_str(), item.right.c_str(),
                                             item.percent, item.color);
                break;
            case OverlayElementType::Sparkline:
                rec->record_panel_sparkline(item.left.c_str(), item.color);
                break;
            case OverlayElementType::Row:
                rec->record_panel_row(item.left.c_str(), item.right.c_str(),
                                      item.color, item.color2);
                break;
            case OverlayElementType::Label:
                rec->record_panel_label(item.left.c_str(), item.color);
                break;
            case OverlayElementType::Progress:
                rec->record_panel_progress(item.left.c_str(), item.percent,
                                           item.color2, item.color3, item.extra_h);
                break;
            case OverlayElementType::Separator:
                rec->record_panel_separator(item.color);
                break;
            case OverlayElementType::Spacer:
                rec->record_panel_spacer(item.extra_h);
                break;
            case OverlayElementType::Header:
                rec->record_panel_header(item.left.c_str(), item.color);
                break;
            case OverlayElementType::ItemRow:
                rec->record_panel_item_row(item.left.c_str(), item.int_val,
                                           item.int_val2, (item.flags & 1) != 0,
                                           item.color, item.color2, item.item_id);
                break;
            case OverlayElementType::IconText:
                rec->record_panel_icon_text(item.left.c_str(), item.right.c_str(), item.color);
                break;
            case OverlayElementType::ImageRect:
                rec->record_panel_image_rect(item.left.c_str(), item.int_val, item.int_val2,
                                             item.color, item.color2);
                break;
            case OverlayElementType::TableRow: {
                std::string packed;
                for (size_t i = 0; i < item.cells.size(); ++i) {
                    if (i > 0) packed += '|';
                    packed += item.cells[i];
                }
                uint32_t cols[4] = {0, 0, 0, 0};
                for (size_t i = 0; i < item.cell_colors.size() && i < 4; ++i)
                    cols[i] = item.cell_colors[i];
                uint16_t aligns = 0;
                for (size_t i = 0; i < item.cell_aligns.size() && i < 4; ++i)
                    aligns |= static_cast<uint16_t>(item.cell_aligns[i] & 0x3) << (i * 2);
                rec->record_panel_table_row(packed.c_str(), cols[0], cols[1], cols[2], cols[3],
                                            aligns);
                break;
            }
            default: break;
            }
        }
        rec->record_panel_end();
        return {0, 0, panel.calc_width(), panel.calc_height()};
    }

    auto* layout = static_cast<OverlayPanelLayout*>(ctx.layout());
    if (layout) {
        return layout->render_panel(ctx, panel, id, pos);
    }

    return panel.render(ctx, 0, 0);
}

} // namespace obsidian::api
