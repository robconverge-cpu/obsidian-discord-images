#pragma once
/// @file overlay_recorder.h
/// @brief Host-side command recorder interface used by OverlayContext.
///
/// When `OverlayContext::recorder_` is non-null, every `render_*` method
/// forwards its arguments to a matching `record_*` hook on this interface
/// instead of drawing directly. The concrete implementation serialises
/// the call into a command stream which the client drains once per
/// frame and replays through a recorder-less
/// OverlayContext (i.e. the normal core drawing path).
///
/// This is the glue that lets host-side plugins register ordinary
/// `Overlay` subclasses, write plain `render(OverlayContext&)` bodies,
/// and have their draws appear in the game viewport — with zero per-plugin
/// core-side companion code.

#include <obsidian/api/coords.h>
#include <cstdint>

namespace obsidian::api {

struct SceneNpc;
struct ScenePlayer;
enum class TileLineStyle;

/// Abstract record target for `OverlayContext` draw calls. One method
/// per host-reachable `render_*` primitive. Argument order must match
/// the matching `OverlayContext::render_*` method exactly so the context
/// bodies stay boilerplate.
///
/// Implementations MUST be thread-compatible (called from the single
/// host-side overlay tick thread only).
class OverlayRecorder {
public:
    virtual ~OverlayRecorder() = default;

    // ── World / tile primitives ──────────────────────────────────────────
    virtual void record_tile(int32_t scene_x, int32_t scene_y,
                             uint32_t fill, uint32_t outline,
                             float thickness, int32_t line_style) = 0;

    virtual void record_actor_highlight(int32_t local_x, int32_t local_y,
                                        int32_t size,
                                        uint32_t fill, uint32_t outline,
                                        float thickness, int32_t line_style) = 0;

    virtual void record_object_bounds(int32_t tile_x, int32_t tile_y,
                                      int32_t size_x, int32_t size_y,
                                      uint32_t fill, uint32_t outline,
                                      float thickness, int32_t line_style) = 0;

    /// @brief 3D box hull highlight for scene objects.
    ///
    /// Projects an 8-corner AABB (footprint × height) through the camera
    /// and draws the convex hull of the projected points. Gives a proper
    /// 3D-looking outline for scene objects without needing access to
    /// their model vertex data — matches the fallback path of
    /// `render_npc_hull` when model capture is unavailable.
    virtual void record_object_bounds_hull(int32_t tile_x, int32_t tile_y,
                                           int32_t size_x, int32_t size_y,
                                           int32_t height,
                                           uint32_t fill, uint32_t outline,
                                           float thickness) = 0;

    /// @brief Real model-vertex hull for a scene object.
    ///
    /// Reads the scene object's animated model **at draw time**, then
    /// projects every vertex through the camera and draws the 2D convex hull.
    /// Re-reading the model pointer on the render thread (rather
    /// than caching it from the host emit path) prevents flicker
    /// when the game swaps the model during animation or state
    /// transitions — same stability guarantee the NPC hull hook
    /// pipeline provides, without requiring a hook.
    virtual void record_scene_object_hull(int32_t local_x, int32_t local_y,
                                          int32_t anchor_y,
                                          int32_t orientation,
                                          uintptr_t scene_obj_real_base,
                                          uint32_t fill, uint32_t outline,
                                          float thickness) = 0;

    virtual void record_object_hull_by_id(int32_t object_id,
                                          int32_t world_x, int32_t world_y,
                                          uint32_t fill, uint32_t outline,
                                          float thickness) = 0;

    virtual void record_text(int32_t local_x, int32_t local_y,
                             const char* text, uint32_t color,
                             bool background, int32_t height_offset) = 0;

    virtual void record_line(int32_t lx1, int32_t ly1, int32_t lx2, int32_t ly2,
                             uint32_t color, float thickness) = 0;

    virtual void record_quad(const ScreenPoint& a, const ScreenPoint& b,
                             const ScreenPoint& c, const ScreenPoint& d,
                             uint32_t fill, uint32_t outline,
                             float thickness, int32_t line_style) = 0;

    virtual void record_arrow_world(int32_t scene_x, int32_t scene_y,
                                    int32_t extra_h,
                                    uint32_t color) = 0;

    // ── NPC primitives ───────────────────────────────────────────────────
    virtual void record_npc_hull(const SceneNpc& npc,
                                 uint32_t fill, uint32_t outline,
                                 float thickness) = 0;

    virtual void record_npc_tile(const SceneNpc& npc,
                                 uint32_t fill, uint32_t outline,
                                 float thickness, int32_t line_style) = 0;

    virtual void record_npc_tile_true(const SceneNpc& npc,
                                      uint32_t fill, uint32_t outline,
                                      float thickness, int32_t line_style) = 0;

    virtual void record_npc_sw_tile(const SceneNpc& npc,
                                    uint32_t fill, uint32_t outline,
                                    float thickness, int32_t line_style) = 0;

    virtual void record_npc_sw_tile_true(const SceneNpc& npc,
                                         uint32_t fill, uint32_t outline,
                                         float thickness, int32_t line_style) = 0;

    virtual void record_npc_outline(const SceneNpc& npc,
                                    uint32_t color, float thickness,
                                    int32_t feather) = 0;

    virtual void record_npc_clickbox(const SceneNpc& npc,
                                     uint32_t fill, uint32_t outline,
                                     float thickness) = 0;

    virtual void record_npc_clickbox_hover(const SceneNpc& npc,
                                           uint32_t normal_fill,
                                           uint32_t normal_outline,
                                           uint32_t hover_fill,
                                           uint32_t hover_outline,
                                           float thickness) = 0;

    // ── Player primitives ────────────────────────────────────────────────
    virtual void record_player_tile(const ScenePlayer& p,
                                    uint32_t fill, uint32_t outline,
                                    float thickness, int32_t line_style) = 0;

    virtual void record_player_tile_true(const ScenePlayer& p,
                                         uint32_t fill, uint32_t outline,
                                         float thickness, int32_t line_style) = 0;

    virtual void record_player_text(const ScenePlayer& p,
                                     const char* text, uint32_t color,
                                     int32_t height_offset) = 0;

    // ── Widget-anchored primitives ───────────────────────────────────────
    virtual void record_widget_text(uintptr_t widget_ptr,
                                     const char* text, uint32_t color,
                                     int32_t offset_x, int32_t offset_y) = 0;

    virtual void record_widget_rect(uintptr_t widget_ptr,
                                     uint32_t color, float thickness,
                                     int32_t offset_x, int32_t offset_y,
                                     int32_t size_w, int32_t size_h) = 0;

    virtual void record_widget_rect_filled(uintptr_t widget_ptr,
                                            uint32_t color,
                                            int32_t offset_x, int32_t offset_y,
                                            int32_t size_w, int32_t size_h) = 0;

    // ── Screen-space primitives ──────────────────────────────────────────
    virtual void record_text_screen(float x, float y,
                                    const char* text, uint32_t color,
                                    bool background) = 0;

    virtual void record_line_screen(float x1, float y1, float x2, float y2,
                                    uint32_t color, float thickness) = 0;

    virtual void record_rect_screen(float x, float y, float w, float h,
                                    uint32_t color, float thickness,
                                    float rounding) = 0;

    virtual void record_rect_filled_screen(float x, float y, float w, float h,
                                           uint32_t color, float rounding) = 0;

    // ── Panel commands ──────────────────────────────────────────────────
    virtual void record_panel_begin(const char* id, int32_t position,
                                    uint32_t bg, uint32_t border,
                                    uint32_t title_col, uint32_t label_col,
                                    uint32_t text_col, uint32_t accent,
                                    float border_radius, int32_t padding,
                                    int32_t line_height,
                                    uint32_t header_bg = 0,
                                    uint32_t item_have = 0,
                                    uint32_t item_missing = 0,
                                    uint32_t style_flags = 0) = 0;

    virtual void record_panel_title(const char* text, uint32_t color,
                                    const char* right = nullptr) = 0;

    // ── Round-2 panel elements. Non-pure with no-op defaults so future
    //    recorder implementations degrade gracefully. ─────────────────────
    virtual void record_panel_stat_tile(const char* value, const char* caption,
                                        uint32_t color) {
        (void)value; (void)caption; (void)color;
    }
    virtual void record_panel_timer_ring(const char* center, const char* label,
                                         float percent, uint32_t color) {
        (void)center; (void)label; (void)percent; (void)color;
    }
    virtual void record_panel_sparkline(const char* hex_samples, uint32_t color) {
        (void)hex_samples; (void)color;
    }

    virtual void record_panel_row(const char* left, const char* right,
                                  uint32_t left_color, uint32_t right_color) = 0;

    virtual void record_panel_label(const char* text, uint32_t color) = 0;

    virtual void record_panel_progress(const char* label, float percent,
                                       uint32_t bar_color, uint32_t bg_color,
                                       int32_t bar_height) = 0;

    virtual void record_panel_separator(uint32_t color) = 0;

    virtual void record_panel_spacer(int32_t height) = 0;

    virtual void record_panel_header(const char* text, uint32_t color) = 0;

    virtual void record_panel_item_row(const char* name, int32_t qty_have,
                                       int32_t qty_need, bool has_item,
                                       uint32_t bullet_color, uint32_t text_color,
                                       int32_t item_id = -1) = 0;

    virtual void record_panel_icon_text(const char* icon, const char* text,
                                        uint32_t color) = 0;

    /// `aligns`: 2 bits per column (0=left, 1=right, 2=center), 4 columns.
    virtual void record_panel_table_row(const char* cells_pipe_delimited,
                                         uint32_t col0, uint32_t col1,
                                         uint32_t col2, uint32_t col3,
                                         uint16_t aligns = 0) = 0;

    virtual void record_panel_image_rect(const char* label, int32_t w, int32_t h,
                                         uint32_t fill, uint32_t border) = 0;

    virtual void record_panel_end() = 0;
};

} // namespace obsidian::api
