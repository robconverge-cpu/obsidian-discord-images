#pragma once
/// @file container_api.h
/// @brief ContainerItem struct definition.
///
/// Query functions moved to: inventory::, equipment::, bank:: (see inventory.h)
/// Raw container read: client::container_items() (see client.h)

#include <cstdint>
#include <vector>

namespace obsidian::api {

/// A container slot: item id, stack quantity, and true slot index.
struct ContainerItem {
    int32_t id = -1;
    int32_t quantity = 0;
    int32_t slot = -1;   ///< True container slot index (0-based; -1 if unknown).
    // Placeholder detection: a bank placeholder slot holds the placeholder-variant
    // item id at quantity 0, so check `quantity == 0` or
    // definitions::item(id).placeholder rather than a per-slot flag.
};

} // namespace obsidian::api
