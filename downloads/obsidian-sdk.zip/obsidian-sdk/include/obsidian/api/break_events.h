/// @file break_events.h
/// @brief EventBus events broadcast by the per-tab Break Handler engine.
///
/// The Break Handler (host/src/breaks/break_engine.{h,cpp}) coordinates
/// automated breaks/logout/relogin per tab. Consumer plugins poll the engine
/// (register/should_break/start_break/is_break_active) and also subscribe to
/// these events for push-style notification. Events fire on the current tab's
/// EventBus, so a plugin only sees events for its own tab.
///
/// See docs/break_handler_plan.md.
#pragma once

#include <cstdint>
#include <string>

namespace obsidian::api {

/// @brief A break has been scheduled for a consumer (fired on plan / replan).
struct BreakScheduledEvent {
    std::string plugin;        ///< Consumer plugin key/name the break is for.
    int64_t     at_epoch_ms;   ///< Monotonic ms timestamp when the break is due.
};

/// @brief A break has just become active — the consumer should stop acting.
struct BreakStartedEvent {
    std::string plugin;          ///< Consumer plugin key/name.
    int64_t     until_epoch_ms;  ///< Monotonic ms timestamp when the break ends.
    bool        logout;          ///< True if this break logs the account out (P2+).
};

/// @brief A break has ended and the client is back in a playable state.
///
/// For logout breaks this fires only after relogin + settle (P2+), so a
/// subscriber can treat it as "safe to resume acting". For in-game breaks it
/// fires when the break timer elapses.
struct BreakEndedEvent {
    std::string plugin;   ///< Consumer plugin key/name.
};

/// @brief A consumer's session was stopped by the engine (not by the user).
///
/// Reasons include the stop-after-N-breaks limit or an unrecoverable login
/// failure (P2+). Carries a short machine-readable reason string.
struct BreakSessionStoppedEvent {
    std::string plugin;   ///< Consumer plugin key/name.
    std::string reason;   ///< e.g. "stop_after_breaks", "login_failed".
};

} // namespace obsidian::api
