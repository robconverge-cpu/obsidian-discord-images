#pragma once
/// @file game_state.h
/// @brief GameState enum and session-state predicates.
/// @ingroup core
// ═══════════════════════════════════════════════════════════════════════════
// GAME STATE — GameState enum matching RuneLite GameState.java
// ═══════════════════════════════════════════════════════════════════════════

#include <cstdint>

namespace obsidian::api {

/// Current game session state.
/// Mirrors RuneLite GameState.java values.
enum class GameState : int32_t {
    UNKNOWN        = -1,
    STARTING       = 0,
    LOGIN_SCREEN   = 10,
    LOGIN_SCREEN_AUTHENTICATOR = 11,
    LOGGING_IN     = 20,
    LOADING        = 25,
    LOGGED_IN      = 30,
    CONNECTION_LOST = 40,
    HOPPING        = 45,
};

/// Returns a human-readable name for the given game state.
inline const char* game_state_name(GameState gs) {
    switch (gs) {
        case GameState::STARTING:       return "Starting";
        case GameState::LOGIN_SCREEN:   return "Login Screen";
        case GameState::LOGIN_SCREEN_AUTHENTICATOR: return "Authenticator";
        case GameState::LOGGING_IN:     return "Logging In";
        case GameState::LOADING:        return "Loading";
        case GameState::LOGGED_IN:      return "Logged In";
        case GameState::CONNECTION_LOST: return "Connection Lost";
        case GameState::HOPPING:        return "Hopping";
        default:                        return "Unknown";
    }
}

// These values correspond to RuneLite's Client.loginIndex
// (30 = logged in, 10 = login screen, etc.).

// Returns true for states where the player is still "in session" —
// loading screens, world hops, connection lost (reconnectable).
// Plugin state (active quest, hint arrows, etc.) should be PRESERVED
// across these states. Only clear on actual logout (login screen states).
/// Returns true when the player is "in session" — logged in, loading, hopping, or
/// connection-lost (reconnectable). Plugin state should be preserved across these states.
inline bool is_in_session_state(int32_t gs) {
    return gs == 30  // LOGGED_IN
        || gs == 25  // LOADING (area transition, world hop load)
        || gs == 40  // CONNECTION_LOST (may reconnect)
        || gs == 45; // HOPPING (world hop in progress)
}

// Returns true only when the player has fully left the game session —
// returned to login screen or client is starting up.
/// Returns true when the player has fully left the game — returned to login screen
/// or authenticator. Plugin state may be reset on entry to these states.
inline bool is_logout_state(int32_t gs) {
    return gs == 0   // STARTING
        || gs == 10  // LOGIN_SCREEN
        || gs == 11  // LOGIN_SCREEN_AUTHENTICATOR
        || gs == 20; // LOGGING_IN
}

} // namespace obsidian::api
