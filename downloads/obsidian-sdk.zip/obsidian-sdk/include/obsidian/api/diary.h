#pragma once
/// @file diary.h
/// @brief Achievement diary completion state.
///
/// Diaries matter to planners as *rate modifiers*, not just trophies: the Ardougne medium
/// diary raises Ardougne-knight pickpocket success, Kandarin hard improves Seers' rooftop
/// throughput, and several diaries unlock teleports that change travel cost. Method
/// ranking is wrong without them.
///
/// Usage:
/// @code
///   namespace diary = obsidian::api::diary;
///   if (diary::is_complete(diary::Region::ARDOUGNE, diary::Tier::MEDIUM)) { ... }
///   int32_t tiers = diary::tiers_complete(diary::Region::VARROCK);   // 0-4
/// @endcode

#include <cstdint>

#include <obsidian/api/client.h>

namespace obsidian::api::diary {

enum class Region : int32_t {
    ARDOUGNE = 0,
    DESERT,
    FALADOR,
    FREMENNIK,
    KANDARIN,
    KARAMJA,
    KOUREND,
    LUMBRIDGE,
    MORYTANIA,
    VARROCK,
    WESTERN,
    WILDERNESS,
};

constexpr int32_t REGION_COUNT = 12;

enum class Tier : int32_t {
    EASY   = 0,
    MEDIUM = 1,
    HARD   = 2,
    ELITE  = 3,
};

constexpr int32_t TIER_COUNT = 4;

/// Completion varbit for a region/tier, or -1 when unavailable.
///
/// Karamja is the exception: only its ELITE tier exists as a completion varbit in the
/// generated table (4566). Easy/medium/hard Karamja progress is stored differently and is
/// **not** exposed here — is_complete() returns false for them rather than guessing at an
/// ID. Treat Karamja easy/medium/hard as unknown, not as incomplete, if it matters.
inline int32_t varbit_for(Region region, Tier tier) {
    const int32_t t = static_cast<int32_t>(tier);
    switch (region) {
        case Region::ARDOUGNE:   return 4458 + t;
        case Region::FALADOR:    return 4462 + t;
        case Region::WILDERNESS: return 4466 + t;
        case Region::WESTERN:    return 4471 + t;
        case Region::KANDARIN:   return 4475 + t;
        case Region::VARROCK:    return 4479 + t;
        case Region::DESERT:     return 4483 + t;
        case Region::MORYTANIA:  return 4487 + t;
        case Region::FREMENNIK:  return 4491 + t;
        case Region::LUMBRIDGE:  return 4495 + t;
        case Region::KOUREND:    return 7925 + t;
        case Region::KARAMJA:    return tier == Tier::ELITE ? 4566 : -1;
    }
    return -1;
}

/// True if that diary tier is complete. False when the varbit is unavailable
/// (see the Karamja note on varbit_for).
inline bool is_complete(Region region, Tier tier) {
    const int32_t vb = varbit_for(region, tier);
    return vb >= 0 && client::varbit(vb) != 0;
}

/// True only if the ID backing this region/tier is known — lets a caller distinguish
/// "not done" from "cannot tell".
inline bool is_known(Region region, Tier tier) { return varbit_for(region, tier) >= 0; }

/// Number of completed tiers in a region (0-4). Tiers with unknown IDs count as 0.
inline int32_t tiers_complete(Region region) {
    int32_t n = 0;
    for (int32_t t = 0; t < TIER_COUNT; t++)
        if (is_complete(region, static_cast<Tier>(t))) n++;
    return n;
}

/// True if every known tier in the region is complete.
inline bool is_region_complete(Region region) {
    for (int32_t t = 0; t < TIER_COUNT; t++) {
        const Tier tier = static_cast<Tier>(t);
        if (is_known(region, tier) && !is_complete(region, tier)) return false;
    }
    return true;
}

inline const char* name(Region region) {
    switch (region) {
        case Region::ARDOUGNE:   return "Ardougne";
        case Region::DESERT:     return "Desert";
        case Region::FALADOR:    return "Falador";
        case Region::FREMENNIK:  return "Fremennik";
        case Region::KANDARIN:   return "Kandarin";
        case Region::KARAMJA:    return "Karamja";
        case Region::KOUREND:    return "Kourend";
        case Region::LUMBRIDGE:  return "Lumbridge";
        case Region::MORYTANIA:  return "Morytania";
        case Region::VARROCK:    return "Varrock";
        case Region::WESTERN:    return "Western Provinces";
        case Region::WILDERNESS: return "Wilderness";
    }
    return "Unknown";
}

inline const char* name(Tier tier) {
    switch (tier) {
        case Tier::EASY:   return "Easy";
        case Tier::MEDIUM: return "Medium";
        case Tier::HARD:   return "Hard";
        case Tier::ELITE:  return "Elite";
    }
    return "Unknown";
}

} // namespace obsidian::api::diary
