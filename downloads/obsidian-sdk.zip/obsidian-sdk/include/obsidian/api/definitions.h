#pragma once
/// @file definitions.h
/// @brief NPC, item, and object definition access (composition reader).
/// @ingroup entities
// ═══════════════════════════════════════════════════════════════════════════
// DEFINITIONS — Unified NPC, Item, Object definition access
// ═══════════════════════════════════════════════════════════════════════════
// Merges runtime definitions (native TypeList functions), cache definitions
// (CacheReader), and blob parsing (LocType) into a single API.
//
// Mirrors RuneLite's NPCComposition, ItemComposition, ObjectComposition.
// ═══════════════════════════════════════════════════════════════════════════


#include <cstdint>
#include <string>
#include <array>

namespace obsidian::api {


} // namespace obsidian::api
