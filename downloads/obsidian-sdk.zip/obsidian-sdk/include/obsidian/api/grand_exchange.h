#pragma once
/// @file grand_exchange.h
/// @brief Grand Exchange offer slot access.
/// @ingroup ui
// ==========================================================================
// GRAND EXCHANGE — GE offer slots
// ==========================================================================
// Mirrors RuneLite GrandExchangeOffer.java.
// v238.1: 8 offer slots stored as pointer array at Client+GEOfferArrayBase.
// Each pointer -> heap-allocated 0x20-byte offer struct.
// ==========================================================================


#include <cstdint>
#include <array>

namespace obsidian::api {

/// Current state of a GE offer slot (the client's raw state byte).
/// FINISHED covers both a completed and a cancelled offer — tell them apart
/// with quantity_traded == total_quantity. Items/coins wait in the slot until
/// collected; the slot returns to EMPTY after collection.
enum class GrandExchangeOfferState : int32_t {
    EMPTY       = 0,
    PENDING     = 1,   ///< being placed (client "adding")
    ACTIVE      = 2,   ///< live on the exchange (client "stable")
    FINISHED    = 5,   ///< completed or cancelled; awaiting collection
};

/// Offer type (buy or sell).
enum class GrandExchangeOfferType : int32_t {
    BUY  = 0,
    SELL = 1,
};

/// Plain GE offer data, readable host-side. Available to BOTH C++
/// plugins (call grand_exchange::get_offers()) and JS (obsidian.ge.getOffers()).
struct GeOffer {
    int32_t slot = -1;
    int32_t state = 0;            ///< GrandExchangeOfferState (0=empty,1=pending,2=active,5=finished)
    int32_t type = 0;             ///< GrandExchangeOfferType (0=buy,1=sell)
    int32_t item_id = -1;
    int64_t price = 0;            ///< price per item (64-bit since v241, RuneLite getPrice() is long)
    int32_t total_quantity = 0;   ///< total requested
    int32_t quantity_traded = 0;  ///< traded so far
    int64_t spent = 0;            ///< gold spent/received (64-bit, RuneLite getSpent() is long)
};

namespace grand_exchange {
/// All 8 GE offer slots (refreshed each tick).
/// Host-side accessor — works from any plugin without in-process access.
std::array<GeOffer, 8> get_offers();
}


} // namespace obsidian::api
