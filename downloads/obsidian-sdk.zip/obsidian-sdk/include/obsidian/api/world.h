/// @file world.h
/// @brief World, region, and instance state helpers.
///
/// Covers PoH detection, instance detection, map region queries,
/// and world type checks. All derived from existing varbit/varp reads
/// and client state.
#pragma once

#include <cstdint>
#include <string>
#include <vector>

namespace obsidian::api::world {

/// Known map regions for special locations.
namespace regions {
    constexpr int32_t POH_REGION_1 = 7513;   ///< Player-owned house.
    constexpr int32_t POH_REGION_2 = 7514;   ///< Player-owned house (alternative).
    constexpr int32_t TUTORIAL_ISLAND = 12336;
}

/// True if the player is inside their Player-Owned House.
bool is_in_poh();

// is_in_instance() is in game_api.h.

/// Get the map region IDs the player is currently in.
/// Typically 1-4 regions depending on position relative to region boundaries.
std::vector<int32_t> get_map_regions();

/// Get the current map region ID for the player's tile.
int32_t get_region_id();

/// Current world number.
int32_t get_world();

// ── World Type flags (bitmask, matches Java WorldType enum) ─────────

/// World type bit flags (bitmask, matches Java WorldType enum).
enum WorldTypeFlag : uint32_t {
    WORLD_MEMBERS           = 1,
    WORLD_PVP               = 1 << 2,
    WORLD_BOUNTY            = 1 << 5,
    WORLD_PVP_ARENA         = 1 << 6,
    WORLD_SKILL_TOTAL       = 1 << 7,
    WORLD_QUEST_SPEEDRUN    = 1 << 8,
    WORLD_HIGH_RISK         = 1 << 10,
    WORLD_LMS               = 1 << 14,
    WORLD_BETA              = 1 << 16,
    WORLD_NOSAVE            = 1 << 25,
    WORLD_TOURNAMENT        = 1 << 26,
    WORLD_FRESH_START       = 1 << 27,
    WORLD_DEADMAN           = 1 << 29,
    WORLD_SEASONAL          = 1u << 30,
};

/// A single world entry from the world list.
struct WorldEntry {
    int32_t id = 0;            ///< World number (e.g. 301).
    int32_t player_count = 0;  ///< Current players online.
    int32_t location = 0;      ///< Server region (0=US, 1=UK, 7=AU, 7=DE).
    uint32_t type_mask = 0;    ///< Bitmask of WorldTypeFlag values.
    std::string address;       ///< Server hostname.
    std::string activity;      ///< Description (e.g. "Trade - Members").

    bool is_members()     const { return (type_mask & WORLD_MEMBERS) != 0; }
    bool is_pvp()         const { return (type_mask & WORLD_PVP) != 0; }
    bool is_high_risk()   const { return (type_mask & WORLD_HIGH_RISK) != 0; }
    bool is_skill_total() const { return (type_mask & WORLD_SKILL_TOTAL) != 0; }
    bool is_deadman()     const { return (type_mask & WORLD_DEADMAN) != 0; }
    bool is_seasonal()    const { return (type_mask & WORLD_SEASONAL) != 0; }
    bool is_beta()        const { return (type_mask & WORLD_BETA) != 0; }
    bool is_safe()        const {
        return !is_pvp() && !is_high_risk() && !is_deadman() && !is_seasonal()
            && !is_beta() && !(type_mask & WORLD_TOURNAMENT)
            && !(type_mask & WORLD_FRESH_START);
    }
};

// ── World List + Hop ────────────────────────────────────────────────────

/// Packed widget IDs for world hop actions.
namespace widget_id {
    constexpr int32_t WORLD_SWITCHER_BUTTON = (182 << 16) | 3;   ///< Logout panel "World Switcher".
    constexpr int32_t WORLD_SWITCHER_LIST   = (69 << 16) | 18;   ///< World list entries.
}

/// Get the full world list (populated after WorldListLoadEvent fires).
/// Returns empty if the list hasn't been fetched yet this session.
std::vector<WorldEntry> get_world_list();

/// True if the world switcher is actually on screen: logout tab selected and the
/// list mounted (group 69 stays loaded after a hop even when not displayed).
bool is_world_switcher_open();

/// One step towards opening the switcher: selects the logout tab if needed,
/// otherwise clicks its World Switcher button. Call again until open.
void open_world_switcher();

/// Hop to a specific world by ID. The world switcher must be open.
/// Use open_world_switcher() first, wait for the widget, then call this.
void hop_to_world(int32_t world_id);

/// True if the current world is a members world.
bool is_members_world();


} // namespace obsidian::api::world
