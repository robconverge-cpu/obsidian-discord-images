#pragma once
/// @file all.h
/// @brief Single include for the full Obsidian plugin API.
///
/// Include this header to get access to all API types:
/// @code
/// #include <obsidian/api/all.h>
/// @endcode

/// @defgroup core Core Types
/// @brief Coordinate system, game state, and client access.

/// @defgroup entities Entity Types
/// @brief NPC/player definitions, hitsplats, skills, prayers.

/// @defgroup scene Scene Types
/// @brief Tile objects, collision, effects, world-to-screen projection.

/// @defgroup ui Interface Types
/// @brief Widgets, right-click menus, item containers, Grand Exchange, chat.

/// @defgroup events Event System
/// @brief Type-safe pub/sub event bus and 40+ event struct definitions.

/// @defgroup overlays Overlay System
/// @brief Plugin overlay rendering, tile highlights, text labels, info boxes.

// Core types
#include <obsidian/api/game_api.h>
#include <obsidian/api/coords.h>
#include <obsidian/api/game_state.h>
#include <obsidian/api/client.h>
#include <obsidian/api/varp_ids.h>

// Entity types
#include <obsidian/api/hitsplat.h>
#include <obsidian/api/skill.h>
#include <obsidian/api/prayer.h>
#include <obsidian/api/definitions.h>
#include <obsidian/api/hint_arrow.h>

// Scene types
#include <obsidian/api/objects.h>
#include <obsidian/api/tile.h>
#include <obsidian/api/collision.h>
#include <obsidian/api/effects.h>
#include <obsidian/api/perspective.h>

// Interface types
#include <obsidian/api/widget.h>
#include <obsidian/api/menu.h>
#include <obsidian/api/container.h>
#include <obsidian/api/grand_exchange.h>
#include <obsidian/api/chat.h>

// High-level APIs
#include <obsidian/api/dialogue.h>
#include <obsidian/api/inventory.h>
#include <obsidian/api/combat.h>
#include <obsidian/api/world.h>
// NOTE: query.h currently does NOT compile — its entry points (npcs/objects/players/
// ground_items) collide with the namespaces of the same name that it includes. That makes
// this whole aggregate uncompilable, which is why nothing includes all.h today.
// See docs/api_bugs.md §4.
#include <obsidian/api/query.h>
#include <obsidian/api/break_handler.h>
#include <obsidian/api/actions.h>

// Account progress
#include <obsidian/api/quest.h>
#include <obsidian/api/favour.h>
#include <obsidian/api/diary.h>

// Event system
#include <obsidian/api/events.h>
#include <obsidian/api/event_bus.h>
#include <obsidian/api/break_events.h>

// Overlay system
#include <obsidian/api/overlay.h>
#include <obsidian/api/overlay_panel.h>
#include <obsidian/api/overlay_layout.h>
#include <obsidian/api/panel.h>
#include <obsidian/api/infobox.h>
