#pragma once
/// @file movement.h
/// @brief Walking and pathfinding.

#include <obsidian/api/coords.h>
#include <obsidian/api/scene_api.h>
#include <cstdint>
#include <optional>
#include <vector>

namespace obsidian::api::movement {

/// Walk toward a world tile (queues synthetic movement).
/// @return Whether the walk was accepted for dispatch. False means it did not
///         happen at all. This is a single click-to-walk, not pathfinding —
///         for cross-region travel use `walker::walk_to`.
bool walk_to(int32_t world_x, int32_t world_y);
/// Walk toward a world point (plane is ignored — the click lands on the
/// current scene). Accepts the `location` of any entity read this session.
bool walk_to(const WorldPoint& target);

/// @name Scene / local / template walking
/// The walk command itself is always a scene click, so these are the
/// instance-safe forms: a scene tile or fine-local point refers to the scene
/// that is loaded NOW and is resolved against the live base at call time.
/// Inside an instance the world tile of a given spot changes between visits
/// (the server places each copy at a different base); the scene offset of a
/// fixed-layout instance does not. Store scene offsets, not world tiles.
/// @{

/// Walk toward a scene tile (0..103) of the currently loaded scene.
bool walk_to_scene(int32_t scene_x, int32_t scene_y);
/// Walk toward a scene tile (ScenePoint form).
bool walk_to_scene(const ScenePoint& target);
/// Walk toward the tile containing a fine-local point (128 units per tile),
/// e.g. an actor's `local_location`.
bool walk_to_local(int32_t local_x, int32_t local_y);
/// Walk toward the tile containing a fine-local point (LocalPoint form).
bool walk_to_local(const LocalPoint& target);
/// Walk toward a TEMPLATE world point — the real-map tile the instance was
/// copied from (what WorldPoint::from_local_instance returns). Resolves every
/// occurrence of that tile in the current instance via
/// WorldPoint::to_local_instance, prefers the nearest reachable one, and
/// walks there. Outside an instance this is plain walk_to(). This is the only
/// form that survives chunk rotation and can be persisted across visits.
/// @return False if the point has no occurrence in the loaded scene or the
///         walk was not accepted.
bool walk_to_template(const WorldPoint& template_point);
/// @}

/// Clear any queued synthetic movement steps.
void clear_synth_queue();
/// True if the target tile can be stood on.
bool is_walkable(const WorldPoint& target);
/// True if a path exists to the target tile. Flood-fills the current plane's
/// collision map; target.plane is not used to reject (bridge objects report
/// the plane above the walkable one).
bool can_reach(const WorldPoint& target);
/// True if a path exists to within radius of the target tile.
bool can_reach(const WorldPoint& target, int32_t radius);
/// All tiles currently reachable from the player.
std::vector<WorldPoint> reachable_tiles();
/// Walkable tiles within radius of a center tile.
std::vector<WorldPoint> walkable_tiles(const WorldPoint& center, int32_t radius);
/// Nearest reachable tile from a candidate list.
WorldPoint closest_reachable_tile(const std::vector<WorldPoint>& tiles);

/// Raw collision bitfield for a world tile (see api::CollisionFlag).
/// Returns 0xFFFFFFFF if the tile is outside the loaded scene.
/// This is the live native collision map (updated each game tick), so callers
/// can inspect walls/objects/LoS directly instead of trusting reachability.
uint32_t collision_flag(int32_t world_x, int32_t world_y);

/// True iff a single step between two adjacent tiles is possible, honouring
/// directional walls/doors (and the corner rules for diagonals). Unlike
/// can_reach()/reachable_tiles(), this does NOT path around obstacles — it is the
/// "can I move straight from `from` to `to` right now" check. `from`/`to` must be
/// adjacent (Chebyshev distance 1); returns false otherwise.
bool can_step(const WorldPoint& from, const WorldPoint& to);

/// True if a world tile cannot be stood on (solid floor/floor-deco, or an object
/// with no walk-through). Off-scene tiles report blocked. Inverse of is_walkable.
bool is_blocked(int32_t world_x, int32_t world_y);

/// Decoded collision flags for a world tile — the ergonomic form of
/// collision_flag(). `on_scene` is false (and the rest default) when the tile is
/// outside the loaded scene.
struct TileFlags {
    uint32_t flags    = 0xFFFFFFFF; ///< raw bitfield (see api::CollisionFlag)
    bool     on_scene = false;      ///< false if tile is outside the loaded scene
    bool     blocked  = true;       ///< cannot be stood on
    bool     object   = false;      ///< an object occupies the tile
    struct { bool n, e, s, w, ne, se, sw, nw; } wall{}; ///< movement blocked across edge
    struct { bool n, e, s, w, full; }           los{};  ///< line-of-sight blocked across edge
};
/// Decoded collision flags for a world tile (see TileFlags).
TileFlags tile_flags(int32_t world_x, int32_t world_y);

/// Plane-checked forms of collision_flag / is_blocked / tile_flags. Only the
/// current plane's collision map is live, so a tile on another plane reads as
/// off-scene (0xFFFFFFFF / blocked / on_scene=false).
uint32_t collision_flag(int32_t world_x, int32_t world_y, int32_t plane);
bool is_blocked(int32_t world_x, int32_t world_y, int32_t plane);
TileFlags tile_flags(int32_t world_x, int32_t world_y, int32_t plane);

/// Line of sight between two areas (RuneLite WorldArea.hasLineOfSightTo) over
/// the live collision map. `from`/`to` are the SW tiles; widths/heights give a
/// large NPC's footprint. Any two tiles in the loaded scene, not just the local
/// player's. False when the areas are on different planes, not on the current
/// plane, off-scene, or overlapping (RuneLite rule: same tile => false).
bool has_line_of_sight(const WorldPoint& from, const WorldPoint& to,
                       int32_t from_width = 1, int32_t from_height = 1,
                       int32_t to_width = 1, int32_t to_height = 1);

/// BFS path cost (in tiles) between two world points on the current plane.
/// Uses the live collision map — only works within the loaded 104x104 scene.
/// @return Tile distance via walkable path, or -1 if unreachable / off-scene.
int32_t path_cost(const WorldPoint& from, const WorldPoint& to);

/// Cost (in tiles) to reach an interactable edge of an NPC's footprint.
/// Checks all cardinal tiles around the NPC's size and returns the cheapest.
/// @return Minimum path cost, or -1 if no edge tile is reachable.
int32_t interaction_cost(const SceneNpc& npc);

/// Cost (in tiles) to reach an interactable edge of a scene object's footprint.
/// Uses the object definition's size_x / size_y for the footprint.
/// @return Minimum path cost, or -1 if no edge tile is reachable.
int32_t interaction_cost(const SceneObject& obj);

} // namespace obsidian::api::movement
