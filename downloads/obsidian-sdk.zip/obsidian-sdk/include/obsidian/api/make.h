#pragma once
/// @file make.h
/// @brief The Skill-Multi ("Make-X") production interface.
///
/// Every processing skill funnels through this one interface: fletching logs, cooking on a
/// range, smithing at an anvil, crafting hides, brewing potions. Driving it is the single
/// piece of plumbing that makes "add another skill" a data change rather than a code
/// change, which is why it belongs in the API and not in one plugin.
///
/// SELECTION IS BY ITEM ID, NOT BY NAME
///   Verified against a live interface. A product occupies one of the static components
///   `Skillmulti::A`..`R` (children 15..32), which carries the action "Make" and 39 dynamic
///   children. The product itself is an ITEM on one of those dynamic children - nothing on
///   the slot carries a product name, and neither `text()` nor `name()` returns anything
///   for it. A label-matching API was written first and could not work at all.
///
///   So a caller names the item id it wants. The slot index is then irrelevant, which also
///   disposes of the question of whether products the account cannot yet make are removed
///   or merely greyed: whatever item is present can be made, and an id that is absent
///   cannot.
///
/// QUANTITY
///   `_1`/`_5`/`_10` are one click each. `X` (child 11) carries the "Other quantity"
///   action and opens the numeric-entry dialogue, so `set_quantity` is RE-ENTRANT: it
///   returns false while the dialogue is still being driven and true once committed.
///   Note the component the cache calls `OTHER` (child 10) carries no action - it is not
///   the one to click.

#include <cstdint>
#include <vector>

namespace obsidian::api::make {

/// Quantity sentinel for `set_quantity` and `make`. Any other positive number is entered
/// through the X dialogue.
constexpr int32_t QTY_ALL = -1;

/// True when the Skill-Multi interface is loaded and visible.
bool is_open();

/// The item id offered in each product slot, in slot order.
///
/// Entry `i` corresponds to `select_slot(i)`. A slot with nothing in it reports 0, and the
/// positions are kept so an index never shifts meaning between calls.
std::vector<int32_t> products();

/// Does the open interface offer this item?
bool offers(int32_t item_id);

/// Click the slot holding this item id.
/// @return false if the interface is closed or no slot holds it.
bool select(int32_t item_id);

/// Click a slot by 0-based position. For the rare interface whose slots hold no item.
bool select_slot(int32_t slot);

/// Set the quantity. 1/5/10 and QTY_ALL are a single click; anything else drives the
/// X dialogue and is RE-ENTRANT - call again next tick until it returns true.
/// @return true when the quantity is set, false while still working.
bool set_quantity(int32_t qty);

/// The quantity the interface currently has selected, or -1 if unknown.
int32_t quantity();

/// Set the quantity and select the item in one call. RE-ENTRANT: call each tick until true.
///
/// This is the call a skill engine wants - it is the whole interaction, so adding a skill
/// means naming an item in the corpus rather than writing interface code.
/// @return true when the make has been dispatched.
bool make(int32_t item_id, int32_t qty);

}  // namespace obsidian::api::make
