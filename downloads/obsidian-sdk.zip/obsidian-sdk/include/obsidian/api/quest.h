#pragma once
/// @file quest.h
/// @brief Quest state queries — completion, progress, diary checks.
///
/// Uses CS2 script 4029 (QUEST_STATUS_GET) for accurate quest state
/// detection, matching RuneLite's approach. Results are cached per account:
/// the first query after login runs the batch itself, and the cache is
/// re-run when it is older than 30s or the bound account changes. A query
/// before the client is logged in returns NOT_STARTED (nothing to read yet).
///
/// Usage:
/// @code
///   namespace quest = obsidian::api::quest;
///   if (quest::is_complete(obsidian::id::quest::ANIMAL_MAGNETISM)) { ... }
///   auto state = quest::state(obsidian::id::quest::DESERT_TREASURE_I);
/// @endcode

#include <cstdint>
#include <string_view>

#include <obsidian/api/client.h>

namespace obsidian::api::quest {

enum class State : int32_t {
    NOT_STARTED  = 0,
    IN_PROGRESS  = 1,
    FINISHED     = 2,
};

/// Varp holding the account's total quest points.
constexpr int32_t QUEST_POINTS_VARP = 101;

/// Total quest points earned. Several quests gate on a QP threshold
/// (Dragon Slayer II needs 200), so planners need this directly.
inline int32_t points() { return client::varp(QUEST_POINTS_VARP); }

/// Get quest state using CS2 script 4029. Served from the per-account cache,
/// which this call populates/refreshes itself (see the file comment) — no
/// explicit refresh_all() is needed. May block for the IPC round-trip (a few
/// ms, up to ~500ms if the core is unresponsive) at most once per 30s.
/// @param quest_id Game quest enum ID (from obsidian::id::quest::).
State state(int32_t quest_id);

/// Convenience: returns true if quest is complete.
bool is_complete(int32_t quest_id);

/// Look up a quest ID by display name (case-sensitive).
/// Returns -1 if not found.
int32_t find_id(std::string_view name);

/// Force an immediate re-run of the batch (state() refreshes on its own; use
/// this only to pick up a completion within the 30s window). No-op unless a
/// client is attached and logged in.
void refresh_all();

/// Refresh quests associated with a specific varp (called on VarbitChanged).
/// For now this refreshes ALL quests since the varp→quest mapping isn't tracked.
void refresh_for_varp(int32_t varp_id);

} // namespace obsidian::api::quest
