#pragma once
/// @file model_api.h
/// @brief Model vertex/face data for convex hull and outline rendering.
/// @ingroup scene
///
/// Split from game_api.h — model data is only needed by overlays that draw hulls.

#include <cstdint>
#include <vector>

namespace obsidian::api {

/// @name Model Data
/// @{

/// A single vertex in model space.
struct ModelVertex { int32_t x, y, z; };
/// A triangular face referencing three vertex indices.
struct ModelFace { int32_t v1, v2, v3; };

/// Vertex and face data for a model, used for convex hull / outline rendering.
struct ModelData {
    int32_t vertex_count = 0;
    int32_t face_count = 0;
    std::vector<ModelVertex> vertices;
    std::vector<ModelFace> faces;
    // AABB bounds (model-space)
    int32_t min_x = 0, min_y = 0, min_z = 0;
    int32_t max_x = 0, max_y = 0, max_z = 0;
    bool valid = false;
};

namespace model {

/// Reads model vertex and face data from an NPC entity via vtable getModel().
/// @warning Must be called from the render thread — model data is transient per frame.
ModelData read_npc_model(uintptr_t npc_entity_ptr);

/// Reads model vertex and face data from a player entity via vtable getModel().
/// @warning Must be called from the render thread — model data is transient per frame.
ModelData read_player_model(uintptr_t player_entity_ptr);

} // namespace model
/// @}

} // namespace obsidian::api
