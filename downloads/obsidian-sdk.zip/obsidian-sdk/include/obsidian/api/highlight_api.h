#pragma once
/// @file highlight_api.h
/// @brief Hint arrow control and native GPU highlight system.
/// @ingroup scene
///
/// Split from game_api.h — highlight/hint arrow is a distinct visual subsystem.

#include <obsidian/api/coords.h>
#include <cstdint>

namespace obsidian::api {

/// @name Hint Arrow
/// @{
namespace hint_arrow {
    void set(const WorldPoint& target);     ///< Point the hint arrow at a world tile.
    void set_npc(int32_t npc_index);        ///< Point the hint arrow at an NPC.
    void set_player(int32_t player_index);  ///< Point the hint arrow at a player.
    void clear();                           ///< Remove the hint arrow.
    void nuke();                            ///< @internal Debug: zero ALL hint arrow fields.
    void apply_override();                  ///< @internal Re-apply hint arrow override (call from gameloop).

    /// Toggle where the hint arrow is drawn. Both default on.
    void set_visibility(bool on_minimap, bool in_world);
    /// Flash cadence (in client ticks). Default 20 on / 10 off.
    void set_flash(int32_t rate_ticks, int32_t off_ticks);
    /// Sub-tile offset in fine coords (0..128 per tile). Default 64,64 (tile center).
    void set_fine_coords(int32_t fine_x, int32_t fine_y);
    /// Override the arrow sprite — use a cache sprite id.
    void set_sprite(int32_t sprite_id);
} // namespace hint_arrow
/// @}

/// @name Native GPU Highlight
/// Uses the game's own highlight system (GPU render targets + shaders).
/// Each highlight uses a channel [1-32] which must be configured first.
/// @{
namespace highlight {
    /// Enable native GPU highlight for an NPC on the given channel.
    void npc_on(int32_t npc_id, int32_t creation_cycle, int32_t channel);
    /// Disable the native highlight for an NPC on the given channel.
    void npc_off(int32_t npc_id, int32_t channel);
    /// Enable native GPU highlight for a world tile on the given channel.
    void tile_on(int32_t world_x, int32_t world_y, int32_t channel);
    /// Disable the native highlight for a world tile on the given channel.
    void tile_off(int32_t world_x, int32_t world_y, int32_t channel);
    /// Enable native GPU highlight for an object at world coords on the given channel.
    void object_on(int32_t object_id, int32_t world_x, int32_t world_y, int32_t channel);
    /// Disable the native highlight for an object at world coords on the given channel.
    void object_off(int32_t object_id, int32_t world_x, int32_t world_y, int32_t channel);

    /// Configure a highlight channel. Must be called once for a channel before
    /// *_on will actually render — the on-call silently no-ops when the
    /// channel's flag bits aren't set in the config block at mgr+0x290.
    /// @param category  0=NPC, 1=NpcType, 2=Obj, 3=ObjType, 4=Tile, 5=Player.
    /// @param channel   0..31.
    /// @param color_rgb 0xRRGGBB — packed color for the highlight outline.
    /// @param outline_w Outline width in pixels (0..255, typically 1-3).
    void configure(int32_t category, int32_t channel,
                   uint32_t color_rgb, uint8_t outline_w = 2);

    /// Returns the current cycle for an NPC — needed for npc_on since
    /// the native keys highlights by (cycle << 32) | npcId. Returns 0 if NPC
    /// isn't present in the world view.
    int32_t npc_creation_cycle(int32_t npc_index);
} // namespace highlight
/// @}

} // namespace obsidian::api
