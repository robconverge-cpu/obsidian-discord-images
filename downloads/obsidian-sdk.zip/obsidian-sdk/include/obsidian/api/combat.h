/// @file combat.h
/// @brief Combat and buff state helpers — varbit/varp-driven queries.
///
/// All reads are derived from existing varp/varbit accessors. No RE needed.
/// Covers prayer, poison/venom, attack style, special attack, and
/// common buff/debuff detection.
///
/// Usage:
/// @code
///   if (combat::health_percent() < 50.0f) eat_food();
///   if (combat::is_poisoned()) drink_antipoison();
///   if (combat::spec_percent() >= 50) use_spec();
///   if (combat::is_prayer_active(Prayer::ProtectMelee)) { ... }
/// @endcode
#pragma once

#include <cstdint>
#include <string>
#include <obsidian/ids/interface_id.h>

namespace obsidian::api::combat {

// ── Varp/Varbit IDs for combat state ────────────────────────────────────

/// Varp IDs used for combat state reads.
namespace varps {
    constexpr int32_t SPECIAL_ATTACK_PERCENT = 300;   ///< Spec energy × 10 (0-1000).
    constexpr int32_t SPECIAL_ATTACK_ENABLED = 301;   ///< 1 when spec orb is toggled on.
    constexpr int32_t ATTACK_STYLE           = 43;    ///< 0=accurate, 1=aggressive, 2=defensive, 3=controlled.
    constexpr int32_t AUTO_RETALIATE_DISABLED = 172;   ///< 0=auto-retaliate ON, 1=OFF (inverted!).
    constexpr int32_t POISON                 = 102;   ///< >0 = poisoned (tick counter), <0 = immune, >=1000000 = venomed.
    constexpr int32_t DISEASE                = 456;   ///< >0 = diseased.
}

/// Varp IDs used for combat state reads.
namespace varps {
    constexpr int32_t RUN_ENABLED            = 173;
}

/// Varbit IDs used for combat state reads.
namespace varbits {
    constexpr int32_t STAMINA_EFFECT         = 25;
    constexpr int32_t SUPER_ANTIFIRE         = 13240;
    constexpr int32_t ANTIFIRE               = 13241;
    constexpr int32_t IN_WILDERNESS          = 5963;
    constexpr int32_t SKULL_REMAINING        = 4923;
    constexpr int32_t SPELLBOOK              = 4070;   ///< 0=Standard, 1=Ancient, 2=Lunar, 3=Necromancy.
    constexpr int32_t MULTIWAY_INDICATOR     = 4605;
    constexpr int32_t QUICK_PRAYER_ACTIVE    = 4103;   ///< 1 when quick-prayers are toggled on.
    /// >0 when the prayer regeneration potion is active. This was 4103 until
    /// 2026-07-30, which is QUICKPRAYER_ACTIVE — has_prayer_regen() was really
    /// reporting "quick prayers are on". 11361 is the potion timer per the
    /// cache-generated ids (varbit_id.h PRAYER_REGENERATION_POTION_TIMER).
    constexpr int32_t PRAYER_REGEN_EFFECT    = 11361;
    constexpr int32_t GOADING_EFFECT         = 12752;  ///< >0 when goading potion is active.
    constexpr int32_t IMBUED_HEART_TIMER     = 5361;
    constexpr int32_t SATURATED_HEART_TIMER  = 14704;
}

/// Constants for poison/venom threshold.
constexpr int32_t VENOM_THRESHOLD = 1000000;  ///< Poison varp >= this = venomed (not just poisoned).

/// Wilderness coordinate constants.
constexpr int32_t WILDERNESS_Y_START = 3520;       ///< World Y where wilderness begins.
constexpr int32_t WILDERNESS_TILES_PER_LEVEL = 8;  ///< Tiles per wilderness level.

// ── Prayer enum ─────────────────────────────────────────────────────────
// Ordered by visual grid position (matches RuneLite Prayer.java ordinal).
// Use prayer_widget_id() for the packed widget ID and prayer_varbit() for
// the active-state varbit.

enum class Prayer : int32_t {
    ThickSkin       = 0,
    BurstOfStrength = 1,
    ClarityOfThought = 2,
    SharpEye        = 3,
    MysticWill      = 4,
    RockSkin        = 5,
    SuperhumanStrength = 6,
    ImprovedReflexes = 7,
    RapidRestore    = 8,
    RapidHeal       = 9,
    ProtectItem     = 10,
    HawkEye         = 11,
    MysticLore      = 12,
    SteelSkin       = 13,
    UltimateStrength = 14,
    IncredibleReflexes = 15,
    ProtectFromMagic = 16,
    ProtectFromMissiles = 17,
    ProtectFromMelee = 18,
    EagleEye        = 19,
    MysticMight     = 20,
    Retribution     = 21,
    Redemption      = 22,
    Smite           = 23,
    Preserve        = 24,
    Chivalry        = 25,
    Piety           = 26,
    Rigour          = 27,
    Augury          = 28,
    COUNT           = 29,
};

namespace prayer_detail {
    using IID = obsidian::id::InterfaceID;
    // Packed widget IDs indexed by Prayer enum. Derived from the Java
    // Prayers enum packedId field — uses InterfaceID::Prayerbook constants.
    inline constexpr int32_t WIDGET_IDS[] = {
        IID::Prayerbook::PRAYER1,   // ThickSkin        child  9
        IID::Prayerbook::PRAYER2,   // BurstOfStrength  child 10
        IID::Prayerbook::PRAYER3,   // ClarityOfThought child 11
        IID::Prayerbook::PRAYER19,  // SharpEye         child 27
        IID::Prayerbook::PRAYER22,  // MysticWill       child 30
        IID::Prayerbook::PRAYER4,   // RockSkin         child 12
        IID::Prayerbook::PRAYER5,   // SuperhumanStr    child 13
        IID::Prayerbook::PRAYER6,   // ImprovedReflexes child 14
        IID::Prayerbook::PRAYER7,   // RapidRestore     child 15
        IID::Prayerbook::PRAYER8,   // RapidHeal        child 16
        IID::Prayerbook::PRAYER9,   // ProtectItem      child 17
        IID::Prayerbook::PRAYER20,  // HawkEye          child 28
        IID::Prayerbook::PRAYER23,  // MysticLore       child 31
        IID::Prayerbook::PRAYER10,  // SteelSkin        child 18
        IID::Prayerbook::PRAYER11,  // UltimateStr      child 19
        IID::Prayerbook::PRAYER12,  // IncredibleRef    child 20
        IID::Prayerbook::PRAYER13,  // ProtectMagic     child 21
        IID::Prayerbook::PRAYER14,  // ProtectMissiles  child 22
        IID::Prayerbook::PRAYER15,  // ProtectMelee     child 23
        IID::Prayerbook::PRAYER21,  // EagleEye         child 29
        IID::Prayerbook::PRAYER24,  // MysticMight      child 32
        IID::Prayerbook::PRAYER16,  // Retribution      child 24
        IID::Prayerbook::PRAYER17,  // Redemption       child 25
        IID::Prayerbook::PRAYER18,  // Smite            child 26
        IID::Prayerbook::PRAYER29,  // Preserve         child 37
        IID::Prayerbook::PRAYER26,  // Chivalry         child 34
        IID::Prayerbook::PRAYER27,  // Piety            child 35
        IID::Prayerbook::PRAYER25,  // Rigour           child 33
        IID::Prayerbook::PRAYER28,  // Augury           child 36
    };
    // Varbit IDs indexed by Prayer enum (from RuneLite Varbits).
    inline constexpr int32_t VARBIT_IDS[] = {
        4104, // ThickSkin
        4105, // BurstOfStrength
        4106, // ClarityOfThought
        4122, // SharpEye
        4123, // MysticWill
        4107, // RockSkin
        4108, // SuperhumanStrength
        4109, // ImprovedReflexes
        4110, // RapidRestore
        4111, // RapidHeal
        4112, // ProtectItem
        4124, // HawkEye
        4125, // MysticLore
        4113, // SteelSkin
        4114, // UltimateStrength
        4115, // IncredibleReflexes
        4116, // ProtectFromMagic
        4117, // ProtectFromMissiles
        4118, // ProtectFromMelee
        4126, // EagleEye
        4127, // MysticMight
        4119, // Retribution
        4120, // Redemption
        4121, // Smite
        5466, // Preserve
        4128, // Chivalry
        4129, // Piety
        5464, // Rigour
        5465, // Augury
    };
}

/// Packed widget ID for a prayer's toggle button (0 if out of range).
inline int32_t prayer_widget_id(Prayer p) {
    int i = static_cast<int>(p);
    if (i < 0 || i >= static_cast<int>(Prayer::COUNT)) return 0;
    return prayer_detail::WIDGET_IDS[i];
}

/// Active-state varbit ID for a prayer (0 if out of range).
inline int32_t prayer_varbit(Prayer p) {
    int i = static_cast<int>(p);
    if (i < 0 || i >= static_cast<int>(Prayer::COUNT)) return 0;
    return prayer_detail::VARBIT_IDS[i];
}

// ── Attack style ────────────────────────────────────────────────────────

/// Combat attack-style selection (varp 43 value).
enum class AttackStyle : int32_t {
    Accurate  = 0,
    Aggressive = 1,
    Defensive  = 2,
    Controlled = 3,
    Casting    = 4,  // Magic autocast
    DefensiveCasting = 5,
};

/// Active spellbook.
enum class Spellbook : int32_t {
    Standard    = 0,
    Ancient     = 1,
    Lunar       = 2,
    Necromancy  = 3,
};

/// Packed widget IDs for toggle actions — sourced from interface_id.h.
namespace widget_id {
    using IID = obsidian::id::InterfaceID;
    constexpr int32_t QUICK_PRAYER = IID::Orbs::PRAYERBUTTON;
    constexpr int32_t RUN_ORB      = IID::Orbs::RUNBUTTON;
    constexpr int32_t SPEC_ORB     = IID::Orbs::SPECBUTTON;

    /// Combat tab group. The four style buttons and the retaliate toggle only
    /// exist while this group is loaded, i.e. while the combat tab is open.
    constexpr int32_t COMBAT_GROUP = IID::COMBAT_INTERFACE;
    /// The four attack-style buttons, indexed by the ATTACK_STYLE varp (0-3).
    /// A weapon with only three styles simply has no 4th button, so clicking
    /// it fails rather than selecting something wrong.
    constexpr int32_t ATTACK_STYLE_BUTTON[4] = {
        IID::Combat_Interface::_0,
        IID::Combat_Interface::_1,
        IID::Combat_Interface::_2,
        IID::Combat_Interface::_3,
    };
    constexpr int32_t RETALIATE    = IID::Combat_Interface::RETALIATE;
}

// ── Health ──────────────────────────────────────────────────────────────

/// Current health as a percentage (0-100). Returns -1 if not available.
float health_percent();

/// Current hitpoints level (boosted).
int32_t current_hp();

/// Max hitpoints level (base).
int32_t max_hp();

// ── Prayer ──────────────────────────────────────────────────────────────

/// Current prayer points.
int32_t prayer_points();

/// Max prayer level (base).
int32_t max_prayer();

/// True if a specific prayer is currently active.
bool is_prayer_active(Prayer prayer);

/// True if any protection prayer is active (melee/range/magic).
bool is_protection_prayer_active();

// ── Poison / Venom / Disease ────────────────────────────────────────────

/// True if the player is poisoned (not venomed).
bool is_poisoned();

/// True if the player is venomed.
bool is_venomed();

/// True if the player is immune to poison (antipoison active).
bool is_poison_immune();

/// True if the player is diseased.
bool is_diseased();

// ── Skull / Wilderness ──────────────────────────────────────────────────

/// True if the player is skulled.
bool is_skulled();

/// True if the player is in the wilderness.
bool is_in_wilderness();

/// Wilderness level (0 if not in wilderness).
int32_t wilderness_level();

// ── Special Attack ──────────────────────────────────────────────────────

/// Special attack energy as a percentage (0-100).
int32_t spec_percent();

/// True if the special attack orb is toggled on.
bool is_spec_enabled();

/// Toggle the special attack orb. If on, turns off; if off, turns on.
/// @return whether the click was accepted for dispatch.
bool toggle_spec();

/// Enable special attack (no-op returning true if already enabled).
bool enable_spec();

/// Disable special attack (no-op returning true if already disabled).
bool disable_spec();

// ── Combat Style ────────────────────────────────────────────────────────

/// Current attack style.
AttackStyle attack_style();

/// Select an attack style.
///
/// Clicks the matching button on the combat tab, so **the combat tab must be
/// open** — the buttons do not exist otherwise. Returns false if the tab is
/// closed, if the current weapon has no button at that index (three-style
/// weapons have no 4th), or if the click was rejected.
///
/// No-op returning true when the style is already selected.
///
/// Only the four button styles (Accurate/Aggressive/Defensive/Controlled) are
/// settable here. `Casting` and `DefensiveCasting` are autocast modes chosen
/// through the spell-selection interface, not these buttons, so passing either
/// returns false.
bool set_attack_style(AttackStyle style);

/// True if auto-retaliate is enabled.
bool is_auto_retaliate();

/// Toggle auto-retaliate. Requires the combat tab to be open.
/// @return whether the click was accepted for dispatch.
bool toggle_auto_retaliate();

/// Set auto-retaliate on/off (no-op returning true if already in that state).
/// Requires the combat tab to be open — returns false if it is closed.
bool set_auto_retaliate(bool enabled);

/// Get the current active spellbook.
Spellbook get_spellbook();

/// True if the player is in a multi-combat zone.
bool is_in_multi();

// ── Run / Stamina ───────────────────────────────────────────────────────

/// True if run is toggled on.
bool is_run_enabled();

/// Toggle run on/off.
/// @return whether the click was accepted for dispatch.
bool toggle_run();

/// Set run state (no-op returning true if already in the desired state).
bool set_run(bool enabled);

/// True if the stamina potion effect is active.
bool has_stamina_effect();

/// Current run energy (0-10000, divide by 100 for percentage).
int32_t run_energy();

// ── Antifire ────────────────────────────────────────────────────────────

/// True if any antifire protection is active (regular or super).
bool has_antifire();

/// True if super antifire is active.
bool has_super_antifire();

// ── Interacting / Combat State ──────────────────────────────────────────

/// True if the local player is currently interacting with (targeting) another entity.
bool is_in_combat();

/// Index of the entity the player is interacting with (-1 if none).
int32_t interacting_index();

// ── Prayer Actions ──────────────────────────────────────────────────────

/// Toggle a specific prayer on/off.
/// Activating (prayer currently off) is a no-op returning false when prayer
/// points are 0 — the click could never succeed. Deactivating never checks
/// points. Prayer LEVEL requirements are still not checked.
/// @return false if the prayer has no known widget id, points are 0 on an
///         activation attempt, or the click was rejected.
bool toggle_prayer(Prayer prayer);

/// Set a prayer to a specific state. Idempotent: returns true without
/// clicking when the prayer is already in the requested state, so stale-state
/// double-flips are impossible. Enabling at 0 prayer points is a no-op
/// returning false (via toggle_prayer).
bool set_prayer(Prayer prayer, bool enabled);

/// Enable a prayer (no-op returning true if already active).
bool enable_prayer(Prayer prayer);

/// Disable a prayer (no-op returning true if already inactive).
bool disable_prayer(Prayer prayer);

/// Toggle a prayer by name (e.g. "Protect from Melee", "Rigour", "Piety").
/// Case-insensitive.
/// @return false if the name is not recognised OR the click was rejected —
///         either way the prayer was not toggled. Use `toggle_prayer` with a
///         `Prayer` value if you need to tell those two apart.
bool toggle_prayer_by_name(const std::string& name);

/// Toggle quick-prayers on/off. Enabling with 0 prayer points is a no-op
/// returning false (same guard as toggle_prayer).
/// @return whether the click was accepted for dispatch.
bool toggle_quick_prayers();

/// True if quick-prayers are currently active.
bool is_quick_prayers_active();

/// Set quick-prayers on/off (no-op returning true if already in that state).
/// Clicks the prayer orb, which is always present — unlike the combat-tab
/// toggles this needs no interface open.
bool set_quick_prayers(bool enabled);

// ── Potion Buff Timers ──────────────────────────────────────────────────

/// True if prayer regeneration potion effect is active.
bool has_prayer_regen();

/// True if goading potion effect is active.
bool has_goading();

/// True if imbued heart cooldown is active.
bool has_imbued_heart_effect();

/// True if saturated heart cooldown is active.
bool has_saturated_heart_effect();

/// True if any heart effect (imbued or saturated) is active.
bool has_heart_effect();

} // namespace obsidian::api::combat
