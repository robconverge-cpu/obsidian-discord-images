#pragma once
/// @file npcs.h
/// @brief NPC queries and interactions.
///
/// Usage:
/// @code
///   namespace npcs = obsidian::api::npcs;
///   auto npc = npcs::find_nearest_by_name("Banker");
///   if (npc) npcs::interact_by_action(npc->index, "Bank");
/// @endcode

#include <obsidian/api/scene_api.h>  // SceneNpc, ScenePoint, SpotAnimData
#include <obsidian/api/action_types.h>
#include <cstdint>
#include <optional>
#include <string>
#include <vector>

namespace obsidian::api::npcs {

// ── Queries ────────────────────────────────────────────────────────────

/// Returns every NPC currently visible in the scene.
std::vector<SceneNpc> find_all();
/// Returns all NPCs with the given composition/definition ID.
std::vector<SceneNpc> find(int32_t npc_id);
/// Returns all NPCs whose display name matches @p name.
std::vector<SceneNpc> find_by_name(const std::string& name);
/// Returns the NPC at the given entity-table slot index, or nullopt.
std::optional<SceneNpc> find_by_index(int32_t index);

/// Resolve the actor this NPC is targeting (RuneLite Actor.getInteracting()).
/// Returns nullopt if the NPC is idle, gone, or its target left the scene.
std::optional<InteractingTarget> get_interacting(int32_t npc_index);

/// Returns the nearest NPC with the given ID, or nullopt if none.
std::optional<SceneNpc> find_nearest(int32_t npc_id);
/// Returns the nearest NPC matching @p name, or nullopt if none.
std::optional<SceneNpc> find_nearest_by_name(const std::string& name);
/// True if any NPC with the given name is currently in the scene.
bool exists(const std::string& name);

// ── Entity Data ────────────────────────────────────────────────────────

/// Returns the active spot animations (graphics) on the NPC.
std::vector<SpotAnimData> spot_anims(uintptr_t npc_ptr);
/// Returns the NPC's queued movement path points.
std::vector<ScenePoint> path(uintptr_t npc_ptr);

// ── Interactions ───────────────────────────────────────────────────────

/// Interact with the NPC using a typed action.
bool interact(int32_t npc_index, NpcAction action);
/// Interact with the NPC using a right-click option index.
bool interact(int32_t npc_index, int32_t option);
/// Interact with the NPC by action text; returns true if dispatched.
bool interact_by_action(int32_t npc_index, const std::string& action);
/// Interact with the nearest NPC named @p npc_name via action text; true if dispatched.
bool interact_nearest(const std::string& npc_name, const std::string& action);
/// Use an inventory item on the NPC after an optional tick delay.
void use_item_on(int32_t item_slot, int32_t item_id, int32_t npc_index, int32_t delay_ticks = 1);
/// Cast a spell (by packed widget) on the NPC after an optional tick delay.
void cast_spell_on(int32_t spell_packed_widget, int32_t npc_index, int32_t delay_ticks = 1);

} // namespace obsidian::api::npcs
