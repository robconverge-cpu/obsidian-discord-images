#pragma once
/// @file container.h
/// @brief Item container access — inventory, equipment, bank, and more.
/// @ingroup ui
// ═══════════════════════════════════════════════════════════════════════════
// ITEM CONTAINER — Inventory, equipment, bank, etc.
// ═══════════════════════════════════════════════════════════════════════════
// Mirrors RuneLite ItemContainer.java + Item.java.
// Reads from the container hash table in game memory.
// ═══════════════════════════════════════════════════════════════════════════


#include <cstdint>
#include <vector>

namespace obsidian::api {

/// A single item slot: item ID and stack quantity.
/// id == -1 means the slot is empty.
struct Item {
    int32_t id       = -1;
    int32_t quantity = 0;
};

/// Well-known container ID constants (from RuneLite InventoryID).
/// Pass to ItemContainer::read() to fetch a specific container.
namespace ContainerId {
    constexpr int INVENTORY                = 93;
    constexpr int EQUIPMENT                = 94;
    constexpr int BANK                     = 95;
    constexpr int TRADE                    = 90;
    constexpr int TRADE_OTHER              = 519;
    constexpr int GROUP_STORAGE            = 550;
    constexpr int BARROWS_REWARD           = 141;
    constexpr int KINGDOM_OF_MISCELLANIA   = 390;
    constexpr int CHAMBERS_OF_XERIC_CHEST  = 581;
    constexpr int THEATRE_OF_BLOOD_CHEST   = 612;
    constexpr int SEED_VAULT               = 625;
    constexpr int LOOT_KEY                 = 529;
    constexpr int WILDERNESS_LOOT_CHEST    = 942;
}

/// Snapshot of an item container (inventory, bank, equipment, etc.).
/// Populated by ItemContainer::read(). All access is to the cached copy —
/// call read() again to refresh from game memory.
class ItemContainer {
    int32_t id_ = -1;
    std::vector<Item> items_;

public:
    /// Construct an empty/invalid container.
    ItemContainer() = default;
    /// Construct a container snapshot from an id and item vector.
    ItemContainer(int32_t id, std::vector<Item> items) : id_(id), items_(std::move(items)) {}

    /// Container id (see ContainerId); -1 if invalid.
    int32_t id() const { return id_; }
    /// True if this holds a valid container.
    bool valid() const { return id_ >= 0; }

    /// All slots in the container.
    const std::vector<Item>& items() const { return items_; }

    /// Item at the given slot (empty Item if out of range).
    Item get_item(int slot) const {
        if (slot < 0 || slot >= static_cast<int>(items_.size())) return {};
        return items_[slot];
    }

    /// Number of slots in the container.
    int size() const { return static_cast<int>(items_.size()); }

    /// True if any slot holds the given item id.
    bool contains(int item_id) const {
        for (const auto& item : items_)
            if (item.id == item_id) return true;
        return false;
    }

    /// Total quantity of the given item id across all slots.
    int count(int item_id) const {
        int total = 0;
        for (const auto& item : items_)
            if (item.id == item_id) total += item.quantity;
        return total;
    }

    /// Number of occupied slots.
    int count() const {
        int total = 0;
        for (const auto& item : items_)
            if (item.id > 0) total++;
        return total;
    }

    /// First slot index holding the given item id, or -1.
    int find(int item_id) const {
        for (int i = 0; i < static_cast<int>(items_.size()); i++)
            if (items_[i].id == item_id) return i;
        return -1;
    }

};

} // namespace obsidian::api
