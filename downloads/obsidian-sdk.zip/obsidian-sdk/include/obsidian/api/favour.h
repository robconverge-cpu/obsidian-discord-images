#pragma once
/// @file favour.h
/// @brief Great Kourend house favour.
///
/// Favour gates a surprising amount of training content — Hosidius fruit stalls (15%),
/// the Woodcutting Guild (75% Hosidius), Lovakengj blast mining, Arceuus blood runes
/// (100%) and the Farming Guild. Any planner that selects training methods needs it.
///
/// **The stored value is scaled by 10.** Varbit 6029 reading 1000 means 100.0% favour.
/// Reading the varbit directly and comparing against 75 is a bug that silently reports
/// 7.5% as passing; use percent() or the has_* helpers, which do the division for you.
///
/// Usage:
/// @code
///   namespace favour = obsidian::api::favour;
///   if (favour::has_at_least(favour::House::HOSIDIUS, 75)) { /* woodcutting guild */ }
///   int32_t pct = favour::percent(favour::House::ARCEUUS);   // 0-100
/// @endcode

#include <cstdint>

#include <obsidian/api/client.h>

namespace obsidian::api::favour {

/// The five Great Kourend houses.
enum class House : int32_t {
    ARCEUUS      = 0,
    HOSIDIUS     = 1,
    LOVAKENGJ    = 2,
    PISCARILIUS  = 3,
    SHAYZIEN     = 4,
};

constexpr int32_t HOUSE_COUNT = 5;

/// Raw favour varbits. Values are percent x10 (1000 == 100.0%).
namespace varbits {
constexpr int32_t ARCEUUS     = 7858;
constexpr int32_t HOSIDIUS    = 6029;
constexpr int32_t LOVAKENGJ   = 7802;
constexpr int32_t PISCARILIUS = 6039;
constexpr int32_t SHAYZIEN    = 6360;
} // namespace varbits

/// Varbit ID backing a house's favour, or -1 for an out-of-range house.
inline int32_t varbit_for(House house) {
    switch (house) {
        case House::ARCEUUS:     return varbits::ARCEUUS;
        case House::HOSIDIUS:    return varbits::HOSIDIUS;
        case House::LOVAKENGJ:   return varbits::LOVAKENGJ;
        case House::PISCARILIUS: return varbits::PISCARILIUS;
        case House::SHAYZIEN:    return varbits::SHAYZIEN;
    }
    return -1;
}

/// Raw stored value (percent x10). Prefer percent() unless you need the extra precision.
inline int32_t raw(House house) {
    const int32_t vb = varbit_for(house);
    return vb < 0 ? 0 : client::varbit(vb);
}

/// Favour as a whole percentage, 0-100. Truncates — 99.9% reports as 99, so a
/// "needs 100%" gate is never satisfied early.
inline int32_t percent(House house) { return raw(house) / 10; }

/// Favour to one decimal place, e.g. 62.5f.
inline float percent_exact(House house) { return static_cast<float>(raw(house)) / 10.0f; }

/// True if the house is at or above `required_percent` (0-100).
inline bool has_at_least(House house, int32_t required_percent) {
    return raw(house) >= required_percent * 10;
}

/// Display name for a house.
inline const char* name(House house) {
    switch (house) {
        case House::ARCEUUS:     return "Arceuus";
        case House::HOSIDIUS:    return "Hosidius";
        case House::LOVAKENGJ:   return "Lovakengj";
        case House::PISCARILIUS: return "Piscarilius";
        case House::SHAYZIEN:    return "Shayzien";
    }
    return "Unknown";
}

} // namespace obsidian::api::favour
