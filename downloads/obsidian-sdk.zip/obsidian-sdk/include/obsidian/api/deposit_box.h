#pragma once
/// @file deposit_box.h
/// @brief The bank deposit box interface (group 192).
///
/// Separate from `bank::` because it is a different interface with its own widgets and
/// quantity model: there is no bank tab, items are deposited from a copy of the
/// inventory shown inside the box, and the per-item click deposits whatever the box's
/// quantity mode is set to (varbit DEPOSITBOX_MODE) rather than naming a quantity.
///
/// Opening it is an ordinary object interaction ("Deposit" on a "Bank deposit box").
///
/// Widget actions mirror the Cuell utils DepositBox helper, which drove them live:
/// "Deposit inventory" is op 1 on DEPOSIT_INV, a per-item click is op 1 on the
/// INVENTORY container at the item's slot, and the quantity buttons are op 1.

#include <cstdint>

namespace obsidian::api::deposit_box {

/// True when the deposit box interface is open and its inventory is visible.
bool is_open();

/// Click "Deposit inventory".
/// @return false when the box is closed or the click was not dispatched.
bool deposit_inventory();

/// Deposit every one of this item id from the inventory.
///
/// RE-ENTRANT: the per-item click deposits the box's current quantity mode, so if the
/// mode is not "All" this call clicks the All button and returns false. Call again next
/// tick; it returns true once the item click itself was dispatched.
/// @return false while switching the quantity mode, when the box is closed, or when the
///         item is not in the inventory.
bool deposit_all(int32_t item_id);

/// Close the deposit box.
bool close();

} // namespace obsidian::api::deposit_box
