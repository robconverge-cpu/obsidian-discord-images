#pragma once
/// @file break_handler.h
/// @brief Break Handler API — register a plugin as a break consumer and drive
///        the per-tab break engine (schedule/take/relogin around breaks).
///
/// The engine lives in the host (per tab). Any plugin — built-in, DLL, or JS —
/// registers by a stable NAME string, sets its timing/logout policy, starts a
/// session, then each tick asks the engine whether it should break and gates
/// its own actions on whether a break is active. Push-style notification is via
/// the BreakScheduled/Started/Ended/SessionStopped events (break_events.h).
///
/// Usage:
/// @code
///   namespace breaks = obsidian::api::breaks;
///   breaks::register_consumer("my-bot");
///   breaks::set_timing("my-bot", 45, 90, 8, 20);   // minutes
///   breaks::start_session("my-bot");
///   // each tick:
///   if (breaks::is_break_active("my-bot")) return;                  // stand down
///   if (breaks::should_break("my-bot")) { breaks::start_break("my-bot"); return; }
/// @endcode

#include <cstdint>
#include <string>

namespace obsidian::api::breaks {

/// How a consumer's break decides to log out. Mirrors the engine's mode; values
/// are ABI-stable — never renumber.
enum class LogoutMode : int32_t {
    Never  = 0,   ///< Stay logged in, idle out the break.
    Always = 1,   ///< Log the account out for the break.
    Random = 2,   ///< Roll `percent` each break to decide.
};

// ── Registration / lifecycle ──────────────────────────────────────────────
/// Register this consumer with the break engine. `configurable` = whether the
/// user may edit its timings in the Break Handler panel (false = fixed). Safe to
/// call more than once. (`register` is a C++ keyword, hence `register_consumer`.)
void register_consumer(const std::string& name, bool configurable = true);
/// Remove a consumer. Call in the plugin's stop path to avoid a stale entry.
void unregister_consumer(const std::string& name);
/// True if `name` is currently registered.
bool is_registered(const std::string& name);
/// Begin a session: starts the play timer and schedules the first break.
void start_session(const std::string& name);
/// End a session: clears any planned/active break and session timers.
void stop_session(const std::string& name);

// ── Poll contract ─────────────────────────────────────────────────────────
/// True once a scheduled break is due — acknowledge by calling start_break() at
/// a safe stopping point. False while disabled, mid-break, or not yet due.
bool should_break(const std::string& name);
/// True while this consumer's break is active — the consumer must not act.
bool is_break_active(const std::string& name);
/// Acknowledge a due break: gaussian-samples a duration from the consumer's
/// range and activates it (logging out if the consumer's logout mode says so).
void start_break(const std::string& name);
/// Force a break now (e.g. a panic/stop trigger), even if none was scheduled.
void break_now(const std::string& name);

// ── Config (programmatic; the panel drives the same engine setters) ────────
/// Set this consumer's timing ranges, in MINUTES: play-time before a break is
/// scheduled [threshold_from, threshold_to], and LOGOUT break duration
/// [break_from, break_to]. The engine clamps from<=to. In-game (AFK) breaks
/// draw from a separate, shorter range — see set_afk_timing().
void set_timing(const std::string& name, int32_t threshold_from, int32_t threshold_to,
                int32_t break_from, int32_t break_to);
/// Set this consumer's IN-GAME (AFK) break duration range, in MINUTES. Used
/// when a break does not log out (LogoutMode::Never, or a Random roll that
/// stays in). Defaults to 1-25; the engine additionally clamps every AFK break
/// to the tab's AFK ceiling (the game's ~25 min idle logout) so an AFK break
/// never ends on the login screen. Logout breaks keep using set_timing().
void set_afk_timing(const std::string& name, int32_t afk_from, int32_t afk_to);
/// Set whether this consumer's breaks log out. `percent` (0-100) is used only
/// for LogoutMode::Random. The type is decided BEFORE the duration is drawn,
/// so an AFK roll gets an AFK-length break and a logout roll a logout-length
/// one. The nightly sleep (Break Handler cog) overrides both: a break that
/// starts at bedtime becomes a long logout until the drawn wake time.
void set_logout_mode(const std::string& name, LogoutMode mode, int32_t percent);
/// Attach an arbitrary key/value string shown against the consumer in the panel.
void set_extra_data(const std::string& name, const std::string& key, const std::string& value);

// ── Status ────────────────────────────────────────────────────────────────
/// Master enable of this tab's break engine (the panel's Enabled toggle).
bool enabled();
/// Total breaks taken across all consumers this tab.
int32_t total_breaks_taken();

/// Trigger a login using the configured relogin account. Only works when the
/// engine is idle and the game is on the login screen. Returns true if initiated.
bool request_login();

} // namespace obsidian::api::breaks
