#pragma once
/// @file overlay_panel.h
/// @brief Declarative overlay panel builder — RuneLite-style info panels.
/// Auto-sizes width to fit content. Configurable theme. Shared between
/// C++ plugins, host plugins, and JS plugins via IPC serialization.

#include <obsidian/api/overlay.h>
#include <cstdint>
#include <cstdio>
#include <cstring>
#include <string>
#include <vector>
#include <algorithm>
#include <functional>
#include <initializer_list>

namespace obsidian::api {

/// Pack a familiar #RRGGBB value (+ alpha) into the ImGui-style ABGR
/// (0xAABBGGRR) format every overlay draw call consumes. Theme constants
/// were previously written as 0xAARRGGBB literals and rendered with red
/// and blue swapped — the "indigo" default theme actually drew maroon
/// with salmon titles. Always author panel colors through this helper.
constexpr uint32_t panel_rgb(uint32_t rgb, uint32_t alpha = 0xFF) {
    return (alpha << 24)
         | ((rgb & 0x0000FFu) << 16)
         |  (rgb & 0x00FF00u)
         | ((rgb & 0xFF0000u) >> 16);
}

/// Replace an ABGR colour's alpha, keeping its RGB channels.
constexpr uint32_t panel_alpha(uint32_t abgr, uint32_t alpha) {
    return (abgr & 0x00FFFFFFu) | (alpha << 24);
}

/// Blend an ABGR colour toward white by `pct` percent (0-100), keeping alpha.
constexpr uint32_t panel_lighten(uint32_t abgr, uint32_t pct) {
    const uint32_t r = (abgr      ) & 0xFF;
    const uint32_t g = (abgr >> 8 ) & 0xFF;
    const uint32_t b = (abgr >> 16) & 0xFF;
    return (abgr & 0xFF000000u)
         | (((b + (255 - b) * pct / 100) & 0xFF) << 16)
         | (((g + (255 - g) * pct / 100) & 0xFF) << 8)
         |  ((r + (255 - r) * pct / 100) & 0xFF);
}

/// Configurable color/sizing theme for overlay panels.
/// Plugins can create custom themes or use PanelTheme::Default().
struct PanelTheme {
    // Brand-violet chrome (#9B7CFF family) with semantic green/red status.
    uint32_t background    = panel_rgb(0x16131D, 0xE0);
    uint32_t border        = panel_rgb(0x9B7CFF, 0x30);
    uint32_t title_color   = panel_rgb(0xB9A8FF);
    uint32_t text_color    = panel_rgb(0xEFEEF8);
    uint32_t label_color   = panel_rgb(0x9A94B0);
    uint32_t accent        = panel_rgb(0x3FCB6E);
    uint32_t header_bg     = panel_rgb(0xFFFFFF, 0x14);
    uint32_t item_have     = panel_rgb(0x3FCB6E);
    uint32_t item_missing  = panel_rgb(0xE05252);
    int32_t  padding       = 8;
    int32_t  line_height   = 15;
    float    border_radius = 7.0f;
    int32_t  gap           = 6;

    /// Shared default theme instance.
    static const PanelTheme& Default() {
        static PanelTheme t;
        return t;
    }
};

/// Per-panel style flags — lets developers dial the chrome from the full
/// "advanced" look down to the classic flat panel. Serialized over IPC.
enum PanelStyleFlags : uint32_t {
    PANEL_STYLE_NO_SHADOW    = 1u << 0,  ///< skip the drop shadow
    PANEL_STYLE_FLAT_BG      = 1u << 1,  ///< solid background, no gradient/highlight
    PANEL_STYLE_NO_GLASS     = 1u << 2,  ///< opt out of the frosted-glass backdrop
    PANEL_STYLE_SIMPLE_TITLE = 1u << 3,  ///< plain title text + underline, no bar
    PANEL_STYLE_ZEBRA        = 1u << 4,  ///< faint alternating tint on data rows
};

/// Cell alignment for table_row columns.
enum class PanelAlign : uint8_t { Left = 0, Right = 1, Center = 2 };

/// Element types for overlay panel items. Named distinctly from sidebar
/// OverlayElementType (panel.h) to avoid collisions.
enum class OverlayElementType : uint8_t {
    Title,
    Row,
    Label,
    Progress,
    Separator,
    Spacer,
    Header,
    ItemRow,
    IconText,
    TableRow,
    ImageRect,
    StatTile,   ///< big value + small caption; consecutive tiles render 2-up
    TimerRing,  ///< radial progress ring + center text + optional label
    Sparkline,  ///< mini line chart from hex-packed u8 samples
};

/// A single overlay panel element. Public struct so the IPC layer can
/// read fields for serialization into overlay commands.
struct OverlayPanelItem {
    OverlayElementType type = OverlayElementType::Spacer;
    std::string left;
    std::string right;
    float percent = 0;
    int32_t extra_h = 0;
    uint32_t color = 0;
    uint32_t color2 = 0;
    uint32_t color3 = 0;
    int32_t int_val = 0;
    int32_t int_val2 = 0;
    int32_t item_id = -1;   ///< ItemRow: game item id for the icon (-1 = chip)
    uint8_t flags = 0;
    std::vector<std::string> cells;
    std::vector<uint32_t> cell_colors;
    std::vector<uint8_t> cell_aligns;   ///< TableRow: PanelAlign per column
};

/// Fluent builder for a RuneLite-style overlay info panel; auto-sizes to content.
class OverlayPanel {
public:
    // ── Theme ───────────────────────────────────────────────────────────

    /// Apply a full color/sizing theme.
    OverlayPanel& theme(const PanelTheme& t) {
        pad_ = t.padding; lh_ = t.line_height; bg_ = t.background;
        border_ = t.border; title_col_ = t.title_color; text_col_ = t.text_color;
        dim_col_ = t.label_color; accent_ = t.accent; header_bg_ = t.header_bg;
        item_have_ = t.item_have; item_missing_ = t.item_missing;
        border_radius_ = t.border_radius; gap_ = t.gap;
        return *this;
    }

    // ── Individual style overrides ──────────────────────────────────────

    /// Set a fixed panel width (overrides auto-sizing).
    OverlayPanel& width(int32_t w) { fixed_width_ = w; return *this; }
    /// Set the minimum auto-sized width.
    OverlayPanel& min_width(int32_t w) { min_width_ = w; return *this; }
    /// Set inner padding in pixels.
    OverlayPanel& padding(int32_t p) { pad_ = p; return *this; }
    /// Set the per-row line height in pixels.
    OverlayPanel& line_height(int32_t h) { lh_ = h; return *this; }
    /// Set the panel background color.
    OverlayPanel& background(uint32_t color) { bg_ = color; return *this; }
    /// Set the panel border color.
    OverlayPanel& border_color(uint32_t color) { border_ = color; return *this; }
    /// Set the title text color.
    OverlayPanel& title_color(uint32_t color) { title_col_ = color; return *this; }
    /// Set the body text color.
    OverlayPanel& text_color(uint32_t color) { text_col_ = color; return *this; }
    /// Set the label (dim) text color.
    OverlayPanel& label_color(uint32_t color) { dim_col_ = color; return *this; }
    /// Set the accent color (default progress-bar fill).
    OverlayPanel& accent(uint32_t color) { accent_ = color; return *this; }
    /// Set the border corner radius.
    OverlayPanel& border_radius(float r) { border_radius_ = r; return *this; }
    /// Set the non-leading title bar background.
    OverlayPanel& header_background(uint32_t color) { header_bg_ = color; return *this; }
    /// Set the item-row have/missing indicator colors. Applies to item rows
    /// appended AFTER this call (colors are baked at append time).
    OverlayPanel& item_colors(uint32_t have, uint32_t missing) {
        item_have_ = have; item_missing_ = missing; return *this;
    }
    /// Set the render scale (percent, 100 = neutral). Applied by the core
    /// FX pass from the user's panel-scale setting; scales fonts + layout.
    OverlayPanel& set_scale(int32_t pct) {
        scale_ = (pct < 50 ? 50 : (pct > 200 ? 200 : pct)) / 100.0f;
        return *this;
    }
    /// Set PanelStyleFlags directly (OR of PANEL_STYLE_*).
    OverlayPanel& style_flags(uint32_t flags) { style_flags_ = flags; return *this; }
    /// Classic flat look: no shadow, solid background, no glass, plain
    /// underlined title. Pairs well with padding(6).line_height(13).
    OverlayPanel& basic() {
        style_flags_ |= PANEL_STYLE_NO_SHADOW | PANEL_STYLE_FLAT_BG |
                        PANEL_STYLE_NO_GLASS | PANEL_STYLE_SIMPLE_TITLE;
        return *this;
    }
    /// Faint alternating tint behind data rows (rows / item rows / table rows).
    OverlayPanel& zebra(bool on = true) {
        if (on) style_flags_ |= PANEL_STYLE_ZEBRA;
        else    style_flags_ &= ~PANEL_STYLE_ZEBRA;
        return *this;
    }

    // ── Font measurement override ───────────────────────────────────────

    /// Callback that returns the pixel width of a string for layout.
    using MeasureFn = std::function<int32_t(const char*)>;

    /// Provide a font-measurement callback (else a built-in estimate is used).
    OverlayPanel& set_font_measure(MeasureFn fn) {
        measure_fn_ = std::move(fn);
        return *this;
    }

    // ── Element builders ────────────────────────────────────────────────

    /// Append a title bar. Optional `right` renders right-aligned in the
    /// bar (session clock, status text).
    OverlayPanel& title(const std::string& text, uint32_t color = 0,
                        const std::string& right = "") {
        items_.push_back({OverlayElementType::Title, text, right, 0, 0,
                         color ? color : title_col_, dim_col_, 0});
        return *this;
    }

    /// Append a stat tile: large value text over a small caption.
    /// Two consecutive stat tiles render side by side.
    OverlayPanel& stat_tile(const std::string& value, const std::string& caption,
                            uint32_t tint = 0) {
        items_.push_back({OverlayElementType::StatTile, value, caption, 0, 0,
                         tint ? tint : title_col_, text_col_, 0});
        return *this;
    }

    /// Append a radial timer ring (percent 0-100) with center text and an
    /// optional label to the ring's right.
    OverlayPanel& timer_ring(float percent, const std::string& center,
                             const std::string& label = "", uint32_t color = 0) {
        OverlayPanelItem it;
        it.type = OverlayElementType::TimerRing;
        it.left = center;
        it.right = label;
        it.percent = percent;
        it.color = color ? color : accent_;
        it.color2 = text_col_;
        it.color3 = dim_col_;
        items_.push_back(std::move(it));
        return *this;
    }

    /// Append a sparkline. Values are min-max normalised into the chart.
    OverlayPanel& sparkline(const std::vector<float>& values, uint32_t color = 0,
                            int32_t height = 22) {
        OverlayPanelItem it;
        it.type = OverlayElementType::Sparkline;
        it.left = pack_sparkline(values);
        it.extra_h = height;
        it.color = color ? color : title_col_;
        items_.push_back(std::move(it));
        return *this;
    }

    /// Append a left/right justified row.
    OverlayPanel& row(const std::string& left, const std::string& right,
                      uint32_t left_color = 0, uint32_t right_color = 0) {
        items_.push_back({OverlayElementType::Row, left, right, 0, 0,
                         left_color ? left_color : dim_col_,
                         right_color ? right_color : text_col_, 0});
        return *this;
    }

    /// Append a key/value row (alias for row).
    OverlayPanel& key_value(const std::string& key, const std::string& value,
                            uint32_t key_color = 0, uint32_t value_color = 0) {
        return row(key, value, key_color, value_color);
    }

    /// Append a single-line text label.
    OverlayPanel& label(const std::string& text, uint32_t color = 0) {
        items_.push_back({OverlayElementType::Label, text, "", 0, 0,
                         color ? color : text_col_, 0, 0});
        return *this;
    }

    /// Append a labelled progress bar (percent 0-100).
    OverlayPanel& progress(const std::string& label, float percent,
                           uint32_t bar_color = 0, uint32_t bg_color = panel_rgb(0x151221),
                           int32_t bar_height = 10) {
        items_.push_back({OverlayElementType::Progress, label, "", percent, bar_height,
                         dim_col_, bar_color ? bar_color : accent_, bg_color});
        return *this;
    }

    /// Append a horizontal separator line.
    OverlayPanel& separator(uint32_t color = 0) {
        items_.push_back({OverlayElementType::Separator, "", "", 0, 0,
                         color ? color : border_, 0, 0});
        return *this;
    }

    /// Append vertical empty space.
    OverlayPanel& spacer(int32_t height = 4) {
        items_.push_back({OverlayElementType::Spacer, "", "", 0, height, 0, 0, 0});
        return *this;
    }

    /// Append an underlined section header.
    OverlayPanel& header(const std::string& text, uint32_t color = 0) {
        items_.push_back({OverlayElementType::Header, text, "", 0, 0,
                         color ? color : text_col_, 0, 0});
        return *this;
    }

    /// Append an item row with have/need quantities and a have/missing
    /// indicator. Pass the game `item_id` to render the item's inventory
    /// icon (cache-rendered core-side); -1 keeps the colour chip.
    OverlayPanel& item_row(const std::string& name, int32_t qty_have, int32_t qty_need,
                           bool has_item, int32_t item_id = -1) {
        OverlayPanelItem it;
        it.type = OverlayElementType::ItemRow;
        it.left = name;
        it.int_val = qty_have;
        it.int_val2 = qty_need;
        it.item_id = item_id;
        it.flags = has_item ? 1 : 0;
        it.color = has_item ? item_have_ : item_missing_;
        it.color2 = text_col_;
        items_.push_back(std::move(it));
        return *this;
    }

    /// Append an icon followed by text on one line.
    OverlayPanel& icon_text(const std::string& icon, const std::string& text,
                            uint32_t color = 0) {
        items_.push_back({OverlayElementType::IconText, icon, text, 0, 0,
                         color ? color : text_col_, 0, 0});
        return *this;
    }

    /// Append a table row of evenly-spaced cells (initializer_list form).
    /// `aligns`: 'l' / 'r' / 'c' per column ({} = all left).
    OverlayPanel& table_row(std::initializer_list<std::string> cells,
                            std::initializer_list<uint32_t> colors = {},
                            std::initializer_list<char> aligns = {}) {
        std::vector<uint8_t> al;
        for (char a : aligns)
            al.push_back(a == 'r' ? 1 : (a == 'c' ? 2 : 0));
        return table_row(std::vector<std::string>(cells),
                         std::vector<uint32_t>(colors.begin(), colors.end()),
                         std::move(al));
    }

    /// Append a table row of evenly-spaced cells (vector form).
    /// `aligns`: PanelAlign values per column (empty = all left).
    OverlayPanel& table_row(std::vector<std::string> cells,
                            std::vector<uint32_t> colors,
                            std::vector<uint8_t> aligns = {}) {
        OverlayPanelItem it;
        it.type = OverlayElementType::TableRow;
        it.cells = std::move(cells);
        it.cell_colors = std::move(colors);
        it.cell_aligns = std::move(aligns);
        while (it.cell_colors.size() < it.cells.size())
            it.cell_colors.push_back(text_col_);
        while (it.cell_aligns.size() < it.cells.size())
            it.cell_aligns.push_back(0);
        items_.push_back(std::move(it));
        return *this;
    }

    /// Append a centered filled rectangle with optional border and label.
    OverlayPanel& image_rect(int32_t width, int32_t height,
                             uint32_t fill_color, uint32_t border_color = 0,
                             const std::string& label = "") {
        OverlayPanelItem it;
        it.type = OverlayElementType::ImageRect;
        it.left = label;
        it.int_val = width;
        it.int_val2 = height;
        it.color = fill_color;
        it.color2 = border_color;
        items_.push_back(std::move(it));
        return *this;
    }

    /// Append a sparkline from already hex-packed samples (IPC replay path).
    OverlayPanel& sparkline_packed(const std::string& hex, uint32_t color = 0,
                                   int32_t height = 22) {
        OverlayPanelItem it;
        it.type = OverlayElementType::Sparkline;
        it.left = hex;
        it.extra_h = height;
        it.color = color ? color : title_col_;
        items_.push_back(std::move(it));
        return *this;
    }

    // ── Accessors for IPC serialization ─────────────────────────────────

    /// The appended panel elements (for IPC serialization).
    const std::vector<OverlayPanelItem>& items() const { return items_; }
    /// Mutable element access — used by the core-side FX pass (progress
    /// easing, value-change flash) to adjust the cached display copy.
    std::vector<OverlayPanelItem>& items_mut() { return items_; }
    /// Current inner padding.
    int32_t get_padding() const { return pad_; }
    /// Current per-row line height.
    int32_t get_line_height() const { return lh_; }
    /// Current background color.
    uint32_t get_background() const { return bg_; }
    /// Current border color.
    uint32_t get_border() const { return border_; }
    /// Current title text color.
    uint32_t get_title_color() const { return title_col_; }
    /// Current body text color.
    uint32_t get_text_color() const { return text_col_; }
    /// Current label (dim) text color.
    uint32_t get_label_color() const { return dim_col_; }
    /// Current accent color.
    uint32_t get_accent() const { return accent_; }
    /// Current border corner radius.
    float get_border_radius() const { return border_radius_; }
    /// Current non-leading title bar background.
    uint32_t get_header_bg() const { return header_bg_; }
    /// Current item-row "have" indicator color.
    uint32_t get_item_have() const { return item_have_; }
    /// Current item-row "missing" indicator color.
    uint32_t get_item_missing() const { return item_missing_; }
    /// Current style flags (OR of PANEL_STYLE_*).
    uint32_t get_style_flags() const { return style_flags_; }

    // ── Render ──────────────────────────────────────────────────────────

    /// Bounding rectangle returned by render().
    struct RenderResult { int32_t x, y, w, h; };

    /// Compute the panel's width from its content (or the fixed width).
    int32_t calc_width() const {
        if (fixed_width_ > 0) return fixed_width_;
        int32_t max_w = sc(min_width_);
        for (auto& it : items_) {
            int32_t iw = spad() * 2;
            switch (it.type) {
            case OverlayElementType::Title:
                iw += measure_text(it.left)
                    + (it.right.empty() ? 0 : sc(24) + measure_text(it.right));
                break;
            case OverlayElementType::Header:
                iw += measure_text(it.left);
                break;
            case OverlayElementType::StatTile:
                // Sized for the 2-up case; a pair of tiles shares the row.
                // Values draw at 16px but measure at 13px — scale by 5/4.
                iw += (measure_text(it.left) * 5 / 4 + sc(20)) * 2 + sc(6);
                break;
            case OverlayElementType::TimerRing:
                iw += sc(40) + measure_text(it.right) + sc(8);
                break;
            case OverlayElementType::Sparkline:
                if (iw < sc(140)) iw = sc(140);
                break;
            case OverlayElementType::Row:
                iw += measure_text(it.left) + sc(20) + measure_text(it.right) + 4;
                break;
            case OverlayElementType::Label:
                iw += measure_text(it.left);
                break;
            case OverlayElementType::IconText:
                iw += measure_text(it.left) + 4 + measure_text(it.right);
                break;
            case OverlayElementType::ItemRow: {
                std::string qty = std::to_string(it.int_val) + "/" + std::to_string(it.int_val2);
                const int32_t lead = (it.item_id >= 0) ? sc(27) : sc(14);  // icon vs chip + gap
                iw += lead + measure_text(it.left) + 12 + measure_text(qty);
                break;
            }
            case OverlayElementType::TableRow: {
                int32_t tw = 0;
                for (auto& c : it.cells) tw += measure_text(c) + 8;
                iw += tw;
                break;
            }
            case OverlayElementType::ImageRect:
                iw += it.int_val;
                break;
            default: break;
            }
            if (iw > max_w) max_w = iw;
        }
        return max_w;
    }

    /// Compute the panel's total height from its content. Mirrors render()'s
    /// cy advances exactly, including 2-up stat-tile pairing.
    int32_t calc_height() const {
        int32_t h = spad() * 2;
        for (size_t i = 0; i < items_.size(); ++i) {
            const auto& it = items_[i];
            switch (it.type) {
            case OverlayElementType::Title:    h += slh() + sc(10); break;
            case OverlayElementType::Header:   h += slh() + sc(4); break;
            case OverlayElementType::Row:
            case OverlayElementType::Label:
            case OverlayElementType::IconText:
            case OverlayElementType::TableRow: h += slh(); break;
            case OverlayElementType::ItemRow:  h += (it.item_id >= 0) ? sc(24) : slh(); break;
            case OverlayElementType::Progress: h += slh() + sc(it.extra_h > 0 ? it.extra_h : 6) + sc(2); break;
            case OverlayElementType::Separator: h += 6; break;
            case OverlayElementType::Spacer:   h += it.extra_h; break;
            case OverlayElementType::ImageRect: h += it.int_val2 + 2; break;
            case OverlayElementType::StatTile:
                h += sc(38);
                if (i + 1 < items_.size() &&
                    items_[i + 1].type == OverlayElementType::StatTile)
                    ++i;  // pair shares the row
                break;
            case OverlayElementType::TimerRing: h += sc(40); break;
            case OverlayElementType::Sparkline: h += sc(it.extra_h > 0 ? it.extra_h : 22) + sc(6); break;
            }
        }
        return h;
    }

    /// Draw the panel at (x, y) via the OverlayContext; returns its bounds.
    RenderResult render(OverlayContext& ctx, int32_t x, int32_t y) const {
        int32_t w = calc_width();
        int32_t h = calc_height();

        auto F = [](int32_t v) -> float { return static_cast<float>(v); };

        // Soft drop shadow — expanding translucent layers, faintest first.
        struct ShadowLayer { int32_t grow; uint32_t alpha; };
        constexpr ShadowLayer SHADOW[3] = {{6, 0x0E}, {4, 0x18}, {2, 0x22}};
        if (!(style_flags_ & PANEL_STYLE_NO_SHADOW))
        for (const auto& s : SHADOW)
            ctx.render_rect_filled_screen(F(x - s.grow), F(y - s.grow + 3),
                                          F(w + s.grow * 2), F(h + s.grow * 2),
                                          panel_alpha(0, s.alpha),
                                          sradius() + static_cast<float>(s.grow));

        // Background: solid fill (FLAT_BG) or a subtle vertical gradient
        // with a 1px inner top highlight, plus the border.
        if (style_flags_ & PANEL_STYLE_FLAT_BG) {
            ctx.render_rect_filled_screen(F(x), F(y), F(w), F(h), bg_, sradius());
        } else {
            ctx.render_rect_gradient_screen(F(x), F(y), F(w), F(h),
                                            panel_lighten(bg_, 7), bg_, sradius());
            ctx.render_rect_filled_screen(F(x + static_cast<int32_t>(sradius())), F(y + 1),
                                          F(w - static_cast<int32_t>(sradius()) * 2), 1.0f,
                                          panel_rgb(0xFFFFFF, 0x0C));
        }
        ctx.render_rect_screen(F(x), F(y), F(w), F(h), border_, 1.0f, sradius());

        // Text draws top-anchored; centre the 13px UI font (Fonts[0],
        // loaded in core overlay.cpp) inside each slh()-tall row. Stat-tile
        // values are the one 16px exception.
        const int32_t FONT_PX = sc(13);
        const int32_t t_off = (slh() > FONT_PX) ? (slh() - FONT_PX) / 2 : 0;

        int32_t cy = y + spad();
        const bool zebra_on = (style_flags_ & PANEL_STYLE_ZEBRA) != 0;
        int32_t zrow = 0;   // data-row counter; headers/titles/separators reset it
        auto zebra_fill = [&](int32_t row_h) {
            if (zebra_on && (zrow & 1))
                ctx.render_rect_filled_screen(F(x + 1), F(cy), F(w - 2), F(row_h),
                                              panel_rgb(0xFFFFFF, 0x07));
            zrow++;
        };
        for (size_t ii = 0; ii < items_.size(); ++ii) {
            const auto& it = items_[ii];
            switch (it.type) {
            case OverlayElementType::Title: {
                if (ii == 0 && (style_flags_ & PANEL_STYLE_SIMPLE_TITLE)) {
                    // Classic look: plain title text + hairline underline,
                    // same vertical budget as the bar so layout is stable.
                    zrow = 0;
                    const int32_t sty = cy + t_off;
                    ctx.render_text_screen_ui(F(x + spad()), F(sty), it.left.c_str(), it.color);
                    if (!it.right.empty()) {
                        int32_t rw = measure_text(it.right);
                        ctx.render_text_screen_ui(F(x + w - spad() - rw), F(sty),
                                               it.right.c_str(), it.color2 ? it.color2 : dim_col_);
                    }
                    ctx.render_rect_filled_screen(F(x + spad()), F(cy + slh() + sc(3)),
                                                  F(w - spad() * 2), 1.0f,
                                                  panel_alpha(it.color, 0x50));
                    cy = y + spad() + slh() + sc(10);
                } else if (ii == 0) {
                    // Leading title: full-bleed bar flush with the panel top,
                    // tinted from the title colour, with a visible underline.
                    // The bar ends above the row budget so a small gap
                    // separates it from the first row; vertical budget still
                    // matches calc_height's slh() + 10 exactly.
                    const int32_t bar_top = y + 1;
                    int32_t bar_bot = y + slh() + sc(11);
                    if (bar_bot > y + spad() + slh() + sc(6)) bar_bot = y + spad() + slh() + sc(6);
                    ctx.render_rect_gradient_screen(F(x + 1), F(bar_top), F(w - 2), F(bar_bot - bar_top),
                                                    panel_alpha(it.color, 0x20),
                                                    panel_alpha(it.color, 0x08),
                                                    sradius() - 1.0f, /*round_top_only=*/true);
                    ctx.render_rect_filled_screen(F(x + 1), F(bar_bot), F(w - 2), 1.0f,
                                                  panel_alpha(it.color, 0x48));
                    const int32_t ty = bar_top + ((bar_bot - bar_top) - FONT_PX) / 2 + 1;
                    ctx.render_text_screen_ui(F(x + spad()), F(ty), it.left.c_str(), it.color);
                    if (!it.right.empty()) {
                        int32_t rw = measure_text(it.right);
                        ctx.render_text_screen_ui(F(x + w - spad() - rw), F(ty),
                                               it.right.c_str(), it.color2 ? it.color2 : dim_col_);
                    }
                    cy = y + spad() + slh() + sc(10);
                } else {
                    int32_t bar_h = slh() + sc(6);
                    ctx.render_rect_filled_screen(F(x + 1), F(cy), F(w - 2), F(bar_h),
                                                  header_bg_, sradius() * 0.5f);
                    ctx.render_text_screen_ui(F(x + spad()), F(cy + (bar_h - FONT_PX) / 2),
                                           it.left.c_str(), it.color);
                    cy += bar_h + sc(4);
                }
                break;
            }

            case OverlayElementType::Header:
                zrow = 0;
                ctx.render_rect_filled_screen(F(x + spad()), F(cy + slh() + sc(2)), F(w - spad() * 2), 1.0f, border_);
                ctx.render_text_screen_ui(F(x + spad()), F(cy + t_off), it.left.c_str(), it.color);
                cy += slh() + sc(4);
                break;

            case OverlayElementType::Row: {
                zebra_fill(slh());
                ctx.render_text_screen_ui(F(x + spad()), F(cy + t_off), it.left.c_str(), it.color);
                int32_t rw = measure_text(it.right);
                ctx.render_text_screen_ui(F(x + w - spad() - rw), F(cy + t_off), it.right.c_str(), it.color2);
                cy += slh();
                break;
            }

            case OverlayElementType::Label:
                ctx.render_text_screen_ui(F(x + spad()), F(cy + t_off), it.left.c_str(), it.color);
                cy += slh();
                break;

            case OverlayElementType::Progress: {
                ctx.render_text_screen_ui(F(x + spad()), F(cy + t_off), it.left.c_str(), it.color);
                cy += slh();
                int32_t bw = w - spad() * 2;
                int32_t bh = sc(it.extra_h > 0 ? it.extra_h : 6);
                const float br = bh * 0.5f;
                ctx.render_rect_filled_screen(F(x + spad()), F(cy), F(bw), F(bh), it.color3, br);
                int32_t fw = static_cast<int32_t>(bw * std::clamp(it.percent, 0.0f, 100.0f) / 100.0f);
                if (fw > 0) {
                    ctx.render_rect_filled_screen(F(x + spad()), F(cy), F(fw), F(bh), it.color2, br);
                    // 1px sheen along the top of the fill.
                    if (fw > bh)
                        ctx.render_rect_filled_screen(F(x + spad() + static_cast<int32_t>(br)), F(cy + 1),
                                                      F(fw - bh), 1.0f,
                                                      panel_alpha(panel_lighten(it.color2, 45), 0xA0));
                }
                ctx.render_rect_screen(F(x + spad()), F(cy), F(bw), F(bh),
                                       panel_alpha(it.color2, 0x1C), 1.0f, br);
                if (bh >= 9) {
                    // Percent label inside the bar (10px small font).
                    char pct_txt[8];
                    const int pc = static_cast<int>(std::clamp(it.percent, 0.0f, 100.0f) + 0.5f);
                    std::snprintf(pct_txt, sizeof(pct_txt), "%d%%", pc);
                    const int32_t est = static_cast<int32_t>(std::strlen(pct_txt)) * sc(6);
                    ctx.render_text_screen_small(F(x + spad() + bw / 2 - est / 2),
                                                 F(cy + (bh - sc(10)) / 2),
                                                 pct_txt, panel_rgb(0xFFFFFF, 0xE6));
                }
                cy += bh + sc(2);
                break;
            }

            case OverlayElementType::Separator:
                zrow = 0;
                cy += 3;
                ctx.render_rect_filled_screen(F(x + spad()), F(cy), F(w - spad() * 2), 1.0f, it.color);
                cy += 3;
                break;

            case OverlayElementType::Spacer:
                cy += it.extra_h;
                break;

            case OverlayElementType::ItemRow: {
                const bool want_icon = it.item_id >= 0;
                const int32_t row_h = want_icon ? sc(24) : slh();
                zebra_fill(row_h);
                int32_t text_x = x + spad() + sc(14);   // chip layout default
                bool icon_drawn = false;
                if (want_icon) {
                    // 36x32 icon scaled to 25x22, slightly into the padding.
                    icon_drawn = ctx.render_item_icon_screen(F(x + spad() - 2), F(cy + 1),
                                                             F(sc(25)), F(sc(22)),
                                                             it.item_id, it.int_val);
                    text_x = x + spad() + sc(27);
                }
                if (!icon_drawn) {
                    // Rounded colour chip (also the warm-up fallback).
                    const int32_t CHIP = sc(8);
                    ctx.render_rect_filled_screen(F(x + spad()), F(cy + (row_h - CHIP) / 2),
                                                  F(CHIP), F(CHIP), it.color, 2.0f);
                    if (!want_icon) text_x = x + spad() + CHIP + sc(6);
                }
                const int32_t ty = cy + (row_h - FONT_PX) / 2;
                ctx.render_text_screen_ui(F(text_x), F(ty), it.left.c_str(), it.color2);
                std::string qty = std::to_string(it.int_val) + "/" + std::to_string(it.int_val2);
                int32_t qw = measure_text(qty);
                ctx.render_text_screen_ui(F(x + w - spad() - qw), F(ty), qty.c_str(), it.color);
                cy += row_h;
                break;
            }

            case OverlayElementType::IconText:
                ctx.render_text_screen_ui(F(x + spad()), F(cy + t_off), it.left.c_str(), it.color);
                ctx.render_text_screen_ui(F(x + spad() + measure_text(it.left) + 4), F(cy + t_off),
                                       it.right.c_str(), it.color);
                cy += slh();
                break;

            case OverlayElementType::TableRow: {
                zebra_fill(slh());
                const int32_t n = static_cast<int32_t>(std::max(it.cells.size(), size_t(1)));
                const int32_t col_w = (w - spad() * 2) / n;
                for (size_t i = 0; i < it.cells.size(); ++i) {
                    const uint32_t col = i < it.cell_colors.size() ? it.cell_colors[i] : text_col_;
                    const uint8_t align = i < it.cell_aligns.size() ? it.cell_aligns[i] : 0;
                    const int32_t cell_x0 = x + spad() + static_cast<int32_t>(i) * col_w;
                    const int32_t cell_x1 = (i + 1 == it.cells.size())
                        ? x + w - spad() : cell_x0 + col_w;
                    int32_t tx = cell_x0;
                    if (align != 0) {
                        const int32_t tw = measure_text(it.cells[i]);
                        tx = (align == 1) ? cell_x1 - tw
                                          : cell_x0 + (cell_x1 - cell_x0 - tw) / 2;
                    }
                    ctx.render_text_screen_ui(F(tx), F(cy + t_off), it.cells[i].c_str(), col);
                }
                cy += slh();
                break;
            }

            case OverlayElementType::ImageRect: {
                int32_t iw = it.int_val;
                int32_t ih = it.int_val2;
                int32_t ix = x + (w - iw) / 2;
                ctx.render_rect_filled_screen(F(ix), F(cy), F(iw), F(ih), it.color);
                if (it.color2)
                    ctx.render_rect_screen(F(ix), F(cy), F(iw), F(ih), it.color2);
                if (!it.left.empty()) {
                    int32_t tw = measure_text(it.left);
                    ctx.render_text_screen_ui(F(ix + (iw - tw) / 2), F(cy + (ih - FONT_PX) / 2),
                                           it.left.c_str(), text_col_);
                }
                cy += ih + 2;
                break;
            }

            case OverlayElementType::StatTile: {
                // 2-up when the next item is also a stat tile.
                const int32_t TILE_H = sc(34);
                const int32_t bw = w - spad() * 2;
                const bool paired = (ii + 1 < items_.size() &&
                                     items_[ii + 1].type == OverlayElementType::StatTile);
                const int32_t tw = paired ? (bw - sc(6)) / 2 : bw;
                auto draw_tile = [&](const OverlayPanelItem& t, int32_t tx) {
                    ctx.render_rect_filled_screen(F(tx), F(cy), F(tw), F(TILE_H),
                                                  panel_alpha(t.color, 0x0E), 6.0f);
                    ctx.render_rect_screen(F(tx), F(cy), F(tw), F(TILE_H),
                                           panel_alpha(t.color, 0x18), 1.0f, 6.0f);
                    // Value stays on the 16px font — it's the "big number".
                    ctx.render_text_screen(F(tx + sc(8)), F(cy + sc(4)), t.left.c_str(),
                                           t.color2 ? t.color2 : text_col_);
                    ctx.render_text_screen_small(F(tx + sc(8)), F(cy + sc(22)),
                                                 t.right.c_str(), dim_col_);
                };
                draw_tile(it, x + spad());
                if (paired) {
                    draw_tile(items_[ii + 1], x + spad() + tw + sc(6));
                    ++ii;
                }
                cy += TILE_H + sc(4);   // sc(38) total — must match calc_height
                break;
            }

            case OverlayElementType::TimerRing: {
                const int32_t RING_H = sc(40);
                const float rcx = F(x + spad() + sc(16));
                const float rcy = F(cy + RING_H / 2 - 2);
                ctx.render_ring_screen(rcx, rcy, 14.0f * scale_, 3.5f * scale_,
                                       std::clamp(it.percent, 0.0f, 100.0f) / 100.0f,
                                       it.color, panel_alpha(it.color, 0x20));
                const int32_t est = static_cast<int32_t>(it.left.size()) * sc(6);
                ctx.render_text_screen_small(rcx - est / 2.0f, rcy - 5.0f,
                                             it.left.c_str(), it.color2 ? it.color2 : text_col_);
                if (!it.right.empty())
                    ctx.render_text_screen_ui(F(x + spad() + sc(38)), F(cy + (RING_H - FONT_PX) / 2 - 2),
                                           it.right.c_str(), it.color3 ? it.color3 : dim_col_);
                cy += RING_H;
                break;
            }

            case OverlayElementType::Sparkline: {
                const int32_t sh = sc(it.extra_h > 0 ? it.extra_h : 22);
                const int32_t bw = w - spad() * 2;
                const int32_t n = static_cast<int32_t>(it.left.size() / 2);
                if (n >= 2 && bw > 8) {
                    const float step = static_cast<float>(bw) / static_cast<float>(n - 1);
                    float px_ = 0, py_ = 0;
                    for (int32_t i = 0; i < n; i++) {
                        const int32_t v = sparkline_sample(it.left, static_cast<size_t>(i));
                        const float sx = F(x + spad()) + step * i;
                        const float sy = F(cy + sh) - (v / 255.0f) * (sh - 2);
                        if (i > 0)
                            ctx.render_line_screen(px_, py_, sx, sy, it.color, 1.5f);
                        px_ = sx; py_ = sy;
                    }
                    // Emphasised endpoint.
                    ctx.render_rect_filled_screen(px_ - 2.0f, py_ - 2.0f, 4.0f, 4.0f,
                                                  panel_lighten(it.color, 35), 2.0f);
                }
                cy += sh + sc(6);
                break;
            }
            }
        }
        return {x, y, w, h};
    }

    /// Draw only the title bar (collapsed panel). Same width as expanded so
    /// anchored stacks don't shift; height is calc_height_collapsed().
    RenderResult render_collapsed(OverlayContext& ctx, int32_t x, int32_t y) const {
        const int32_t w = calc_width();
        const int32_t h = calc_height_collapsed();
        auto F = [](int32_t v) -> float { return static_cast<float>(v); };
        const int32_t FONT_PX = sc(13);

        ctx.render_rect_filled_screen(F(x - 2), F(y - 2 + 2), F(w + 4), F(h + 4),
                                      panel_alpha(0, 0x22), sradius() + 2.0f);
        const uint32_t tint = (!items_.empty() &&
                               items_.front().type == OverlayElementType::Title)
                                  ? items_.front().color : title_col_;
        ctx.render_rect_filled_screen(F(x), F(y), F(w), F(h), bg_, sradius());
        ctx.render_rect_gradient_screen(F(x), F(y), F(w), F(h),
                                        panel_alpha(tint, 0x2E), panel_alpha(tint, 0x10),
                                        sradius());
        ctx.render_rect_screen(F(x), F(y), F(w), F(h), border_, 1.0f, sradius());

        const char* text = (!items_.empty() &&
                            items_.front().type == OverlayElementType::Title)
                               ? items_.front().left.c_str() : "(panel)";
        const int32_t ty = y + (h - FONT_PX) / 2;
        ctx.render_text_screen_ui(F(x + spad()), F(ty), text, tint);
        // Expand hint.
        ctx.render_text_screen_ui(F(x + w - spad() - sc(10)), F(ty), "+", dim_col_);
        return {x, y, w, h};
    }

    /// Remove all appended elements.
    void clear() { items_.clear(); }

    /// Measure a string's pixel width via the callback or built-in estimate,
    /// scaled by the render scale (glyphs draw at font_size * scale).
    int32_t measure_text(const std::string& s) const {
        const int32_t raw = measure_fn_ ? measure_fn_(s.c_str())
                                        : estimate_text_width(s);
        return static_cast<int32_t>(raw * scale_ + 0.5f);
    }

public:
    /// Hex-pack float samples into a 2-chars-per-sample string (min-max
    /// normalised to 0-255). Public so IPC layers and JS bindings share it.
    static std::string pack_sparkline(const std::vector<float>& values) {
        std::string out;
        if (values.empty()) return out;
        size_t n = values.size() > 64 ? 64 : values.size();
        float lo = values[0], hi = values[0];
        for (size_t i = 1; i < n; i++) {
            if (values[i] < lo) lo = values[i];
            if (values[i] > hi) hi = values[i];
        }
        const float range = (hi - lo) > 0.0001f ? (hi - lo) : 1.0f;
        static const char* HEX = "0123456789ABCDEF";
        out.reserve(n * 2);
        for (size_t i = 0; i < n; i++) {
            int v = static_cast<int>((values[i] - lo) / range * 255.0f + 0.5f);
            if (v < 0) v = 0; if (v > 255) v = 255;
            out.push_back(HEX[(v >> 4) & 0xF]);
            out.push_back(HEX[v & 0xF]);
        }
        return out;
    }

    /// Decode one hex-packed sample (returns 0-255, or -1 past the end).
    static int32_t sparkline_sample(const std::string& packed, size_t idx) {
        if (idx * 2 + 1 >= packed.size()) return -1;
        auto nib = [](char c) -> int32_t {
            if (c >= '0' && c <= '9') return c - '0';
            if (c >= 'A' && c <= 'F') return c - 'A' + 10;
            if (c >= 'a' && c <= 'f') return c - 'a' + 10;
            return 0;
        };
        return (nib(packed[idx * 2]) << 4) | nib(packed[idx * 2 + 1]);
    }

    /// Height of the collapsed (title-bar-only) rendering.
    int32_t calc_height_collapsed() const { return slh() + sc(16); }

private:
    /// Scale a layout metric by the render scale (user panel-scale setting).
    int32_t sc(int32_t v) const { return static_cast<int32_t>(v * scale_ + 0.5f); }
    /// Scaled padding / line height / radius — layout code reads these;
    /// the raw members survive for serialization getters and setters.
    int32_t spad() const { return sc(pad_); }
    int32_t slh() const { return sc(lh_); }
    float   sradius() const { return border_radius_ * scale_; }

    static int32_t estimate_text_width(const std::string& s) {
        int32_t w = 0;
        for (char c : s) {
            if (c == 'W' || c == 'M' || c == 'm' || c == 'w') w += 12;
            else if (c >= 'A' && c <= 'Z') w += 10;
            else if (c == 'i' || c == 'l' || c == '!' || c == '|' || c == '.') w += 5;
            else if (c == ':' || c == ';') w += 5;
            else if (c == ' ') w += 5;
            else if (c == '/') w += 7;
            else w += 8;
        }
        return w + 2;
    }

    std::vector<OverlayPanelItem> items_;
    MeasureFn measure_fn_;
    float   scale_       = 1.0f;
    uint32_t style_flags_ = 0;
    int32_t fixed_width_ = 0;
    int32_t min_width_   = 120;
    int32_t pad_         = 8;
    int32_t lh_          = 15;
    int32_t gap_         = 6;
    // Defaults must mirror PanelTheme's — the theme() setter overwrites all
    // of these, but a panel used without a theme should look identical.
    uint32_t bg_         = panel_rgb(0x16131D, 0xE0);
    uint32_t border_     = panel_rgb(0x9B7CFF, 0x30);
    uint32_t title_col_  = panel_rgb(0xB9A8FF);
    uint32_t text_col_   = panel_rgb(0xEFEEF8);
    uint32_t dim_col_    = panel_rgb(0x9A94B0);
    uint32_t accent_     = panel_rgb(0x3FCB6E);
    uint32_t header_bg_  = panel_rgb(0xFFFFFF, 0x14);
    uint32_t item_have_  = panel_rgb(0x3FCB6E);
    uint32_t item_missing_ = panel_rgb(0xE05252);
    float    border_radius_ = 7.0f;
};

} // namespace obsidian::api
