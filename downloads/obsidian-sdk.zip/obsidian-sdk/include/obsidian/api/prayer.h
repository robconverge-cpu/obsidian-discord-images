#pragma once
/// @file prayer.h
/// @brief Prayer enum with varbit activation IDs and drain rates.
/// @ingroup entities
// ═══════════════════════════════════════════════════════════════════════════
// PRAYER — Prayer enum with varbit IDs for activation state
// ═══════════════════════════════════════════════════════════════════════════
// Mirrors RuneLite Prayer.java. Each prayer has an associated varbit
// that reads 1 when active, 0 when inactive.
// Usage: client.varbit(prayer_varbit(Prayer::PROTECT_FROM_MELEE)) == 1
// ═══════════════════════════════════════════════════════════════════════════

#include <cstdint>

namespace obsidian::api {

/// All standard OSRS prayers. Values match RuneLite Prayer.java ordinals.
enum class Prayer : int32_t {
    THICK_SKIN            = 0,
    BURST_OF_STRENGTH     = 1,
    CLARITY_OF_THOUGHT    = 2,
    SHARP_EYE             = 3,
    MYSTIC_WILL           = 4,
    ROCK_SKIN             = 5,
    SUPERHUMAN_STRENGTH   = 6,
    IMPROVED_REFLEXES     = 7,
    RAPID_RESTORE         = 8,
    RAPID_HEAL            = 9,
    PROTECT_ITEM          = 10,
    HAWK_EYE              = 11,
    MYSTIC_LORE           = 12,
    STEEL_SKIN            = 13,
    ULTIMATE_STRENGTH     = 14,
    INCREDIBLE_REFLEXES   = 15,
    PROTECT_FROM_MAGIC    = 16,
    PROTECT_FROM_MISSILES = 17,
    PROTECT_FROM_MELEE    = 18,
    EAGLE_EYE             = 19,
    MYSTIC_MIGHT          = 20,
    RETRIBUTION            = 21,
    REDEMPTION             = 22,
    SMITE                  = 23,
    PRESERVE               = 24,
    CHIVALRY               = 25,
    PIETY                  = 26,
    RIGOUR                 = 27,
    AUGURY                 = 28,
};

/// Returns the varbit ID used to check if a prayer is active.
/// Usage: `client.varbit(prayer_varbit(Prayer::PIETY)) == 1`
inline int32_t prayer_varbit(Prayer p) {
    switch (p) {
        case Prayer::THICK_SKIN:            return 4104;
        case Prayer::BURST_OF_STRENGTH:     return 4105;
        case Prayer::CLARITY_OF_THOUGHT:    return 4106;
        case Prayer::SHARP_EYE:             return 4122;
        case Prayer::MYSTIC_WILL:           return 4123;
        case Prayer::ROCK_SKIN:             return 4107;
        case Prayer::SUPERHUMAN_STRENGTH:   return 4108;
        case Prayer::IMPROVED_REFLEXES:     return 4109;
        case Prayer::RAPID_RESTORE:         return 4110;
        case Prayer::RAPID_HEAL:            return 4111;
        case Prayer::PROTECT_ITEM:          return 4112;
        case Prayer::HAWK_EYE:              return 4124;
        case Prayer::MYSTIC_LORE:           return 4125;
        case Prayer::STEEL_SKIN:            return 4113;
        case Prayer::ULTIMATE_STRENGTH:     return 4114;
        case Prayer::INCREDIBLE_REFLEXES:   return 4115;
        case Prayer::PROTECT_FROM_MAGIC:    return 4116;
        case Prayer::PROTECT_FROM_MISSILES: return 4117;
        case Prayer::PROTECT_FROM_MELEE:    return 4118;
        case Prayer::EAGLE_EYE:             return 4126;
        case Prayer::MYSTIC_MIGHT:          return 4127;
        case Prayer::RETRIBUTION:           return 4119;
        case Prayer::REDEMPTION:            return 4120;
        case Prayer::SMITE:                 return 4121;
        case Prayer::PRESERVE:              return 5466;
        case Prayer::CHIVALRY:              return 4128;
        case Prayer::PIETY:                 return 4129;
        case Prayer::RIGOUR:                return 5464;
        case Prayer::AUGURY:                return 5465;
        default:                            return -1;
    }
}

/// Returns the display name for a prayer (e.g. "Protect from Melee").
inline const char* prayer_name(Prayer p) {
    switch (p) {
        case Prayer::THICK_SKIN:            return "Thick Skin";
        case Prayer::BURST_OF_STRENGTH:     return "Burst of Strength";
        case Prayer::CLARITY_OF_THOUGHT:    return "Clarity of Thought";
        case Prayer::SHARP_EYE:             return "Sharp Eye";
        case Prayer::MYSTIC_WILL:           return "Mystic Will";
        case Prayer::ROCK_SKIN:             return "Rock Skin";
        case Prayer::SUPERHUMAN_STRENGTH:   return "Superhuman Strength";
        case Prayer::IMPROVED_REFLEXES:     return "Improved Reflexes";
        case Prayer::RAPID_RESTORE:         return "Rapid Restore";
        case Prayer::RAPID_HEAL:            return "Rapid Heal";
        case Prayer::PROTECT_ITEM:          return "Protect Item";
        case Prayer::HAWK_EYE:              return "Hawk Eye";
        case Prayer::MYSTIC_LORE:           return "Mystic Lore";
        case Prayer::STEEL_SKIN:            return "Steel Skin";
        case Prayer::ULTIMATE_STRENGTH:     return "Ultimate Strength";
        case Prayer::INCREDIBLE_REFLEXES:   return "Incredible Reflexes";
        case Prayer::PROTECT_FROM_MAGIC:    return "Protect from Magic";
        case Prayer::PROTECT_FROM_MISSILES: return "Protect from Missiles";
        case Prayer::PROTECT_FROM_MELEE:    return "Protect from Melee";
        case Prayer::EAGLE_EYE:             return "Eagle Eye";
        case Prayer::MYSTIC_MIGHT:          return "Mystic Might";
        case Prayer::RETRIBUTION:           return "Retribution";
        case Prayer::REDEMPTION:            return "Redemption";
        case Prayer::SMITE:                 return "Smite";
        case Prayer::PRESERVE:              return "Preserve";
        case Prayer::CHIVALRY:              return "Chivalry";
        case Prayer::PIETY:                 return "Piety";
        case Prayer::RIGOUR:                return "Rigour";
        case Prayer::AUGURY:                return "Augury";
        default:                            return "Unknown";
    }
}

/// Returns the prayer drain rate in prayer points per game tick (before bonus reductions).
inline double prayer_drain_rate(Prayer p) {
    switch (p) {
        case Prayer::THICK_SKIN:            return 1.0 / 12;
        case Prayer::BURST_OF_STRENGTH:     return 1.0 / 12;
        case Prayer::CLARITY_OF_THOUGHT:    return 1.0 / 12;
        case Prayer::SHARP_EYE:             return 1.0 / 12;
        case Prayer::MYSTIC_WILL:           return 1.0 / 12;
        case Prayer::ROCK_SKIN:             return 1.0 / 6;
        case Prayer::SUPERHUMAN_STRENGTH:   return 1.0 / 6;
        case Prayer::IMPROVED_REFLEXES:     return 1.0 / 6;
        case Prayer::RAPID_RESTORE:         return 1.0 / 36;
        case Prayer::RAPID_HEAL:            return 1.0 / 18;
        case Prayer::PROTECT_ITEM:          return 1.0 / 18;
        case Prayer::HAWK_EYE:              return 1.0 / 6;
        case Prayer::MYSTIC_LORE:           return 1.0 / 6;
        case Prayer::STEEL_SKIN:            return 1.0 / 3;
        case Prayer::ULTIMATE_STRENGTH:     return 1.0 / 3;
        case Prayer::INCREDIBLE_REFLEXES:   return 1.0 / 3;
        case Prayer::PROTECT_FROM_MAGIC:    return 1.0 / 3;
        case Prayer::PROTECT_FROM_MISSILES: return 1.0 / 3;
        case Prayer::PROTECT_FROM_MELEE:    return 1.0 / 3;
        case Prayer::EAGLE_EYE:             return 1.0 / 3;
        case Prayer::MYSTIC_MIGHT:          return 1.0 / 3;
        case Prayer::RETRIBUTION:           return 1.0 / 12;
        case Prayer::REDEMPTION:            return 1.0 / 6;
        case Prayer::SMITE:                 return 1.0 / 2;
        case Prayer::PRESERVE:              return 1.0 / 18;
        case Prayer::CHIVALRY:              return 1.0 / 1.5;
        case Prayer::PIETY:                 return 1.0 / 1.5;
        case Prayer::RIGOUR:                return 1.0 / 1.5;
        case Prayer::AUGURY:                return 1.0 / 1.5;
        default:                            return 0.0;
    }
}

} // namespace obsidian::api
