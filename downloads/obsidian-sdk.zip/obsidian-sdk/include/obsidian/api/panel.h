#pragma once
/// @file panel.h
/// @brief Declarative sidebar panel builder for plugins.
///
/// Plugins build sidebar panels using a flat list of typed elements.
/// The host reads the element list and renders it in ImGui.
/// User interactions (button clicks, list selections) fire events
/// back to the plugin via the EventBus.
///
/// Example usage:
/// @code
///   auto panel = api::PanelBuilder();
///   panel.section("Quest Progress");
///   panel.label("Cook's Assistant", 0xFF00FF00);
///   panel.progress("Progress", 66);
///   panel.separator();
///   panel.section("Items Needed");
///   panel.item_row("Bucket of milk", 1, 1, true);
///   panel.item_row("Pot of flour", 0, 1, false);
///   panel.item_row("Egg", 1, 1, true);
///   panel.separator();
///   panel.button("Track Quest", 1);
///   panel.publish();
/// @endcode

#include <cstdint>
#include <cstring>

namespace obsidian::api {

/// Maximum panel elements a plugin can publish.
static constexpr int MAX_PANEL_ELEMENTS = 128;

/// Panel element types.
enum class PanelElementType : uint8_t {
    SECTION,        ///< Collapsible section header. text = title.
    LABEL,          ///< Text label. text = content, color = text color.
    KEY_VALUE,      ///< "Key: Value" pair. text = key, secondary = value.
    SEPARATOR,      ///< Horizontal rule.
    SPACER,         ///< Vertical spacing.
    BUTTON,         ///< Clickable button. text = label, id = callback ID.
    PROGRESS,       ///< Progress bar. text = label, int_value = percent (0-100).
    ITEM_ROW,       ///< Item with status. text = name, int_value = qty_have, int_value2 = qty_need, flags bit 0 = has_item.
    LIST_HEADER,    ///< Selectable list header. text = title.
    LIST_ITEM,      ///< Selectable list entry. text = name, id = selection ID, flags bit 0 = selected, bit 1 = completed.
    ICON_LABEL,     ///< Label with icon prefix. text = label, secondary = icon_fa string.
    MULTI_VALUE,    ///< Row with multiple values. text = label, secondary = "val1|val2|val3".
};

/// Flags for panel elements.
namespace PanelFlags {
    constexpr uint8_t HAS_ITEM    = 1 << 0; ///< Item row: player has this item.
    constexpr uint8_t SELECTED    = 1 << 0; ///< List item: currently selected.
    constexpr uint8_t COMPLETED   = 1 << 1; ///< List item: completed/finished.
    constexpr uint8_t COLLAPSED   = 1 << 0; ///< Section: collapsed by default.
    constexpr uint8_t EQUIPPED    = 1 << 1; ///< Item row: item is equipped.
    constexpr uint8_t HIGHLIGHT   = 1 << 2; ///< General: highlight this element.
    constexpr uint8_t DISABLED    = 1 << 3; ///< Button: greyed out.
}

/// A single panel element in the flat element list.
struct PanelElement {
    PanelElementType type = PanelElementType::SPACER;
    uint8_t id    = 0;     ///< Element ID for callbacks (button clicks, list selections).
    uint8_t flags = 0;     ///< Element-specific flags (see PanelFlags).
    uint8_t _pad  = 0;
    int32_t int_value  = 0; ///< Primary integer (progress %, quantity have, etc.).
    int32_t int_value2 = 0; ///< Secondary integer (quantity needed, item ID, etc.).
    uint32_t color = 0xFFFFFFFF; ///< RGBA color (0xAABBGGRR ImGui format).
    char text[48]      = {}; ///< Primary text (label, key, section name, button text).
    char secondary[48] = {}; ///< Secondary text (value, description, icon).
}; // 112 bytes per element

// ── Panel transport bridge ─────────────────────────────────────────────
// The contract header declares these function pointers; the host installs them
// during initialization. Plugins call publish/poll and never see the transport.

namespace panel_bridge {
    using PublishFn = void(*)(const PanelElement* elements, int count, int slot);
    using PollButtonFn = int32_t(*)(int plugin_index);
    using PollSelectionFn = int32_t(*)(int plugin_index);

    /// Mutable slot holding the panel-publish transport function pointer.
    inline PublishFn& publish_fn() { static PublishFn f = nullptr; return f; }
    /// Mutable slot holding the button-poll transport function pointer.
    inline PollButtonFn& poll_button_fn() { static PollButtonFn f = nullptr; return f; }
    /// Mutable slot holding the selection-poll transport function pointer.
    inline PollSelectionFn& poll_selection_fn() { static PollSelectionFn f = nullptr; return f; }
    /// This plugin's index, set by the host during initialization.
    inline int32_t& plugin_index() { static int32_t idx = -1; return idx; }
    /// This plugin's panel slot, set by the host during initialization.
    inline int32_t& panel_slot() { static int32_t s = -1; return s; }
}

/// Builder for constructing panel element lists.
///
/// Call methods to append elements, then publish() to write to the host.
/// The host renders the panel when the plugin's sidebar icon is selected.
class PanelBuilder {
    PanelElement elements_[MAX_PANEL_ELEMENTS] = {};
    int count_ = 0;

    PanelElement& next() {
        if (count_ >= MAX_PANEL_ELEMENTS) return elements_[MAX_PANEL_ELEMENTS - 1];
        return elements_[count_++];
    }

    static void safe_copy(char* dst, const char* src, size_t max) {
        if (src) { strncpy(dst, src, max - 1); dst[max - 1] = '\0'; }
    }

public:
    /// Append a collapsible section header.
    PanelBuilder& section(const char* title, bool collapsed = false) {
        auto& e = next();
        e.type = PanelElementType::SECTION;
        e.flags = collapsed ? PanelFlags::COLLAPSED : 0;
        safe_copy(e.text, title, sizeof(e.text));
        return *this;
    }

    /// Append a text label.
    PanelBuilder& label(const char* text, uint32_t color = 0xFFFFFFFF) {
        auto& e = next();
        e.type = PanelElementType::LABEL;
        e.color = color;
        safe_copy(e.text, text, sizeof(e.text));
        return *this;
    }

    /// Append a "Key: Value" pair row.
    PanelBuilder& key_value(const char* key, const char* value, uint32_t value_color = 0xFFFFFFFF) {
        auto& e = next();
        e.type = PanelElementType::KEY_VALUE;
        e.color = value_color;
        safe_copy(e.text, key, sizeof(e.text));
        safe_copy(e.secondary, value, sizeof(e.secondary));
        return *this;
    }

    /// Append a horizontal rule.
    PanelBuilder& separator() { next().type = PanelElementType::SEPARATOR; return *this; }
    /// Append vertical spacing.
    PanelBuilder& spacer() { next().type = PanelElementType::SPACER; return *this; }

    /// Append a clickable button with a callback id.
    PanelBuilder& button(const char* text, uint8_t id, uint8_t flags = 0) {
        auto& e = next();
        e.type = PanelElementType::BUTTON;
        e.id = id; e.flags = flags;
        safe_copy(e.text, text, sizeof(e.text));
        return *this;
    }

    /// Append a progress bar (percent 0-100).
    PanelBuilder& progress(const char* label, int32_t percent, uint32_t color = 0xFF00FF00) {
        auto& e = next();
        e.type = PanelElementType::PROGRESS;
        e.int_value = percent; e.color = color;
        safe_copy(e.text, label, sizeof(e.text));
        return *this;
    }

    /// Append an item row showing name, have/need quantities, and status flags.
    PanelBuilder& item_row(const char* name, int32_t qty_have, int32_t qty_need,
                           bool has_item, bool equipped = false, int32_t item_id = -1) {
        auto& e = next();
        e.type = PanelElementType::ITEM_ROW;
        e.int_value = qty_have; e.int_value2 = qty_need;
        e.flags = (has_item ? PanelFlags::HAS_ITEM : 0) | (equipped ? PanelFlags::EQUIPPED : 0);
        e.color = static_cast<uint32_t>(item_id);
        safe_copy(e.text, name, sizeof(e.text));
        return *this;
    }

    /// Append a selectable-list header.
    PanelBuilder& list_header(const char* title) {
        auto& e = next();
        e.type = PanelElementType::LIST_HEADER;
        safe_copy(e.text, title, sizeof(e.text));
        return *this;
    }

    /// Append a selectable list entry with a selection id.
    PanelBuilder& list_item(const char* name, uint8_t id,
                            bool selected = false, bool completed = false) {
        auto& e = next();
        e.type = PanelElementType::LIST_ITEM;
        e.id = id;
        e.flags = (selected ? PanelFlags::SELECTED : 0) | (completed ? PanelFlags::COMPLETED : 0);
        safe_copy(e.text, name, sizeof(e.text));
        return *this;
    }

    /// Append a label prefixed with a FontAwesome icon.
    PanelBuilder& icon_label(const char* text, const char* icon_fa, uint32_t color = 0xFFFFFFFF) {
        auto& e = next();
        e.type = PanelElementType::ICON_LABEL;
        e.color = color;
        safe_copy(e.text, text, sizeof(e.text));
        safe_copy(e.secondary, icon_fa, sizeof(e.secondary));
        return *this;
    }

    /// Append a row with multiple pipe-separated values.
    PanelBuilder& multi_value(const char* label, const char* values, uint32_t color = 0xFFFFFFFF) {
        auto& e = next();
        e.type = PanelElementType::MULTI_VALUE;
        e.color = color;
        safe_copy(e.text, label, sizeof(e.text));
        safe_copy(e.secondary, values, sizeof(e.secondary));
        return *this;
    }

    /// Number of elements appended so far.
    int count() const { return count_; }
    /// Pointer to the internal element array.
    const PanelElement* elements() const { return elements_; }

    /// Write the panel data to the host for rendering.
    inline void publish() {
        auto fn = panel_bridge::publish_fn();
        if (fn) fn(elements_, count_, panel_bridge::panel_slot());
    }

    /// Reset the builder, removing all appended elements.
    void clear() { count_ = 0; memset(elements_, 0, sizeof(elements_)); }
};

/// Poll for a panel button click from the host.
/// Returns the button ID that was clicked, or -1 if no click pending.
inline int32_t poll_panel_button() {
    auto fn = panel_bridge::poll_button_fn();
    return fn ? fn(panel_bridge::plugin_index()) : -1;
}

/// Poll for a panel list selection from the host.
/// Returns the list item ID that was selected, or -1 if no selection pending.
inline int32_t poll_panel_selection() {
    auto fn = panel_bridge::poll_selection_fn();
    return fn ? fn(panel_bridge::plugin_index()) : -1;
}

} // namespace obsidian::api
