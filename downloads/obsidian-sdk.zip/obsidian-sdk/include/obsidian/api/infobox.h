#pragma once
/// @file infobox.h
/// @brief RuneLite-style persistent overlay info boxes (timers, counters, toggles).
/// @ingroup overlays
// ═══════════════════════════════════════════════════════════════════════════
// INFOBOX API — RuneLite-style overlay info boxes
// ═══════════════════════════════════════════════════════════════════════════
// Plugins register InfoBox instances to display persistent status indicators
// (timers, counters, toggles) rendered as small boxes at the top-left of the
// game screen. The InfoBoxManager renders all registered boxes each frame.
//
// Usage:
//   auto& mgr = api::get_infobox_manager();
//   auto* box = mgr.add("My Counter", "42", IM_COL32(0,255,0,255), "Tooltip text");
//   // Later:
//   box->text = "43";          // update text
//   mgr.remove(box);           // remove when done
// ═══════════════════════════════════════════════════════════════════════════

#include <cstdint>
#include <string>
#include <vector>
#include <algorithm>
#include <functional>

// Forward declare ImGui types
using ImU32 = unsigned int;

namespace obsidian::api {

/// A single info box displayed in the overlay panel.
/// Managed by InfoBoxManager — use `mgr.add()` and `mgr.remove()` rather than
/// constructing directly.
struct InfoBox {
    std::string title;          // label above the box (optional)
    std::string text;           // main display text (e.g. "42", "1:30")
    std::string tooltip;        // hover tooltip
    ImU32       color = 0;      // box background color (ABGR), 0 = default dark
    ImU32       text_color = 0xFFFFFFFF; // text color
    int32_t     priority = 100; // sort order (lower = left)
    bool        visible = true;
    void*       owner = nullptr; // plugin pointer for ownership tracking

    // Timer support — if duration_ms > 0, text auto-updates with remaining time
    int64_t     start_ms = 0;
    int64_t     duration_ms = 0;

    // Callback for click handling (optional)
    std::function<void()> on_click;
};

/// Manages the set of active InfoBox instances rendered each frame.
/// The global instance is accessed via get_infobox_manager().
class InfoBoxManager {
    std::vector<InfoBox*> boxes_;
    bool visible_ = true;

public:
    /// Create and register a new info box; returns the owned pointer.
    InfoBox* add(const std::string& title, const std::string& text,
                 ImU32 color = 0, const std::string& tooltip = "") {
        auto* box = new InfoBox();
        box->title = title;
        box->text = text;
        box->color = color;
        box->tooltip = tooltip;
        boxes_.push_back(box);
        return box;
    }

    /// Remove and delete a single info box.
    void remove(InfoBox* box) {
        boxes_.erase(std::remove(boxes_.begin(), boxes_.end(), box), boxes_.end());
        delete box;
    }

    /// Remove and delete all info boxes owned by the given plugin pointer.
    void remove_all(void* owner) {
        boxes_.erase(std::remove_if(boxes_.begin(), boxes_.end(),
            [owner](InfoBox* b) {
                if (b->owner == owner) { delete b; return true; }
                return false;
            }), boxes_.end());
    }

    /// Remove and delete every info box.
    void clear() {
        for (auto* b : boxes_) delete b;
        boxes_.clear();
    }

    /// Show or hide the entire info box panel.
    void set_visible(bool v) { visible_ = v; }
    /// Whether the info box panel is currently visible.
    bool visible() const { return visible_; }

    /// Get the list of active info boxes.
    const std::vector<InfoBox*>& boxes() const { return boxes_; }

    /// Destructor — deletes all managed info boxes.
    ~InfoBoxManager() { clear(); }
};

// ── Global infobox manager ──────────────────────────────────────────────
/// @private Internal pointer storage for the global InfoBoxManager.
inline InfoBoxManager*& infobox_manager_ptr() { static InfoBoxManager* p = nullptr; return p; }

/// Returns the global InfoBoxManager. Falls back to a static instance if not yet set by the core.
inline InfoBoxManager& get_infobox_manager() {
    auto* p = infobox_manager_ptr();
    if (!p) {
        static InfoBoxManager fallback;
        infobox_manager_ptr() = &fallback;
        return fallback;
    }
    return *p;
}

/// Sets the global InfoBoxManager. Called by the core during initialisation.
inline void set_infobox_manager(InfoBoxManager* mgr) { infobox_manager_ptr() = mgr; }

} // namespace obsidian::api
