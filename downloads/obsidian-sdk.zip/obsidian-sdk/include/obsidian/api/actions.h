#pragma once
/// @file actions.h
/// @brief Health and throughput of the action dispatch pipeline.
///
/// Every write call a plugin makes (`widgets::click`, `bank::withdraw`,
/// `movement::walk_to`, …) crosses a process boundary: the plugin publishes a
/// command to the game client, which executes it on the game thread and
/// turns it into a real click.
///
/// Those calls return a bool, but the bool only says the command was
/// **accepted for dispatch**. This domain is how you find out *why* one came
/// back false, and whether the pipeline as a whole is keeping up:
///
/// @code
///   if (!api::widgets::click(-1, packed, 1)) {
///       if (!api::actions::client_attached())      // no game attached
///       else if (api::actions::pending() >= api::actions::capacity())
///           log("dispatch queue saturated — %u dropped so far",
///               api::actions::dropped());
///   }
/// @endcode
///
/// A steadily climbing `dropped()` means actions are being issued faster than
/// the client can consume them (one drain per frame), so the bot is running
/// ahead of the game — worth throttling rather than retrying.

#include <cstdint>

namespace obsidian::api::actions {

/// Commands published into the dispatch ring but not yet consumed by the
/// client. 0 in steady state — the client drains the ring every frame.
/// Returns 0 when no client is attached.
int32_t pending();

/// Total commands dropped because the ring was full when they were pushed.
/// Monotonic for the lifetime of the client connection; never reset. Each one
/// is an action that a caller asked for and that never reached the game.
uint32_t dropped();

/// Ring capacity, i.e. the maximum value `pending()` can reach.
int32_t capacity();

/// True when a game client is attached and reachable. When this
/// is false every write call returns false, because there is nowhere to
/// publish to.
bool client_attached();

/// True when a client is attached and the ring has room. False means the next
/// write call is at risk of being dropped.
bool queue_healthy();

} // namespace obsidian::api::actions
