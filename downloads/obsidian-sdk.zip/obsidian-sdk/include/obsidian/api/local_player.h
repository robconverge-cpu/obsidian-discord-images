#pragma once
/// @file local_player.h
/// @brief Local player state queries — position, animation, movement, combat state.
///
/// Usage:
/// @code
///   namespace LP = obsidian::api::local_player;
///   auto loc = LP::world_location();
///   if (LP::is_idle()) { ... }
///   if (LP::health_percent() < 50) { ... }
/// @endcode

#include <obsidian/api/coords.h>
#include <obsidian/api/local_player_api.h>  // SpotAnimData, SkullIcon, OverheadIcon enums
#include <obsidian/api/scene_api.h>         // InteractingTarget
#include <cstdint>
#include <optional>
#include <string>
#include <vector>

namespace obsidian::api::local_player {

// ── Identity ───────────────────────────────────────────────────────────

bool exists();                ///< True when a local player is available (logged in).
                              ///< Other accessors return sentinel values while this is false.
int32_t index();              ///< Player list index.
std::string name();           ///< Display name (returns override if set, else real name).
int32_t combat_level();       ///< Combat level (-1 if unavailable).


// ── Position ───────────────────────────────────────────────────────────

WorldPoint world_location();  ///< Server tile (true tile — where the server says the player is).
WorldPoint path_destination();///< End of movement queue (where the player is walking to).
LocalPoint local_location();  ///< Fine local coordinates (interpolated visual position).
int32_t orientation();        ///< Facing direction (0-2047).

// ── Animation & Movement ───────────────────────────────────────────────

int32_t animation();          ///< Current animation ID (-1 = idle).
int32_t animation_frame();    ///< Current frame of action animation.
int32_t pose_animation();     ///< Pose animation (walk/run/idle).
bool is_moving();             ///< True if walking/running.
bool is_animating();          ///< True if action animation running.
bool is_idle();               ///< Not moving, not animating, not in combat.
int32_t path_length();        ///< Tiles remaining in walk path.
std::vector<ScenePoint> path(); ///< Walk path as scene tile coords.

// ── Combat & Status ────────────────────────────────────────────────────

bool is_in_combat();          ///< True if targeting an entity.
int32_t interacting_index();  ///< Validated entity slot being targeted (-1 = not interacting; stale values filtered).
int32_t interacting_type();   ///< 0 = not interacting, 1 = target is NPC, 2 = target is player.
bool is_interacting();        ///< True if currently interacting (interacting_type() != 0).

/// Resolve the actor the local player is targeting (RuneLite Actor.getInteracting()).
/// Returns nullopt when idle or when the target left the scene.
std::optional<InteractingTarget> get_interacting();
float health_percent();       ///< Health bar fill [0,100], -1 if no bar.
int32_t special_attack_percent(); ///< Spec energy 0-100.
SkullIcon skull_icon();       ///< Skull icon above head.
OverheadIcon overhead_icon(); ///< Prayer icon above head.
std::string overhead_text();  ///< Overhead chat text (empty = none).
std::vector<SpotAnimData> spot_anims(); ///< Active spotanims on player.

} // namespace obsidian::api::local_player
