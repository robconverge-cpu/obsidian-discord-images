#pragma once
/// @file convex_hull.h
/// @brief Convex hull computation (Jarvis march / gift-wrapping) for model outlines.
/// @ingroup overlays
// ═══════════════════════════════════════════════════════════════════════════
// CONVEX HULL — Jarvis march (gift-wrapping) algorithm
// ═══════════════════════════════════════════════════════════════════════════
// Port of RuneLite's Jarvis.java. Computes the 2D convex hull of a set of
// screen-space points projected from 3D model vertices.
// ═══════════════════════════════════════════════════════════════════════════

#include <vector>
#include <cstdint>
#include <algorithm>
#include <imgui.h>

namespace obsidian::api {

/// A 2D integer screen-space point used as input to the hull algorithm.
struct HullPoint { int32_t x, y; };

/// Computes the convex hull of a set of 2D projected points using Jarvis march.
/// Returns hull vertices in counter-clockwise order. Points with x == INT_MIN
/// (off-screen sentinels returned by model_to_canvas) are skipped.
/// Port of RuneLite Jarvis.java.
/// @param xs    Array of X coordinates.
/// @param ys    Array of Y coordinates.
/// @param count Number of input points.
inline std::vector<ImVec2> jarvis_convex_hull(const int32_t* xs, const int32_t* ys, int count) {
    std::vector<ImVec2> hull;
    if (count < 3) {
        for (int i = 0; i < count; i++) {
            if (xs[i] != INT_MIN)
                hull.push_back(ImVec2((float)xs[i], (float)ys[i]));
        }
        return hull;
    }

    // Find leftmost point
    int left = -1;
    int left_x = INT_MAX;
    for (int i = 0; i < count; i++) {
        if (xs[i] == INT_MIN) continue;
        if (xs[i] < left_x || (xs[i] == left_x && ys[i] < (left >= 0 ? ys[left] : INT_MAX))) {
            left_x = xs[i];
            left = i;
        }
    }
    if (left < 0) return hull;

    int current = left;
    do {
        hull.push_back(ImVec2((float)xs[current], (float)ys[current]));
        if (hull.size() > 256) break; // safety limit

        int next = -1;
        for (int i = 0; i < count; i++) {
            if (xs[i] == INT_MIN || i == current) continue;
            if (next < 0) { next = i; continue; }

            // Cross product: (next-current) × (i-current)
            int64_t cp = (int64_t)(xs[next] - xs[current]) * (ys[i] - ys[current])
                       - (int64_t)(ys[next] - ys[current]) * (xs[i] - xs[current]);

            if (cp < 0) {
                // i is to the left of current→next, so i is the new next
                next = i;
            } else if (cp == 0) {
                // Collinear — pick the further point
                int64_t d_next = (int64_t)(xs[next] - xs[current]) * (xs[next] - xs[current])
                               + (int64_t)(ys[next] - ys[current]) * (ys[next] - ys[current]);
                int64_t d_i    = (int64_t)(xs[i] - xs[current]) * (xs[i] - xs[current])
                               + (int64_t)(ys[i] - ys[current]) * (ys[i] - ys[current]);
                if (d_i > d_next) next = i;
            }
        }

        if (next < 0) break;
        current = next;
    } while (current != left);

    return hull;
}

/// Expands each hull vertex outward from the centroid by @p pixels.
/// Useful to ensure the rendered outline covers the full visual extent of a model.
/// @param hull   Hull as returned by jarvis_convex_hull().
/// @param pixels Expansion distance in screen pixels.
inline std::vector<ImVec2> expand_hull(const std::vector<ImVec2>& hull, float pixels) {
    if (hull.size() < 3) return hull;

    // Compute centroid
    float cx = 0, cy = 0;
    for (auto& p : hull) { cx += p.x; cy += p.y; }
    cx /= (float)hull.size();
    cy /= (float)hull.size();

    // Push each vertex outward from centroid
    std::vector<ImVec2> expanded(hull.size());
    for (size_t i = 0; i < hull.size(); i++) {
        float dx = hull[i].x - cx;
        float dy = hull[i].y - cy;
        float len = sqrtf(dx * dx + dy * dy);
        if (len > 0.001f) {
            float scale = (len + pixels) / len;
            expanded[i] = ImVec2(cx + dx * scale, cy + dy * scale);
        } else {
            expanded[i] = hull[i];
        }
    }
    return expanded;
}

} // namespace obsidian::api
