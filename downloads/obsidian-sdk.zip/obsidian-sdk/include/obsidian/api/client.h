#pragma once
/// @file client.h
/// @brief Client-level game state queries — ticks, canvas, varps, skills, UI state.
///
/// Usage:
/// @code
///   namespace client = obsidian::api::client;
///   int tick = client::game_tick();
///   int level = client::skill_level(Skill::ATTACK);
///   if (client::is_bank_open()) { ... }
/// @endcode

#include <obsidian/api/coords.h>
#include <obsidian/api/skill.h>
#include <obsidian/api/container_api.h>
#include <atomic>
#include <cstdint>
#include <filesystem>
#include <initializer_list>
#include <string>
#include <vector>

#include <obsidian/api/varp_ids.h>

namespace obsidian::api {

// ── Shared types (used by both client:: and internal implementation) ────

/// Varp index and bit range (lsb..msb) that back a varbit definition.
struct VarbitDef { int32_t varp_index; int32_t lsb; int32_t msb; };

/// Outcome of client::run_script_checked().
enum class ScriptStatus : int32_t {
    Ok            = 0,
    Timeout       = 1,  ///< Game thread didn't pick it up in time; the call was cancelled.
    NotConnected  = 2,  ///< No core attached (client not injected / shutting down).
    UnknownScript = 3,  ///< No such script id in the cache.
    TooManyArgs   = 4,  ///< More int args than the script declares (nothing was run).
    Fault         = 5,  ///< The game faulted while running the script.
    Cancelled     = 6,  ///< Internal: an abandoned request the core skipped.
    Unsupported   = 7,  ///< Host is too old for run_script_checked (plugin-side only).
};

/// Result of client::run_script_checked(). `value` is intStack[0] and only
/// meaningful when ok().
struct ScriptResult {
    ScriptStatus status = ScriptStatus::NotConnected;
    int32_t      value  = 0;
    bool ok() const { return status == ScriptStatus::Ok; }
    explicit operator bool() const { return ok(); }
};

namespace detail { inline std::atomic<bool>& game_memory_safe_ref() { static std::atomic<bool> v{false}; return v; } }
/// True if game memory is currently safe to read (set by the core each frame).
inline bool is_game_memory_safe() { return detail::game_memory_safe_ref().load(std::memory_order_acquire); }
/// Set whether game memory is currently safe to read.
inline void set_game_memory_safe(bool safe) { detail::game_memory_safe_ref().store(safe, std::memory_order_release); }

} // namespace obsidian::api

namespace obsidian::api::client {

// ── Game State ─────────────────────────────────────────────────────────

int32_t game_state();       ///< Current game state (see GameState enum).
int32_t game_cycle();       ///< Raw client cycle counter (~20ms). For internal/render use.
int32_t game_tick();        ///< Server game tick counter (~600ms). Use for plugin timers.
int32_t world();            ///< Current world number.
int32_t world_type();       ///< Native worldType bitmask (bit0 = MEMBERS). 0 when logged out.
bool is_members_account();  ///< True if the logged-in ACCOUNT is subscribed — regardless of the current world's type.
int32_t plane();            ///< Current plane (0 = ground).
int32_t base_x();           ///< Scene base X (world tiles).
int32_t base_y();           ///< Scene base Y (world tiles).

/// Dimensions of the currently loaded scene, in tiles. Read live from the
/// active WorldView (WorldView+0x58/+0x70). Standard scenes are 104×104
/// (= the SCENE_SIZE constant), but instances and any extended-scene mode
/// can differ — use this when you need the actual current size rather than
/// the compile-time default.
struct SceneSize { int32_t width = 0; int32_t height = 0; };
/// Current loaded scene dimensions in tiles (see SceneSize).
SceneSize scene_size();
int32_t scene_width();      ///< Convenience: scene_size().width.
int32_t scene_height();     ///< Convenience: scene_size().height.

/// @brief Convert world coords to scene coords using current base.
inline ScenePoint world_to_scene(int32_t world_x, int32_t world_y) {
    return {world_x - base_x(), world_y - base_y()};
}
/// @brief Convert world point to scene coords using current base.
inline ScenePoint world_to_scene(const WorldPoint& wp) {
    return {wp.x - base_x(), wp.y - base_y()};
}
/// @brief Convert scene tile coords to a world point using the current base.
/// The result is only meaningful for the scene that is loaded NOW: inside an
/// instance the base moves between visits, so store scene offsets (or template
/// points — see WorldPoint::from_local_instance), never the world tile.
inline WorldPoint scene_to_world(int32_t scene_x, int32_t scene_y, int32_t plane_) {
    return {base_x() + scene_x, base_y() + scene_y, plane_};
}
/// @brief scene_to_world on the current plane.
inline WorldPoint scene_to_world(int32_t scene_x, int32_t scene_y) {
    return scene_to_world(scene_x, scene_y, plane());
}
/// @brief scene_to_world for a ScenePoint on the current plane.
inline WorldPoint scene_to_world(const ScenePoint& sp) {
    return scene_to_world(sp.x, sp.y, plane());
}
/// @brief Convert fine local coords (128 units per tile) to the world tile
/// they fall in, using the current base. Same caveat as scene_to_world.
inline WorldPoint local_to_world(int32_t local_x, int32_t local_y, int32_t plane_) {
    return WorldPoint::from_local(local_x, local_y, base_x(), base_y(), plane_);
}
/// @brief local_to_world on the current plane.
inline WorldPoint local_to_world(int32_t local_x, int32_t local_y) {
    return local_to_world(local_x, local_y, plane());
}
/// @brief local_to_world for a LocalPoint on the current plane.
inline WorldPoint local_to_world(const LocalPoint& lp) {
    return local_to_world(lp.x, lp.y, plane());
}
/// @brief Convert a world tile to the fine local point at its centre.
inline LocalPoint world_to_local(int32_t world_x, int32_t world_y) {
    return LocalPoint::from_world(world_x, world_y, base_x(), base_y());
}
/// @brief Convert a world point to the fine local point at its centre.
inline LocalPoint world_to_local(const WorldPoint& wp) {
    return LocalPoint::from_world(wp, base_x(), base_y());
}
bool is_in_instance();      ///< True if the current scene is an instanced area.
std::vector<int32_t> map_regions(); ///< Map region IDs the player is in.
const int32_t* instance_template_chunks(); ///< Instance template chunk array (nullptr if not instanced).

// ── Canvas ─────────────────────────────────────────────────────────────

int32_t canvas_width();     ///< Game canvas width in pixels.
int32_t canvas_height();    ///< Game canvas height in pixels.

// ── Skills ─────────────────────────────────────────────────────────────

int32_t skill_level(Skill skill);   ///< Base level (1-99).
int32_t boosted_level(Skill skill); ///< Current level after boosts/drains.
int32_t skill_xp(Skill skill);     ///< Total XP in the skill.
int32_t run_energy();               ///< Run energy (0-10000; divide by 100 for %).

/// Sum of base levels across every skill.
/// Computed from skill_level() rather than the game's own total-level field, which is
/// only reliable for the local player. Inline so it needs no per-layer body.
inline int32_t total_level() {
    int32_t total = 0;
    for (int32_t i = 0; i < SKILL_COUNT; i++)
        total += skill_level(static_cast<Skill>(i));
    return total;
}

/// Sum of XP across every skill.
inline int64_t total_xp() {
    int64_t total = 0;
    for (int32_t i = 0; i < SKILL_COUNT; i++)
        total += skill_xp(static_cast<Skill>(i));
    return total;
}

// ── Varps and Varbits ──────────────────────────────────────────────────

int32_t varp(int32_t varp_id);         ///< Raw varp (variable player) value.
int32_t varbit(int32_t varbit_id);     ///< Varbit value extracted from parent varp.
int32_t server_varp(int32_t varp_id);  ///< Server-side varp (unmodified by predictions).
/// 64-bit varp (v241+). GE offer-setup price is varp 5753 (replaced varbit 4398).
/// 0 for ordinary int varps — use varp() for those.
int64_t varp_long(int32_t varp_id);
int64_t server_varp_long(int32_t varp_id);

/// Ironman mode of the logged-in account (0=normal, 1=ironman, 2=ULTIMATE, 3=HARDCORE,
/// 4=group, 5=hardcore group, 6=unranked group). Compare against api::AccountType::*.
/// 2 and 3 were documented the other way round until 2026-10-06, which made a real
/// Hardcore look unprotected and a real Ultimate look like it had a bank.
/// Inline over the already-forwarded varbit() so it needs no per-layer body — it works
/// identically in host, core and sealed plugins. Varbit 1777 = VarPlayer::ACCOUNT_TYPE.
inline int32_t account_type() { return varbit(1777); }

/// @name Account-type predicates
/// Restricted accounts change which content is even reachable — an Ironman cannot use the
/// Grand Exchange or trade, so any plan built for a standard account is invalid for one.
/// Check these BEFORE planning, not while executing.
/// @{

/// True for every Ironman variant (regular, hardcore, ultimate, and all three group modes).
inline bool is_ironman() { return account_type() != 0; }

/// True if the account cannot use the Grand Exchange or trade other players.
/// Group Ironmen may trade within their group only — treat that as a separate source.
inline bool is_trade_restricted() { return account_type() != 0; }

/// True if death permanently changes account status (Hardcore / Hardcore Group).
/// Risky content must be gated behind an explicit opt-in for these.
inline bool is_hardcore() {
    const int32_t t = account_type();
    return t == AccountType::HARDCORE || t == AccountType::HARDCORE_GROUP_IRONMAN;
}

/// True if the account has no bank (Ultimate Ironman).
/// This invalidates every bank-loop method, not merely some items — it is a different
/// execution model, not a filter.
inline bool has_no_bank() { return account_type() == AccountType::ULTIMATE; }

/// True for the three group-ironman variants (trading is possible within the group).
inline bool is_group_ironman() {
    const int32_t t = account_type();
    return t == 4 || t == 5 || t == 6;
}
/// @}
VarbitDef varbit_def(int32_t varbit_id); ///< Varp index and bit range for a varbit.
int32_t varbit_count();                  ///< Total known varbit definitions.
int32_t varc_int(int32_t varc_id);       ///< VarClient integer value, or -1 if unset.
int64_t varc_long(int32_t varc_id);      ///< VarClient 64-bit value (v241, e.g. SLOTINFO_*_LONG); int varcs widen. -1 if unset.
std::string varc_str(int32_t varc_id);   ///< VarClient string value, or "" if unset.
void set_varc_int(int32_t varc_id, int32_t value);    ///< Write a VarClient integer.
void set_varc_str(int32_t varc_id, const std::string& value); ///< Write a VarClient string.
void set_varbit(int32_t varbit_id, int32_t value);    ///< Write a varbit (read-modify-write on parent varp).

// ── CS2 Script Execution ──────────────────────────────────────────────

// Threading: callable from any plugin/host thread, including GameTick
// handlers — scripts never run on the caller's thread. The request is queued
// to the game thread and runs on its next loop (normally within one frame),
// and the caller blocks until then. Calls are serialised process-wide.
// Only int arguments are supported; they are passed in order, exactly
// (including -1). Values -2147483647..-2147483638 are CS2 event "magic"
// placeholders (MOUSE_X, WIDGET_ID, ...) and are substituted by the game.

/// Execute a CS2 client script and report whether it actually ran.
/// @param script_id   The CS2 script ID.
/// @param args        Up to 8 int arguments, in order. Fewer than the script
///                    declares → the rest are 0; more → TooManyArgs, not run.
/// @param timeout_ms  How long to wait for the game thread. On Timeout the
///                    request is cancelled if it hasn't started yet.
/// @code
///   auto r = client::run_script_checked(6009, {0x950000, 28, 1, -1});
///   if (!r) OBS_LOG_WARN("MyPlugin", "script failed: %d", int(r.status));
/// @endcode
ScriptResult run_script_checked(int32_t script_id, const std::vector<int32_t>& args,
                                int32_t timeout_ms = 1000);

/// Execute a CS2 client script and return the int stack result (intStack[0]).
/// Same as run_script_checked() but returns 0 on ANY failure — use the
/// checked form when you need to tell a failure from a real 0.
int32_t run_script(int32_t script_id, std::initializer_list<int32_t> args = {});

/// Execute the same one-int-arg CS2 script with multiple first-arguments in a
/// single IPC round-trip (up to 256).
/// @param script_id  The CS2 script ID.
/// @param args       Vector of first-argument values (one per call).
/// @param results    Output vector, resized and filled with results.
/// @return true if every call ran; false on timeout or any per-call failure.
bool run_script_batch(int32_t script_id, const std::vector<int32_t>& args, std::vector<int32_t>& results);

// ── Input / Mouse ──────────────────────────────────────────────────────

WorldPoint mouse_tile();       ///< World tile under the cursor (-1,-1,-1 if unavailable).
CanvasPoint mouse_canvas();    ///< Mouse position in canvas pixels.

// ── Interface / UI State ───────────────────────────────────────────────

int32_t top_level_interface();  ///< Currently open top-level interface ID (-1 if none).
bool is_bank_open();            ///< True if the bank interface is open.
bool is_shop_open();            ///< True if a shop interface is open.
bool is_trade_open();           ///< True if the trade screen is open.

// ── Action Budget ──────────────────────────────────────────────────────

int32_t action_budget();       ///< Remaining action slots this server tick (0-10).
bool has_pending_actions();    ///< True if actions are queued for execution.

// ── Containers (raw) ──────────────────────────────────────────────────

using ContainerItem = obsidian::api::ContainerItem;
/// All items in a container by ID (see ContainerId).
std::vector<ContainerItem> container_items(int32_t container_id);
/// Total count of an item across every known container.
int32_t count_item_all_containers(int32_t item_id);

// ── Idle / Session ─────────────────────────────────────────────────────

/// Reset the idle timer (suppresses idle logout).
void reset_idle();
/// Mouse idle ticks (= (now - last_mouse_move_time) / 20). -1 if unavailable.
int32_t mouse_idle_ticks();
/// Keyboard idle ticks (= (now - last_keyboard_time) / 20). -1 if unavailable.
int32_t keyboard_idle_ticks();
/// Player's carried weight in grams (Client field, not sum of items).
int32_t weight();
/// Login screen sub-state index (2=credentials, 6=password, 10=JL, etc.). -1 if unavailable.
int32_t login_index();
/// Log out of the game.
void logout();

// ── Chat ───────────────────────────────────────────────────────────────

/// Add a message to the chat box.
void add_chat_message(int32_t type, const std::string& sender, const std::string& message);

// ── Keyboard ───────────────────────────────────────────────────────────

/// Send a synthetic key event (vk_code; mode selects down/up/press).
void send_key(int32_t vk_code, int32_t mode = 0);
/// Send a synthetic character input.
void send_char(uint32_t ch);
/// Raw local mouse action at a canvas pixel coordinate. For title-screen
/// buttons that aren't CS2 widgets — notably the Jagex-Login "Play Now" button,
/// which needs a click rather than Enter. Not focus-gated. mode: 0 = full
/// click (move+down+up), 1 = press (move+down), 2 = release (up) — split across
/// two frames so a polled title screen sees the button held.
void click_canvas(int32_t x, int32_t y, int32_t mode = 0);
/// Start a regular (user/pass) login: calls the client's native connect
/// function on the game thread (credentials must already be written). Used by
/// the Break Handler relogin because Enter can't reach the native title
/// screen's login handler.
void start_login();

/// Move the mouse cursor without clicking — idle drift, no DoAction.
void mouse_idle_move(int32_t target_x, int32_t target_y);

/// Move the mouse to the centre of a widget (core resolves screen position).
void mouse_move_to_widget(int32_t packed_widget_id);

/// Send a mouse scroll event (signed delta in notches, +up/-down).
void send_scroll(int32_t delta);

// ── Window Management ─────────────────────────────────────────────────
void minimize_window();                  ///< Minimize the game window.
bool is_focused();                       ///< True if the game window currently has keyboard focus.

// ── Synthetic Events ───────────────────────────────────────────────────

/// Fire a synthetic XP-drop event for a skill.
void fire_fake_xp_drop(int32_t skill, int32_t xp);

// ── Account ────────────────────────────────────────────────────────────

/// Unique account hash of the logged-in account (0 if unknown).
uint64_t account_hash();
/// Display name of the logged-in account.
std::string account_name();
/// True if the account hash/name has been resolved.
bool is_account_known();
/// Per-account data directory path.
std::filesystem::path account_dir();


} // namespace obsidian::api::client
