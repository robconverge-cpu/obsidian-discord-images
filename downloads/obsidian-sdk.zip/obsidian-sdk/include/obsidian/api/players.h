#pragma once
/// @file players.h
/// @brief Other player queries and interactions.

#include <obsidian/api/scene_api.h>  // ScenePlayer
#include <cstdint>
#include <optional>
#include <string>
#include <vector>

namespace obsidian::api::players {

/// Returns every other player currently visible in the scene.
std::vector<ScenePlayer> find_all();
/// Returns all players whose display name matches @p name.
std::vector<ScenePlayer> find_by_name(const std::string& name);
/// Returns the player at the given entity-table slot index, or nullopt.
std::optional<ScenePlayer> find_by_index(int32_t index);

/// Resolve the actor this player is targeting (RuneLite Actor.getInteracting()).
/// Returns nullopt if the player is idle, gone, or their target left the scene.
std::optional<InteractingTarget> get_interacting(int32_t player_index);
/// Returns the nearest other player, or nullopt if none.
std::optional<ScenePlayer> find_nearest();
/// Returns the nearest player matching @p name, or nullopt if none.
std::optional<ScenePlayer> find_nearest_by_name(const std::string& name);
/// Interact with the player using a right-click option index.
void interact(int32_t player_index, int32_t option);

/// The client's player right-click options (RuneLite getPlayerOptions): 8
/// entries, entry i is option i+1 for interact(); "" = unset. Server-set, so
/// they change with context (e.g. "Attack" only in PvP areas).
std::vector<std::string> options();

/// Option number (1..8) whose text equals @p text (case-insensitive, e.g.
/// "Attack", "Follow", "Trade with"), or -1 if no slot currently has it.
int32_t option_index(const std::string& text);

/// interact() by option text (e.g. "Attack", "Follow"), resolved through
/// option_index(). False if no current option has that text.
bool interact(int32_t player_index, const std::string& option_text);

/// interact_nearest() by option text. False if no option has that text or no
/// matching player is nearby.
bool interact_nearest(const std::string& player_name, const std::string& option_text);

/// Interact with the nearest player matching @p player_name using the given
/// right-click option index (same indices as interact()). Use option_index()
/// to resolve an option by its text.
/// @return true if a matching player was found and the interaction dispatched.
bool interact_nearest(const std::string& player_name, int32_t option);

} // namespace obsidian::api::players
