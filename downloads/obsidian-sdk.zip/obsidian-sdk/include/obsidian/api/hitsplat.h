#pragma once
/// @file hitsplat.h
/// @brief Damage/heal hitsplat types and data structures.
/// @ingroup entities
// ═══════════════════════════════════════════════════════════════════════════
// HITSPLAT — Damage/heal splat data on actors
// ═══════════════════════════════════════════════════════════════════════════
// Mirrors RuneLite Hitsplat.java + HitsplatID constants.
// Read from Actor struct offsets +0x250-0x264.
// ═══════════════════════════════════════════════════════════════════════════

#include <cstdint>

namespace obsidian::api {

/// Common hitsplat type IDs (from RuneLite HitsplatID). Used in Hitsplat::type.
namespace HitsplatType {
    constexpr int BLOCK_ME          = 12;
    constexpr int BLOCK_OTHER       = 13;
    constexpr int DAMAGE_ME         = 16;
    constexpr int DAMAGE_OTHER      = 17;
    constexpr int POISON            = 65;
    constexpr int DISEASE           = 2;
    constexpr int VENOM             = 66;
    constexpr int HEAL              = 6;
    constexpr int DAMAGE_ME_CYAN    = 18;
    constexpr int DAMAGE_OTHER_CYAN = 19;
    constexpr int DAMAGE_ME_ORANGE  = 20;
    constexpr int DAMAGE_OTHER_ORANGE = 21;
    constexpr int DAMAGE_ME_YELLOW  = 22;
    constexpr int DAMAGE_OTHER_YELLOW = 23;
    constexpr int DAMAGE_ME_WHITE   = 24;
    constexpr int DAMAGE_OTHER_WHITE = 25;
}

/// A single damage or heal splat displayed on an actor.
/// Read from Actor struct offsets +0x250–+0x264 (up to 4 splats per actor).
struct Hitsplat {
    int32_t type   = -1;    // HitsplatType constant
    int32_t amount = 0;     // damage/heal value
    int32_t cycle  = -1;    // game cycle when splat appeared
    bool    active = false;  // currently visible on screen

    /// True if this splat represents damage/block dealt to the local player.
    bool is_mine() const {
        return type == HitsplatType::DAMAGE_ME ||
               type == HitsplatType::BLOCK_ME ||
               type == HitsplatType::DAMAGE_ME_CYAN ||
               type == HitsplatType::DAMAGE_ME_ORANGE ||
               type == HitsplatType::DAMAGE_ME_YELLOW ||
               type == HitsplatType::DAMAGE_ME_WHITE;
    }

    /// True if this splat represents damage/block dealt to another actor.
    bool is_others() const {
        return type == HitsplatType::DAMAGE_OTHER ||
               type == HitsplatType::BLOCK_OTHER ||
               type == HitsplatType::DAMAGE_OTHER_CYAN ||
               type == HitsplatType::DAMAGE_OTHER_ORANGE ||
               type == HitsplatType::DAMAGE_OTHER_YELLOW ||
               type == HitsplatType::DAMAGE_OTHER_WHITE;
    }
};

} // namespace obsidian::api
