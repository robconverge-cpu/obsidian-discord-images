#pragma once
/// @file tabs.h
/// @brief Side-panel tabs: open a tab by mouse or by the account's F-key, read which tab
///        is open, and hover a skill on the Skills tab.
///
/// open / hover_skill are SINGLE actions that return immediately. For a full "check my
/// XP" glance (open Skills → wait → hover → hold → back) use glance_start(): the host
/// sequences it one step per game tick, each step waiting for the game to confirm the
/// last. Or build your own from the single actions.
///
/// Tab numbering is the side-panel stone index, which is also the value of varc
/// TOPLEVEL_PANEL (171) for the open tab: the mouse path clicks STONE<n> of whichever
/// top-level layout is active (fixed, resizable classic, resizable modern).
/// Live-verified (v241.1): varc 171 == stone index for COMBAT..MAGIC (0-6); the bottom row
/// reports 8..13 too (FRIENDS = 9 confirmed live).
/// Keybind varbits read 0 = none, n = F<n> (verified F1..F12 on a live account).

#include <obsidian/api/skill.h>
#include <cstdint>

namespace obsidian::api::tabs {

enum class Tab : int32_t {
    COMBAT = 0, SKILLS = 1, QUESTS = 2, INVENTORY = 3, EQUIPMENT = 4, PRAYER = 5,
    MAGIC = 6, CLAN = 7, ACCOUNT = 8, FRIENDS = 9, LOGOUT = 10, SETTINGS = 11,
    EMOTES = 12, MUSIC = 13,
};

/// How to open a tab.
///   MOUSE — click the tab stone (through the mouse synth).
///   KEY   — press the account's bound F-key; fails if the tab has no key bound.
///   AUTO  — the key when one is bound, otherwise the mouse.
enum class Method : int32_t { MOUSE = 0, KEY = 1, AUTO = 2 };

/// The open tab, or -1 when unknown (no side panel / not logged in).
int32_t current();

/// True when `tab` is the open tab.
bool is_open(Tab tab);

/// Windows virtual-key code bound to `tab` in the account's keybinding settings
/// (VK_F1..VK_F12, or VK_ESCAPE), or 0 when the tab has no key.
int32_t key_for(Tab tab);

/// Open `tab`. One action — the tab is open once `is_open(tab)` reports it, usually the
/// next tick. Already open → true without acting.
/// @return false when the action could not be dispatched (KEY with no bound key, no
///         recognised top-level layout).
bool open(Tab tab, Method method = Method::MOUSE);

/// Move the cursor over `skill` on the Skills tab (no click) — the game shows that
/// skill's XP tooltip. A varied point inside the skill's box, through the mouse synth.
/// @return false unless the Skills tab is open (an unopened tab's widget positions are
///         stale, so this never guesses).
bool hover_skill(Skill skill);

// ── Glance: a host-driven "check my progress" sequence ──────────────────────
//
//   open Skills (or Equipment) → confirmed open → settle → hover the skill (sometimes a
//   neighbouring one first) → hold → switch back to the tab that was open before.
//
// The HOST advances it, one step per game tick, each step waiting for the game to
// confirm the previous one — the tab click and the hover never share a tick. Plugins
// only decide WHEN to start (e.g. mid-obstacle, while mining, while stunned) and may
// wrap it up early with glance_finish(). One glance per client at a time.

struct GlanceConfig {
    Skill   skill = Skill::ATTACK;           ///< skill to hover
    Method  method = Method::MOUSE;          ///< how tabs are switched
    int32_t settle_min = 1, settle_max = 2;  ///< ticks after the tab is confirmed open
    int32_t hold_min = 2, hold_max = 6;      ///< ticks spent hovering
    int32_t return_min = 0, return_max = 1;  ///< extra ticks before switching back
    float   neighbour_chance = 0.25f;        ///< hover a nearby skill first
    float   equipment_chance = 0.0f;         ///< look at Equipment instead (no hover)
    int32_t timeout_ticks = 4;               ///< a tab that never opens → give up
};

/// Start a glance. The first action (opening the tab) happens on the next game tick.
/// @return false while a glance is already running on this client.
bool glance_start(const GlanceConfig& cfg);

/// True while a glance is in progress (including switching back).
bool glance_active();

/// Wrap up early: switch back to the previous tab on the next tick. Before the tab
/// click has been sent this just cancels.
void glance_finish();

/// Drop the glance without touching the UI (e.g. a break is taking over).
void glance_cancel();

} // namespace obsidian::api::tabs
