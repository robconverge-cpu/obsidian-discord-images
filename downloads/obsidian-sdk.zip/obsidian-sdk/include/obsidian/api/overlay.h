#pragma once
/// @file overlay.h
/// @brief Plugin overlay registration and rendering system.
/// @ingroup overlays
///
/// Mirrors RuneLite's Overlay / OverlayManager / OverlayUtil.
/// Plugins create Overlay subclasses, register them with the OverlayManager,
/// and the core DLL calls render() each frame in the correct order.
///
/// The OverlayContext provides shared rendering utilities (tile highlights,
/// text labels, line drawing) that use the Perspective API for projection.
/// All overlays — both built-in devtools and external plugins — use the
/// same OverlayContext and rendering path.

#include <obsidian/api/coords.h>
#include <obsidian/api/perspective.h>
#include <obsidian/api/overlay_recorder.h>
#include <obsidian/api/game_api.h>


#include <cstdint>
#include <cmath>
#include <string>
#include <vector>
#include <algorithm>
#include <functional>

// Forward declare ImGui types
struct ImDrawList;
struct ImVec2;
struct ImFont;
using ImU32 = unsigned int;

namespace obsidian::api {

// SceneNpc / ScenePlayer definitions live in game_api.h (included above).
// They are complete here so the `SceneNpc&` inline render_* method bodies
// below can touch `.entity_size`, `.local_location`, etc. inside the
// OBSIDIAN_CORE_INTERNAL branch.
class OverlayRecorder;

/// @brief Rendering layer that determines draw order relative to the game scene and UI.
enum class OverlayLayer {
    ABOVE_SCENE,       ///< After 3D mesh, before HP bars. NativeRenderer only.
    ABOVE_OVERLAYS,    ///< After HP bars/nameplates, before widgets. NativeRenderer only.
    UNDER_WIDGETS,     ///< Alias for ABOVE_OVERLAYS (above game, behind UI). NativeRenderer only.
    ABOVE_WIDGETS,     ///< After all game widgets. NativeRenderer only.
    ALWAYS_ON_TOP,     ///< After everything (ImGui overlay). Default. Full OverlayContext.
};

/// @brief Line-rendering style for tile / quad / actor highlight helpers.
///
/// Affects only the **outline** of these primitives — the fill is
/// always a continuous polygon. Selecting `Solid` matches the
/// pre-existing behaviour exactly so passing this as a default is
/// fully backward compatible.
enum class TileLineStyle {
    Solid,    ///< Continuous polyline around the perimeter.
    Dashed,   ///< Alternating short dashes along the perimeter.
    Corners,  ///< Only short stubs at each corner — middles of edges are invisible.
};

/// @brief Positioning strategy for overlay panels.
enum class OverlayPosition {
    DYNAMIC,           ///< Plugin controls position
    TOP_LEFT,          ///< Anchored to the top-left corner
    TOP_CENTER,        ///< Anchored to the top-center
    TOP_RIGHT,         ///< Anchored to the top-right corner
    BOTTOM_LEFT,       ///< Anchored to the bottom-left corner
    BOTTOM_RIGHT,      ///< Anchored to the bottom-right corner
    ABOVE_CHATBOX_RIGHT, ///< Above the chatbox, right-aligned
    CANVAS_TOP_RIGHT,  ///< Like RuneLite infoboxes
    TOOLTIP,           ///< Rendered as a tooltip near the cursor
};

/// @brief Native function type for querying tile height from the game engine.
using fn_GetTileHeight = int32_t(__fastcall*)(void* worldView, int localX, int localY, int plane);

/// @brief Per-frame rendering context shared across all overlays.
///
/// Passed to Overlay::render(). Provides all rendering utilities that
/// plugins and built-in overlays need. Created once per frame in
/// render_frame(), shared across all overlays.
///
/// Equivalent to RuneLite's OverlayUtil methods combined with the
/// Graphics2D context and Perspective class.
class NativeRenderer; // forward decl

class OverlayContext {
    ImDrawList* draw_list_ = nullptr;  ///< ImGui draw list (ALWAYS_ON_TOP layer only)
    NativeRenderer* native_ = nullptr; ///< Game's 2D renderer (native layers only)
    perspective::CameraState camera_;  ///< Snapshot of camera state for this frame
    int32_t base_x_ = 0, base_y_ = 0; ///< Scene base coordinates (world origin)
    int32_t plane_ = 0;               ///< Current game plane (0-3)
    int32_t player_local_x_ = 0, player_local_y_ = 0; ///< Player fine-grained local position

    fn_GetTileHeight get_tile_height_fn_ = nullptr; ///< Native tile height function (optional — height=0 if not set)
    void* world_view_ptr_ = nullptr;   ///< WorldView pointer for native calls
    int32_t world_view_id_ = 0;        ///< WorldView ID for this render pass (0 = overworld)

    uintptr_t image_base_ = 0;        ///< Image base for game function resolution

    ImFont* overlay_font_ = nullptr;   ///< Overlay font (cached per frame)

    /// Host-side command recorder. When non-null, every `render_*` method
    /// forwards to this recorder instead of drawing directly. Core creates
    /// a recorder-less context; host's per-tab overlay tick injects a
    /// recorder so `Overlay::render` calls end up in the client's
    /// draw command stream.
    OverlayRecorder* recorder_ = nullptr;

    /// Panel layout manager (opaque on host side). Set on core side only.
    /// Cast to OverlayPanelLayout* when overlay_layout.h is included.
    void* layout_ = nullptr;

    /// Alpha multiplier for screen-space primitives (see set_global_alpha).
    float global_alpha_ = 1.0f;

    /// Scale multiplier for screen-space text (see set_ui_scale).
    float ui_scale_ = 1.0f;

public:
    /// @brief Default constructor.
    OverlayContext() = default;

    /// @brief Full constructor used by render_frame in overlay.cpp (core side).
    OverlayContext(ImDrawList* dl, const perspective::CameraState& cam,
                   int32_t bx, int32_t by, int32_t plane,
                   int32_t plx = 0, int32_t ply = 0,
                   fn_GetTileHeight height_fn = nullptr, void* wv_ptr = nullptr,
                   uintptr_t image_base = 0)
        : draw_list_(dl), camera_(cam), base_x_(bx), base_y_(by),
          plane_(plane), player_local_x_(plx), player_local_y_(ply),
          get_tile_height_fn_(height_fn), world_view_ptr_(wv_ptr),
          image_base_(image_base) {}

    /// @brief Host-side constructor — every render_* call is routed to
    /// the given recorder instead of drawing. No draw list, no camera.
    ///
    /// Host plugins still depend on `base_x()`, `base_y()`, `plane()`,
    /// and `player_local_x()` / `player_local_y()` to convert world
    /// positions into scene coordinates before emitting draw commands,
    /// so the host tick must seed them from the tab's state each frame.
    /// Without these, world-to-scene math produces out-of-range values
    /// and plugins silently drop every draw whose target tile would
    /// be outside `[0, SCENE_SIZE)`.
    explicit OverlayContext(OverlayRecorder* rec,
                            int32_t bx = 0, int32_t by = 0, int32_t plane = 0,
                            int32_t plx = 0, int32_t ply = 0)
        : base_x_(bx), base_y_(by),
          plane_(plane),
          player_local_x_(plx), player_local_y_(ply),
          recorder_(rec) {}

    /// @brief Install / clear a recorder on an already-constructed context.
    /// Rarely needed — the two constructors above cover normal usage.
    void set_recorder(OverlayRecorder* rec) { recorder_ = rec; }
    /// @brief Get the currently installed recorder (null on the core side).
    OverlayRecorder* recorder() const { return recorder_; }

    /// @brief Set the panel layout manager (core side only).
    /// Pass an OverlayPanelLayout* — stored as void* to avoid circular includes.
    void set_layout(void* layout) { layout_ = layout; }
    /// @brief Get the panel layout manager (null on host side).
    void* layout() const { return layout_; }

    /// @brief Global alpha multiplier applied by every screen-space
    /// primitive (panel fade-in, user opacity). World-space primitives
    /// ignore it. Callers must reset to 1.0 when done.
    void set_global_alpha(float a) { global_alpha_ = a < 0.0f ? 0.0f : (a > 1.0f ? 1.0f : a); }
    float global_alpha() const { return global_alpha_; }

    /// @brief UI scale multiplier for the screen-space text primitives
    /// (user panel-scale setting; glyphs draw at font_size * scale). Set
    /// alongside OverlayPanel::set_scale; callers reset to 1.0 when done.
    void set_ui_scale(float s) { ui_scale_ = s < 0.5f ? 0.5f : (s > 2.0f ? 2.0f : s); }
    float ui_scale() const { return ui_scale_; }
    /// @brief Scale a colour's alpha channel by the global alpha.
    ImU32 mod_alpha(ImU32 c) const {
        if (global_alpha_ >= 0.999f) return c;
        const unsigned a = static_cast<unsigned>(((c >> 24) & 0xFFu) * global_alpha_);
        return (c & 0x00FFFFFFu) | (a << 24);
    }

    /// @name Accessors
    /// @{

    /// @brief Get the ImGui draw list for the current frame.
    ImDrawList* draw_list() const { return draw_list_; }
    /// @brief Get the NativeRenderer (only valid for native-layer overlays).
    NativeRenderer* native_renderer() const { return native_; }
    /// @brief Set the NativeRenderer for native-layer contexts.
    void set_native_renderer(NativeRenderer* nr) { native_ = nr; }
    /// @brief Get the camera state snapshot for this frame.
    const perspective::CameraState& camera() const { return camera_; }
    /// @brief Get the scene base X coordinate.
    int32_t base_x() const { return base_x_; }
    /// @brief Get the scene base Y coordinate.
    int32_t base_y() const { return base_y_; }
    /// @brief Get the current game plane.
    int32_t plane() const { return plane_; }
    /// @brief Get the player's scene X coordinate (tile granularity).
    int32_t player_scene_x() const { return player_local_x_ >> LOCAL_COORD_BITS; }
    /// @brief Get the player's scene Y coordinate (tile granularity).
    int32_t player_scene_y() const { return player_local_y_ >> LOCAL_COORD_BITS; }
    /// @brief Get the player's local X coordinate (fine granularity).
    int32_t player_local_x() const { return player_local_x_; }
    /// @brief Get the player's local Y coordinate (fine granularity).
    int32_t player_local_y() const { return player_local_y_; }
    /// @brief Get the game image base address.
    uintptr_t image_base() const { return image_base_; }
    /// @brief Get the WorldView ID for this render pass (0 = overworld).
    int32_t world_view_id() const { return world_view_id_; }
    /// @brief Set the WorldView ID for this render pass.
    void set_world_view_id(int32_t id) { world_view_id_ = id; }
    /// @brief Get the WorldView raw pointer for this render pass.
    uintptr_t world_view_raw() const { return reinterpret_cast<uintptr_t>(world_view_ptr_); }

    /// @}

    /// @name Tile Height
    /// @{

    /// @brief Return tile height at the given local (fine) coordinates.
    ///
    /// Uses native GetTileHeight if available, otherwise returns 0.
    int32_t get_tile_height(int32_t local_x, int32_t local_y) const {
        if (!get_tile_height_fn_ || !world_view_ptr_) return 0;
        int32_t h = 0;
        __try {
            h = get_tile_height_fn_(world_view_ptr_, local_x, local_y, plane_);
        } __except(1) {
            h = 0;
        }
        return h;
    }

    /// @}

    /// @name Projection
    /// @{

    /// @brief Project local (fine) coordinates to screen space.
    ///
    /// Prefers the software-renderer-matched path (local_to_canvas_sw)
    /// which uses the Scene-cached camera snapshot — same values the
    /// game's mesh pass used. Falls back to the legacy path when the
    /// cached sin/cos aren't available yet.
    std::optional<ScreenPoint> project(int32_t local_x, int32_t local_y, int32_t height = 0) const {
        if (camera_.have_mesh_matrix)
            return perspective::local_to_canvas_mesh(camera_, local_x, local_y, height);
        return perspective::local_to_canvas_sw(camera_, local_x, local_y, height);
    }

    /// @brief Project a LocalPoint to screen space.
    std::optional<ScreenPoint> project(const LocalPoint& lp, int32_t height = 0) const {
        if (camera_.have_mesh_matrix)
            return perspective::local_to_canvas_mesh(camera_, lp.x, lp.y, height);
        return perspective::local_to_canvas_sw(camera_, lp.x, lp.y, height);
    }

    /// @brief Project a WorldPoint to screen space.
    std::optional<ScreenPoint> project_world(const WorldPoint& wp, int32_t height = 0) const {
        auto lp = LocalPoint::from_world(wp, base_x_, base_y_);
        if (camera_.have_mesh_matrix)
            return perspective::local_to_canvas_mesh(camera_, lp.x, lp.y, height);
        return perspective::local_to_canvas_sw(camera_, lp.x, lp.y, height);
    }

    /// @}

    /// @name Quad Validation
    /// @{

    /// @brief Check if a projected quad is valid for rendering.
    ///
    /// Verifies the quad is on-screen, not degenerate, free of horizon
    /// spike artifacts, and convex.
    static bool is_quad_valid(const ScreenPoint& a, const ScreenPoint& b,
                              const ScreenPoint& c, const ScreenPoint& d) {
        if (!a.valid() || !b.valid() || !c.valid() || !d.valid())
            return false;

        // Edge length check — prevents horizon spike artifacts
        auto edge_sq = [](const ScreenPoint& p1, const ScreenPoint& p2) {
            float dx = static_cast<float>(p1.x - p2.x);
            float dy = static_cast<float>(p1.y - p2.y);
            return dx * dx + dy * dy;
        };
        constexpr float max_edge_sq = 200.f * 200.f;
        if (edge_sq(a, b) > max_edge_sq || edge_sq(b, c) > max_edge_sq ||
            edge_sq(c, d) > max_edge_sq || edge_sq(d, a) > max_edge_sq)
            return false;

        // Convexity check — all cross products must have same sign
        auto cross = [](const ScreenPoint& o, const ScreenPoint& p1, const ScreenPoint& p2) {
            return static_cast<float>((p1.x - o.x) * (p2.y - o.y) - (p1.y - o.y) * (p2.x - o.x));
        };
        float c0 = cross(a, b, c), c1 = cross(b, c, d);
        float c2 = cross(c, d, a), c3 = cross(d, a, b);
        if (!((c0 > 0 && c1 > 0 && c2 > 0 && c3 > 0) ||
              (c0 < 0 && c1 < 0 && c2 < 0 && c3 < 0)))
            return false;

        // Minimum area — reject sub-pixel quads
        float area = 0.5f * std::abs(
            static_cast<float>(a.x * b.y - b.x * a.y) +
            static_cast<float>(b.x * c.y - c.x * b.y) +
            static_cast<float>(c.x * d.y - d.x * c.y) +
            static_cast<float>(d.x * a.y - a.x * d.y));
        if (area < 4.f) return false;

        return true;
    }

    /// @}

    /// @name Rendering Utilities
    /// @brief OverlayUtil equivalent — methods plugins and devtools call to draw overlays.
    ///
    /// All use Perspective API for projection — zero native W2S calls.
    /// @{

    /// @brief Draw a tile quad at the given scene tile coordinates.
    ///
    /// Uses per-corner tile heights for terrain following. The
    /// trailing @p style controls how the outline edge is rendered.
    ///
    /// Inline so host plugins can link against it — recorder branch
    /// serialises the call; core branch delegates to `render_tile_core`
    /// in `overlay_util.cpp`.
    void render_tile(int32_t scene_x, int32_t scene_y,
                     ImU32 fill_col, ImU32 outline_col,
                     float thickness = 2.0f,
                     TileLineStyle style = TileLineStyle::Solid) const {
        if (recorder_) {
            recorder_->record_tile(scene_x, scene_y, fill_col, outline_col,
                                   thickness, static_cast<int32_t>(style));
            return;
        }
#ifdef OBSIDIAN_CORE_INTERNAL
        render_tile_core(scene_x, scene_y, fill_col, outline_col, thickness, style);
#endif
    }

    /// @brief Draw a tile highlight from a world point.
    void render_tile_at(const WorldPoint& wp, ImU32 fill_col, ImU32 outline_col,
                        float thickness = 2.0f,
                        TileLineStyle style = TileLineStyle::Solid) const {
        int sx = wp.x - base_x_, sy = wp.y - base_y_;
        if (sx >= 0 && sx < SCENE_SIZE && sy >= 0 && sy < SCENE_SIZE)
            render_tile(sx, sy, fill_col, outline_col, thickness, style);
    }

    /// @brief Draw a tile-sized quad centered on an actor's fine position.
    ///
    /// For multi-tile actors (size > 1), draws a larger bounding box.
    void render_actor_highlight(int32_t local_x, int32_t local_y, int32_t size,
                                ImU32 fill_col, ImU32 outline_col,
                                float thickness = 2.0f,
                                TileLineStyle style = TileLineStyle::Solid) const {
        if (recorder_) {
            recorder_->record_actor_highlight(local_x, local_y, size,
                                              fill_col, outline_col, thickness,
                                              static_cast<int32_t>(style));
            return;
        }
#ifdef OBSIDIAN_CORE_INTERNAL
        render_actor_highlight_core(local_x, local_y, size, fill_col, outline_col, thickness, style);
#endif
    }

    /// @brief Draw a bounding rectangle for multi-tile objects.
    void render_object_bounds(int32_t tile_x, int32_t tile_y,
                              int32_t size_x, int32_t size_y,
                              ImU32 fill_col, ImU32 outline_col,
                              float thickness = 2.0f,
                              TileLineStyle style = TileLineStyle::Solid) const {
        if (recorder_) {
            recorder_->record_object_bounds(tile_x, tile_y, size_x, size_y,
                                            fill_col, outline_col, thickness,
                                            static_cast<int32_t>(style));
            return;
        }
#ifdef OBSIDIAN_CORE_INTERNAL
        render_object_bounds_core(tile_x, tile_y, size_x, size_y,
                                  fill_col, outline_col, thickness, style);
#endif
    }

    /// @brief Projected 3D box hull for a scene object.
    ///
    /// Constructs an 8-corner AABB from the footprint (tile_x, tile_y,
    /// size_x, size_y) and the supplied model-space height, projects
    /// every corner through the camera, and draws the convex hull as
    /// a stroked + optionally filled polygon. Matches the AABB
    /// fallback in `render_npc_hull` so scene-object outlines have the
    /// same 3D feel as NPC hulls.
    ///
    /// @param tile_x, tile_y    scene tile of the object's south-west corner
    /// @param size_x, size_y    footprint in tiles (from ObjectComposition)
    /// @param height            model-space height in local units (e.g. 300 ≈ 2.3 tiles)
    /// @param fill_col          ABGR fill colour (0 = no fill)
    /// @param outline_col       ABGR stroke colour
    /// @param thickness         stroke width in pixels
    void render_object_bounds_hull(int32_t tile_x, int32_t tile_y,
                                   int32_t size_x, int32_t size_y,
                                   int32_t height,
                                   ImU32 fill_col, ImU32 outline_col,
                                   float thickness = 2.0f) const {
        if (recorder_) {
            recorder_->record_object_bounds_hull(tile_x, tile_y, size_x, size_y,
                                                  height, fill_col, outline_col,
                                                  thickness);
            return;
        }
#ifdef OBSIDIAN_CORE_INTERNAL
        render_object_bounds_hull_core(tile_x, tile_y, size_x, size_y, height,
                                        fill_col, outline_col, thickness);
#endif
    }

    /// @brief Real model-vertex hull for a scene object.
    ///
    /// Takes the scene object's **real_base** pointer and re-reads the
    /// animated ModelLitImpl at `+0x168` on the render thread at draw
    /// time. This avoids flicker from the host/core timing gap — the
    /// model pointer stored on the object may change mid-frame when
    /// the game animates or transitions state, so we can't cache it
    /// in the command.
    ///
    /// Falls back silently (draws nothing) when the scene object slot
    /// is empty, the model pointer is freed, or vertex counts come
    /// back out of range.
    void render_scene_object_hull(int32_t local_x, int32_t local_y,
                                  int32_t anchor_y,
                                  int32_t orientation,
                                  uintptr_t scene_obj_real_base,
                                  ImU32 fill_col, ImU32 outline_col,
                                  float thickness = 2.0f) const {
        if (recorder_) {
            recorder_->record_scene_object_hull(local_x, local_y, anchor_y, orientation,
                                                 scene_obj_real_base,
                                                 fill_col, outline_col, thickness);
            return;
        }
#ifdef OBSIDIAN_CORE_INTERNAL
        render_scene_object_hull_core(local_x, local_y, anchor_y, orientation,
                                       scene_obj_real_base,
                                       fill_col, outline_col, thickness);
#endif
    }

    /// @brief Draw a scene object's model hull, looked up by object id, at a world position.
    void render_object_hull_by_id(int32_t object_id,
                                  int32_t world_x, int32_t world_y,
                                  ImU32 fill_col, ImU32 outline_col,
                                  float thickness = 2.0f) const {
        if (recorder_) {
            recorder_->record_object_hull_by_id(object_id, world_x, world_y,
                                                 fill_col, outline_col, thickness);
            return;
        }
    }

    /// @brief Draw a text label above a local position.
    ///
    /// Projects the local position to screen and draws centered text above it.
    /// @param local_x       Fine-coord X of the target position.
    /// @param local_y       Fine-coord Y of the target position.
    /// @param text          Null-terminated string to render.
    /// @param col           Text colour (ImU32 ABGR).
    /// @param background    If true, draws a dark background rectangle behind the text.
    /// @param height_offset Vertical offset above ground in model units (default 200 ≈ actor head height).
    void render_text(int32_t local_x, int32_t local_y,
                     const char* text, ImU32 col, bool background = false,
                     int32_t height_offset = 200) const {
        if (recorder_) {
            recorder_->record_text(local_x, local_y, text, col, background, height_offset);
            return;
        }
#ifdef OBSIDIAN_CORE_INTERNAL
        render_text_core(local_x, local_y, text, col, background, height_offset);
#endif
    }

    /// @brief Draw text at the center of a scene tile.
    /// @param height_offset Vertical offset in model units (default 0 = ground level; 200 ≈ head height).
    void render_text_at_tile(int32_t scene_x, int32_t scene_y,
                             const char* text, ImU32 col,
                             int32_t height_offset = 0) const {
        render_text((scene_x << 7) + 64, (scene_y << 7) + 64, text, col, false, height_offset);
    }

    /// @brief Draw a line between two local positions.
    void render_line(int32_t lx1, int32_t ly1, int32_t lx2, int32_t ly2,
                     ImU32 col, float thickness = 2.0f) const {
        if (recorder_) {
            recorder_->record_line(lx1, ly1, lx2, ly2, col, thickness);
            return;
        }
#ifdef OBSIDIAN_CORE_INTERNAL
        render_line_core(lx1, ly1, lx2, ly2, col, thickness);
#endif
    }

    /// @brief Draw a quad from four arbitrary screen points.
    ///
    /// For overlays that compute their own screen coordinates.
    void render_quad(const ScreenPoint& a, const ScreenPoint& b,
                     const ScreenPoint& c, const ScreenPoint& d,
                     ImU32 fill_col, ImU32 outline_col,
                     float thickness = 2.0f,
                     TileLineStyle style = TileLineStyle::Solid) const {
        if (recorder_) {
            recorder_->record_quad(a, b, c, d, fill_col, outline_col, thickness,
                                   static_cast<int32_t>(style));
            return;
        }
#ifdef OBSIDIAN_CORE_INTERNAL
        render_quad_core(a, b, c, d, fill_col, outline_col, thickness, style);
#endif
    }

    /// @brief Draw a pulsing vertical 3D arrow above a scene tile.
    ///
    /// Projects two heights at the same local (x, y) to get the shaft's
    /// top and bottom screen points, then renders a coloured line + a
    /// small arrowhead triangle at the base. This is a first-class
    /// overlay primitive because the canonical primitives (`render_line`
    /// and friends) only operate at ground height and can't express a
    /// vertical 3D shaft without a dedicated helper.
    ///
    /// @param scene_x Scene X (0..SCENE_SIZE-1).
    /// @param scene_y Scene Y (0..SCENE_SIZE-1).
    /// @param extra_h Height in model units above ground to plant the
    ///                arrow's base. The shaft spans `extra_h..extra_h+40`.
    /// @param color   Arrow colour (ImU32). A black outline is drawn
    ///                underneath for contrast regardless of this value.
    void render_arrow_world(int32_t scene_x, int32_t scene_y,
                            int32_t extra_h, ImU32 color) const {
        if (recorder_) {
            recorder_->record_arrow_world(scene_x, scene_y, extra_h, color);
            return;
        }
#ifdef OBSIDIAN_CORE_INTERNAL
        render_arrow_world_core(scene_x, scene_y, extra_h, color);
#endif
    }

#ifdef OBSIDIAN_CORE_INTERNAL
    // Core-only draw backends — called by the public inline wrappers above
    // when no recorder is installed. Defined in `overlay_util.cpp`.
    /// Internal: core-side implementation of render_tile.
    void render_tile_core(int32_t scene_x, int32_t scene_y,
                          ImU32 fill, ImU32 outline,
                          float thickness, TileLineStyle style) const;
    /// Internal: core-side implementation of render_actor_highlight.
    void render_actor_highlight_core(int32_t local_x, int32_t local_y, int32_t size,
                                      ImU32 fill, ImU32 outline,
                                      float thickness, TileLineStyle style) const;
    /// Internal: core-side implementation of render_object_bounds.
    void render_object_bounds_core(int32_t tile_x, int32_t tile_y,
                                    int32_t size_x, int32_t size_y,
                                    ImU32 fill, ImU32 outline,
                                    float thickness, TileLineStyle style) const;
    /// Internal: core-side implementation of render_object_bounds_hull.
    void render_object_bounds_hull_core(int32_t tile_x, int32_t tile_y,
                                         int32_t size_x, int32_t size_y,
                                         int32_t height,
                                         ImU32 fill, ImU32 outline,
                                         float thickness) const;
    /// Internal: core-side implementation of render_scene_object_hull.
    void render_scene_object_hull_core(int32_t local_x, int32_t local_y,
                                        int32_t anchor_y,
                                        int32_t orientation,
                                        uintptr_t scene_obj_real_base,
                                        ImU32 fill, ImU32 outline,
                                        float thickness) const;
    /// Internal: core-side implementation of render_text.
    void render_text_core(int32_t local_x, int32_t local_y,
                          const char* text, ImU32 col, bool background,
                          int32_t height_offset) const;
    /// Internal: core-side implementation of render_line.
    void render_line_core(int32_t lx1, int32_t ly1, int32_t lx2, int32_t ly2,
                          ImU32 col, float thickness) const;
    /// Internal: core-side implementation of render_quad.
    void render_quad_core(const ScreenPoint& a, const ScreenPoint& b,
                          const ScreenPoint& c, const ScreenPoint& d,
                          ImU32 fill, ImU32 outline,
                          float thickness, TileLineStyle style) const;
    /// Internal: core-side implementation of render_arrow_world.
    void render_arrow_world_core(int32_t scene_x, int32_t scene_y,
                                 int32_t extra_h, ImU32 color) const;
#endif

    /// @brief Generate a translucent fill color from an outline color.
    static ImU32 fill_from_outline(ImU32 col, uint8_t alpha = 40) {
        return (col & 0x00FFFFFF) | (static_cast<ImU32>(alpha) << 24);
    }

    /// @name NPC / Player tile highlights — interpolated vs true position
    /// @brief Convenience wrappers that pull `local_location`, `location`
    /// and `entity_size` off a `SceneNpc` / `ScenePlayer` and render a
    /// tile-sized highlight using the same rules as `render_actor_highlight`
    /// or `render_object_bounds`.
    ///
    /// **Two rendering modes**:
    /// - `render_npc_tile` / `render_player_tile` — uses `local_location`
    ///   (the **interpolated visual position**); the highlight follows
    ///   the actor smoothly during walks and may straddle two tiles.
    /// - `render_npc_tile_true` / `render_player_tile_true` — uses
    ///   `location` (the **snapped per-tick world tile**); the highlight
    ///   only changes position when the actor's logical tile changes.
    ///
    /// Multi-tile actors (NPC `entity_size > 1`, e.g. GWD bosses)
    /// render their full footprint; the SW-corner variants render
    /// only the south-west 1×1 tile of that footprint.
    /// @{

    /// Tile highlight at the NPC's INTERPOLATED visual position.
    ///
    /// Inline so host plugins can link against it without pulling in the
    /// core-only drawing code. On host, the recorder branch fires; on core,
    /// the `OBSIDIAN_CORE_INTERNAL` branch delegates to `render_actor_highlight`
    /// / `render_object_bounds` as before. The `uintptr_t` overloads of the
    /// NPC primitives remain out-of-line in `overlay_util.cpp` and are only
    /// callable from core TUs.
    void render_npc_tile(const SceneNpc& npc,
                         ImU32 fill, ImU32 outline,
                         float thickness = 2.0f,
                         TileLineStyle style = TileLineStyle::Solid) const {
        if (recorder_) {
            recorder_->record_npc_tile(npc, fill, outline, thickness,
                                       static_cast<int32_t>(style));
            return;
        }
#ifdef OBSIDIAN_CORE_INTERNAL
        int size = npc.entity_size > 0 ? npc.entity_size : 1;
        render_actor_highlight(npc.local_location.x, npc.local_location.y,
                               size, fill, outline, thickness, style);
#endif
    }

    /// Tile highlight at the NPC's TRUE per-tick world position.
    void render_npc_tile_true(const SceneNpc& npc,
                              ImU32 fill, ImU32 outline,
                              float thickness = 2.0f,
                              TileLineStyle style = TileLineStyle::Solid) const {
        if (recorder_) {
            recorder_->record_npc_tile_true(npc, fill, outline, thickness,
                                            static_cast<int32_t>(style));
            return;
        }
#ifdef OBSIDIAN_CORE_INTERNAL
        int size = npc.entity_size > 0 ? npc.entity_size : 1;
        int sx = npc.location.x - base_x_;
        int sy = npc.location.y - base_y_;
        if (sx < 0 || sy < 0 || sx >= SCENE_SIZE || sy >= SCENE_SIZE) return;
        if (size > 1)
            render_object_bounds(sx, sy, size, size, fill, outline, thickness, style);
        else
            render_tile(sx, sy, fill, outline, thickness, style);
#endif
    }

    /// Single 1×1 tile at the SW corner of the NPC's interpolated footprint.
    void render_npc_sw_tile(const SceneNpc& npc,
                            ImU32 fill, ImU32 outline,
                            float thickness = 2.0f,
                            TileLineStyle style = TileLineStyle::Solid) const {
        if (recorder_) {
            recorder_->record_npc_sw_tile(npc, fill, outline, thickness,
                                          static_cast<int32_t>(style));
            return;
        }
#ifdef OBSIDIAN_CORE_INTERNAL
        int size = npc.entity_size > 0 ? npc.entity_size : 1;
        int half_extra = ((size - 1) * LOCAL_TILE_SIZE) / 2;
        render_actor_highlight(npc.local_location.x - half_extra,
                               npc.local_location.y - half_extra,
                               1, fill, outline, thickness, style);
#endif
    }

    /// Single 1×1 tile at the SW corner of the NPC's true world tile.
    void render_npc_sw_tile_true(const SceneNpc& npc,
                                 ImU32 fill, ImU32 outline,
                                 float thickness = 2.0f,
                                 TileLineStyle style = TileLineStyle::Solid) const {
        if (recorder_) {
            recorder_->record_npc_sw_tile_true(npc, fill, outline, thickness,
                                               static_cast<int32_t>(style));
            return;
        }
#ifdef OBSIDIAN_CORE_INTERNAL
        int sx = npc.location.x - base_x_;
        int sy = npc.location.y - base_y_;
        if (sx < 0 || sy < 0 || sx >= SCENE_SIZE || sy >= SCENE_SIZE) return;
        render_tile(sx, sy, fill, outline, thickness, style);
#endif
    }

    /// Player tile (always 1×1) at the player's INTERPOLATED visual position.
    void render_player_tile(const ScenePlayer& p,
                            ImU32 fill, ImU32 outline,
                            float thickness = 2.0f,
                            TileLineStyle style = TileLineStyle::Solid) const {
        if (recorder_) {
            recorder_->record_player_tile(p, fill, outline, thickness,
                                          static_cast<int32_t>(style));
            return;
        }
#ifdef OBSIDIAN_CORE_INTERNAL
        render_actor_highlight(p.local_location.x, p.local_location.y,
                               1, fill, outline, thickness, style);
#endif
    }

    /// Player tile at the player's TRUE per-tick world position.
    void render_player_tile_true(const ScenePlayer& p,
                                 ImU32 fill, ImU32 outline,
                                 float thickness = 2.0f,
                                 TileLineStyle style = TileLineStyle::Solid) const {
        if (recorder_) {
            recorder_->record_player_tile_true(p, fill, outline, thickness,
                                               static_cast<int32_t>(style));
            return;
        }
#ifdef OBSIDIAN_CORE_INTERNAL
        int sx = p.location.x - base_x_;
        int sy = p.location.y - base_y_;
        if (sx < 0 || sy < 0 || sx >= SCENE_SIZE || sy >= SCENE_SIZE) return;
        render_tile(sx, sy, fill, outline, thickness, style);
#endif
    }

    /// Text anchored to a player's live interpolated position.
    /// Core resolves the entity at render time so the text tracks smoothly.
    void render_player_text(const ScenePlayer& p,
                            const char* text, ImU32 col,
                            int32_t height_offset = 140) const {
        if (recorder_) {
            recorder_->record_player_text(p, text, col, height_offset);
            return;
        }
#ifdef OBSIDIAN_CORE_INTERNAL
        render_text_core(p.local_location.x, p.local_location.y,
                         text, col, false, height_offset);
#endif
    }

    /// @}

    /// @name Widget-anchored rendering
    /// @brief Primitives anchored to a widget's live screen position.
    ///
    /// On the host side, these encode the widget pointer into the command
    /// stream. Core resolves the widget position at render time via
    /// `widget_screen_pos_by_ptr` and draws at the resolved coordinates.
    /// This means overlay text/rects track the widget even as it moves
    /// (e.g. inventory slot positions shift when the bank opens).
    /// @{

    /// Text anchored to a widget's live screen position.
    /// Core resolves the widget position at render time.
    void render_widget_text(uintptr_t widget_ptr,
                            const char* text, ImU32 col,
                            int32_t offset_x = 0, int32_t offset_y = 0) const {
        if (recorder_) {
            recorder_->record_widget_text(widget_ptr, text, col, offset_x, offset_y);
            return;
        }
#ifdef OBSIDIAN_CORE_INTERNAL
        int32_t wx, wy, ww, wh;
        if (widgets::screen_pos_by_ptr(widget_ptr, wx, wy, ww, wh))
            render_text_screen_core(static_cast<float>(wx + offset_x),
                                     static_cast<float>(wy + offset_y),
                                     text, col, false);
#endif
    }

    /// Rectangle outline anchored to a widget's live screen position.
    /// If size_w/size_h are 0, the widget's own dimensions are used.
    void render_widget_rect(uintptr_t widget_ptr,
                            ImU32 col, float thickness = 2.0f,
                            int32_t offset_x = 0, int32_t offset_y = 0,
                            int32_t size_w = 0, int32_t size_h = 0) const {
        if (recorder_) {
            recorder_->record_widget_rect(widget_ptr, col, thickness,
                                           offset_x, offset_y, size_w, size_h);
            return;
        }
#ifdef OBSIDIAN_CORE_INTERNAL
        int32_t wx, wy, ww, wh;
        if (widgets::screen_pos_by_ptr(widget_ptr, wx, wy, ww, wh)) {
            int32_t rw = size_w > 0 ? size_w : ww;
            int32_t rh = size_h > 0 ? size_h : wh;
            render_rect_screen_core(static_cast<float>(wx + offset_x),
                                     static_cast<float>(wy + offset_y),
                                     static_cast<float>(rw),
                                     static_cast<float>(rh),
                                     col, thickness, 0.0f);
        }
#endif
    }

    /// Filled rectangle anchored to a widget's live screen position.
    /// If size_w/size_h are 0, the widget's own dimensions are used.
    void render_widget_rect_filled(uintptr_t widget_ptr,
                                    ImU32 col,
                                    int32_t offset_x = 0, int32_t offset_y = 0,
                                    int32_t size_w = 0, int32_t size_h = 0) const {
        if (recorder_) {
            recorder_->record_widget_rect_filled(widget_ptr, col,
                                                  offset_x, offset_y, size_w, size_h);
            return;
        }
#ifdef OBSIDIAN_CORE_INTERNAL
        int32_t wx, wy, ww, wh;
        if (widgets::screen_pos_by_ptr(widget_ptr, wx, wy, ww, wh)) {
            int32_t rw = size_w > 0 ? size_w : ww;
            int32_t rh = size_h > 0 ? size_h : wh;
            render_rect_filled_screen_core(static_cast<float>(wx + offset_x),
                                            static_cast<float>(wy + offset_y),
                                            static_cast<float>(rw),
                                            static_cast<float>(rh),
                                            col, 0.0f);
        }
#endif
    }

    /// @}

    // @brief Render NPC Hull
    // ── Model convex hull rendering ─────────────────────────────────
    // Projects model vertices to screen and draws the convex hull.
    // npc_ptr: entity pointer, orientation: JAU angle (0-2047)
    //
    // There are two overloads:
    //   - `render_npc_hull(npc_ptr, orientation, ...)` is the legacy
    //     raw-pointer form, used by internal core overlays that have
    //     already dereferenced an entity. **Do not call from host
    //     plugins** — the recorder cannot safely serialise a raw ptr.
    //   - `render_npc_hull(const SceneNpc&, ...)` is the host-safe form:
    //     carries the entity index + id so the host recorder can
    //     serialise a lookup, which the core drain then resolves before
    //     drawing. Host plugins should always use this form.
#ifdef OBSIDIAN_CORE_INTERNAL
    void render_npc_hull(uintptr_t npc_ptr, int32_t orientation,
                         ImU32 fill_col, ImU32 outline_col, float thickness = 2.0f) const;
#endif
    void render_npc_hull(const SceneNpc& npc,
                         ImU32 fill_col, ImU32 outline_col, float thickness = 2.0f) const {
        if (recorder_) {
            recorder_->record_npc_hull(npc, fill_col, outline_col, thickness);
            return;
        }
#ifdef OBSIDIAN_CORE_INTERNAL
        if (npc.ptr > 0x10000)
            render_npc_hull(npc.ptr, npc.orientation, fill_col, outline_col, thickness);
#endif
    }

    /// @brief Project the NPC's model AABB to screen and draw a quad.
    ///
    /// Reads the per-tick model capture (same path as `render_npc_hull`),
    /// projects all 8 corners of the model-space AABB
    /// (`min/max_x/y/z`) through `perspective::model_to_canvas`, and
    /// computes the screen-space bounding rectangle. Approximates
    /// RuneLite's `Perspective.getClickbox` — used to highlight the
    /// region where mouse clicks would interact with the NPC.
    ///
    /// @param fill        Fill colour (zero alpha = no fill).
    /// @param outline     Outline colour (zero alpha = no outline).
    /// @param thickness   Outline stroke width.
#ifdef OBSIDIAN_CORE_INTERNAL
    void render_npc_clickbox(uintptr_t npc_ptr, int32_t orientation,
                             ImU32 fill, ImU32 outline,
                             float thickness = 2.0f) const;
#endif
    void render_npc_clickbox(const SceneNpc& npc,
                             ImU32 fill, ImU32 outline,
                             float thickness = 2.0f) const {
        if (recorder_) {
            recorder_->record_npc_clickbox(npc, fill, outline, thickness);
            return;
        }
#ifdef OBSIDIAN_CORE_INTERNAL
        if (npc.ptr > 0x10000)
            render_npc_clickbox(npc.ptr, npc.orientation, fill, outline, thickness);
#endif
    }

    /// @brief `render_npc_clickbox` variant that picks one of two
    /// colour pairs based on whether the current mouse position
    /// (from `client::mouse_canvas`) is inside the projected AABB.
    /// Used for "clickbox lights up under the cursor" feedback.
    void render_npc_clickbox_hover(uintptr_t npc_ptr, int32_t orientation,
                                   ImU32 normal_fill, ImU32 normal_outline,
                                   ImU32 hover_fill,  ImU32 hover_outline,
                                   float thickness = 2.0f) const;
    void render_npc_clickbox_hover(const SceneNpc& npc,
                                   ImU32 normal_fill, ImU32 normal_outline,
                                   ImU32 hover_fill,  ImU32 hover_outline,
                                   float thickness = 2.0f) const {
        if (recorder_) {
            recorder_->record_npc_clickbox_hover(npc, normal_fill, normal_outline,
                                                 hover_fill, hover_outline, thickness);
            return;
        }
#ifdef OBSIDIAN_CORE_INTERNAL
        if (npc.ptr > 0x10000)
            render_npc_clickbox_hover(npc.ptr, npc.orientation,
                                      normal_fill, normal_outline,
                                      hover_fill, hover_outline, thickness);
#endif
    }

    /// @brief Draw the NPC model's silhouette outline.
    ///
    /// CPU edge tracer: walks every triangle in the model, computes
    /// per-triangle screen-space facing (signed area), and emits as
    /// silhouette edges (a) edges shared by exactly one triangle
    /// (boundary) and (b) edges shared by one front-facing and one
    /// back-facing triangle. Result is the projected silhouette of
    /// the model — a "true" outline that follows concave contours,
    /// unlike a convex hull.
    ///
    /// @p feather ≥ 1 redraws the silhouette `feather` extra times
    /// with progressively wider lines and decreasing alpha. Cheap
    /// CPU approximation of a Gaussian-blur "glow" effect (we have
    /// no shader pipeline; the trick looks reasonable for thin
    /// outlines on dark backgrounds).
    ///
    /// @param npc_ptr     Entity pointer (used for `read_npc_model`
    ///                    and live position/orientation reads).
    /// @param orientation JAU rotation 0–2047.
    /// @param colour      Outline colour (alpha used directly for the
    ///                    core stroke; feather passes scale alpha down).
    /// @param thickness   Core stroke width.
    /// @param feather     0 = no glow. 1–10 = number of extra passes.
#ifdef OBSIDIAN_CORE_INTERNAL
    void render_npc_outline(uintptr_t npc_ptr, int32_t orientation,
                            ImU32 colour, float thickness = 2.0f,
                            int32_t feather = 0) const;
#endif
    void render_npc_outline(const SceneNpc& npc,
                            ImU32 colour, float thickness = 2.0f,
                            int32_t feather = 0) const {
        if (recorder_) {
            recorder_->record_npc_outline(npc, colour, thickness, feather);
            return;
        }
#ifdef OBSIDIAN_CORE_INTERNAL
        if (npc.ptr > 0x10000)
            render_npc_outline(npc.ptr, npc.orientation, colour, thickness, feather);
#endif
    }

    /// @}

    /// @name Screen-space drawing
    /// @brief 2D drawing in raw screen coordinates (no world projection).
    ///
    /// Use these for HUD elements, minimap annotations, edge-of-screen
    /// indicators, or any overlay content that already has canvas-space
    /// coordinates. The origin is the top-left of the game canvas and
    /// Y grows downward. All primitives draw to the same ImDrawList as
    /// the world-space methods — layering is controlled by the overlay's
    /// `OverlayLayer` setting, not by which primitive family you call.
    /// @{

    /// @brief Draw text at a raw screen position.
    /// @param screen_x  Canvas X (top-left origin).
    /// @param screen_y  Canvas Y (top-left origin).
    /// @param text      Null-terminated string.
    /// @param col       Text colour (ImU32).
    /// @param background If true, draws a translucent black rounded rect behind the text.
    void render_text_screen(float screen_x, float screen_y,
                            const char* text, ImU32 col,
                            bool background = false) const {
        if (recorder_) {
            recorder_->record_text_screen(screen_x, screen_y, text, col, background);
            return;
        }
#ifdef OBSIDIAN_CORE_INTERNAL
        render_text_screen_core(screen_x, screen_y, text, col, background);
#endif
    }

    /// @brief Draw a line between two canvas points.
    /// @param x1        Canvas X of the start point.
    /// @param y1        Canvas Y of the start point.
    /// @param x2        Canvas X of the end point.
    /// @param y2        Canvas Y of the end point.
    /// @param col       Line colour (ImU32).
    /// @param thickness Stroke width in pixels (default 1.0).
    void render_line_screen(float x1, float y1, float x2, float y2,
                            ImU32 col, float thickness = 1.0f) const {
        if (recorder_) {
            recorder_->record_line_screen(x1, y1, x2, y2, col, thickness);
            return;
        }
#ifdef OBSIDIAN_CORE_INTERNAL
        render_line_screen_core(x1, y1, x2, y2, col, thickness);
#endif
    }

    /// @brief Draw a rectangle outline in canvas coordinates.
    /// @param x         Top-left canvas X.
    /// @param y         Top-left canvas Y.
    /// @param w         Width in pixels.
    /// @param h         Height in pixels.
    /// @param col       Outline colour (ImU32).
    /// @param thickness Stroke width in pixels (default 1.0).
    /// @param rounding  Corner radius in pixels (default 0 = sharp corners).
    void render_rect_screen(float x, float y, float w, float h,
                            ImU32 col, float thickness = 1.0f,
                            float rounding = 0.0f) const {
        if (recorder_) {
            recorder_->record_rect_screen(x, y, w, h, col, thickness, rounding);
            return;
        }
#ifdef OBSIDIAN_CORE_INTERNAL
        render_rect_screen_core(x, y, w, h, col, thickness, rounding);
#endif
    }

    /// @brief Draw a filled rectangle in canvas coordinates.
    /// @param x        Top-left canvas X.
    /// @param y        Top-left canvas Y.
    /// @param w        Width in pixels.
    /// @param h        Height in pixels.
    /// @param col      Fill colour (ImU32).
    /// @param rounding Corner radius in pixels (default 0 = sharp corners).
    void render_rect_filled_screen(float x, float y, float w, float h,
                                   ImU32 col, float rounding = 0.0f) const {
        if (recorder_) {
            recorder_->record_rect_filled_screen(x, y, w, h, col, rounding);
            return;
        }
#ifdef OBSIDIAN_CORE_INTERNAL
        render_rect_filled_screen_core(x, y, w, h, col, rounding);
#endif
    }

    /// @brief Draw 13px UI text (panel body) in canvas coordinates. Panels
    /// use this for rows/labels/titles; the 16px overlay font stays for
    /// world text and stat-tile values. Recorder path degrades to normal
    /// text; panels render core-side so the 13px path is what runs.
    void render_text_screen_ui(float screen_x, float screen_y,
                               const char* text, ImU32 col) const {
        if (recorder_) {
            recorder_->record_text_screen(screen_x, screen_y, text, col, false);
            return;
        }
#ifdef OBSIDIAN_CORE_INTERNAL
        render_text_screen_ui_core(screen_x, screen_y, text, col);
#endif
    }

    /// @brief Draw small (10px) text in canvas coordinates — used for panel
    /// captions and in-bar percent labels. Falls back to normal-size text
    /// over IPC; panels render core-side so the small path is what runs.
    void render_text_screen_small(float screen_x, float screen_y,
                                  const char* text, ImU32 col) const {
        if (recorder_) {
            recorder_->record_text_screen(screen_x, screen_y, text, col, false);
            return;
        }
#ifdef OBSIDIAN_CORE_INTERNAL
        render_text_screen_small_core(screen_x, screen_y, text, col);
#endif
    }

    /// @brief Draw an item's inventory icon at canvas coordinates. Returns
    /// true if the icon was drawn; false while the icon cache is still
    /// warming (or on host/recorder contexts) so callers can draw a
    /// fallback. Core-side only — icons come from the game cache.
    bool render_item_icon_screen(float x, float y, float w, float h,
                                 int32_t item_id, int32_t quantity = 1) const {
        if (recorder_) return false;
#ifdef OBSIDIAN_CORE_INTERNAL
        return render_item_icon_screen_core(x, y, w, h, item_id, quantity);
#else
        (void)x; (void)y; (void)w; (void)h; (void)item_id; (void)quantity;
        return false;
#endif
    }

    /// @brief Draw a partial ring (radial progress) in canvas coordinates.
    /// @param frac  Fill fraction 0..1, clockwise from 12 o'clock.
    /// Recorder path is a no-op (panels render core-side).
    void render_ring_screen(float cx, float cy, float radius, float thickness,
                            float frac, ImU32 col, ImU32 track_col) const {
        if (recorder_) return;
#ifdef OBSIDIAN_CORE_INTERNAL
        render_ring_screen_core(cx, cy, radius, thickness, frac, col, track_col);
#else
        (void)cx; (void)cy; (void)radius; (void)thickness;
        (void)frac; (void)col; (void)track_col;
#endif
    }

    /// @brief Draw a vertical-gradient filled rectangle in canvas coordinates.
    /// @param col_top       Fill colour at the top edge (ImU32).
    /// @param col_bottom    Fill colour at the bottom edge (ImU32).
    /// @param rounding      Corner radius in pixels (default 0 = sharp corners).
    /// @param round_top_only Round only the top two corners (title bars).
    /// Over IPC this degrades to two solid halves — panels render core-side,
    /// so the gradient path is what panel chrome actually uses.
    void render_rect_gradient_screen(float x, float y, float w, float h,
                                     ImU32 col_top, ImU32 col_bottom,
                                     float rounding = 0.0f,
                                     bool round_top_only = false) const {
        (void)round_top_only;  // used by the core path only
        if (recorder_) {
            recorder_->record_rect_filled_screen(x, y, w, h * 0.5f, col_top, rounding);
            recorder_->record_rect_filled_screen(x, y + h * 0.5f, w, h - h * 0.5f,
                                                 col_bottom, rounding);
            return;
        }
#ifdef OBSIDIAN_CORE_INTERNAL
        render_rect_gradient_screen_core(x, y, w, h, col_top, col_bottom,
                                         rounding, round_top_only);
#endif
    }

#ifdef OBSIDIAN_CORE_INTERNAL
    /// Internal: core-side implementation of render_text_screen.
    void render_text_screen_core(float screen_x, float screen_y,
                                 const char* text, ImU32 col, bool background) const;
    /// Internal: core-side implementation of render_rect_gradient_screen.
    void render_rect_gradient_screen_core(float x, float y, float w, float h,
                                          ImU32 col_top, ImU32 col_bottom,
                                          float rounding, bool round_top_only) const;
    /// Internal: core-side implementation of render_text_screen_small.
    void render_text_screen_small_core(float screen_x, float screen_y,
                                       const char* text, ImU32 col) const;
    /// Internal: core-side implementation of render_text_screen_ui.
    void render_text_screen_ui_core(float screen_x, float screen_y,
                                    const char* text, ImU32 col) const;
    /// Internal: core-side implementation of render_ring_screen.
    void render_ring_screen_core(float cx, float cy, float radius, float thickness,
                                 float frac, ImU32 col, ImU32 track_col) const;
    /// Internal: core-side implementation of render_item_icon_screen.
    bool render_item_icon_screen_core(float x, float y, float w, float h,
                                      int32_t item_id, int32_t quantity) const;
    /// Internal: core-side implementation of render_line_screen.
    void render_line_screen_core(float x1, float y1, float x2, float y2,
                                 ImU32 col, float thickness) const;
    /// Internal: core-side implementation of render_rect_screen.
    void render_rect_screen_core(float x, float y, float w, float h,
                                 ImU32 col, float thickness, float rounding) const;
    /// Internal: core-side implementation of render_rect_filled_screen.
    void render_rect_filled_screen_core(float x, float y, float w, float h,
                                        ImU32 col, float rounding) const;
#endif

    /// @brief Raw foreground draw list accessor — use for primitives not
    /// covered by the methods above (filled polygons, bezier curves,
    /// circles, images). Identical to the `draw_list()` accessor today,
    /// but with explicit semantics: this is the screen-space draw list,
    /// not the world-projected overlay list. May return nullptr if the
    /// overlay context hasn't been initialised with a draw list.
    ImDrawList* screen_draw_list() const { return draw_list_; }

    /// @}
};


/// @brief Abstract base class for all overlays.
///
/// Plugins subclass Overlay and implement render() to draw custom content.
/// Registered overlays are called each frame by the OverlayManager in
/// layer/priority order.
class Overlay {
    OverlayLayer layer_ = OverlayLayer::ALWAYS_ON_TOP;   ///< Rendering layer (default: on top of everything)
    OverlayPosition position_ = OverlayPosition::DYNAMIC; ///< Positioning strategy
    int priority_ = 0;   ///< Sort priority within the layer (lower = drawn first)
    bool enabled_ = true; ///< Whether this overlay is currently active

public:
    /// @brief Virtual destructor.
    virtual ~Overlay() = default;
    /// @brief Render overlay content for the current frame.
    virtual void render(OverlayContext& ctx) = 0;

    /// @name Accessors
    /// @{

    /// @brief Get the rendering layer.
    OverlayLayer layer() const { return layer_; }
    /// @brief Get the positioning strategy.
    OverlayPosition position() const { return position_; }
    /// @brief Get the sort priority.
    int priority() const { return priority_; }
    /// @brief Check if the overlay is enabled.
    bool enabled() const { return enabled_; }

    /// @}

    /// @name Mutators
    /// @{

    /// @brief Set the rendering layer.
    void set_layer(OverlayLayer l) { layer_ = l; }
    /// @brief Set the positioning strategy.
    void set_position(OverlayPosition p) { position_ = p; }
    /// @brief Set the sort priority within the layer.
    void set_priority(int p) { priority_ = p; }
    /// @brief Enable or disable this overlay.
    void set_enabled(bool e) { enabled_ = e; }

    /// @}
};

/// @brief Manages overlay registration, sorting, and per-frame rendering.
///
/// Maintains a sorted list of overlays and dispatches render calls in
/// layer/priority order. Equivalent to RuneLite's OverlayManager.
class OverlayManager {
    std::vector<Overlay*> overlays_; ///< Registered overlays (sorted by layer then priority)
    bool dirty_ = false;             ///< True when the sort order needs refreshing

    /// @brief Re-sort overlays by layer and priority if the list has changed.
    void sort_if_dirty() {
        if (!dirty_) return;
        std::stable_sort(overlays_.begin(), overlays_.end(),
            [](const Overlay* a, const Overlay* b) {
                if (a->layer() != b->layer())
                    return static_cast<int>(a->layer()) < static_cast<int>(b->layer());
                return a->priority() < b->priority();
            });
        dirty_ = false;
    }

public:
    /// @brief Register an overlay for rendering.
    void register_overlay(Overlay* overlay) {
        overlays_.push_back(overlay);
        dirty_ = true;
    }

    /// @brief Unregister an overlay, removing it from the render list.
    void unregister_overlay(Overlay* overlay) {
        overlays_.erase(
            std::remove(overlays_.begin(), overlays_.end(), overlay),
            overlays_.end());
    }

    /// @brief Render all enabled overlays in a specific layer.
    void render_layer(OverlayLayer layer, OverlayContext& ctx) {
        sort_if_dirty();
        for (auto* overlay : overlays_) {
            if (overlay->layer() == layer && overlay->enabled()) {
                overlay->render(ctx);
            }
        }
    }

    /// @brief Render all enabled overlays across all layers.
    void render_all(OverlayContext& ctx) {
        sort_if_dirty();
        for (auto* overlay : overlays_) {
            if (overlay->enabled()) {
                overlay->render(ctx);
            }
        }
    }

    /// @brief Remove all registered overlays.
    void clear() { overlays_.clear(); }
    /// @brief Get the list of registered overlays.
    const std::vector<Overlay*>& overlays() const { return overlays_; }
};

/// @name Global Overlay Manager
/// @{

/// @brief Access the global overlay manager pointer storage.
inline OverlayManager*& overlay_manager_ptr() { static OverlayManager* p = nullptr; return p; }

/// @brief Get the global overlay manager, creating a fallback if none was set.
inline OverlayManager& get_overlay_manager() {
    auto* p = overlay_manager_ptr();
    if (!p) {
        static OverlayManager fallback;
        overlay_manager_ptr() = &fallback;
        return fallback;
    }
    return *p;
}

/// @brief Set the global overlay manager instance.
inline void set_overlay_manager(OverlayManager* mgr) { overlay_manager_ptr() = mgr; }

/// @}

/// @brief Tick the shared hull vertex cache at the start of each frame.
///
/// Called once per frame at the top of `drain_host_overlay_commands` so
/// the NPC / scene-object hull renderers can evict stale snapshots and
/// bump the frame counter that drives cache-age checks. Defined in
/// `core/src/overlay/overlay_util.cpp`.
void overlay_hull_cache_begin_frame();

} // namespace obsidian::api
