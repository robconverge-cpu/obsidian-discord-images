#pragma once
/// @file definitions_api.h
/// @brief Item, NPC, and Object cache definitions.
/// @ingroup entities
///
/// Split from game_api.h — definition lookup is a distinct domain from
/// scene queries and interactions.

#include <cstdint>
#include <optional>
#include <string>
#include <utility>
#include <vector>

namespace obsidian::api {

/// @name Definitions
/// @{

/// Cached item definition (name, flags, actions, model properties).
/// Matches RuneLite's ItemComposition with getInventoryActions() + getSubops().
struct ItemDef {
    int32_t id = -1;
    std::string name;
    bool stackable = false;        ///< True if the item stacks (noted items are always stackable).
    bool members = false;
    bool noted = false;            ///< True if this item is a bank note (RuneLite getNote() != -1).
    int32_t noted_id = -1;         ///< Cross-link to the noted/unnoted counterpart (set on both).
    bool placeholder = false;      ///< True if this item is a bank placeholder (empty-slot marker).
    int32_t placeholder_id = -1;   ///< The real item this placeholder represents (-1 if none).
    int32_t cost = 0;              ///< Store price (NOT GE price).
    int32_t weight_grams = 0;      ///< Weight in grams (divide by 1000 for kg).
    std::string actions[5];        ///< Inventory action menu options (iop1-5).
    std::string ground_actions[5]; ///< Ground item action menu options.

    /// Inventory subops — matches RuneLite's ItemComposition.getSubops().
    /// Indexed by parent action index (0-4): subops[action_idx][subop_idx] = label.
    /// E.g., Glory actions[0]="Rub", subops[0]={"Edgeville","Karamja","Draynor Village","Al Kharid"}.
    std::vector<std::string> subops[5];

    // Model / rendering properties
    int32_t inventory_model = -1;  ///< 3D model ID shown in inventory sprite.
    int32_t xan2d = 0;             ///< Inventory sprite X rotation (pitch).
    int32_t yan2d = 0;             ///< Inventory sprite Y rotation (yaw).
    int32_t zan2d = 0;             ///< Inventory sprite Z rotation (roll).
    int32_t zoom2d = 2000;         ///< Inventory sprite zoom level.
    int32_t offset_x = 0;          ///< Inventory sprite X offset.
    int32_t offset_y = 0;          ///< Inventory sprite Y offset.
    int32_t ambient = 0;           ///< Ambient light intensity.
    int32_t contrast = 0;          ///< Contrast / directional light intensity.
    int32_t resize_x = 128;        ///< Model X scale (128 = 100%).
    int32_t resize_y = 128;        ///< Model Y scale.
    int32_t resize_z = 128;        ///< Model Z scale.
};

/// Cached NPC definition. 1:1 with RuneLite's NPCComposition.
/// The full field set is populated from the loaded cache (host side). The
/// core-side native read fills the scalar fields it can map from npc_comp;
/// footprint_size and stats are cache-only (no native offset yet).
struct NpcDef {
    int32_t id = -1;
    std::string name;
    int32_t combat_level = -1;             ///< NPCComposition.getCombatLevel().
    std::string actions[5];                ///< NPCComposition.getActions() (op slots, empty = unused).
    int32_t size = 1;                      ///< Tile footprint width/height. getSize().
    std::vector<int32_t> models;           ///< getModels().
    std::vector<int32_t> configs;          ///< getConfigs(): transform child NPC ids (impostors).
    int32_t transform_varbit = -1;         ///< Varbit selecting the transform (or -1).
    int32_t transform_varp = -1;           ///< Varp selecting the transform (or -1).
    bool interactible = true;              ///< isInteractible(): has menu options.
    bool minimap_visible = true;           ///< isMinimapVisible().
    bool visible = true;                   ///< isVisible().
    bool follower = false;                 ///< isFollower().
    int32_t width_scale = 128;             ///< getWidthScale() (128 = 100%).
    int32_t height_scale = 128;            ///< getHeightScale().
    std::vector<int32_t> color_to_replace;     ///< getColorToReplace() (recolor src).
    std::vector<int32_t> color_to_replace_with;///< getColorToReplaceWith() (recolor dst).
    int32_t footprint_size = -1;           ///< getFootprintSize() (cache-only).
    int32_t stats[6] = {1, 1, 1, 1, 1, 1}; ///< getStats(): Atk, Def, Str, HP, Range, Mage (cache-only).
};

/// Cached object definition (name, actions, transform metadata).
/// For a multiloc, `id`/`configs`/`transform_*` describe the requested base while
/// name/actions/size come from the child its varbit/varp currently selects.
struct ObjectDef {
    int32_t id = -1;                       ///< The requested id (base id for multilocs).
    std::string name;
    std::string actions[5];
    int32_t size_x = 1;
    int32_t size_y = 1;
    std::vector<int32_t> configs;          ///< Transform child object ids (impostorIds).
    int32_t transform_varbit = -1;         ///< Varbit selecting the transform (or -1).
    int32_t transform_varp = -1;           ///< Varp selecting the transform (or -1).
    int32_t map_scene_id = -1;             ///< Map scene sprite ID (-1 = none).
    int32_t interact_type = 2;             ///< Interaction type (0=none, 1=line-of-sight, 2=walk-to).
    int32_t animation = -1;                ///< Default animation (-1 = none).
    int32_t category = -1;                 ///< Category grouping (-1 = none).
    int32_t wall_or_door = -1;             ///< Wall/door type (-1 = neither).
    bool blocks_projectile = true;         ///< Whether projectiles are blocked.
};

/// @}

/// A game cache enum definition (id → int or string values).
struct EnumDef {
    int32_t id = -1;
    int32_t key_type = 0;
    int32_t value_type = 0;
    std::string default_string;
    int32_t default_int = 0;
    std::vector<std::pair<int32_t, int32_t>> int_values;
    std::vector<std::pair<int32_t, std::string>> string_values;
};

/// A game cache struct definition (parameterised key-value container).
struct StructDef {
    int32_t id = -1;
    std::vector<std::pair<int32_t, int32_t>> int_params;
    std::vector<std::pair<int32_t, std::string>> string_params;
};

/// Loaded plugin metadata (read-only).
struct PluginInfo {
    std::string key;
    std::string name;
    std::string version;
    std::string author;
    bool enabled = false;
};

/// A single log entry from the host log ring buffer.
struct LogEntry {
    uint64_t timestamp_ms = 0;
    uint8_t level = 0;
    std::string module;
    std::string message;
};

namespace definitions {
    void set_game_thread_id();  ///< Call once from hk_GameLoop to register the game thread. TypeList lookups are game-thread-only.

    const ItemDef* item(int32_t item_id);          ///< Returns cached def, or nullptr if unknown.
    const NpcDef* npc(int32_t npc_id);             ///< Returns cached def, or nullptr if unknown.
    const ObjectDef* object(int32_t object_id);    ///< Returns cached def, or nullptr if unknown.
    const ItemDef* find_item_by_name(const std::string& name); ///< Returns first item whose name matches (case-sensitive), or nullptr.
} // namespace definitions


} // namespace obsidian::api
