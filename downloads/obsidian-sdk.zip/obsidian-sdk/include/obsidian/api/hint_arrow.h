#pragma once
/// @file hint_arrow.h
/// @brief Tutorial/quest hint arrow state read from the Client struct.
/// @ingroup entities
// ═══════════════════════════════════════════════════════════════════════════
// HINT ARROW — Tutorial/quest hint arrow state
// ═══════════════════════════════════════════════════════════════════════════
// Mirrors RuneLite HintArrowType + Client.getHintArrow*() methods.
// ═══════════════════════════════════════════════════════════════════════════


#include <obsidian/api/coords.h>
#include <cstdint>

namespace obsidian::api {

/// What the hint arrow is pointing at.
enum class HintArrowType : int32_t {
    NONE       = 0,
    NPC        = 1,
    COORDINATE = 2,
    PLAYER     = 10,
};

/// Current hint arrow state. Uses offsets from game::client::hint_arrow.
struct HintArrow {
    HintArrowType type = HintArrowType::NONE;
    int32_t target_index = -1;
    WorldPoint world_point;
    bool arrow_mode = false;

    bool active() const { return type != HintArrowType::NONE && arrow_mode; }

};

} // namespace obsidian::api
