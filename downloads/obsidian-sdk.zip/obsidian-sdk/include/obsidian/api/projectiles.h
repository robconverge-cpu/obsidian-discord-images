#pragma once
/// @file projectiles.h
/// @brief In-flight projectile queries.

#include <obsidian/api/scene_api.h>  // SceneProjectile
#include <vector>

namespace obsidian::api::projectiles {

/// Returns every in-flight projectile currently in the scene.
std::vector<SceneProjectile> find_all();

} // namespace obsidian::api::projectiles
