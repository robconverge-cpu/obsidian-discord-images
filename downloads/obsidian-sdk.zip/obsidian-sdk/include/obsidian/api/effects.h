#pragma once
/// @file effects.h
/// @brief In-flight projectiles and ground graphics objects (SpotAnims).
/// @ingroup scene
// ═══════════════════════════════════════════════════════════════════════════
// EFFECTS — Projectile and GraphicsObject (SpotAnim on ground)
// ═══════════════════════════════════════════════════════════════════════════
// Mirrors RuneLite Projectile.java and GraphicsObject.java.
// Both are iterated as linked lists via the get_all() factories below.
// ═══════════════════════════════════════════════════════════════════════════


#include <obsidian/api/coords.h>
#include <cstdint>
#include <vector>

namespace obsidian::api {

// ── Projectile ───────────────────────────────────────────────────────────
// In-flight projectiles (arrows, spells, cannonballs).

/// Field offsets for projectile nodes, relative to the projectile struct base.
/// @note These offsets require final in-game verification.
namespace projectile_offsets {
    constexpr uint32_t Next         = 0x00;
    constexpr uint32_t Prev         = 0x08;
    constexpr uint32_t Id           = 0x10;
    constexpr uint32_t StartCycle   = 0x14;
    constexpr uint32_t EndCycle     = 0x18;
    constexpr uint32_t Slope        = 0x1C;
    constexpr uint32_t StartHeight  = 0x20;
    constexpr uint32_t EndHeight    = 0x24;
    constexpr uint32_t StartX       = 0x28;
    constexpr uint32_t StartY       = 0x2C;
    constexpr uint32_t TargetX      = 0x30;
    constexpr uint32_t TargetY      = 0x34;
    constexpr uint32_t Interacting  = 0x38;
    constexpr uint32_t CurrentX     = 0x48;  // double
    constexpr uint32_t CurrentY     = 0x50;  // double
    constexpr uint32_t CurrentZ     = 0x58;  // double
}


} // namespace obsidian::api
