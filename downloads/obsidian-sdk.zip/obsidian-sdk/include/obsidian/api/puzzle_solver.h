#pragma once
/// @file puzzle_solver.h
/// @brief Reusable puzzle solvers: sliding puzzle (5x5) and light box.
/// Ported from RuneLite's puzzlesolver plugin.
///
/// Usage:
/// @code
///   auto solution = obsidian::api::puzzle::solve_sliding({0,1,2,...,24,-1});
///   auto lights = obsidian::api::puzzle::solve_lightbox(initial, switches);
/// @endcode

#include <array>
#include <vector>
#include <cstdint>
#include <cmath>
#include <algorithm>
#include <optional>

namespace obsidian::api::puzzle {

// ════════════════════════════════════════════════════════════════════════
// Sliding Puzzle Solver (5x5 tile rearrangement, IDA* + Manhattan)
// ════════════════════════════════════════════════════════════════════════

constexpr int SLIDE_DIM = 5;
constexpr int SLIDE_SIZE = SLIDE_DIM * SLIDE_DIM;
constexpr int BLANK_TILE = -1;

struct SlideState {
    std::array<int, SLIDE_SIZE> pieces{};
    int empty = -1;
    int h = -1;
    int parent_empty = -1;

    int piece(int x, int y) const { return pieces[y * SLIDE_DIM + x]; }

    void find_empty() {
        for (int i = 0; i < SLIDE_SIZE; i++)
            if (pieces[i] == BLANK_TILE) { empty = i; return; }
    }

    int manhattan() {
        if (h >= 0) return h;
        h = 0;
        for (int x = 0; x < SLIDE_DIM; x++) {
            for (int y = 0; y < SLIDE_DIM; y++) {
                int p = piece(x, y);
                if (p == BLANK_TILE) continue;
                h += std::abs(x - p % SLIDE_DIM) + std::abs(y - p / SLIDE_DIM);
            }
        }
        return h;
    }

    std::vector<SlideState> moves() const {
        std::vector<SlideState> result;
        int ex = empty % SLIDE_DIM, ey = empty / SLIDE_DIM;
        auto try_move = [&](int target) {
            if (parent_empty == target) return;
            SlideState s = *this;
            s.parent_empty = empty;
            s.pieces[empty] = pieces[target];
            s.pieces[target] = BLANK_TILE;
            s.empty = target;
            s.h = -1;
            result.push_back(s);
        };
        if (ex > 0) try_move(empty - 1);
        if (ex < SLIDE_DIM - 1) try_move(empty + 1);
        if (ey > 0) try_move(empty - SLIDE_DIM);
        if (ey < SLIDE_DIM - 1) try_move(empty + SLIDE_DIM);
        return result;
    }

    SlideState swap(int x1, int y1, int x2, int y2) const {
        SlideState s = *this;
        std::swap(s.pieces[y1 * SLIDE_DIM + x1], s.pieces[y2 * SLIDE_DIM + x2]);
        s.find_empty();
        s.h = -1;
        return s;
    }
};

namespace detail {

struct Point { int x, y; };

inline Point find_piece(const SlideState& s, int val) {
    for (int x = 0; x < SLIDE_DIM; x++)
        for (int y = 0; y < SLIDE_DIM; y++)
            if (s.piece(x, y) == val) return {x, y};
    return {-1, -1};
}

inline SlideState do_swap(const SlideState& s, Point a, Point b) {
    return s.swap(a.x, a.y, b.x, b.y);
}

inline const SlideState* ida_search(const SlideState& node, int g, int bound,
                                     std::vector<SlideState>& path) {
    int f = g + const_cast<SlideState&>(node).manhattan();
    if (f > bound) return nullptr;
    if (const_cast<SlideState&>(node).manhattan() == 0) {
        path.push_back(node);
        return &path.back();
    }
    for (auto& succ : node.moves()) {
        path.push_back(succ);
        auto* result = ida_search(succ, g + 1, bound, path);
        if (result) return result;
        path.pop_back();
    }
    return nullptr;
}

} // namespace detail

/// Solve a 5x5 sliding puzzle. Returns the sequence of states from start to goal.
/// Pieces are numbered 0-23 in row-major order. -1 is the blank.
/// Returns empty vector if unsolvable within reasonable time.
inline std::vector<SlideState> solve_sliding(const std::array<int, SLIDE_SIZE>& initial) {
    SlideState start;
    start.pieces = initial;
    start.find_empty();

    int bound = start.manhattan();
    for (int iter = 0; iter < 200; iter++) {
        std::vector<SlideState> path;
        path.push_back(start);
        auto* result = detail::ida_search(start, 0, bound, path);
        if (result) return path;
        bound++;
    }
    return {};
}

// ════════════════════════════════════════════════════════════════════════
// Light Box Solver (5x5 grid, 8 switches, brute-force XOR)
// ════════════════════════════════════════════════════════════════════════

constexpr int LIGHT_W = 5;
constexpr int LIGHT_H = 5;
constexpr int LIGHT_SWITCHES = 8;

struct LightState {
    bool grid[LIGHT_W][LIGHT_H] = {};

    void set(int x, int y, bool v) { grid[x][y] = v; }
    bool get(int x, int y) const { return grid[x][y]; }

    bool all_on() const {
        for (int x = 0; x < LIGHT_W; x++)
            for (int y = 0; y < LIGHT_H; y++)
                if (!grid[x][y]) return false;
        return true;
    }

    LightState xor_with(const LightState& other) const {
        LightState result;
        for (int x = 0; x < LIGHT_W; x++)
            for (int y = 0; y < LIGHT_H; y++)
                result.grid[x][y] = grid[x][y] ^ other.grid[x][y];
        return result;
    }
};

struct LightSolution {
    int bits = 0;

    bool switch_used(int idx) const { return (bits >> idx) & 1; }
    int num_moves() const {
        int c = 0;
        for (int i = 0; i < LIGHT_SWITCHES; i++) c += (bits >> i) & 1;
        return c;
    }
};

/// Solve a light box puzzle. Returns the combination of switches to toggle.
/// initial = current light state, switches[0..7] = effect of each switch (XOR mask).
/// A null optional in switches means that switch hasn't been discovered yet.
/// Returns nullopt if no solution found.
inline std::optional<LightSolution> solve_lightbox(
    const LightState& initial,
    const std::array<std::optional<LightState>, LIGHT_SWITCHES>& switches)
{
    std::optional<LightSolution> best;

    for (int i = 0; i < (1 << LIGHT_SWITCHES); i++) {
        LightState s = initial;
        bool valid = true;

        for (int bit = 0; bit < LIGHT_SWITCHES; bit++) {
            if ((i >> bit) & 1) {
                if (!switches[bit]) { valid = false; break; }
                s = s.xor_with(*switches[bit]);
            }
        }

        if (!valid) continue;
        if (!s.all_on()) continue;

        LightSolution sol{i};
        if (!best || sol.num_moves() < best->num_moves())
            best = sol;
    }

    return best;
}

} // namespace obsidian::api::puzzle
