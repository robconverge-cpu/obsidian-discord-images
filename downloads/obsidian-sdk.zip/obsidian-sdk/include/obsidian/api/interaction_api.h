#pragma once
/// @file interaction_api.h
/// @brief Low-level game interactions — widget clicks, raw DoAction, synth bypass.
///
/// Most interaction functions have moved to domain namespaces:
/// - npcs::interact() — see npcs.h
/// - objects::interact() — see objects_api.h
/// - movement::walk_to() — see movement.h
/// - magic::cast() — see magic.h
/// - inventory::interact_by_id() — see inventory.h

#include <cstdint>
#include <string>

namespace obsidian::api {

// -- Mouse Synth Bypass (RAII guard, root type) --
/// RAII guard that suppresses mouse-movement synthesis for its lifetime.
struct SynthBypass {
    SynthBypass();
    ~SynthBypass();
    SynthBypass(const SynthBypass&) = delete;
    SynthBypass& operator=(const SynthBypass&) = delete;
};

namespace interaction {

// -- NPC low-level (raw menu action type) --
/// Interact with an NPC by index using a raw menu-action opcode.
void interact_npc_action(int32_t npc_index, int32_t menu_action);

// -- Widget selection (spell targeting, item use-on) --
/// Select a widget for spell targeting / item use-on (optional item id and slot).
void set_selected_widget(int32_t packed_widget_id, int32_t item_id = -1, int32_t slot = -1);

// -- Item on Item --
/// Use an inventory item on an NPC.
void use_item_on_npc(int32_t item_slot, int32_t item_id, int32_t npc_index, int32_t delay_ticks = 1);
/// Use an inventory item on a scene object at the given scene coords.
void use_item_on_object(int32_t item_slot, int32_t item_id, int32_t object_id, int32_t scene_x, int32_t scene_y, int32_t delay_ticks = 1);
/// Use one inventory item on another inventory item.
void use_item_on_item(int32_t source_slot, int32_t source_item_id,
                      int32_t target_slot, int32_t target_item_id,
                      int32_t delay_ticks = 1);

// -- Spell on target --
/// Cast a spell (by spell widget) on an NPC.
void cast_spell_on_npc(int32_t spell_widget, int32_t npc_index, int32_t delay_ticks = 1);
/// Cast a spell on a scene object at the given scene coords.
void cast_spell_on_object(int32_t spell_widget, int32_t object_id, int32_t scene_x, int32_t scene_y, int32_t delay_ticks = 1);
/// Cast a spell on an inventory item.
void cast_spell_on_item(int32_t spell_widget, int32_t item_slot, int32_t item_id, int32_t delay_ticks = 1);
/// Cast a spell on a player by index.
void cast_spell_on_player(int32_t spell_widget, int32_t player_id, int32_t delay_ticks = 1);
/// Cast a spell on a ground item at the given scene coords.
void cast_spell_on_ground_item(int32_t spell_widget, int32_t item_id, int32_t scene_x, int32_t scene_y, int32_t delay_ticks = 1);

// -- Low-Level DoAction --
/// Low-level DoAction dispatch; optionally bypassing mouse synth.
///
/// @return Whether the action was **accepted for dispatch** — NOT whether the
///         game acted on it. What a `true` guarantees depends on the side:
///         - core (in-process): the action reached the game — queued on the
///           mouse synth, or dispatched through DoAction without faulting.
///         - host/plugin (over IPC): the command was published into the
///           command ring and core will consume it. A later core-side guard
///           can still reject it; see `api::actions` for the counters that
///           expose that.
///         A `false` always means the action definitely did not happen.
bool invoke_action(int32_t p0, int32_t p1, int32_t opType,
                   int32_t identifier, int32_t itemID = -1,
                   bool bypass_synth = false);

/// Returns true if mouse-synth bypass is currently active.
bool is_synth_bypassed();

} // namespace interaction

} // namespace obsidian::api
