#pragma once
/// @file query_builder.h
/// @brief Chainable query builders for NPCs, Players, Objects, GroundItems.
///
/// Usage (C++):
///   auto guard = npcs::query()
///       .nameEquals("Guard")
///       .isAlive()
///       .within(10)
///       .first();
///
/// The JS/TS API mirrors this exactly:
///   const guard = obsidian.npcs.query()
///       .nameEquals("Guard")
///       .isAlive()
///       .within(10)
///       .first();

#include <obsidian/api/npcs.h>
#include <obsidian/api/players.h>
#include <obsidian/api/objects_api.h>
#include <obsidian/api/ground_items.h>
#include <obsidian/api/local_player.h>
#include <obsidian/api/definitions_api.h>
#include <obsidian/api/str_util.h>
#include <functional>
#include <vector>
#include <optional>
#include <string>
#include <algorithm>
#include <cmath>

namespace obsidian::api {

// ── Generic query base ─────────────────────────────────────────────────

/// CRTP base for all query builders: accumulates filters, then folds via terminals.
template<typename T, typename Derived>
class QueryBase {
protected:
    std::vector<std::function<bool(const T&)>> filters_;

    Derived& self() { return static_cast<Derived&>(*this); }

    bool passes(const T& item) const {
        for (auto& f : filters_)
            if (!f(item)) return false;
        return true;
    }

public:
    /// Add a custom predicate; only items for which it returns true are kept.
    Derived& where(std::function<bool(const T&)> pred) {
        filters_.push_back(std::move(pred));
        return self();
    }

    /// The first match, or nullopt if none.
    std::optional<T> first() {
        for (auto& item : self().source())
            if (passes(item)) return item;
        return std::nullopt;
    }

    /// All matches as a vector.
    std::vector<T> toArray() {
        std::vector<T> result;
        for (auto& item : self().source())
            if (passes(item)) result.push_back(item);
        return result;
    }

    /// Number of matches.
    int count() {
        int n = 0;
        for (auto& item : self().source())
            if (passes(item)) n++;
        return n;
    }

    /// True if at least one entity matches.
    bool any() { return first().has_value(); }

    /// The match nearest to `origin`, or nullopt.
    std::optional<T> nearestTo(WorldPoint origin) {
        std::optional<T> best;
        int32_t best_dist = INT32_MAX;
        for (auto& item : self().source()) {
            if (!passes(item)) continue;
            int32_t d = origin.distance_to(self().location_of(item));
            if (d < best_dist) { best_dist = d; best = item; }
        }
        return best;
    }

    /// The match nearest to the local player, or nullopt.
    std::optional<T> nearest() {
        return nearestTo(local_player::world_location());
    }

    /// Invoke `fn` for each match.
    void forEach(std::function<void(const T&)> fn) {
        for (auto& item : self().source())
            if (passes(item)) fn(item);
    }
};

// ── NPC Query ──────────────────────────────────────────────────────────

/// Fluent query over scene NPCs. Start with npcs::query().
class NpcQuery : public QueryBase<SceneNpc, NpcQuery> {
public:
    /// Backing result set: all NPCs currently in the scene.
    std::vector<SceneNpc> source() { return npcs::find_all(); }
    /// World location of an NPC, used by nearest/nearestTo terminals.
    static WorldPoint location_of(const SceneNpc& n) { return n.location; }

    /// Keep only NPCs whose name matches `name` (case-insensitive, tag-stripped).
    NpcQuery& nameEquals(const std::string& name) {
        return static_cast<NpcQuery&>(where([name](const SceneNpc& n) { return iequals_stripped(n.name, name); }));
    }
    /// Keep only NPCs whose name contains `sub` (case-insensitive, tag-stripped).
    NpcQuery& nameContains(const std::string& sub) {
        return static_cast<NpcQuery&>(where([sub](const SceneNpc& n) {
            return icontains_stripped(n.name, sub);
        }));
    }
    /// Keep only NPCs with the given composition ID.
    NpcQuery& id(int32_t npc_id) {
        return static_cast<NpcQuery&>(where([npc_id](const SceneNpc& n) { return n.npc_id == npc_id; }));
    }
    /// Keep only NPCs that expose the given right-click action (case-insensitive).
    NpcQuery& hasAction(const std::string& action) {
        return static_cast<NpcQuery&>(where([action](const SceneNpc& n) {
            for (auto& a : n.actions) if (iequals(a, action)) return true;
            return false;
        }));
    }
    /// Keep only NPCs that are not dead.
    NpcQuery& isAlive() {
        return static_cast<NpcQuery&>(where([](const SceneNpc& n) { return !n.dead; }));
    }
    /// Keep only NPCs that are dead.
    NpcQuery& isDead() {
        return static_cast<NpcQuery&>(where([](const SceneNpc& n) { return n.dead; }));
    }
    /// Keep only NPCs currently playing an animation.
    NpcQuery& isAnimating() {
        return static_cast<NpcQuery&>(where([](const SceneNpc& n) { return n.animation != -1; }));
    }
    /// Keep only NPCs not currently animating.
    NpcQuery& notAnimating() {
        return static_cast<NpcQuery&>(where([](const SceneNpc& n) { return n.animation == -1; }));
    }
    /// Keep only NPCs playing the given animation ID.
    NpcQuery& animation(int32_t anim) {
        return static_cast<NpcQuery&>(where([anim](const SceneNpc& n) { return n.animation == anim; }));
    }
    /// Keep only NPCs within `radius` tiles of the local player.
    NpcQuery& within(int32_t radius) {
        auto origin = local_player::world_location();
        return static_cast<NpcQuery&>(where([origin, radius](const SceneNpc& n) {
            return origin.distance_to(n.location) <= radius;
        }));
    }
    /// Keep only NPCs within `radius` tiles of `origin`.
    NpcQuery& within(int32_t radius, WorldPoint origin) {
        return static_cast<NpcQuery&>(where([origin, radius](const SceneNpc& n) {
            return origin.distance_to(n.location) <= radius;
        }));
    }
    /// Keep only NPCs that can currently be interacted with.
    NpcQuery& interactable() {
        return static_cast<NpcQuery&>(where([](const SceneNpc& n) { return n.interactable; }));
    }
};

// ── Player Query ───────────────────────────────────────────────────────

/// Fluent query over scene players. Start with players::query().
class PlayerQuery : public QueryBase<ScenePlayer, PlayerQuery> {
public:
    /// Backing result set: all players currently in the scene.
    std::vector<ScenePlayer> source() { return players::find_all(); }
    /// World location of a player, used by nearest/nearestTo terminals.
    static WorldPoint location_of(const ScenePlayer& p) { return p.location; }

    /// Keep only players whose name matches `name` (case-insensitive).
    PlayerQuery& nameEquals(const std::string& name) {
        return static_cast<PlayerQuery&>(where([name](const ScenePlayer& p) { return iequals(p.name, name); }));
    }
    /// Keep only players within `radius` tiles of the local player.
    PlayerQuery& within(int32_t radius) {
        auto origin = local_player::world_location();
        return static_cast<PlayerQuery&>(where([origin, radius](const ScenePlayer& p) {
            return origin.distance_to(p.location) <= radius;
        }));
    }
    /// Keep only players who are skulled.
    PlayerQuery& isSkulled() {
        return static_cast<PlayerQuery&>(where([](const ScenePlayer& p) {
            return p.skull_icon != SkullIcon::NONE;
        }));
    }
};

// ── Object Query ───────────────────────────────────────────────────────

/// Fluent query over scene objects (game/wall/decorative/ground). Start with objects::query().
class ObjectQuery : public QueryBase<SceneObject, ObjectQuery> {
    int32_t filter_id_ = -1;
    std::string filter_name_;
public:
    /// Backing result set: objects matching the id/name pre-filter, or all if no filter set.
    std::vector<SceneObject> source() {
        if (filter_id_ >= 0) return objects::find_objects(filter_id_);
        if (!filter_name_.empty()) return objects::find_objects_by_name(filter_name_);
        return objects::find_all();
    }
    /// World location of an object, used by nearest/nearestTo terminals.
    static WorldPoint location_of(const SceneObject& o) { return o.location; }

    /// Restrict the source scan to objects with the given ID.
    ObjectQuery& id(int32_t obj_id) { filter_id_ = obj_id; return *this; }
    /// Keep only objects whose name matches `name` (case-insensitive, tag-stripped).
    /// When used as the FIRST filter, also pre-filters the source scan.
    ObjectQuery& nameEquals(const std::string& name) {
        filter_name_ = name;
        return static_cast<ObjectQuery&>(where([name](const SceneObject& o) {
            auto def = definitions::object(o.id);
            return def && iequals_stripped(def->name, name);
        }));
    }
    /// Keep only objects whose name contains `sub` (case-insensitive, tag-stripped).
    ObjectQuery& nameContains(const std::string& sub) {
        return static_cast<ObjectQuery&>(where([sub](const SceneObject& o) {
            auto def = definitions::object(o.id);
            return def && icontains_stripped(def->name, sub);
        }));
    }
    /// Keep only objects that expose the given right-click action (case-insensitive).
    ObjectQuery& hasAction(const std::string& action) {
        return static_cast<ObjectQuery&>(where([action](const SceneObject& o) {
            auto def = definitions::object(o.id);
            if (!def) return false;
            for (auto& a : def->actions) if (iequals(a, action)) return true;
            return false;
        }));
    }
    /// Keep only objects within `radius` tiles of the local player.
    ObjectQuery& within(int32_t radius) {
        auto origin = local_player::world_location();
        return static_cast<ObjectQuery&>(where([origin, radius](const SceneObject& o) {
            return origin.distance_to(o.location) <= radius;
        }));
    }
};

// ── Ground Item Query ──────────────────────────────────────────────────

/// Fluent query over ground items. Start with ground_items::query().
class GroundItemQuery : public QueryBase<GroundItem, GroundItemQuery> {
public:
    /// Backing result set: all ground items currently in the scene.
    std::vector<GroundItem> source() { return ground_items::find_all(); }
    /// World location of a ground item, used by nearest/nearestTo terminals.
    static WorldPoint location_of(const GroundItem& gi) {
        return {gi.world_x, gi.world_y, gi.plane};
    }

    /// Keep only ground items with the given item ID.
    GroundItemQuery& id(int32_t item_id) {
        return static_cast<GroundItemQuery&>(where([item_id](const GroundItem& gi) {
            return gi.id == item_id;
        }));
    }
    /// Keep only ground items within `radius` tiles of the local player.
    GroundItemQuery& within(int32_t radius) {
        auto origin = local_player::world_location();
        return static_cast<GroundItemQuery&>(where([origin, radius](const GroundItem& gi) {
            WorldPoint gp{gi.world_x, gi.world_y, gi.plane};
            return origin.distance_to(gp) <= radius;
        }));
    }
};

// ── Factory functions on existing namespaces ───────────────────────────

/// Begin a fluent query over scene NPCs.
namespace npcs { inline NpcQuery query() { return {}; } }
/// Begin a fluent query over scene players.
namespace players { inline PlayerQuery query() { return {}; } }
/// Begin a fluent query over scene objects.
namespace objects { inline ObjectQuery query() { return {}; } }
/// Begin a fluent query over ground items.
namespace ground_items { inline GroundItemQuery query() { return {}; } }

} // namespace obsidian::api
