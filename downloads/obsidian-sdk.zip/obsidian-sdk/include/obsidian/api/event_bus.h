#pragma once
/// @file event_bus.h
/// @brief Type-safe pub/sub event system for plugins.
/// @ingroup events
///
/// Mirrors RuneLite's EventBus. Plugins subscribe to specific event types
/// and receive callbacks when events fire.
///
/// ### Usage
/// @code
/// auto& bus = obsidian::api::get_event_bus();
/// auto sub = bus.subscribe<GameTickEvent>([](const GameTickEvent& e) { ... });
/// // sub auto-unsubscribes on destruction (RAII)
/// @endcode
///
/// @note Thread safety: All subscribe/fire calls must happen on the game thread.
/// This is enforced by the core DLL's hook architecture.

#include <cstdint>
#include <functional>
#include <vector>
#include <algorithm>
#include <typeindex>
#include <unordered_map>
#include <memory>

namespace obsidian::api {

/// @brief RAII subscription handle — automatically unsubscribes on destruction.
///
/// Move-only. Calling cancel() or letting the handle go out of scope
/// removes the subscription from the EventBus.
class EventBus; // forward

class EventSubscription {
    friend class EventBus;
    EventBus* bus_ = nullptr;
    uint64_t id_ = 0;
    std::type_index type_ = typeid(void);

    EventSubscription(EventBus* bus, uint64_t id, std::type_index type)
        : bus_(bus), id_(id), type_(type) {}

public:
    EventSubscription() = default;
    EventSubscription(EventSubscription&& o) noexcept
        : bus_(o.bus_), id_(o.id_), type_(o.type_) { o.bus_ = nullptr; }
    EventSubscription& operator=(EventSubscription&& o) noexcept {
        if (this != &o) { cancel(); bus_ = o.bus_; id_ = o.id_; type_ = o.type_; o.bus_ = nullptr; }
        return *this;
    }
    EventSubscription(const EventSubscription&) = delete;
    EventSubscription& operator=(const EventSubscription&) = delete;

    ~EventSubscription() { cancel(); }
    /// @brief Manually unsubscribe. Safe to call multiple times.
    void cancel();  // defined after EventBus

    /// @brief Forget the subscription WITHOUT touching the bus. For process
    /// teardown only: a namespace-scope EventSubscription is destroyed by the
    /// CRT after the bus it points at (static destruction order), and
    /// cancel() then erases from a dead map. Call this from DllMain's
    /// PROCESS_DETACH path (before CRT static destruction) so the destructor
    /// becomes a no-op; the bus is being destroyed anyway.
    void release() noexcept { bus_ = nullptr; }

    /// @brief Returns true if this handle is still subscribed.
    bool valid() const { return bus_ != nullptr; }
    /// @brief Returns the internal subscription ID.
    uint64_t id() const { return id_; }
};

/// @brief Central event dispatcher — type-safe pub/sub for game events.
///
/// Plugins subscribe to event structs (e.g. GameTickEvent, NpcSpawnedEvent)
/// and receive callbacks when the core DLL fires those events.
/// Subscriptions return RAII handles that auto-unsubscribe on destruction.
///
/// @see EventSubscription, events.h
class EventBus {
    struct HandlerEntry {
        uint64_t id;
        int priority;
        std::function<void(const void*)> handler;
    };

    std::unordered_map<std::type_index, std::vector<HandlerEntry>> handlers_;
    uint64_t next_id_ = 1;
    bool paused_ = false;

    // Replay providers: fire cached state to a single new subscriber.
    // Registered by the host for event types that have persistent scene state
    // (e.g. GameObjectSpawnedEvent). When a new handler subscribes, any
    // registered provider replays existing events to that handler only —
    // matching RuneLite's behaviour where toggling a plugin on mid-session
    // fires spawn events for all currently-loaded objects.
    using ReplayFn = std::function<void(const std::function<void(const void*)>&)>;
    std::unordered_map<std::type_index, ReplayFn> replay_providers_;

public:
    /// @brief Register a replay provider for event type @p E.
    /// The provider is called once for each new subscriber to @p E, passing a
    /// fire-one callback. The provider should invoke that callback for every
    /// cached event of type @p E.
    template<typename E>
    void register_replay(std::function<void(const std::function<void(const E&)>&)> provider) {
        replay_providers_[std::type_index(typeid(E))] =
            [p = std::move(provider)](const std::function<void(const void*)>& raw) {
                p([&raw](const E& event) { raw(&event); });
            };
    }

    /// @brief Remove the replay provider for event type @p E.
    template<typename E>
    void remove_replay() { replay_providers_.erase(std::type_index(typeid(E))); }

    /// @brief Subscribe to events of type @p E.
    /// @tparam E The event struct type (e.g. GameTickEvent).
    /// @param handler Callback invoked when the event fires.
    /// @param priority Lower values are called first (default 0).
    /// @return RAII handle that auto-unsubscribes on destruction.
    ///
    /// If a replay provider is registered for @p E, the new handler
    /// immediately receives all cached events (e.g. every scene object
    /// currently loaded). This matches RuneLite's replay-on-subscribe
    /// behaviour for spawn events.
    template<typename E>
    EventSubscription subscribe(std::function<void(const E&)> handler, int priority = 0) {
        auto type = std::type_index(typeid(E));
        uint64_t id = next_id_++;

        // Capture handler before moving it — replay needs the original
        std::function<void(const E&)> handler_copy = handler;

        auto& vec = handlers_[type];
        vec.push_back({id, priority, [h = std::move(handler)](const void* ptr) {
            h(*static_cast<const E*>(ptr));
        }});

        // Keep sorted by priority
        std::stable_sort(vec.begin(), vec.end(),
            [](const HandlerEntry& a, const HandlerEntry& b) { return a.priority < b.priority; });

        // Replay existing state to this subscriber only
        auto replay_it = replay_providers_.find(type);
        if (replay_it != replay_providers_.end()) {
            auto wrapper = [&handler_copy](const void* ptr) {
                handler_copy(*static_cast<const E*>(ptr));
            };
            replay_it->second(wrapper);
        }

        return EventSubscription(this, id, type);
    }

    /// @brief Pause or resume event dispatch.
    /// When paused, fire() and fire_consumable() are no-ops.
    /// Used during logout to prevent handlers from reading stale memory.
    void set_paused(bool p) { paused_ = p; }
    /// @brief Returns true if the bus is paused.
    bool paused() const { return paused_; }

    /// @brief Fire an event to all subscribers of type @p E.
    /// @tparam E The event struct type.
    /// @param event The event instance to dispatch.
    /// @note Copies the handler vector before iterating, so handlers
    ///       can safely unsubscribe during dispatch.
    template<typename E>
    void fire(const E& event) {
        if (paused_) return;
        auto it = handlers_.find(std::type_index(typeid(E)));
        if (it == handlers_.end()) return;
        auto handlers_copy = it->second; // copy — safe if handler modifies original
        for (auto& entry : handlers_copy) {
            entry.handler(&event);
        }
    }

    /// @brief Fire a consumable event.
    /// @tparam E The event struct type (must have a `consumed` bool field).
    /// @param event The event instance (mutable — handlers may set `consumed = true`).
    /// @return True if any handler consumed the event.
    template<typename E>
    bool fire_consumable(E& event) {
        if (paused_) return false;
        auto it = handlers_.find(std::type_index(typeid(E)));
        if (it == handlers_.end()) return false;
        auto handlers_copy = it->second; // copy — safe if handler modifies original
        for (auto& entry : handlers_copy) {
            entry.handler(&event);
            if (event.consumed) return true;
        }
        return false;
    }

    /// @brief Remove a subscription by type and ID (called by EventSubscription::cancel).
    void remove(std::type_index type, uint64_t id) {
        auto it = handlers_.find(type);
        if (it == handlers_.end()) return;
        auto& vec = it->second;
        vec.erase(std::remove_if(vec.begin(), vec.end(),
            [id](const HandlerEntry& e) { return e.id == id; }), vec.end());
    }

    /// @brief Remove all handlers (e.g., on plugin unload).
    void clear() { handlers_.clear(); }

    /// @brief Count subscribers for a given event type.
    template<typename E>
    size_t subscriber_count() const {
        auto it = handlers_.find(std::type_index(typeid(E)));
        return (it != handlers_.end()) ? it->second.size() : 0;
    }
};

// ── EventSubscription::cancel() ──────────────────────────────────────────
inline void EventSubscription::cancel() {
    if (bus_) {
        bus_->remove(type_, id_);
        bus_ = nullptr;
    }
}

/// @brief Internal pointer storage. Prefer get_event_bus().
/// @details Core DLL owns the instance and sets the pointer during init.
/// Plugin DLLs get their own static pointer set by the plugin loader
/// before calling create_plugin(), avoiding the per-DLL singleton problem.
inline EventBus*& event_bus_ptr() { static EventBus* p = nullptr; return p; }

/// @brief Get the global EventBus instance.
/// @return Reference to the shared EventBus.
inline EventBus& get_event_bus() {
    auto* p = event_bus_ptr();
    if (!p) {
        // Fallback: create a local instance (core DLL on first call)
        static EventBus fallback;
        event_bus_ptr() = &fallback;
        return fallback;
    }
    return *p;
}

/// @brief Set the global EventBus pointer (called by core DLL during init).
inline void set_event_bus(EventBus* bus) { event_bus_ptr() = bus; }

} // namespace obsidian::api
