#pragma once
/// @file rune.h
/// @brief Rune item IDs and combo/staff substitution data.

#include <cstdint>

namespace obsidian::api {

/// Rune item IDs.  Values match in-game item IDs.
enum class Rune : int32_t {
    AIR    = 556,
    WATER  = 555,
    EARTH  = 557,
    FIRE   = 554,
    MIND   = 558,
    BODY   = 559,
    DEATH  = 560,
    NATURE = 561,
    CHAOS  = 562,
    LAW    = 563,
    COSMIC = 564,
    BLOOD  = 565,
    SOUL   = 566,
    ASTRAL = 9075,
    WRATH  = 21880,
    // Combo runes (RuneLite ItemID, verified 2026-09-14: the previous values
    // had mud/dust/steam/smoke shuffled — 4701 isn't even a rune)
    STEAM  = 4694,
    MIST   = 4695,
    DUST   = 4696,
    SMOKE  = 4697,
    MUD    = 4698,
    LAVA   = 4699,
    SUNFIRE = 28929, ///< substitutes fire
    AETHER  = 30843, ///< substitutes soul + cosmic
};

} // namespace obsidian::api
