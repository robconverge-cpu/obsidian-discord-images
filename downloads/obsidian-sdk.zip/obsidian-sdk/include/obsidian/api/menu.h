#pragma once
/// @file menu.h
/// @brief Right-click menu entry manipulation (read and write access).
/// @ingroup ui
// ═══════════════════════════════════════════════════════════════════════════
// MENU API — Full menu entry manipulation matching RuneLite's Menu/MenuEntry
// ═══════════════════════════════════════════════════════════════════════════
// Provides read/write access to the game's right-click menu entries.
// MenuEntry wraps a live pointer into the menu struct — setters write
// directly to game memory. All operations must run on the game thread
// (inside AddEntry or DoAction hooks).
//
// RuneLite equivalent:
//   client.getMenu().createMenuEntry(-1)
//       .setOption("My Action")
//       .setTarget("<col=00ff00>Target")
//       .setType(MenuAction.RUNELITE)
//       .onClick(e -> { ... });
// ═══════════════════════════════════════════════════════════════════════════


#include <cstdint>
#include <cstring>
#include <string>
#include <vector>
#include <functional>
#include <unordered_map>

namespace obsidian::api {

/// Menu action type constants (1:1 with RuneLite MenuAction.java).
/// Used in MenuEntry::type() and MenuEntry::set_type().
namespace MenuAction {
    // Game Object interactions
    constexpr int WIDGET_TARGET_ON_GAME_OBJECT = 2;
    constexpr int GAME_OBJECT_FIRST_OPTION     = 3;
    constexpr int GAME_OBJECT_SECOND_OPTION    = 4;
    constexpr int GAME_OBJECT_THIRD_OPTION     = 5;
    constexpr int GAME_OBJECT_FOURTH_OPTION    = 6;
    constexpr int GAME_OBJECT_FIFTH_OPTION     = 1001;

    // NPC interactions
    constexpr int WIDGET_TARGET_ON_NPC         = 8;
    constexpr int NPC_FIRST_OPTION             = 9;
    constexpr int NPC_SECOND_OPTION            = 10;
    constexpr int NPC_THIRD_OPTION             = 11;
    constexpr int NPC_FOURTH_OPTION            = 12;
    constexpr int NPC_FIFTH_OPTION             = 13;

    // Player interactions
    constexpr int WIDGET_TARGET_ON_PLAYER      = 15;
    constexpr int PLAYER_FIRST_OPTION          = 44;
    constexpr int PLAYER_SECOND_OPTION         = 45;
    constexpr int PLAYER_THIRD_OPTION          = 46;
    constexpr int PLAYER_FOURTH_OPTION         = 47;
    constexpr int PLAYER_FIFTH_OPTION          = 48;
    constexpr int PLAYER_SIXTH_OPTION          = 49;
    constexpr int PLAYER_SEVENTH_OPTION        = 50;
    constexpr int PLAYER_EIGHTH_OPTION         = 51;

    // Ground item interactions
    constexpr int WIDGET_TARGET_ON_GROUND_ITEM = 17;
    constexpr int GROUND_ITEM_FIRST_OPTION     = 18;
    constexpr int GROUND_ITEM_SECOND_OPTION    = 19;
    constexpr int GROUND_ITEM_THIRD_OPTION     = 20;
    constexpr int GROUND_ITEM_FOURTH_OPTION    = 21;
    constexpr int GROUND_ITEM_FIFTH_OPTION     = 22;

    // Movement & widgets
    // WALK (23) is the menu-entry tag for "Walk here" right-click entries
    // (matches RuneLite MenuAction.WALK). The game passes this to DoAction
    // with p0/p1 = MOUSE PIXEL COORDINATES; internally it routes through
    // SetDeferredGroundOp and resolves to a tile on the next tick via
    // ray-cast. Use this for menu-entry classification (is_walk()), NOT
    // for calling DoAction programmatically — you'd need real mouse coords.
    constexpr int WALK                         = 23;
    // Direct-walk opType. Pass with p0=scene_x, p1=scene_y to trigger the
    // native direct scene-coordinate walk path (what walk_to() uses). Not a
    // RuneLite-enumerated value — it's native-internal only.
    constexpr int NATIVE_WALK_DIRECT           = 31;
    constexpr int WIDGET_TYPE_1                = 24;
    constexpr int WIDGET_TARGET                = 25;
    constexpr int WIDGET_CLOSE                 = 26;
    constexpr int WIDGET_TYPE_4                = 28;
    constexpr int WIDGET_TYPE_5                = 29;
    constexpr int WIDGET_CONTINUE              = 30;

    // Widget options
    constexpr int WIDGET_FIRST_OPTION          = 39;
    constexpr int WIDGET_SECOND_OPTION         = 40;
    constexpr int WIDGET_THIRD_OPTION          = 41;
    constexpr int WIDGET_FOURTH_OPTION         = 42;
    constexpr int WIDGET_FIFTH_OPTION          = 43;

    // Component operations
    constexpr int CC_OP                        = 57;
    constexpr int WIDGET_TARGET_ON_WIDGET      = 58;
    constexpr int SET_HEADING                  = 60;

    // World entities
    constexpr int WORLD_ENTITY_FIRST_OPTION    = 63;
    constexpr int WORLD_ENTITY_SECOND_OPTION   = 64;
    constexpr int WORLD_ENTITY_THIRD_OPTION    = 65;
    constexpr int WORLD_ENTITY_FOURTH_OPTION   = 66;
    constexpr int WORLD_ENTITY_FIFTH_OPTION    = 67;

    // Obsidian custom actions (equivalent to RuneLite's RUNELITE_*)
    constexpr int OBSIDIAN_WIDGET              = 998;
    constexpr int OBSIDIAN_HIGH_PRIORITY       = 999;

    // Examine / Cancel
    constexpr int EXAMINE_OBJECT               = 1002;
    constexpr int EXAMINE_NPC                  = 1003;
    constexpr int EXAMINE_ITEM_GROUND          = 1004;
    constexpr int CANCEL                       = 1006;
    constexpr int CC_OP_LOW_PRIORITY           = 1007;
    constexpr int EXAMINE_WORLD_ENTITY         = 1013;

    // Obsidian custom (equivalent to RuneLite's RUNELITE_*)
    constexpr int OBSIDIAN                     = 1500;
    constexpr int OBSIDIAN_OVERLAY             = 1501;
    constexpr int OBSIDIAN_OVERLAY_CONFIG      = 1502;
    constexpr int OBSIDIAN_PLAYER              = 1503;
    constexpr int OBSIDIAN_INFOBOX             = 1504;
    constexpr int OBSIDIAN_LOW_PRIORITY        = 1506;

    // RuneLite compat aliases
    constexpr int RUNELITE                     = OBSIDIAN;
    constexpr int RUNELITE_OVERLAY             = OBSIDIAN_OVERLAY;
    constexpr int RUNELITE_PLAYER              = OBSIDIAN_PLAYER;

    constexpr int UNKNOWN                      = -1;
    constexpr int DEPRIORITIZE_OFFSET          = 2000;
}

/// Callback invoked when a custom menu entry is clicked.
/// Stored per entry index, cleared on each menu rebuild, fired from the DoAction hook.
using MenuClickCallback = std::function<void()>;

namespace detail {
    inline std::unordered_map<int32_t, MenuClickCallback>& click_callbacks() {
        static std::unordered_map<int32_t, MenuClickCallback> cbs;
        return cbs;
    }
    inline void clear_click_callbacks() { click_callbacks().clear(); }
}

namespace menu {

/// Create a custom right-click menu entry. Call each tick — entries are
/// transient (cleared every menu rebuild, same as RuneLite).
/// When clicked, fires MenuOptionClickedEvent with menu_action = type.
///
/// @param index    Insertion position. -1 = first position (left-click default).
/// @param option   Action text (e.g. "Teleport").
/// @param target   Target text with color tags (e.g. "<col=00ff00>Home").
/// @param type     MenuAction type. Default: 1500 (OBSIDIAN custom entry).
/// @param identifier  Plugin-defined ID for matching clicks.
/// @param param0   Custom parameter 0.
/// @param param1   Custom parameter 1.
/// @param item_id  Item ID (-1 if N/A).
void create_entry(int32_t index, const std::string& option,
                  const std::string& target,
                  int32_t type = 1500, int32_t identifier = 0,
                  int32_t param0 = 0, int32_t param1 = 0,
                  int32_t item_id = -1,
                  bool force_left_click = false,
                  bool deprioritize_others = false);

/// Overload with onClick callback — stored by identifier, auto-fired from DoAction.
inline void create_entry(int32_t index, const std::string& option,
                         const std::string& target,
                         int32_t type, int32_t identifier,
                         MenuClickCallback on_click,
                         int32_t param0 = 0, int32_t param1 = 0,
                         int32_t item_id = -1,
                         bool force_left_click = false,
                         bool deprioritize_others = false) {
    detail::click_callbacks()[identifier] = std::move(on_click);
    create_entry(index, option, target, type, identifier, param0, param1,
                 item_id, force_left_click, deprioritize_others);
}

/// Remove all custom menu entries matching the given type.
void remove_entries(int32_t type = -1);


/// Snapshot of a single menu entry (read-only copy for event dispatch).
struct MenuEntrySnapshot {
    int32_t type = 0;
    int32_t identifier = 0;
    int32_t param0 = 0;
    int32_t param1 = 0;
    int32_t item_id = -1;
    bool force_left_click = false;
    std::string option;
    std::string target;
};

/// Read the current live menu entries. Game thread only.
std::vector<MenuEntrySnapshot> get_entries();

} // namespace menu


} // namespace obsidian::api
