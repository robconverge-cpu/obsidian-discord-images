#pragma once
/// @file events.h
/// @brief All event structs for the EventBus system.
/// @ingroup events
///
/// Mirrors RuneLite's event classes. Organized by category.
/// Each struct is self-contained -- no inheritance required for EventBus.
/// Some events have a `consumed` field for cancellation support.

#include <obsidian/api/coords.h>
#include <obsidian/api/hitsplat.h>
#include <obsidian/api/chat.h>
#include <obsidian/api/skill.h>
#include <cstdint>
#include <string>
#include <vector>

namespace obsidian::api {

// ─────────────────────────────────────────────────────────────────────────
// EVENT SNAPSHOT CONTRACT
// ─────────────────────────────────────────────────────────────────────────
// - All fields are captured at the moment the change is detected.
// - Snapshots are immutable — modifying fields has no effect on game state.
// - actor.index / npc.index is valid for same-tick correlation only.
//   Post-despawn, indices may be reused by a different entity.
// - For live data queries, use api::find_npc_by_index(index) which returns
//   std::optional<SceneNpc> with current-tick fields.
// - Despawn event snapshots contain the entity's LAST KNOWN state.
// - Sentinel: -1 means "unknown / not available". 0 is a valid value.
// ─────────────────────────────────────────────────────────────────────────

/// @name Snapshot Types
/// @{

/// Base snapshot shared by NPC and Player entities. Contains all fields
/// that are common to both actor types at the moment of capture.
struct ActorSnapshot {
    int32_t index = -1;              ///< Entity slot index (-1 = invalid).
    int32_t local_x = 0;            ///< Fine local X coordinate.
    int32_t local_y = 0;            ///< Fine local Y coordinate.
    int32_t tile_x = 0;             ///< Scene tile X.
    int32_t tile_y = 0;             ///< Scene tile Y.
    int32_t world_x = 0;            ///< World tile X (tile_x + base_x).
    int32_t world_y = 0;            ///< World tile Y (tile_y + base_y).
    int32_t orientation = 0;         ///< Facing direction (0-2047).
    int32_t animation = -1;          ///< Current animation ID (-1 = none).
    int32_t animation_frame = 0;     ///< Current animation frame.
    int32_t pose_animation = -1;     ///< Idle/pose animation ID.
    int32_t interacting_index = -1;  ///< Validated target slot index (-1 = not interacting; stale game values are filtered out via the interaction guard/type, matching devtools).
    int32_t interacting_type = 0;    ///< 0 = not interacting, 1 = target is an NPC, 2 = target is a player. Use this (not just index) to know it's a live interaction.
    int32_t health_ratio = -1;       ///< Raw health bar green width (-1 = no bar visible).
    int32_t health_scale = -1;       ///< Raw health bar max width (-1 = no bar visible).
    bool    is_dead = false;         ///< True if the entity has died.
    char    overhead_text[64] = {};   ///< Overhead chat/emote text (empty = none).
    int32_t graphic = -1;            ///< Current spot anim / graphic ID (-1 = none).
};

/// NPC-specific snapshot. Extends ActorSnapshot with composition data.
struct NpcSnapshot : ActorSnapshot {
    int32_t npc_id = -1;             ///< NPC definition/composition ID.
    char    name[32] = {};            ///< NPC display name.
    int32_t combat_level = 0;        ///< NPC combat level.
    int32_t size = 1;                ///< Tile size (1 = 1x1, 2 = 2x2, etc.).
};

/// Player-specific snapshot. Extends ActorSnapshot with player data.
struct PlayerSnapshot : ActorSnapshot {
    char    name[32] = {};            ///< Player display name.
    int32_t combat_level = 0;        ///< Player combat level.
    int32_t skull_icon = -1;         ///< Skull icon type (-1 = none).
    int32_t overhead_icon = -1;      ///< Prayer overhead icon (-1 = none).
    int32_t friend_status = 0;       ///< 0=local/unchecked, 1=online friend, 2=not a friend.
    int32_t fc_status = 0;           ///< 0=local/unchecked, 1=FC member, 2=not FC member.
    int32_t clan_status = 0;         ///< 0=local/unchecked, 1=clan member, 2=not clan.
};

/// Tile location snapshot — identifies a tile in both scene and world space.
/// Named TileSnapshot to avoid collision with api::Tile (live memory wrapper).
struct TileSnapshot {
    int32_t scene_x = 0, scene_y = 0;
    int32_t world_x = 0, world_y = 0;
    int32_t plane = 0;
};

/// Game object snapshot (interactive loc like trees, rocks, doors).
/// Matches RuneLite's GameObject with getSceneMinLocation() parity.
struct GameObjectSnapshot {
    int32_t id = -1;
    int32_t scene_x = 0, scene_y = 0;     ///< Tag tile (anchor point).
    int32_t world_x = 0, world_y = 0;
    int32_t plane = 0;
    int32_t orientation = 0;
    int32_t fine_x = 0, fine_y = 0;        ///< Center fine coords (local units).
    int32_t start_tile_x = 0, start_tile_y = 0; ///< SW corner scene tile (= getSceneMinLocation).
    int32_t end_tile_x = 0, end_tile_y = 0;     ///< NE corner scene tile.

    /// SW corner scene tile — equivalent to RuneLite's getSceneMinLocation().
    /// Computed from fine coords + footprint size when start_tile fields aren't reliable.
    int32_t scene_min_x() const { return start_tile_x; }
    int32_t scene_min_y() const { return start_tile_y; }
    /// Footprint in tiles — from end - start + 1, or from definition if available.
    int32_t size_x() const { return (end_tile_x >= start_tile_x) ? (end_tile_x - start_tile_x + 1) : 1; }
    int32_t size_y() const { return (end_tile_y >= start_tile_y) ? (end_tile_y - start_tile_y + 1) : 1; }
    /// SW corner world coords.
    int32_t world_min_x(int32_t base_x) const { return base_x + start_tile_x; }
    int32_t world_min_y(int32_t base_y) const { return base_y + start_tile_y; }
};

/// Wall object snapshot (doors, fences).
struct WallObjectSnapshot {
    int32_t id = -1;
    int32_t scene_x = 0, scene_y = 0;
    int32_t world_x = 0, world_y = 0;
    int32_t plane = 0;
    int32_t orientation = 0;
};

/// Decorative object snapshot (floor decorations).
struct DecorativeObjectSnapshot {
    int32_t id = -1;
    int32_t scene_x = 0, scene_y = 0;
    int32_t world_x = 0, world_y = 0;
    int32_t plane = 0;
};

/// Ground object snapshot (items rendered flat on ground).
struct GroundObjectSnapshot {
    int32_t id = -1;
    int32_t scene_x = 0, scene_y = 0;
    int32_t world_x = 0, world_y = 0;
    int32_t plane = 0;
};

/// Ground item snapshot (dropped/spawned items on tiles).
struct TileItemSnapshot {
    int32_t id = -1;
    int32_t quantity = 0;
    int32_t scene_x = 0, scene_y = 0;
    int32_t world_x = 0, world_y = 0;
    int32_t plane = 0;
};

/// Graphics object snapshot (spell impacts, spot anims).
struct GraphicsObjectSnapshot {
    int32_t id = -1;
    int32_t local_x = 0, local_y = 0;  ///< Fine local coords (>>7 for scene tile).
    int32_t height = 0;                ///< Z height offset.
    int32_t plane = 0;
    int32_t start_cycle = 0;           ///< Game cycle the effect began.
    int32_t anim_frame = 0;            ///< Current animation frame (despawn = last seen).
    int32_t anim_id = -1;              ///< Animation sequence ID.
};

/// @}

/// @name Game State & Timing
/// @{

/// @brief Fired every game tick (~600ms).
struct GameTickEvent {
    int32_t tick_count = 0;  ///< The current game tick count.
};

/// @brief Fired every client frame tick.
struct ClientTickEvent {};

/// @brief Fired after client tick processing completes.
struct PostClientTickEvent {};

/// @brief Fired when the game state transitions between states.
struct GameStateChangedEvent {
    int32_t old_state = 0;  ///< The previous game state.
    int32_t new_state = 0;  ///< The new game state.
};

/// @brief Fired when the player hops to a different world.
struct WorldChangedEvent {};

/// @brief Fired when the client window gains or loses focus.
struct FocusChangedEvent {
    bool focused = false;  ///< True if the client now has focus.
};

/// @brief Fired when the client canvas is resized.
struct CanvasSizeChangedEvent {
    int32_t old_width = 0, old_height = 0;   ///< Previous canvas dimensions.
    int32_t new_width = 0, new_height = 0;   ///< New canvas dimensions.
};

/// @brief Fired when the client switches between fixed and resizable display modes.
/// Mirrors RuneLite's ResizeableChanged. Detected via top-level interface ID
/// (548 = fixed, 161/164 = resizable / resizable-stretched).
struct ResizeableChangedEvent {
    bool resized = false;  ///< true = resizable mode, false = fixed mode.
};

/// @}

/// @name Entity Lifecycle
/// @{

/// @brief Fired when an NPC appears in the scene.
struct NpcSpawnedEvent {
    NpcSnapshot npc;  ///< Full snapshot of the NPC at spawn time.
};

/// @brief Fired when an NPC is removed from the scene.
struct NpcDespawnedEvent {
    NpcSnapshot npc;  ///< Last known state of the NPC before removal.
};

/// @brief Fired when an NPC's composition ID changes (e.g. transformation).
struct NpcChangedEvent {
    NpcSnapshot npc;           ///< Snapshot after the change.
    int32_t old_npc_id = -1;   ///< Previous composition ID.
};

/// @brief Fired when a player appears in the scene.
struct PlayerSpawnedEvent {
    PlayerSnapshot player;  ///< Full snapshot of the player at spawn time.
};

/// @brief Fired when a player is removed from the scene.
struct PlayerDespawnedEvent {
    PlayerSnapshot player;  ///< Last known state of the player before removal.
};

/// @brief Fired when a player's appearance or equipment changes.
struct PlayerChangedEvent {
    PlayerSnapshot player;  ///< Snapshot after the change.
};

/// @brief Fired when an actor (NPC or player) dies.
struct ActorDeathEvent {
    ActorSnapshot actor;   ///< Snapshot of the actor at death.
    bool is_npc = false;   ///< True if the actor is an NPC, false if player.
};

/// @}

/// @name Actor State Changes
/// @{

/// @brief Fired when an actor's animation changes.
struct AnimationChangedEvent {
    ActorSnapshot actor;          ///< Snapshot of the actor.
    bool is_npc = false;          ///< True if NPC, false if player.
    int32_t old_animation = -1;   ///< Previous animation ID.
    int32_t new_animation = -1;   ///< New animation ID.
};

/// @brief Fired when an actor's interaction target changes.
struct InteractingChangedEvent {
    ActorSnapshot actor;   ///< Snapshot of the source actor.
    bool is_npc = false;   ///< True if NPC, false if player.
};

/// @brief Fired when an actor's overhead text changes.
struct OverheadTextChangedEvent {
    ActorSnapshot actor;       ///< Snapshot of the actor.
    bool is_npc = false;       ///< True if NPC, false if player.
    char text[64] = {};        ///< The overhead text content.
};

/// @brief Fired when a hitsplat is applied to an actor.
struct HitsplatAppliedEvent {
    ActorSnapshot actor;   ///< Snapshot of the actor receiving the hitsplat.
    bool is_npc = false;   ///< True if NPC, false if player.
    Hitsplat hitsplat;     ///< The hitsplat data.
};

/// @brief Fired when an actor's graphic (GFX) changes.
struct GraphicChangedEvent {
    ActorSnapshot actor;        ///< Snapshot of the actor.
    bool is_npc = false;        ///< True if NPC, false if player.
    int32_t old_graphic = -1;   ///< Previous graphic ID.
    int32_t new_graphic = -1;   ///< New graphic ID.
    // Appended (keep last: plugins built against the shorter struct stay valid).
    int32_t height = 0;         ///< Height of the new spotanim above the tile.
    int32_t start_cycle = 0;    ///< Client cycle the new spotanim starts (cast tick + delay).
};

/// @brief Fired when an actor's spot animation changes.
struct SpotAnimChangedEvent {
    ActorSnapshot actor;        ///< Snapshot of the actor.
    bool is_npc = false;        ///< True if NPC, false if player.
    int32_t spot_anim_id = -1;  ///< The new spot animation ID.
    // Appended (keep last: plugins built against the shorter struct stay valid).
    int32_t height = 0;         ///< Height above the tile.
    int32_t start_cycle = 0;    ///< Client cycle the spotanim starts (cast tick + delay).
};

/// @}

/// @name Scene Objects
/// @{

/// @brief Fired when a game object spawns in the scene.
struct GameObjectSpawnedEvent {
    TileSnapshot tile;
    GameObjectSnapshot game_object;
};

/// @brief Fired when a game object despawns from the scene.
struct GameObjectDespawnedEvent {
    TileSnapshot tile;
    GameObjectSnapshot game_object;
};

/// @brief Fired when a wall object (door, fence) spawns in the scene.
struct WallObjectSpawnedEvent {
    TileSnapshot tile;
    WallObjectSnapshot wall_object;
};

/// @brief Fired when a wall object despawns from the scene.
struct WallObjectDespawnedEvent {
    TileSnapshot tile;
    WallObjectSnapshot wall_object;
};

/// @brief Fired when a decorative object (floor decoration) spawns in the scene.
struct DecorativeObjectSpawnedEvent {
    TileSnapshot tile;
    DecorativeObjectSnapshot decorative_object;
};

/// @brief Fired when a decorative object despawns from the scene.
struct DecorativeObjectDespawnedEvent {
    TileSnapshot tile;
    DecorativeObjectSnapshot decorative_object;
};

/// @brief Fired when a ground object spawns in the scene.
struct GroundObjectSpawnedEvent {
    TileSnapshot tile;
    GroundObjectSnapshot ground_object;
};

/// @brief Fired when a ground object despawns from the scene.
struct GroundObjectDespawnedEvent {
    TileSnapshot tile;
    GroundObjectSnapshot ground_object;
};

/// Fired when a ground SpotAnim (campfire, spell impact, prayer effect, etc.)
/// first appears in the scene. Graphics objects are anchored to a tile and
/// animate in place — they do not move (no Moved event), unlike projectiles.
struct GraphicsObjectSpawnedEvent {
    GraphicsObjectSnapshot graphics_object;
};

/// Fired when a graphics object is removed from the scene (animation finished
/// or scene cleared). Carries the last snapshot captured before it vanished.
struct GraphicsObjectDespawnedEvent {
    GraphicsObjectSnapshot graphics_object;
};

/// Projectile snapshot — captures all data at spawn/move time.
struct ProjectileSnapshot {
    int32_t id = -1;
    int32_t source_x = 0, source_y = 0;
    int32_t target_x = 0, target_y = 0;
    int32_t start_cycle = 0, end_cycle = 0;
    int32_t target_actor_index = -1;
    int32_t plane = 0;
};

/// @brief Fired when a projectile first appears in the scene.
struct ProjectileSpawnedEvent {
    ProjectileSnapshot projectile;
};

/// @brief Fired when a projectile is removed from the scene.
struct ProjectileDespawnedEvent {
    ProjectileSnapshot projectile;
};

/// @brief Fired each tick a projectile moves toward its target.
struct ProjectileMovedEvent {
    ProjectileSnapshot projectile;
};

/// @}

/// @name Items & Containers
/// @{

/// @brief Fired when a ground item appears on a tile.
struct ItemSpawnedEvent {
    TileSnapshot tile;
    TileItemSnapshot item;
};

/// @brief Fired when a ground item is removed from a tile.
struct ItemDespawnedEvent {
    TileSnapshot tile;
    TileItemSnapshot item;
};

/// @brief Fired when a stacked ground item's quantity changes.
struct ItemQuantityChangedEvent {
    TileSnapshot tile;
    TileItemSnapshot item;
    int32_t old_quantity = 0;
    int32_t new_quantity = 0;
};

/// A single item slot within a container snapshot (id=-1 means empty).
struct ContainerSlot {
    int32_t id       = -1; ///< Item definition ID (-1 = empty slot).
    int32_t quantity = 0;  ///< Stack size (0 for empty slots).
};

/// @brief Fired when an item container's contents change (e.g. inventory, bank, equipment).
///
/// Mirrors RuneLite's ItemContainerChanged. Fired every tick for each container
/// whose contents differ from the previous tick. The full slot snapshot is included
/// so plugins don't need a separate read — `items[slot_index]` gives the current state.
///
/// Common container IDs: 93=inventory, 94=equipment, 95=bank.
struct ItemContainerChangedEvent {
    int32_t container_id = -1;           ///< The container ID that changed.
    std::vector<ContainerSlot> items;    ///< Full slot snapshot after the change (all slots, including empty ones).
};

/// @}

/// @name Variables & Skills
/// @{

/// @brief Fired when a varbit or varp value changes.
/// One event per changed varbit; residual varp bits (not covered by any
/// known varbit) fire with varbit_id == -1. Matches RuneLite's
/// VarbitChanged(varpId, varbitId, value) convention.
struct VarbitChangedEvent {
    int32_t varp_id = -1;    ///< The varp index that changed.
    int32_t varbit_id = -1;  ///< The varbit that changed, or -1 for residual varp bits.
    int32_t value = 0;       ///< New varbit value (extracted), or full varp value when varbit_id == -1.
                             ///< Truncated to 32 bits for a 64-bit varp (RuneLite getValue()).
    int64_t long_value = 0;  ///< Full 64-bit value (RuneLite getLongValue()). v241 long varps
                             ///< (e.g. GE price 5753) fire with varbit_id == -1; equals value otherwise.
};

/// @brief Fired when a client integer variable changes.
struct VarClientIntChangedEvent {
    int32_t index = -1;  ///< The client variable index that changed.
};

/// @brief Fired when a client string variable changes.
struct VarClientStrChangedEvent {
    int32_t index = -1;  ///< The client variable index that changed.
};

/// @brief Fired when a skill's level or XP changes.
struct StatChangedEvent {
    Skill skill = Skill::ATTACK;  ///< The skill that changed.
    int32_t old_level = 0;        ///< Previous boosted level.
    int32_t new_level = 0;        ///< New boosted level.
    int32_t old_xp = 0;           ///< Previous total experience.
    int32_t new_xp = 0;           ///< New total experience.
};

/// @brief Fired when the player gains experience in a skill.
struct ExperienceGainedEvent {
    Skill skill = Skill::ATTACK;  ///< The skill that received XP.
    int32_t xp_gained = 0;        ///< Amount of XP gained.
    int32_t total_xp = 0;         ///< Total XP after the gain.
};

/// @}

/// @name Chat & Messages
/// @{

/// @brief Fired when a chat message is received.
struct ChatMessageEvent {
    ChatMessageType type = ChatMessageType::UNKNOWN;  ///< The chat message type.
    std::string name;      ///< Name of the message sender.
    std::string sender;    ///< Sender field (e.g. clan name).
    std::string message;   ///< The message content.
    bool consumed = false; ///< Set to true to suppress the message; enables event cancellation.
};

/// @brief Fired when a player enters a ::command.
struct CommandExecutedEvent {
    std::string command;   ///< The command name (without the :: prefix).
    std::string args;      ///< Arguments following the command.
    bool consumed = false; ///< Set to true to suppress default handling; enables event cancellation.
};

/// @}

/// @name Menu
/// @{

/// @brief Fired synchronously when a menu entry is added in the AddEntry hook.
///
/// The entry pointer is LIVE -- handlers can modify it directly via
/// set_option(), set_type(), set_deprioritized(), etc. The menu pointer
/// allows creating/removing/swapping entries.
struct MenuEntryAddedEvent {
    uintptr_t entry_addr = 0;    ///< Raw entry address (for MenuEntry wrapping).
    int32_t entry_index = -1;    ///< Index in the menu array.
    uintptr_t menu_ptr = 0;      ///< MiniMenu struct address.
    uintptr_t image_base = 0;    ///< Module base used by the Menu factory.
    int32_t type = 0;            ///< Snapshot of the entry's action type.
    int32_t identifier = 0;      ///< Snapshot of the entry's identifier.
    int32_t action_param0 = 0;   ///< Snapshot of the entry's first action parameter.
    int32_t action_param1 = 0;   ///< Snapshot of the entry's second action parameter.
    int32_t item_id = -1;        ///< Snapshot of the entry's item ID.
    std::string option;          ///< Snapshot of the entry's option text.
    std::string target;          ///< Snapshot of the entry's target text.
};

/// @brief Fired synchronously in the DoAction hook before the action executes.
///
/// If consumed, the original DoAction call is skipped entirely.
///
/// To observe widget clicks (the equivalent of RuneLite's "widget pressed"),
/// filter on `is_widget_click()` — RuneLite has no separate WidgetPressed event;
/// widget interactions flow through this same MenuOptionClicked path with
/// `menu_action == MenuAction::CC_OP`.
struct MenuOptionClickedEvent {
    int32_t action_param0 = 0;   ///< First action parameter.
    int32_t action_param1 = 0;   ///< Second action parameter (for widget clicks: packed widget hash).
    int32_t menu_action = 0;     ///< MenuAction type identifier.
    int32_t identifier = 0;      ///< Entry identifier.
    int32_t item_id = -1;        ///< Item ID associated with the action.
    int32_t entry_index = -1;    ///< Index of the clicked entry.
    std::string option;          ///< Option text of the clicked entry.
    std::string target;          ///< Target text of the clicked entry.
    bool consumed = false;       ///< Set to true to cancel the action; enables event cancellation.
    void consume() { consumed = true; }  ///< Helper to cancel the action.

    /// True if this is a widget click (CC_OP, CC_OP_LOW_PRIORITY, WIDGET_*_OPTION,
    /// or WIDGET_TARGET_ON_WIDGET). When true, `widget_group_id()` and `widget_child_id()`
    /// extract the widget components from `action_param1`.
    bool is_widget_click() const {
        const int op = menu_action % 2000;  // strip DEPRIORITIZE_OFFSET
        return op == 57   /* CC_OP */
            || op == 1007 /* CC_OP_LOW_PRIORITY */
            || op == 58   /* WIDGET_TARGET_ON_WIDGET */
            || (op >= 39 && op <= 43);  /* WIDGET_FIRST..FIFTH_OPTION */
    }
    int32_t widget_group_id() const { return (action_param1 >> 16) & 0xFFFF; }
    int32_t widget_child_id() const { return action_param1 & 0xFFFF; }
};

/// @brief Fired when the right-click menu becomes visible.
///
/// The menu pointer is LIVE -- handlers can reorder/modify entries.
struct MenuOpenedEvent {
    uintptr_t menu_ptr = 0;     ///< MiniMenu struct address.
    uintptr_t image_base = 0;   ///< Module base used by the Menu factory.
    int32_t entry_count = 0;    ///< Number of entries in the menu.
};

/// @}

/// @name Widgets
/// @{

/// @brief Fired when a widget group is loaded.
struct WidgetLoadedEvent {
    int32_t group_id = -1;  ///< The widget group ID that was loaded.
};

/// @brief Fired when a widget group is closed.
struct WidgetClosedEvent {
    int32_t group_id = -1;  ///< The widget group ID that was closed.
    bool unload = false;    ///< True if fully unloaded, false if just hidden.
};

/// @brief Fired when a widget group is fully unloaded.
struct WidgetUnloadedEvent {
    int32_t group_id = -1; ///< The widget group ID that was unloaded.
};

// Note: there is no WidgetPressedEvent. RuneLite doesn't have one either —
// widget clicks are observed via MenuOptionClickedEvent::is_widget_click().

/// @}

/// @name Grand Exchange
/// @{

/// @brief Fired when a Grand Exchange offer slot changes state.
struct GrandExchangeOfferChangedEvent {
    int32_t slot = -1;              ///< GE slot index (0-7).
    int32_t state = 0;             ///< Offer state (0=empty, 1=pending, 2=active, 5=finished — completed or cancelled).
    int32_t type = 0;              ///< Offer type (0=buy, 1=sell).
    int32_t item_id = -1;          ///< Item ID of the offer.
    int64_t price = 0;             ///< Price per item (64-bit since v241).
    int32_t total_quantity = 0;    ///< Total quantity requested.
    int32_t quantity_traded = 0;   ///< Quantity traded so far.
    int64_t spent = 0;             ///< Total gold spent or received (64-bit).
};

/// @}

/// @name Map & Scene Loading
/// @{

/// @brief Fired before a new map region begins loading.
struct PreMapLoadEvent {
    int32_t base_x = 0, base_y = 0;  ///< Base tile coordinates of the new region.
};

/// @brief Fired after a new map region finishes loading.
struct MapLoadedEvent {
    int32_t base_x = 0, base_y = 0;  ///< Base tile coordinates of the loaded region.
};

/// @}

/// @name Composition load hooks
/// @{

/// @brief Fired once when an ItemComposition is loaded for the first time.
/// Mirrors RuneLite's PostItemComposition. Plugins can use this to mutate
/// item names, examine text, etc. before any plugin queries the composition.
struct PostItemCompositionEvent {
    int32_t item_id = -1;
    uintptr_t comp_ptr = 0;  ///< Raw ObjType pointer; wrap with api::ItemComposition.
};

/// @brief Fired once when an ObjectComposition (LocType) is loaded for the first time.
/// Mirrors RuneLite's PostObjectComposition.
struct PostObjectCompositionEvent {
    int32_t object_id = -1;
    uintptr_t comp_ptr = 0;  ///< Raw LocType pointer.
};

/// @brief Fired once when an NpcComposition (NpcType) is loaded for the first time.
/// Obsidian extension — RuneLite has no PostNpcComposition.
struct PostNpcCompositionEvent {
    int32_t npc_id = -1;
    uintptr_t comp_ptr = 0;  ///< Raw NpcType pointer.
};

/// @brief Fired once when a StructComposition is loaded for the first time.
/// Mirrors RuneLite's PostStructComposition.
struct PostStructCompositionEvent {
    int32_t struct_id = -1;
    uintptr_t comp_ptr = 0;
};

/// @brief Fired once when a healthbar/hitsplat type config is loaded.
/// Mirrors RuneLite's PostHealthBarConfig.
struct PostHealthBarConfigEvent {
    int32_t config_id = -1;
    uintptr_t config_ptr = 0;
};

/// @brief Fired once when a HitmarkType (hitsplat definition) is loaded.
/// Mirrors RuneLite's PostHitsplatType. Plugins can use this to customise
/// hitsplat visuals per damage type.
struct PostHitsplatTypeEvent {
    int32_t hitsplat_id = -1;
    uintptr_t hitmark_ptr = 0;
};

/// @brief Fired once when an EnumType definition is loaded.
/// Mirrors RuneLite's PostEnumDefinition. EnumTypes back RuneLite's
/// EnumComposition (key/value lookup tables).
struct PostEnumDefinitionEvent {
    int32_t enum_id = -1;
    uintptr_t enum_ptr = 0;
};

/// @brief Fired once when an InvType (inventory container definition) is loaded.
/// Obsidian extension — RuneLite does not have a PostInvType event.
struct PostInvTypeEvent {
    int32_t inv_id = -1;
    uintptr_t inv_ptr = 0;
};

/// @brief Fired when a new world entity (instance shard) appears.
/// Mirrors RuneLite's WorldEntitySpawned. World entities are dynamic
/// instance regions for things like raids and Tombs of Amascut.
struct WorldEntitySpawnedEvent {
    int32_t entity_id = -1;
};

/// @brief Fired when a world entity is removed.
/// Mirrors RuneLite's WorldEntityDespawned.
struct WorldEntityDespawnedEvent {
    int32_t entity_id = -1;
};

/// @brief Fired when a new world view (instance shard) is loaded.
/// Mirrors RuneLite's WorldViewLoaded.
struct WorldViewLoadedEvent {
    uintptr_t world_view_ptr = 0;
};

/// @brief Fired when a world view is unloaded.
/// Mirrors RuneLite's WorldViewUnloaded.
struct WorldViewUnloadedEvent {
    uintptr_t world_view_ptr = 0;
};

// ─────────────────────────────────────────────────────────────────────────
// Stub events — structs match RuneLite for compile-time plugin compatibility
// but the underlying native triggers are not yet wired up. Plugins can
// subscribe; events will start firing once the trigger functions are RE'd.
// ─────────────────────────────────────────────────────────────────────────

/// @brief Fired when the account hash changes — login (0 → hash), logout
///        (hash → 0), or relog to a different character (h1 → h2).
///        Synthesised host-side from a per-tick diff; not a native
///        trigger. RuneLite-parity field layout.
struct AccountHashChangedEvent {
    int64_t account_hash = -1;
};

/// @brief Fired when the local player's display name changes. Covers
///        both the login-seen-first-time case and the rename-in-place
///        case. Synthesised host-side from a per-tick diff.
struct UsernameChangedEvent {
    std::string username;
};

/// @brief Fired when a player's right-click menu options change. NOT YET FIRING.
struct PlayerMenuOptionsChangedEvent {
    int32_t index = -1;
};

/// @brief Fired when a friend or clan member is renamed. NOT YET FIRING.
struct NameableNameChangedEvent {
    std::string old_name;
    std::string new_name;
};

/// @brief Fired when a friend is removed from the friends list.
/// Mirrors RuneLite's RemovedFriend. Wired via FriendSystem::DelFriend hook.
struct RemovedFriendEvent {
    std::string name;
};

/// @brief Fired when a friend is added to the friends list.
/// Obsidian extension (symmetric to RemovedFriend — RuneLite has no
/// corresponding AddedFriend event). Wired via FriendSystem::AddFriend.
struct AddedFriendEvent {
    std::string name;
};

/// @brief Fired when the friends chat changes. NOT YET FIRING.
struct FriendsChatChangedEvent {
    bool joined = false;
};

/// @brief Fired when a friend joins the friends chat. NOT YET FIRING.
struct FriendsChatMemberJoinedEvent {
    std::string name;
};

/// @brief Fired when a friend leaves the friends chat. NOT YET FIRING.
struct FriendsChatMemberLeftEvent {
    std::string name;
};

/// @brief Fired when the active clan channel changes. NOT YET FIRING.
struct ClanChannelChangedEvent {
    int32_t clan_id = -1;
    bool joined = false;
};

/// @brief Fired when a clan member joins the channel. NOT YET FIRING.
struct ClanMemberJoinedEvent {
    int32_t clan_id = -1;
    std::string name;
};

/// @brief Fired when a clan member leaves the channel. NOT YET FIRING.
struct ClanMemberLeftEvent {
    int32_t clan_id = -1;
    std::string name;
};

/// @brief Fired when a sound effect is created (positional, area-bound). NOT YET FIRING.
struct AmbientSoundEffectCreatedEvent {
    int32_t sound_id = -1;
    int32_t scene_x = 0;
    int32_t scene_y = 0;
};

/// @brief Fired when audio volume changes. NOT YET FIRING.
struct VolumeChangedEvent {
    int32_t music_volume = 0;
    int32_t effects_volume = 0;
    int32_t area_volume = 0;
};

/// @brief Fired when the user types in the GE search bar. NOT YET FIRING.
struct GrandExchangeSearchedEvent {
    std::string search_text;
};

/// @brief Fired when the world list is loaded/refreshed from the server.
/// Mirrors RuneLite's WorldListLoad. Wired via GameWorld::ListFetch hook.
struct WorldListLoadEvent {};

/// @brief Fired once during the native default-click-vs-open-menu decision.
/// Mirrors RuneLite's MenuShouldLeftClick. `force_right_click` is pre-populated with the
/// game's default decision (true if the default path would open a menu). Plugins
/// can set `force_right_click = true` to force the menu open, or `false` to let
/// the left-click go through (at their own risk).
///
/// NOTE: this is a CORE-side consumable event — only plugins subscribed inside
/// the game DLL (e.g. devtools or built-in core plugins) can mutate the result.
/// Host-side plugins don't receive it; this matches MenuEntryAddedEvent /
/// MenuOptionClickedEvent which are also core-synchronous for the same reason.
struct MenuShouldLeftClickEvent {
    bool force_right_click = false;
};

/// @brief Synthetic XP drop fired by plugins to display a fake XP gain.
/// Obsidian helper — plugins call api::fire_fake_xp_drop() to emit. Mirrors
/// RuneLite's FakeXpDrop which is also a plugin-side helper, not a hook.
struct FakeXpDropEvent {
    int32_t skill = -1;
    int32_t xp = 0;
};

/// @brief Fired once when an animation (SeqType) is loaded for the first time.
/// Mirrors RuneLite's PostAnimation.
struct PostAnimationEvent {
    int32_t animation_id = -1;
    uintptr_t anim_ptr = 0;
};

/// @}

/// @name Rendering
/// @{

/// @brief Fired before the frame render pass begins (for overlay setup).
struct BeforeRenderEvent {};

/// @brief Fired immediately before the right-click menu is drawn.
/// Mirrors RuneLite's BeforeMenuRender. Plugins can use this to draw under
/// the menu, modify the visible entries, or hide the menu.
struct BeforeMenuRenderEvent {};

/// @brief Fired after each menu sort pass stabilises.
/// Mirrors RuneLite's PostMenuSort. Plugins use this to re-order entries or
/// swap left-click actions before the menu is acted upon.
struct PostMenuSortEvent {};

/// @brief Fired when a widget is being dragged (e.g. inventory item being
/// dragged to a new slot, bank items being rearranged).
/// Mirrors RuneLite's WidgetDrag.
struct WidgetDragEvent {};

/// @brief Fired after the frame render pass completes (for overlay teardown).
struct AfterRenderEvent {};

// ── Native draw layer events ────────────────────────────────────────────
// These fire at specific points in the game's render pipeline, giving
// plugins access to the NativeRenderer at the correct depth layer.
// Use api::get_native_renderer() inside these handlers to draw through
// the game's own 2D renderer.

/// @brief Fires after the 3D scene mesh render, BEFORE actor overlays
/// (HP bars, nameplates, damage splats). Draws here appear above the
/// 3D world but under all 2D UI.
struct DrawAboveSceneEvent {};

/// @brief Fires after actor overlays (HP bars etc.) but BEFORE widgets.
/// Draws here appear above HP bars but under the inventory/chat/minimap.
struct DrawAboveOverlaysEvent {};

/// @brief Fires after all game widgets have been drawn. Draws here appear
/// above the game UI but under our ImGui overlay (the ALWAYS_ON_TOP layer).
struct DrawAboveWidgetsEvent {};

/// @brief Fires after GameDrawMain returns — after ALL native game rendering
/// (scene, overlays, widgets, minimap, right-click menu). NativeRenderer
/// writes at this point draw on top of everything in the game's pixel buffer.
struct DrawAfterGameEvent {};

/// @}

/// @name Script (CS2)
/// @{

/// @brief Fired before a CS2 script executes.
struct ScriptPreFiredEvent {
    int32_t script_id = -1;  ///< The CS2 script ID about to fire.
    bool consumed = false;   ///< Set to true to prevent the script from executing; enables event cancellation.
};

/// @brief Fired after a CS2 script finishes executing.
struct ScriptPostFiredEvent {
    int32_t script_id = -1;  ///< The CS2 script ID that just fired.
};

/// @brief Fired when a CS2 script triggers a named callback (opcode 6599).
/// Wired via the `ExecuteOtherCommand` hook: it PEEKs opcode 6599's top object-
/// stack string and fires with `event_name` = that string, then lets the native
/// dispatcher run normally (it must NOT pop/skip — doing so desyncs the script
/// VM stack and crashes the game). Mirrors RuneLite's ScriptCallbackEvent.
///
/// Stack access (RuneLite parity): `int_stack` / `string_stack` are a SNAPSHOT
/// of the script's operand stacks at callback time — equivalent to RuneLite's
/// `getIntStack()` / `getStringStack()`. The LAST element of each vector is the
/// TOP of stack (most recently pushed), i.e. `int_stack.back()` ==
/// `getIntStack()[getIntStackSize()-1]`. `int_stack_size` / `string_stack_size`
/// are the real live stack depths; the vectors hold up to the top
/// `MAX_*_SNAPSHOT` values (the host-side path is bounded). For an
/// in-process (core) consumer the vectors hold the full depth.
///
/// NOTE: read-only snapshot. Writing back to the live stack (RuneLite's
/// `setIntStack`) is only meaningful for a synchronous in-process handler; host
/// plugins receive the event asynchronously (after the script has continued), so
/// modifications there cannot affect the running script.
struct ScriptCallbackEvent {
    std::string event_name;                 ///< The callback event name (top of string stack).
    std::vector<int32_t> int_stack;         ///< Int operand stack snapshot; back() = top.
    std::vector<std::string> string_stack;  ///< String operand stack snapshot; back() = top.
    int32_t int_stack_size = 0;             ///< Live int stack depth (may exceed snapshot size).
    int32_t string_stack_size = 0;          ///< Live string stack depth (may exceed snapshot size).
};

/// @}

/// @name Sound
/// @{

/// @brief Fired when a sound effect is played.
struct SoundEffectPlayedEvent {
    int32_t sound_id = -1;   ///< Sound effect definition ID.
    int32_t delay = 0;       ///< Delay in client ticks before the sound plays.
    bool consumed = false;   ///< Set to true to suppress the sound; enables event cancellation.
};

/// @brief Fired when an area-based sound effect is played at a position.
struct AreaSoundEffectPlayedEvent {
    int32_t sound_id = -1;          ///< Sound effect definition ID.
    int32_t scene_x = 0, scene_y = 0;  ///< Scene tile coordinates of the sound source.
    int32_t range = 0;              ///< Audible range in tiles.
    int32_t delay = 0;              ///< Delay in client ticks before the sound plays.
    bool consumed = false;          ///< Set to true to suppress the sound; enables event cancellation.
};

/// @}

} // namespace obsidian::api
