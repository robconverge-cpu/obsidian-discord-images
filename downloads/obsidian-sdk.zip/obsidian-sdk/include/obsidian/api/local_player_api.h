#pragma once
/// @file local_player_api.h
/// @brief Shared types: SpotAnimData, SkullIcon, OverheadIcon.
/// Function declarations moved to <obsidian/api/local_player.h>.

#include <obsidian/api/coords.h>
#include <cstdint>
#include <string>
#include <vector>

namespace obsidian::api {

/// Spot-animation (graphic) applied to an actor.
struct SpotAnimData {
    int32_t id          = -1;
    int32_t height      = 0;
    int32_t start_cycle = 0;
};

/// Skull icon shown above a player's head.
enum class SkullIcon : int32_t {
    NONE            = -1,
    WHITE_SKULL     = 0,
    RED_SKULL       = 1,
    SKULL_HM_ONE    = 2,
    SKULL_HM_TWO    = 3,
    SKULL_HM_THREE  = 4,
    SKULL_HM_FOUR   = 5,
    SKULL_HM_FIVE   = 6,
    SKULL_DEADMAN   = 7,
};

/// Overhead prayer icon shown above an actor's head.
enum class OverheadIcon : int32_t {
    NONE                       = -1,
    PROTECT_FROM_MELEE         = 0,
    PROTECT_FROM_MISSILES      = 1,
    PROTECT_FROM_MAGIC         = 2,
    RETRIBUTION                = 3,
    SMITE                      = 4,
    REDEMPTION                 = 5,
    PROTECT_FROM_MELEE_RANGED  = 6,
    PROTECT_FROM_MELEE_MAGIC   = 7,
    PROTECT_FROM_RANGED_MAGIC  = 8,
    PROTECT_FROM_ALL           = 9,
};

} // namespace obsidian::api
