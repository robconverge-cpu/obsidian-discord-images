#pragma once
/// @file objects.h
/// @brief Tile object types: GameObject, WallObject, DecorativeObject, GroundObject.
/// @ingroup scene
// ═══════════════════════════════════════════════════════════════════════════
// TILE OBJECTS — GameObject, WallObject, DecorativeObject, GroundObject
// ═══════════════════════════════════════════════════════════════════════════
// Mirrors RuneLite TileObject hierarchy. Each wraps a pointer to a
// scene sub-struct or scene_object entry and provides typed access.
// ═══════════════════════════════════════════════════════════════════════════


#include <obsidian/api/coords.h>
#include <cstdint>
#include <string>

namespace obsidian::api {

/// @name Tag Decoding
/// Scene object tag bitfield helpers. Tags encode tile position, plane, type, and ID.
/// @{
// ── Tag decoding (from sub_620c90) ───────────────────────────────────────
// Tag format:
//   bits  0-6:  tileX      bits  7-13: tileY
//   bits 14-15: plane      bits 16-18: type (0=floor, 1=entity, 2=wall, 3=floor_deco, 4=wall_deco, 5=loc)
//   bit  19:    flag       bits 20-35: object/entity ID
//   bits 36-47: worldView  bits 48-63: unused

inline int32_t tag_id(int64_t tag)     { return static_cast<int32_t>((tag >> 20) & 0xFFFF); } ///< Object/entity ID from tag bits 20–35.
inline int32_t tag_type(int64_t tag)   { return static_cast<int32_t>((tag >> 16) & 0x7); }   ///< Tag type (0=floor, 1=entity, 2=wall, 3=floor_deco, 4=wall_deco, 5=loc).
inline int32_t tag_tile_x(int64_t tag) { return static_cast<int32_t>(tag & 0x7F); }           ///< Tile X from tag bits 0–6.
inline int32_t tag_tile_y(int64_t tag) { return static_cast<int32_t>((tag >> 7) & 0x7F); }   ///< Tile Y from tag bits 7–13.
inline int32_t tag_plane(int64_t tag)  { return static_cast<int32_t>((tag >> 14) & 0x3); }   ///< Plane from tag bits 14–15.
/// @}

/// Base class for all scene tile objects. Not instantiated directly —
/// use GameObject, WallObject, DecorativeObject, or GroundObject.
class TileObject {
protected:
    uintptr_t ptr_ = 0;
    int32_t scene_x_ = 0;
    int32_t scene_y_ = 0;
    int32_t plane_ = 0;

public:
    TileObject() = default;
    TileObject(uintptr_t ptr, int32_t sx, int32_t sy, int32_t plane)
        : ptr_(ptr), scene_x_(sx), scene_y_(sy), plane_(plane) {}

    /// True if this object wraps a non-null scene pointer.
    bool valid() const { return ptr_ != 0; }
    /// Raw pointer to the underlying scene struct.
    uintptr_t raw() const { return ptr_; }

    /// Scene tile X coordinate.
    int32_t scene_x() const { return scene_x_; }
    /// Scene tile Y coordinate.
    int32_t scene_y() const { return scene_y_; }
    /// Plane / height level (0–3).
    int32_t plane() const { return plane_; }

    /// Scene tile as a ScenePoint.
    ScenePoint scene_location() const { return {scene_x_, scene_y_}; }

    /// Converts to a world tile using the scene base coordinates.
    WorldPoint world_location(int32_t base_x, int32_t base_y) const {
        return WorldPoint::from_scene(scene_x_, scene_y_, base_x, base_y, plane_);
    }

    /// Fine-local position derived from the scene tile.
    LocalPoint local_location() const {
        return LocalPoint::from_scene(scene_x_, scene_y_);
    }
};


} // namespace obsidian::api
