/// @file sequence.h
/// @brief State-machine helpers: Sequence, Step, SequenceRunner.
///
/// Eliminates hand-rolled switch/case state machines. A Sequence is an
/// ordered list of Steps. Each Step = action + wait condition + timeout.
///
/// Usage:
/// @code
///   auto seq = std::make_shared<SequenceRunner>(this);
///   seq->add_step(Step{}
///       .named("Walk to bank")
///       .do_action([&] { api::walk_to({3182, 3436, 0}); })
///       .wait_for(predicates::until_not_moving(), 10));
///   seq->add_step(Step{}
///       .named("Open bank")
///       .do_action([&] { api::interact_object(BANK_BOOTH, 1, sx, sy); })
///       .wait_for(predicates::until_bank_open(), 15)
///       .on_fail(TimeoutPolicy::Retry, 3));
///   seq->add_step(Step{}
///       .named("Deposit all")
///       .do_action([&] { deposit_all(); }));
///   seq->set_looping(true);
///   seq->start();
/// @endcode
#pragma once

#include <obsidian/sdk/wait.h>
#include <obsidian/sdk/scheduler.h>
#include <functional>
#include <memory>
#include <string>
#include <cstdint>

namespace obsidian::sdk {

class Plugin;

/// What to do when a Step times out.
enum class TimeoutPolicy {
    Abort,  ///< Stop the entire sequence.
    Retry,  ///< Re-run this step's action and restart its wait.
    Skip,   ///< Move to the next step.
};

/// A single step in a Sequence.
struct Step {
    std::string name;
    std::function<void()> action;       ///< nullptr = wait-only step
    Predicate wait;                     ///< nullptr = action-only (completes immediately)
    int32_t timeout_ticks = 0;          ///< 0 = no timeout
    TimeoutPolicy on_timeout_policy = TimeoutPolicy::Abort;
    int32_t max_retries = 3;            ///< Only meaningful with Retry policy

    // Builder pattern
    /// @brief Set the step's display name (from a C string).
    Step& named(const char* n)                      { name = n; return *this; }
    /// @brief Set the step's display name (from a std::string).
    Step& named(std::string n)                      { name = std::move(n); return *this; }
    /// @brief Set the action run when the step begins.
    Step& do_action(std::function<void()> fn)        { action = std::move(fn); return *this; }
    /// @brief Set the wait predicate and its timeout (ticks; 0 = none).
    Step& wait_for(Predicate pred, int32_t t = 0)    { wait = std::move(pred); timeout_ticks = t; return *this; }
    /// @brief Set the timeout policy and retry count for this step.
    Step& on_fail(TimeoutPolicy p, int32_t r = 3)    { on_timeout_policy = p; max_retries = r; return *this; }
};

/// Status of a running Sequence.
enum class SequenceStatus {
    Idle,
    Running,
    Completed,
    Aborted,
    Paused,
};

/// Drives a list of Steps on the game tick.
class SequenceRunner {
public:
    explicit SequenceRunner(Plugin* owner);
    ~SequenceRunner();
    SequenceRunner(const SequenceRunner&) = delete;
    SequenceRunner& operator=(const SequenceRunner&) = delete;

    /// Add a step.
    SequenceRunner& add_step(Step step);

    /// Add a step that only runs if condition is true at evaluation time.
    SequenceRunner& add_step_if(Predicate condition, Step step);

    /// Start from step 0.
    void start();

    /// Stop immediately.
    void abort();

    /// Pause (current wait keeps evaluating but no new steps start).
    void pause();

    /// Resume a paused sequence.
    void resume();

    /// Restart from step 0.
    void restart();

    /// @brief Current run status of the sequence.
    SequenceStatus status() const;
    /// @brief Index of the step currently executing.
    int32_t current_step_index() const;
    /// @brief Name of the step currently executing.
    const std::string& current_step_name() const;
    /// @brief Total number of steps added.
    int32_t step_count() const;

    /// Callback when all steps finish.
    void on_complete(std::function<void()> cb);

    /// Callback when the sequence aborts.
    void on_abort(std::function<void(int32_t step_index, const std::string& step_name)> cb);

    /// Loop back to step 0 after completion.
    void set_looping(bool loop);

private:
    struct Impl;
    std::unique_ptr<Impl> pimpl_;
};

} // namespace obsidian::sdk
