/// @file plugin.h
/// @brief Plugin base class for Obsidian plugins.
#pragma once

#include <obsidian/api/events.h>
#include <obsidian/api/event_bus.h>
#include <obsidian/sdk/log.h>
#include <obsidian/api/overlay.h>
#include <obsidian/api/infobox.h>
#include <obsidian/api/config.h>
#include <obsidian/api/game_api.h>
#include <obsidian/api/panel.h>
#include <obsidian/sdk/config.h>
#include <obsidian/sdk/scheduler.h>
#include <imgui.h>
#include <obsidian/sdk/wait.h>

#include <cstdint>
#include <vector>

// Forward-declared so Plugin::draw_custom_panel can accept a connection
// without the SDK depending on host headers. Built-in plugins compiled
// into host.exe include the full definition; DLL plugins that want a
// custom panel link against the host-side helper.
namespace obsidian::host { class DebugConnection; }

namespace obsidian::sdk {

/// @brief Metadata describing a plugin (name, version, author, etc.).
///
/// Returned by the plugin DLL's exported factory so the host can display
/// plugin information in the UI without loading the plugin logic.
struct PluginInfo {
    const char* key;         ///< @brief Stable snake_case identifier for toggle persistence and API matching.
    const char* name;        ///< @brief Human-readable plugin name.
    const char* description; ///< @brief Short description of what the plugin does.
    const char* version;     ///< @brief Semantic version string (e.g. "1.0.0").
    const char* author;      ///< @brief Plugin author or organization.
    bool        permanent = false; ///< @brief If true, plugin cannot be disabled by the user.
    const char* icon_fa = nullptr; ///< @brief Font Awesome icon for the plugin list (e.g. ICON_FA_HEART). Null = generic circle.
};

/// @brief A single entry in a plugin's configuration schema.
///
/// Plugins declare their config schema as a vector of ConfigEntry.
/// The host generates the settings UI automatically from this schema.
struct ConfigEntry {
    /// @brief Supported configuration value types.
    enum Type {
        BOOL,   ///< @brief Boolean toggle.
        INT,    ///< @brief Integer value.
        STRING, ///< @brief Free-form string.
        COLOR,  ///< @brief Color in "#RRGGBB" format.
        ENUM    ///< @brief Enumeration (string key).
    };

    const char* key;           ///< @brief Unique key used to store/retrieve this setting.
    const char* display_name;  ///< @brief Label shown in the settings UI.
    const char* description;   ///< @brief Tooltip or help text for this setting.
    Type type;                 ///< @brief Data type of this configuration entry.
    const char* default_value; ///< @brief Default value as a string ("true", "42", "#FF0000", etc.).
};

/// @brief Sidebar navigation entry for plugins that provide a panel.
///
/// Plugins that want a sidebar icon declare a NavigationEntry (typically in
/// on_start() via set_sidebar()). The host reads this over IPC and renders
/// the icon in the sidebar strip. When the icon is clicked, the host shows
/// the plugin's panel.
struct NavigationEntry {
    const char* tooltip = "";       ///< @brief Hover text for the sidebar icon.
    const char* icon_fa = nullptr;  ///< @brief Font Awesome UTF-8 icon string (e.g. ICON_FA_BUG).
    int priority = 100;             ///< @brief Sort order (lower = higher in sidebar).
    int panel_type = 0;             ///< @brief Panel type: 0 = none, 3 = custom_panel (PanelBuilder or `draw_custom_panel`). Values 1 and 2 are retired (legacy devtools/quest_helper routing, removed in M1a-9).
};

/// @brief Base class for all Obsidian plugins.
///
/// Plugins inherit from this class, override lifecycle methods, and are
/// loaded as DLLs by the core plugin manager.
///
/// Two patterns are supported:
///
/// 1. **EventBus pattern** (recommended):
///    Subscribe to typed events in on_start() via subscribe(), and register
///    overlays with register_overlay(). Subscriptions are automatically
///    cleaned up via RAII on plugin unload.
///
/// 2. **Legacy pattern**:
///    Override on_game_tick() and on_event() for simple plugins that only
///    need per-tick or raw-event callbacks.
///
/// Both patterns can be mixed freely within a single plugin.
class Plugin {
    std::vector<api::EventSubscription> subscriptions_;
    std::vector<api::Overlay*> overlays_;
    NavigationEntry navigation_;
    bool has_navigation_ = false;

    // Name of the tab profile this instance belongs to. Set by the
    // host plugin manager right after construction, before `on_start`
    // runs, so the plugin can scope its config I/O to the right
    // per-profile file. Defaults to "default" if never set.
    char profile_[64] = { 'd', 'e', 'f', 'a', 'u', 'l', 't', '\0' };

protected:
    /// @name Event Subscription Helpers
    /// @{

    /// @brief Subscribe to a typed event on the global EventBus.
    /// @tparam E     Event type to subscribe to.
    /// @param handler Callback invoked when an event of type E is dispatched.
    /// @param priority Subscription priority (lower fires first). Default is 0.
    ///
    /// The returned EventSubscription is stored internally and automatically
    /// unsubscribed when the plugin is destroyed or cleanup() is called.
    template<typename E>
    void subscribe(std::function<void(const E&)> handler, int priority = 0) {
        subscriptions_.push_back(
            api::get_event_bus().subscribe<E>(std::move(handler), priority));
    }

    /// @}

    /// @name Overlay Registration Helpers
    /// @{

    /// @brief Register an overlay with the global OverlayManager.
    /// @param overlay Pointer to an Overlay instance owned by the plugin.
    ///
    /// Registered overlays are automatically unregistered on plugin cleanup.
    void register_overlay(api::Overlay* overlay) {
        api::get_overlay_manager().register_overlay(overlay);
        overlays_.push_back(overlay);
    }

    /// @}

    /// @name Sidebar Navigation
    /// @{

    /// @brief Register a sidebar icon and panel for this plugin.
    /// @param nav NavigationEntry describing the icon, tooltip, and panel type.
    ///
    /// Call in on_start() to add a sidebar icon. The host renders the icon and
    /// shows the plugin's panel when clicked.
    void set_sidebar(const NavigationEntry& nav) {
        navigation_ = nav;
        has_navigation_ = true;
    }

    /// @}

public:
    /// @brief Virtual destructor that performs automatic cleanup of subscriptions and overlays.
    virtual ~Plugin() { cleanup(); }

    /// @name Lifecycle
    /// @{

    /// @brief Called when the plugin is loaded by the plugin manager.
    /// @return true if initialization succeeded, false to abort loading.
    ///
    /// Plugins should set up EventBus subscriptions, register overlays, and
    /// call set_sidebar() here.
    virtual bool on_start() = 0;

    /// @brief Called when the plugin is stopped or unloaded.
    ///
    /// Override to release plugin-specific resources. The plugin manager
    /// automatically calls cleanup() after on_stop() to unregister
    /// overlays and subscriptions — plugins do NOT need to call super.
    virtual void on_stop() {}

    /// @}

    /// @name Legacy Callbacks
    /// @{

    /// @brief Called once per game tick (legacy pattern).
    /// @param tick_count The current game tick number.
    virtual void on_game_tick(int32_t tick_count) { (void)tick_count; }

    /// @brief Called when a raw event is dispatched (legacy pattern).
    /// @param event Pointer to the opaque event payload.
    virtual void on_event(const void* event) { (void)event; }

    /// @}

    /// @name Configuration
    /// @{

    /// @brief Legacy config schema (flat vector of ConfigEntry).
    /// @deprecated Prefer the declarative `config()` accessor below —
    ///             the plugin manager auto-renders from `sdk::Config`.
    virtual std::vector<ConfigEntry> get_config() const { return {}; }

    /// @brief Called when one of this plugin's declarative config values
    /// changes (UI edit, preset button, or programmatic write). `value` is
    /// the new serialized value. Fired by the host's per-frame persist poll —
    /// NOT fired for the initial load of persisted values at plugin start.
    /// RuneLite equivalent: ConfigChanged.
    virtual void on_config_changed(const char* key, const char* value) {
        (void)key; (void)value;
    }

    /// @brief Return this plugin's declarative config object, or nullptr.
    ///
    /// If non-null, the host auto-renders a settings panel from the
    /// config's `items()` list (toggles, cyclers, etc.). Return nullptr
    /// if the plugin has no configurable settings.
    virtual const Config* config() const { return nullptr; }

    /// @brief Mutable accessor used by the auto-renderer when writing a
    /// changed value back. Default forwards to the const `config()` with
    /// a const_cast — override if you need a separate mutable pointer.
    virtual Config* config_mut() {
        return const_cast<Config*>(config());
    }

    /// @brief Whether this plugin provides a hand-drawn panel beyond
    /// the declarative config items (e.g. list editors, preset buttons).
    /// Renderer calls `draw_custom_panel` after emitting config items
    /// inside the **cog (config) view**.
    virtual bool has_custom_panel() const { return false; }

    /// @brief Draw plugin-specific widgets inside the **cog (config) view**,
    /// AFTER the declarative config items. Use this to add extras that
    /// don't fit the declarative schema — preset buttons, list editors,
    /// inline documentation, etc.
    /// The `conn` is the active client's connection (in-tree plugins only).
    virtual void draw_custom_panel(obsidian::host::DebugConnection* conn) {
        (void)conn;
    }

    /// @brief Draw the plugin's **sidebar panel** — the view shown when
    /// the user clicks its top-level sidebar icon (the icon set via
    /// `set_sidebar`).
    ///
    /// This is a *different surface* from the cog/config view. Use it
    /// for the plugin's runtime UI: live state, interactive lists,
    /// status dashboards, quest pickers, etc. Declarative config items
    /// are NOT auto-rendered here — the sidebar is a blank canvas owned
    /// entirely by the plugin.
    ///
    /// The default implementation delegates to `draw_custom_panel` so
    /// plugins written before the split keep working unchanged. New
    /// plugins with a distinct sidebar UI should override this directly
    /// and leave `draw_custom_panel` for cog-panel extras (or omit it).
    virtual void draw_sidebar_panel(obsidian::host::DebugConnection* conn) {
        if (has_custom_panel()) draw_custom_panel(conn);
    }

    /// @}

    /// @name Navigation Accessors
    /// @{

    /// @brief Check whether this plugin registered a sidebar navigation entry.
    /// @return true if set_sidebar() was called.
    bool has_navigation() const { return has_navigation_; }

    /// @brief Get the plugin's NavigationEntry (read by the plugin manager).
    /// @return Const reference to the NavigationEntry.
    const NavigationEntry& navigation() const { return navigation_; }

    /// @}

    /// @name Profile Awareness
    /// @brief Identifies which tab profile this instance belongs to so
    /// the plugin can scope any hand-drawn persistence calls to the
    /// right config bucket.
    /// @{

    /// @brief Return the profile name this instance was attached under.
    /// @return Pointer to a null-terminated profile name, never null.
    ///         Defaults to `"default"` if the host plugin manager hasn't
    ///         set it yet. Valid from `on_start` through `on_stop`.
    ///
    /// Plugins use this to scope per-profile persistent state — for
    /// example the built-in DevTools plugin passes it to
    /// `ConfigManager::get_in / set_in` so each tab's toggles land in
    /// the right `configs/<profile>.json` file.
    const char* profile() const { return profile_; }

    /// @brief Called by the host plugin manager right after construction,
    /// before `on_start` runs. Plugins should not call this themselves.
    /// @param name Null-terminated profile name (up to 63 characters).
    ///             `nullptr` or empty string clears the profile.
    void set_profile(const char* name) {
        if (!name || !*name) { profile_[0] = '\0'; return; }
        size_t i = 0;
        for (; name[i] && i + 1 < sizeof(profile_); i++) profile_[i] = name[i];
        profile_[i] = '\0';
    }

    /// @}

    /// @name Per-Instance Identity
    /// @brief Set by the host after creation. Multi-plugin DLLs need these
    /// because module-static plugin_index/panel_slot are shared across all
    /// plugins in one DLL.
    /// @{
    /// @brief This instance's plugin index (assigned by the host).
    int32_t plugin_index() const { return plugin_index_; }
    /// @brief This instance's panel slot (assigned by the host).
    int32_t panel_slot()   const { return panel_slot_; }
    /// @brief Set this instance's plugin index (called by the host).
    void set_plugin_index(int32_t idx) { plugin_index_ = idx; }
    /// @brief Set this instance's panel slot (called by the host).
    void set_panel_slot(int32_t slot)  { panel_slot_ = slot; }
    /// @}

    /// @name Scheduler Convenience Methods
    /// @{

    /// Schedule fn on the next game tick.
    TaskHandle run_on_game_tick(std::function<void()> fn) {
        auto* s = get_scheduler();
        return s ? s->run_on_game_tick(this, std::move(fn)) : TaskHandle{};
    }

    /// Schedule fn after N game ticks.
    TaskHandle run_after_ticks(int32_t n, std::function<void()> fn) {
        auto* s = get_scheduler();
        return s ? s->run_after_ticks(this, n, std::move(fn)) : TaskHandle{};
    }

    /// Schedule fn after ~N milliseconds.
    TaskHandle run_after_ms(int64_t ms, std::function<void()> fn) {
        auto* s = get_scheduler();
        return s ? s->run_after_ms(this, ms, std::move(fn)) : TaskHandle{};
    }

    /// Wait until predicate returns true.
    WaitHandle wait_until(Predicate pred, int32_t timeout_ticks = 0) {
        return sdk::wait_until(this, std::move(pred), timeout_ticks);
    }

    /// Wait while predicate remains true.
    WaitHandle wait_while(Predicate pred, int32_t timeout_ticks = 0) {
        return sdk::wait_while(this, std::move(pred), timeout_ticks);
    }

    /// @}

private:
    int32_t plugin_index_ = -1;
    int32_t panel_slot_   = -1;

public:
    /// @brief Release all subscriptions, overlays, and scheduled tasks.
    /// Called automatically by the plugin manager after on_stop().
    /// Idempotent — safe to call multiple times.
    void cleanup() {
#ifndef OBSIDIAN_CORE_INTERNAL
        auto fn = cancel_all_for_bridge();
        if (fn) fn(this);
#endif
        subscriptions_.clear();
        for (auto* overlay : overlays_)
            api::get_overlay_manager().unregister_overlay(overlay);
        overlays_.clear();
    }
};

} // namespace obsidian::sdk

/// @brief Macro to declare a C-linkage DLL export for plugin factory functions.
///
/// Usage:
/// @code
///   OBSIDIAN_PLUGIN_EXPORT obsidian::sdk::Plugin* create_plugin() { ... }
///   OBSIDIAN_PLUGIN_EXPORT obsidian::sdk::PluginInfo get_plugin_info() { ... }
/// @endcode
#define OBSIDIAN_PLUGIN_EXPORT extern "C" __declspec(dllexport)

/// @brief Plugin ABI revision. Bump when `sdk::Plugin` gains or removes
/// virtual methods, when `ConfigItemDesc` layout changes, or when any
/// bridge export signature changes.
///
/// Plugin DLLs must export `obsidian_plugin_abi_version()` returning this
/// value (use `OBSIDIAN_DECLARE_PLUGIN_ABI()` once at file scope). The host
/// refuses to enable post-v1 features (config panels, custom panels) for
/// any DLL whose value doesn't match — calling new vtable slots on a
/// plugin built against an older SDK walks past the end of its actual
/// vtable and crashes the process.
///
/// Revision history:
///   1 — original Plugin interface (on_start/on_stop/on_game_tick/on_event/get_config/on_config_changed)
///   2 — added config()/config_mut()/has_custom_panel()/draw_custom_panel()
///   3 — added profile_/set_profile/profile() for per-profile config persistence
///   4 — added ConfigKind::String/IntList/StringList + accessors; `ConfigItemDesc` grew get_string/set_string/get_int_list/set_int_list/get_string_list/set_string_list/list_max_count/string_max_len fields. Polling dirty detection auto-persists every config item regardless of widget shape (declarative auto-render OR hand-drawn custom panel).
///   5 — added ConfigKind::Color and ConfigKind::Slider. ConfigItemDesc grew get_color/set_color and slider_min/max/step. SceneNpc/ScenePlayer grew `local_location` (LocalPoint) for interpolated visual position. New api::find_all_npcs(). New OverlayContext primitives: render_npc_tile/_true/_sw_tile/_sw_tile_true (and ScenePlayer pair), render_npc_clickbox(_hover), render_npc_outline + TileLineStyle{Solid,Dashed,Corners}.
///   6 — added per-instance plugin_index_/panel_slot_ on Plugin base class for multi-plugin DLL support. Added multi_plugin_registry.h with OBSIDIAN_REGISTER_PLUGIN and OBSIDIAN_DECLARE_MULTI_PLUGIN_EXPORTS macros. PluginInfo gained `permanent` field.
///   7 — added ConfigKind::Button/Separator/Header. ConfigItemDesc grew units/warning/depends_on/hidden/section_collapsible/section_closed_default/on_click/int_min/int_max/string_input_max_len. Collapsible sections. String and Int kinds now auto-rendered.
///   8 — PluginInfo gained `key` field (first member). Registration macros accept KEY as second param (after CLASS). Used for per-sub-plugin toggle identity and launcher.json matching.
///   9 — ApiBridge LAYOUT CHANGED. CombatBridge gained set_attack_style /
///       toggle_auto_retaliate / set_auto_retaliate / is_quick_prayers_active /
///       set_quick_prayers, and several of its slots changed void->bool;
///       InventoryBridge's bank_* slots went void->bool; WalkerBridge gained
///       walk_to_opts / current_path / calculate_path / path_transports /
///       pending_teleport / status / status_ok / is_calculating / is_loading /
///       path_step / destination / loaded_transport_count. Because those live in
///       nested structs, every member AFTER them in ApiBridge shifted — a plugin
///       built against ABI 8 reads `world`, `magic`, `walker`, `quest` and
///       `breaks` at the wrong offsets and calls garbage function pointers.
///       ApiBridge carries no version or size of its own, so THIS is the guard:
///       without the bump an old streamed DLL loads happily and takes the host
///       down with an access violation shortly after login.
#define OBSIDIAN_PLUGIN_ABI_VERSION 9

/// @brief C++ toolchain/STL fingerprint for this translation unit.
///
/// The ABI version above tracks the shape of `sdk::Plugin`'s vtable and the
/// bridge structs — but the boundary ALSO passes `std::string`/`std::vector`/
/// `std::function` and the header-only `EventBus`/`OverlayManager` by value. If
/// the plugin DLL and host.exe were built with different MSVC toolsets, STL
/// versions, or iterator-debug levels, those STL layouts differ and every
/// cross-module STL touch is silent memory corruption — even at the SAME ABI
/// version. This value captures exactly the settings that change STL layout so
/// the loader can reject a mismatch BEFORE any STL crosses the boundary.
///
/// (Once a distributed plugin is fully sealed behind the C-ABI table it passes
/// no STL and this check becomes moot for it — until then it is the real guard.)
/// NOTE: this sits AFTER the `obsidian::sdk` namespace closes (the macros below
/// must be at file scope), so it is re-opened here explicitly — the host calls
/// it as `obsidian::sdk::obsidian_toolchain_fingerprint_value()`.
namespace obsidian::sdk {
inline uint32_t obsidian_toolchain_fingerprint_value() {
    uint32_t f = 0;
#ifdef _MSC_VER
    f ^= (static_cast<uint32_t>(_MSC_VER) << 8);
#endif
#ifdef _ITERATOR_DEBUG_LEVEL
    f ^= (static_cast<uint32_t>(_ITERATOR_DEBUG_LEVEL) << 1);
#endif
#ifdef _MSVC_STL_VERSION
    f ^= static_cast<uint32_t>(_MSVC_STL_VERSION);
#endif
#ifdef _MSVC_STL_UPDATE
    f ^= static_cast<uint32_t>(_MSVC_STL_UPDATE & 0xFFFFu);
#endif
    return f;
}
} // namespace obsidian::sdk

/// @brief Sealed event entry point (defined in the SDK lib, capi_events.cpp).
///
/// The host calls this per event with a POD `ObEvent`; the SDK demarshals it into
/// the real C++ event struct and fires the plugin-local EventBus, so
/// `subscribe<E>()` keeps working unchanged. Declared here only so the loader has
/// a name to resolve — plugins never call it.
///
/// `ObEvent*` is deliberately typed as `void*` in this declaration so plugin.h
/// does not have to pull in the whole C-ABI header.
extern "C" __declspec(dllexport) void obsidian_dispatch_event(void* ob_event);

/// @brief Sealed overlay entry point (SDK lib, capi_overlays.cpp).
///
/// The host calls this once per frame with its `OverlayContext*`; we drive the
/// plugin-local OverlayManager (the one `register_overlay()` populated), so no
/// OverlayManager — a header-only class holding a std::vector — ever crosses the
/// module boundary. Plugins never call this.
extern "C" __declspec(dllexport) void obsidian_render_overlays(void* overlay_ctx);

/// @brief Declare this DLL's ABI version + toolchain fingerprint. Place once at
/// file scope alongside the `create_plugin`/`destroy_plugin`/`get_plugin_info`
/// exports. The host hard-rejects any DLL whose ABI version OR fingerprint
/// doesn't match host.exe (see plugin_manager loader).
#define OBSIDIAN_DECLARE_PLUGIN_ABI()                                                  \
    extern "C" __declspec(dllexport) int obsidian_plugin_abi_version() {               \
        return OBSIDIAN_PLUGIN_ABI_VERSION;                                            \
    }                                                                                  \
    extern "C" __declspec(dllexport) unsigned int obsidian_plugin_toolchain_fingerprint() { \
        return ::obsidian::sdk::obsidian_toolchain_fingerprint_value();                \
    }                                                                                  \
    /* Force the linker to pull in the SDK's sealed event demarshaler.               \
       obsidian_dispatch_event lives in obsidian_sdk.lib and NOTHING in a plugin     \
       references it, so the linker discards that object file and the export         \
       SILENTLY DISAPPEARS from the DLL — the host then finds no dispatch entry and  \
       the plugin receives NO EVENTS AT ALL, with no error anywhere. (Verified: it   \
       really does vanish.)                                                          \
       NOTE: a `const void* const p = &fn;` does NOT work — `const` at namespace     \
       scope has internal linkage, so the unused variable is optimised away before   \
       it can anchor anything. /include: is the reliable lever. x64 C symbols are    \
       undecorated, so the plain name is correct. */                                 \
    __pragma(comment(linker, "/include:obsidian_dispatch_event"))                     \
    __pragma(comment(linker, "/include:obsidian_render_overlays"))                    \
    OBSIDIAN_ANCHOR_SET_CAPI

/* obsidian_set_capi lives in capi_client_api.cpp, which the linker only pulls in if
   the plugin references an api:: function. A plugin that calls none (panels/UI only)
   would silently ship without it and get no API table at all. Anchor it too.
   Only in a sealed build — the in-tree lib has no such symbol, and /include: on a
   symbol that does not exist is a link error. */
#define OBSIDIAN_ANCHOR_SET_CAPI __pragma(comment(linker, "/include:obsidian_set_capi"))

// ── Core→Plugin singleton bridge (ensures one shared EventBus/OverlayManager) ──
// The core plugin manager loads a plugin DLL and, if present, calls these
// exported setters to initialize the plugin module's SDK singletons so that
// all plugins share the same instances.
//
// Plugins compiled with this SDK header will export these automatically and
// the core will call them before create_plugin().

// In plugin builds, define OBSIDIAN_SDK_BRIDGE_EXPORT to export bridge setters.
// Core loads plugins and calls these via GetProcAddress; it should not define them.
#ifdef OBSIDIAN_SDK_BRIDGE_EXPORT

// ── Sealed panel bridge ───────────────────────────────────────────────
// The host passes three function pointers; PanelBuilder::publish() and the poll
// helpers route through these (api/panel.h, panel_bridge), so plugin code never
// sees how panels are transported.
extern "C" __declspec(dllexport) void obsidian_set_panel_fns(
    obsidian::api::panel_bridge::PublishFn publish,
    obsidian::api::panel_bridge::PollButtonFn poll_button,
    obsidian::api::panel_bridge::PollSelectionFn poll_selection)
{
    obsidian::api::panel_bridge::publish_fn()        = publish;
    obsidian::api::panel_bridge::poll_button_fn()    = poll_button;
    obsidian::api::panel_bridge::poll_selection_fn() = poll_selection;
}

extern "C" __declspec(dllexport) void obsidian_set_plugin_index(int32_t idx) {
    obsidian::api::panel_bridge::plugin_index() = idx;
}
extern "C" __declspec(dllexport) void obsidian_set_panel_slot(int32_t slot) {
    obsidian::api::panel_bridge::panel_slot() = slot;
}
extern "C" __declspec(dllexport) void obsidian_set_scheduler(obsidian::sdk::TickScheduler* s) {
    obsidian::sdk::set_scheduler(s);
}
extern "C" __declspec(dllexport) void obsidian_set_cancel_all_for(void (*fn)(obsidian::sdk::Plugin*)) {
    obsidian::sdk::cancel_all_for_bridge() = fn;
}
extern "C" __declspec(dllexport) void obsidian_set_humaniser(obsidian::sdk::Humaniser* h) {
    obsidian::sdk::set_humaniser(h);
}
extern "C" __declspec(dllexport) void obsidian_set_wait_bridge(const obsidian::sdk::WaitFnBridge* b) {
    obsidian::sdk::set_wait_fn_bridge(b);
}
extern "C" __declspec(dllexport) void obsidian_set_imgui_context(void* ctx) {
    ImGui::SetCurrentContext(static_cast<ImGuiContext*>(ctx));
}
extern "C" __declspec(dllexport) void obsidian_set_log_fn(obsidian::sdk::LogFn fn) {
    obsidian::sdk::log_fn_ptr() = fn;
}
#else
// Declarations for the host side (it resolves these by name via GetProcAddress).
extern "C" void obsidian_set_plugin_index(int32_t idx);
extern "C" void obsidian_set_panel_slot(int32_t slot);
extern "C" void obsidian_set_scheduler(obsidian::sdk::TickScheduler* s);
extern "C" void obsidian_set_cancel_all_for(void (*fn)(obsidian::sdk::Plugin*));
extern "C" void obsidian_set_humaniser(obsidian::sdk::Humaniser* h);
extern "C" void obsidian_set_wait_bridge(const obsidian::sdk::WaitFnBridge* b);
extern "C" void obsidian_set_imgui_context(void* ctx);
extern "C" void obsidian_set_log_fn(obsidian::sdk::LogFn fn);
extern "C" void obsidian_set_panel_fns(
    obsidian::api::panel_bridge::PublishFn publish,
    obsidian::api::panel_bridge::PollButtonFn poll_button,
    obsidian::api::panel_bridge::PollSelectionFn poll_selection);
#endif
