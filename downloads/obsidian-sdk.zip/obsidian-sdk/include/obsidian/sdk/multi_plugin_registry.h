#pragma once
/// @file multi_plugin_registry.h
/// @brief Header-only registry for combined multi-plugin DLLs.
///
/// A combined DLL (e.g., obsidian_pvm.dll) contains multiple plugins.
/// Each plugin source uses OBSIDIAN_REGISTER_PLUGIN to add itself to the
/// registry at static-init time. The combined DLL's entry point uses
/// OBSIDIAN_DECLARE_MULTI_PLUGIN_EXPORTS to export the multi-plugin
/// contract that the host detects via get_plugin_count.

#include <obsidian/sdk/plugin.h>
#include <vector>

namespace obsidian::sdk {

struct MultiPluginEntry {
    PluginInfo info;
    Plugin* (*create)();
    void    (*destroy)(Plugin*);
};

class MultiPluginRegistry {
public:
    static MultiPluginRegistry& instance() {
        static MultiPluginRegistry r;
        return r;
    }

    void add(const MultiPluginEntry& e) { entries_.push_back(e); }
    int count() const { return static_cast<int>(entries_.size()); }
    const MultiPluginEntry& at(int i) const { return entries_[i]; }

private:
    MultiPluginRegistry() = default;
    std::vector<MultiPluginEntry> entries_;
};

struct MultiPluginRegistrar {
    MultiPluginRegistrar(const MultiPluginEntry& e) {
        MultiPluginRegistry::instance().add(e);
    }
};

} // namespace obsidian::sdk

/// Register a plugin class into the multi-plugin registry.
/// Use in each plugin .cpp when compiled with OBSIDIAN_MULTI_PLUGIN_DLL.
#define OBSIDIAN_REGISTER_PLUGIN(CLASS, KEY, NAME, DESC, VER, AUTHOR, ...)                \
    namespace {                                                                           \
    static const ::obsidian::sdk::MultiPluginRegistrar                                    \
        OBSIDIAN_MULTI_REG_CAT_(g_multi_reg_, __LINE__) {{                                \
            { KEY, NAME, DESC, VER, AUTHOR, ##__VA_ARGS__ },                              \
            []() -> ::obsidian::sdk::Plugin* { return new CLASS(); },                     \
            [](::obsidian::sdk::Plugin* p) { delete p; }                                  \
        }};                                                                               \
    }

// Token paste helpers
#define OBSIDIAN_MULTI_REG_CAT_(a, b) OBSIDIAN_MULTI_REG_CAT2_(a, b)
#define OBSIDIAN_MULTI_REG_CAT2_(a, b) a##b

/// Export the multi-plugin DLL contract. Place once in the combined DLL's
/// entry point .cpp (e.g., combined_entry.cpp). Must be compiled with
/// OBSIDIAN_SDK_BRIDGE_EXPORT defined.
#define OBSIDIAN_DECLARE_MULTI_PLUGIN_EXPORTS()                                                          \
    extern "C" __declspec(dllexport) int get_plugin_count() {                                            \
        return ::obsidian::sdk::MultiPluginRegistry::instance().count();                                  \
    }                                                                                                    \
    extern "C" __declspec(dllexport) ::obsidian::sdk::PluginInfo get_plugin_info_at(int index) {          \
        return ::obsidian::sdk::MultiPluginRegistry::instance().at(index).info;                           \
    }                                                                                                    \
    extern "C" __declspec(dllexport) ::obsidian::sdk::Plugin* create_plugin_at(int index) {               \
        return ::obsidian::sdk::MultiPluginRegistry::instance().at(index).create();                       \
    }                                                                                                    \
    extern "C" __declspec(dllexport) void destroy_plugin_at(::obsidian::sdk::Plugin* p, int index) {      \
        ::obsidian::sdk::MultiPluginRegistry::instance().at(index).destroy(p);                            \
    }                                                                                                    \
    OBSIDIAN_DECLARE_PLUGIN_ABI()
