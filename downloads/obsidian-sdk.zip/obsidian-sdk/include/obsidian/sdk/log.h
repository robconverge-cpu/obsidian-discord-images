#pragma once
/// @file log.h
/// @brief Logging for SDK plugins — routes to the host Logger singleton.
///
/// Host calls obsidian_set_log_fn() during plugin loading to inject the
/// log function pointer. Plugins use OBS_LOG_* macros which call through it.

#include <cstdint>
#include <cstdarg>
#include <cstdio>

namespace obsidian::sdk {

/// @brief Severity levels for SDK plugin log messages.
enum class LogLevel : uint8_t { Dbg = 0, Info = 1, Warn = 2, Err = 3 };

/// @brief Signature of the host-injected log sink function.
using LogFn = void(*)(uint8_t level, const char* module, const char* message);

/// @brief Accessor for the host-injected log function pointer (set via obsidian_set_log_fn).
inline LogFn& log_fn_ptr() { static LogFn fn = nullptr; return fn; }

/// @brief Format a printf-style message and route it to the host logger at the given level.
inline void log(LogLevel level, const char* module, const char* fmt, ...) {
    auto fn = log_fn_ptr();
    if (!fn) return;
    char buf[512];
    va_list ap;
    va_start(ap, fmt);
    vsnprintf(buf, sizeof(buf), fmt, ap);
    va_end(ap);
    fn(static_cast<uint8_t>(level), module, buf);
}

} // namespace obsidian::sdk

// Only define if not already provided by host/logger.h (built-in plugins get both)
#ifndef OBS_LOG_DEBUG
/// @brief Log a debug-level message tagged with the given module name.
#define OBS_LOG_DEBUG(mod, fmt, ...) ::obsidian::sdk::log(::obsidian::sdk::LogLevel::Dbg,  mod, fmt, ##__VA_ARGS__)
/// @brief Log an info-level message tagged with the given module name.
#define OBS_LOG_INFO(mod, fmt, ...)  ::obsidian::sdk::log(::obsidian::sdk::LogLevel::Info, mod, fmt, ##__VA_ARGS__)
/// @brief Log a warning-level message tagged with the given module name.
#define OBS_LOG_WARN(mod, fmt, ...)  ::obsidian::sdk::log(::obsidian::sdk::LogLevel::Warn, mod, fmt, ##__VA_ARGS__)
/// @brief Log an error-level message tagged with the given module name.
#define OBS_LOG_ERROR(mod, fmt, ...) ::obsidian::sdk::log(::obsidian::sdk::LogLevel::Err,  mod, fmt, ##__VA_ARGS__)
#endif
