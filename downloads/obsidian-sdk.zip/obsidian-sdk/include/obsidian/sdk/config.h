/// @file config.h
/// @brief Declarative plugin configuration schema.
///
/// Plugins expose a subclass of `sdk::Config` from `Plugin::config()`. The
/// host's plugin manager walks the config's `items()` list and auto-renders
/// a settings UI — no drawing code required for simple toggles / ints /
/// cyclers.
///
/// Function-pointer accessors (not std::function) so the schema can cross
/// DLL boundaries when VIP/subscription plugins ship as streamed DLLs.
#pragma once

#include <climits>
#include <cstdint>
#include <string>
#include <vector>

namespace obsidian::sdk {

class Config;

/// @brief Value type for a single config item.
///
/// All kinds are auto-persisted by the host plugin manager — both seeded
/// from the per-profile config store at adopt time and saved back any
/// time the value changes (whether via the auto-rendered widget OR via
/// a hand-drawn custom panel that mutates the underlying state).
enum class ConfigKind : uint8_t {
    Bool,        ///< Rendered as a toggle.
    Int,         ///< Rendered as an integer input with optional min/max clamping.
    IntCycler,   ///< Rendered as `<` / `>` stepper through a fixed option list.
    String,      ///< Free-form string — rendered as a text input.
    IntList,     ///< Editable list of int32 ids — rendered as a list widget with `+`/`-` buttons.
    StringList,  ///< Editable list of short strings (e.g. player names) — rendered as a list widget.
    Color,       ///< 32-bit RGBA colour — rendered as an ImGui ColorEdit4 swatch with alpha.
    Slider,      ///< Bounded integer with min/max/step — rendered as an ImGui SliderInt. Reuses get_int/set_int.
    Dropdown,    ///< Rendered as ImGui Combo. Uses get_int/set_int (0-based index) + dropdown_labels.
    Button,      ///< Action button — fires `on_click` callback. No persistence.
    Separator,   ///< Visual divider — no data, no persistence.
    Header,      ///< Decorative subsection label — renders `name` as accent text. No data, no persistence.
    StringDropdown, ///< Combo whose OPTIONS come from `get_string_list` (queried live each
                    ///< frame) and whose VALUE is a string via `get_string`/`set_string`.
                    ///< Persists the selected string (stable when the option set changes),
                    ///< unlike Dropdown which persists a 0-based index. Use for dynamic sets
                    ///< such as loadout names read from the shared store.
};

/// @brief One declarative config entry.
///
/// Populate one of these per setting in the Config subclass's constructor.
/// The accessor function pointers receive the owning Config* and should
/// cast to the concrete subclass to read/write the backing state.
struct ConfigItemDesc {
    const char* key         = nullptr; ///< Stable identifier (persistence key).
    const char* name        = nullptr; ///< Display label.
    const char* description = nullptr; ///< Tooltip (nullable).
    const char* section     = nullptr; ///< Section header (nullable / empty = unsectioned).
    int         position    = 0;       ///< Relative order within section (informational — iteration uses insertion order).
    ConfigKind  kind        = ConfigKind::Bool;

    /// Bool accessors — used when `kind == Bool`. Both required for Bool.
    bool    (*get_bool)(const Config* self) = nullptr;
    void    (*set_bool)(Config* self, bool v) = nullptr;

    /// Int accessors — used when `kind == Int` or `kind == IntCycler`.
    int32_t (*get_int)(const Config* self) = nullptr;
    void    (*set_int)(Config* self, int32_t v) = nullptr;

    /// IntCycler option table. `cycler_count` is the number of entries in
    /// `cycler_values`. `cycler_fmt` is a printf-style format for the
    /// current value (e.g. `"%d"`); nullptr falls back to `"%d"`.
    const int32_t* cycler_values = nullptr;
    int            cycler_count  = 0;
    const char*    cycler_fmt    = nullptr;

    /// String accessors — used when `kind == String`.
    /// Returns by value (caller copies) so the plugin can back the value
    /// with whatever storage it likes (in-memory, file-backed, etc.).
    std::string (*get_string)(const Config* self) = nullptr;
    void        (*set_string)(Config* self, const std::string& v) = nullptr;

    /// IntList accessors — used when `kind == IntList`.
    /// `get_int_list` returns the current snapshot (caller-owned copy);
    /// `set_int_list` replaces the underlying state with the given list.
    /// `list_max_count` is the upper bound the editor enforces — entries
    /// beyond this are rejected by the renderer.
    std::vector<int32_t> (*get_int_list)(const Config* self) = nullptr;
    void                 (*set_int_list)(Config* self, const std::vector<int32_t>& v) = nullptr;

    /// StringList accessors — used when `kind == StringList`. Strings
    /// are typically short (e.g. player names, ≤ 32 chars). The auto
    /// renderer's editor UI is bounded by `list_max_count` and
    /// `string_max_len`.
    std::vector<std::string> (*get_string_list)(const Config* self) = nullptr;
    void                     (*set_string_list)(Config* self, const std::vector<std::string>& v) = nullptr;

    /// Maximum entries allowed in IntList/StringList editors. 0 = unlimited.
    int list_max_count = 0;
    /// Maximum length per entry in a StringList editor. 0 = no limit.
    int string_max_len = 0;

    /// Color accessors — used when `kind == Color`.
    /// Stored as packed 32-bit RGBA (matches ImGui's `IM_COL32` /
    /// `ImU32` format). The auto-renderer round-trips through
    /// `ImGui::ColorConvertU32ToFloat4` for editing.
    uint32_t (*get_color)(const Config* self) = nullptr;
    void     (*set_color)(Config* self, uint32_t v) = nullptr;

    /// Slider bounds — used when `kind == Slider`. The slider reuses
    /// the `get_int` / `set_int` accessors above; these three fields
    /// just constrain the rendered range.
    int32_t slider_min  = 0;
    int32_t slider_max  = 100;
    int32_t slider_step = 1;

    /// Dropdown labels — used when `kind == Dropdown`.
    /// Double-null-terminated string of labels: "Option A\0Option B\0Option C\0\0".
    /// Value is the 0-based index into this list. Uses get_int/set_int.
    const char* dropdown_labels = nullptr;

    // ── v7 fields ──────────────────────────────────────────────────────

    /// Suffix text displayed after the value (e.g. "ms", "tiles", "%").
    /// Applies to Int, Slider, IntCycler kinds.
    const char* units = nullptr;

    /// If non-null, a confirmation dialog with this text is shown before
    /// enabling a Bool toggle (OFF -> ON). Ignored for non-Bool kinds.
    const char* warning = nullptr;

    /// Key of another Bool item in the same config. When that item is
    /// false, this item is rendered greyed-out / disabled.
    const char* depends_on = nullptr;

    /// If true, the item is persisted but never rendered in the UI.
    bool hidden = false;

    /// Section behaviour — read from the first item that introduces a
    /// given section name. If true, the section header is a collapsible
    /// framed tree node instead of a flat bold label.
    bool section_collapsible = false;

    /// If true (and section_collapsible is true), the section starts
    /// collapsed. Ignored when section_collapsible is false.
    bool section_closed_default = false;

    /// Button callback — used when `kind == Button`. Called on click.
    void (*on_click)(Config* self) = nullptr;

    /// Int range — used when `kind == Int` for input clamping.
    int32_t int_min = INT32_MIN;
    int32_t int_max = INT32_MAX;

    /// Maximum character length for `kind == String` input fields.
    int string_input_max_len = 256;
};

/// @brief Base class for a plugin's config object.
///
/// Subclasses implement `group()` and `items()`, declaring their settings
/// schema. The plugin exposes its `Config*` from `Plugin::config()`.
class Config {
public:
    virtual ~Config() = default;

    /// Stable identifier for the plugin's config namespace (e.g. "entity_hider").
    /// Used as the config-manager group when persisting setting values.
    virtual const char* group() const = 0;

    /// The declared items, in render order. Section headers are emitted by
    /// the renderer whenever a new `section` string is seen.
    virtual const std::vector<ConfigItemDesc>& items() const = 0;
};

// ── Declarative binding helpers ─────────────────────────────────────────────
// The function-pointer accessors are correct for the DLL ABI (no std::function
// across the boundary) but verbose: every setting repeats a
// `static_cast<ConcreteConfig*>(self)->field` lambda PAIR. These macros generate
// that pair from the concrete Config type + member, so a setting drops from
// ~8-10 lines to one. The member name doubles as the persistence key.
//
//   struct MyConfig : obsidian::sdk::Config {
//       bool enabled = true; int speed = 50; std::string label = "hi";
//       const char* group() const override { return "my_plugin"; }
//       const std::vector<obsidian::sdk::ConfigItemDesc>& items() const override {
//           static const std::vector<obsidian::sdk::ConfigItemDesc> v = {
//               OBS_CFG_BOOL(MyConfig, enabled, "Enable feature"),
//               OBS_CFG_SLIDER(MyConfig, speed, "Speed", 0, 100, 1),
//               OBS_CFG_STRING(MyConfig, label, "Label"),
//           };
//           return v;
//       }
//   };
//
// Each macro is an IIFE returning a fully-populated ConfigItemDesc, usable
// directly in a braced initializer list. The generated lambdas are stateless,
// so they decay to the plain function pointers the ABI requires.
#define OBS_CFG_BOOL(T, member, label_) ([]{                                    \
        ::obsidian::sdk::ConfigItemDesc d;                                      \
        d.key = #member; d.name = (label_);                                     \
        d.kind = ::obsidian::sdk::ConfigKind::Bool;                             \
        d.get_bool = [](const ::obsidian::sdk::Config* s){                      \
            return static_cast<const T*>(s)->member; };                         \
        d.set_bool = [](::obsidian::sdk::Config* s, bool v){                    \
            static_cast<T*>(s)->member = v; };                                  \
        return d; }())

#define OBS_CFG_INT(T, member, label_) ([]{                                     \
        ::obsidian::sdk::ConfigItemDesc d;                                      \
        d.key = #member; d.name = (label_);                                     \
        d.kind = ::obsidian::sdk::ConfigKind::Int;                              \
        d.get_int = [](const ::obsidian::sdk::Config* s){                       \
            return static_cast<::int32_t>(static_cast<const T*>(s)->member); }; \
        d.set_int = [](::obsidian::sdk::Config* s, ::int32_t v){                \
            static_cast<T*>(s)->member = v; };                                  \
        return d; }())

#define OBS_CFG_SLIDER(T, member, label_, lo, hi, step_) ([]{                   \
        ::obsidian::sdk::ConfigItemDesc d;                                      \
        d.key = #member; d.name = (label_);                                     \
        d.kind = ::obsidian::sdk::ConfigKind::Slider;                           \
        d.slider_min = (lo); d.slider_max = (hi); d.slider_step = (step_);      \
        d.get_int = [](const ::obsidian::sdk::Config* s){                       \
            return static_cast<::int32_t>(static_cast<const T*>(s)->member); }; \
        d.set_int = [](::obsidian::sdk::Config* s, ::int32_t v){                \
            static_cast<T*>(s)->member = v; };                                  \
        return d; }())

#define OBS_CFG_STRING(T, member, label_) ([]{                                  \
        ::obsidian::sdk::ConfigItemDesc d;                                      \
        d.key = #member; d.name = (label_);                                     \
        d.kind = ::obsidian::sdk::ConfigKind::String;                           \
        d.get_string = [](const ::obsidian::sdk::Config* s){                    \
            return static_cast<const T*>(s)->member; };                         \
        d.set_string = [](::obsidian::sdk::Config* s, const ::std::string& v){  \
            static_cast<T*>(s)->member = v; };                                  \
        return d; }())

#define OBS_CFG_COLOR(T, member, label_) ([]{                                   \
        ::obsidian::sdk::ConfigItemDesc d;                                      \
        d.key = #member; d.name = (label_);                                     \
        d.kind = ::obsidian::sdk::ConfigKind::Color;                            \
        d.get_color = [](const ::obsidian::sdk::Config* s){                     \
            return static_cast<::uint32_t>(static_cast<const T*>(s)->member); };\
        d.set_color = [](::obsidian::sdk::Config* s, ::uint32_t v){             \
            static_cast<T*>(s)->member = v; };                                  \
        return d; }())

} // namespace obsidian::sdk
