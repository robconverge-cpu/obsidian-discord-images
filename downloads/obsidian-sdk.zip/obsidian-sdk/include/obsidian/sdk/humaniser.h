#pragma once

#include <cstdint>
#include <cmath>

namespace obsidian::sdk {

class Plugin;

enum class ActionCategory : uint8_t {
    CLICK_WIDGET,
    INTERACT_NPC,
    INTERACT_OBJECT,
    WALK,
    PRAYER_SWITCH,
    EAT_DRINK,
    EQUIP,
    DROP,
    DIALOGUE,
    SPELL_CAST,
    BANK_OP,
    CUSTOM
};

struct HumaniserProfile {
    float reaction_mean_ms = 200.0f;
    float reaction_sigma = 0.28f;
    float reaction_min_ms = 120.0f;
    float reaction_max_ms = 600.0f;

    float mult_prayer_switch = 0.55f;
    float mult_eat_drink = 0.70f;
    float mult_equip = 0.75f;
    float mult_combat_npc = 0.85f;
    float mult_click_widget = 1.00f;
    float mult_interact_object = 1.05f;
    float mult_walk = 1.10f;
    float mult_dialogue = 1.30f;
    float mult_bank_op = 1.15f;
    float mult_drop = 0.65f;
    float mult_spell_cast = 0.90f;

    float inter_action_mean_ms = 120.0f;
    float inter_action_sd_ms = 40.0f;
    float inter_action_min_ms = 40.0f;
    float inter_action_tick_manip_ms = 30.0f;

    float fatigue_onset_minutes = 40.0f;
    float fatigue_midpoint_minutes = 120.0f;
    float fatigue_steepness = 0.03f;
    float fatigue_max_reaction_mult = 1.5f;
    float fatigue_max_precision_decay = 0.35f;
    float fatigue_max_speed_decay = 0.12f;

    float micro_afk_base_prob = 0.003f;
    float micro_afk_duration_min_s = 3.0f;
    float micro_afk_duration_max_s = 15.0f;
    float micro_afk_fatigue_mult = 3.0f;
    float short_break_interval_min = 20.0f;
    float short_break_interval_max = 50.0f;
    float short_break_duration_min_s = 30.0f;
    float short_break_duration_max_s = 180.0f;

    float attention_drift_prob = 0.05f;
    float attention_drift_extra_ticks_min = 1.0f;
    float attention_drift_extra_ticks_max = 4.0f;

    float ar1_rho = 0.4f;

    // ── Fatigue recovery (breaks) ───────────────────────────────────────
    // Fatigue tracks EFFECTIVE play minutes, not wall-clock: while a break is
    // active the accumulator runs BACKWARDS at these multiples of real time
    // (rest recovers faster than play tires — a 10-minute logged-out break
    // undoes ~40 minutes of grind at the default). Without this, fatigue was
    // a monotone sigmoid of wall time: it kept RISING during breaks and once
    // saturated never came down (field-reported pinned at 100%).
    float fatigue_recover_mult_ingame = 2.0f;   ///< in-game break recovery rate
    float fatigue_recover_mult_logout = 4.0f;   ///< logged-out break recovery rate
};

class Humaniser {
public:
    virtual ~Humaniser() = default;

    virtual int reaction_ticks(ActionCategory cat) const = 0;
    virtual float reaction_ms(ActionCategory cat) const = 0;
    virtual float inter_action_ms() const = 0;
    virtual float fatigue_level() const = 0;
    virtual bool should_micro_afk() const = 0;
    virtual int random_ticks(int min_ticks, int max_ticks) const = 0;
    virtual float random_gaussian(float mean, float sd) const = 0;
    virtual int random_weighted(int min_val, int max_val) const = 0;

    virtual void set_profile(const HumaniserProfile& profile) = 0;
    virtual const HumaniserProfile& profile() const = 0;
    virtual void reset_session() = 0;
    virtual void set_fatigue(float level) = 0;

    virtual float micro_afk_duration_s() const { return 5.0f; }
    virtual int attention_drift_ticks() const { return 0; }
};

inline Humaniser*& humaniser_ptr() { static Humaniser* p = nullptr; return p; }
inline Humaniser*  get_humaniser()                { return humaniser_ptr(); }
inline void        set_humaniser(Humaniser* h)    { humaniser_ptr() = h; }

} // namespace obsidian::sdk
