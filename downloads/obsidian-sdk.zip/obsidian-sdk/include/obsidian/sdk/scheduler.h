/// @file scheduler.h
/// @brief Tick-driven task scheduler for automation plugins.
///
/// Provides run_on_game_tick / run_after_ticks / run_after_ms with
/// cancellable handles. All callbacks execute on the host render thread
/// during GameTickEvent dispatch. Thread-safe enqueue from any thread.
///
/// One TickScheduler per TabPluginContext (multi-client isolation).
/// Plugins interact via Plugin::run_on_game_tick() etc. or via the
/// free-function API using the bridged module-level pointer.
#pragma once

#include <atomic>
#include <cstdint>
#include <functional>
#include <memory>

namespace obsidian::sdk {

class Plugin;
class TickScheduler;

/// @brief Opaque handle to a scheduled task. Move-only.
///
/// Letting the handle destruct cancels the task. Call release() to
/// detach — the task runs even after the handle is gone. Call cancel()
/// for explicit cancellation.
class TaskHandle {
    friend class TickScheduler;
public:
    /// @brief Shared control block tracking a task's cancelled/completed flags.
    struct Impl {
        std::atomic<bool> cancelled{false};
        std::atomic<bool> completed{false};
    };
private:
    std::shared_ptr<Impl> impl_;
    explicit TaskHandle(std::shared_ptr<Impl> impl) : impl_(std::move(impl)) {}
public:
    TaskHandle() = default;
    TaskHandle(TaskHandle&&) noexcept = default;
    TaskHandle& operator=(TaskHandle&&) noexcept = default;
    TaskHandle(const TaskHandle&) = delete;
    TaskHandle& operator=(const TaskHandle&) = delete;
    ~TaskHandle() { cancel(); }

    /// @brief Cancel the scheduled task so it will not run.
    void cancel()   { if (impl_) impl_->cancelled.store(true, std::memory_order_release); }
    /// @brief Detach the handle without cancelling; the task still runs.
    void release()  { impl_.reset(); }
    /// @brief True once the task has finished executing.
    bool completed() const { return impl_ && impl_->completed.load(std::memory_order_acquire); }
    /// @brief True if the task has been cancelled.
    bool cancelled() const { return impl_ && impl_->cancelled.load(std::memory_order_acquire); }
    /// @brief True if this handle refers to a real task (non-empty).
    bool valid()     const { return impl_ != nullptr; }
};

/// @brief Central tick-driven scheduler. One per TabPluginContext.
///
/// Plugins don't construct this. The plugin manager creates one per tab
/// and bridges the pointer via set_scheduler(). Plugin convenience
/// methods (run_on_game_tick, wait_until, etc.) call through it.
class TickScheduler {
public:
    TickScheduler();
    ~TickScheduler();
    TickScheduler(const TickScheduler&) = delete;
    TickScheduler& operator=(const TickScheduler&) = delete;
    TickScheduler(TickScheduler&&) noexcept;
    TickScheduler& operator=(TickScheduler&&) noexcept;

    /// Schedule fn on the next game tick.
    TaskHandle run_on_game_tick(Plugin* owner, std::function<void()> fn);

    /// Schedule fn after N game ticks.
    TaskHandle run_after_ticks(Plugin* owner, int32_t ticks, std::function<void()> fn);

    /// Schedule fn after ~N milliseconds (checked per frame, ~20ms granularity).
    TaskHandle run_after_ms(Plugin* owner, int64_t ms, std::function<void()> fn);

    /// Cancel all pending tasks owned by a specific plugin.
    /// Called automatically on plugin unload.
    void cancel_all_for(Plugin* owner);

    /// Advance the scheduler by one game tick. Called from poll_events()
    /// after dispatching ring events.
    void pump(int32_t current_tick);

    /// Process time-based (ms) tasks. Called every frame.
    void pump_frame();

    /// Current game tick as seen by the scheduler.
    int32_t current_tick() const;

    // ── Internal: wait/sequence support ──────────────────────────────

    /// @brief Internal state for a pending wait_until/wait_while task and its chain.
    struct WaitTask {
        Plugin* owner = nullptr;
        std::function<bool()> predicate;
        bool invert = false;        // true = wait_while
        int32_t timeout_tick = 0;   // 0 = no timeout
        std::shared_ptr<TaskHandle::Impl> handle;

        // Chain support
        std::function<void()> on_satisfied;
        std::function<void()> on_timeout_cb;
        std::shared_ptr<WaitTask> next_wait;
    };

    /// @brief Enqueue a wait task to be evaluated on each tick.
    void add_wait(std::shared_ptr<WaitTask> wt);

private:
    struct Impl;
    std::unique_ptr<Impl> pimpl_;
};

// ── Module-level bridge (same pattern as EventBus / game_shm) ────────

/// @brief Accessor for the module-level scheduler pointer (host-injected).
inline TickScheduler*& scheduler_ptr() { static TickScheduler* p = nullptr; return p; }
/// @brief Return the current per-tab scheduler, or nullptr if none is set.
inline TickScheduler*  get_scheduler()             { return scheduler_ptr(); }
/// @brief Set the module-level scheduler pointer (called by the host bridge).
inline void            set_scheduler(TickScheduler* s) { scheduler_ptr() = s; }

// Bridge for cancel_all_for — host sets this so plugin DLLs can call
// it without linking to the host's TickScheduler implementation.
inline void (*& cancel_all_for_bridge())(Plugin*) {
    static void (*fn)(Plugin*) = nullptr;
    return fn;
}

} // namespace obsidian::sdk
