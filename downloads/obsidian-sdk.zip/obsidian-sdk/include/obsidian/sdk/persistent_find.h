#pragma once
/// @file persistent_find.h
/// @brief Stale-tolerant wrappers around `api::find_*` for plugin
///        overlays that need flicker-free entity lookups.
///
/// Problem: the per-frame snapshots that back `find_npcs(id)` /
/// `find_objects(id)` / `find_all_npcs()` are bounded per frame by
/// a radius scan around the player + `MAX_*_OBJECTS` truncation +
/// tag-type filtering. When an entity briefly cycles out of those
/// constraints (camera pans, tag transitions, list truncation on a
/// busy tile), the host finder returns an empty list for a frame
/// or two. A plugin overlay that keys its draw calls on that result
/// emits no command for the missed frame — visible as a one-frame
/// hull flicker.
///
/// Fix: cache the last non-empty result for a short window of host
/// frames. These templates are the shared, plugin-agnostic form of
/// the pattern originally inlined in the Quest Helper overlay.
///
/// Usage (single finder):
///
///     #include <obsidian/sdk/persistent_find.h>
///
///     class MyOverlay : public obsidian::api::Overlay {
///         obsidian::sdk::PersistentFind<obsidian::api::SceneNpc> npc_cache_;
///         int32_t frame_ = 0;
///     public:
///         void render(obsidian::api::OverlayContext& ctx) override {
///             frame_++;
///             auto& npcs = npc_cache_.query(frame_, []{
///                 return obsidian::api::find_all_npcs();
///             });
///             for (auto& n : npcs) ctx.render_npc_hull(n, ...);
///         }
///     };
///
/// Usage (id-keyed, one cache per lookup key):
///
///     obsidian::sdk::PersistentFindMap<int32_t,
///                                       obsidian::api::SceneObject> objs_;
///     auto& objs = objs_.query(object_id, frame_, [&]{
///         return obsidian::api::find_objects(object_id);
///     });

#include <cstdint>
#include <functional>
#include <unordered_map>
#include <utility>
#include <vector>

namespace obsidian::sdk {

/// Default staleness window (host frames). ~1 s at 60 fps — long
/// enough to survive a radius/filter blip, short enough that a
/// genuinely despawned entity stops getting drawn promptly.
constexpr int32_t kDefaultPersistFrames = 60;

/// Single-slot persistent wrapper. Use when the plugin has ONE
/// finder it runs each render pass (e.g. `find_all_npcs()`).
template<class T>
class PersistentFind {
public:
    /// Run @p fetch and cache the result. If @p fetch returns a
    /// non-empty vector, the cache is updated and `frame` is
    /// recorded. Otherwise the cached list is returned if it's still
    /// inside the staleness window; older entries are cleared and an
    /// empty reference is returned.
    ///
    /// The returned reference is valid until the next `query()` or
    /// `clear()` call on the same instance.
    template<class F>
    const std::vector<T>& query(int32_t frame, F&& fetch,
                                 int32_t max_stale_frames = kDefaultPersistFrames) {
        std::vector<T> fresh = std::forward<F>(fetch)();
        if (!fresh.empty()) {
            cached_     = std::move(fresh);
            last_frame_ = frame;
        } else if (last_frame_ < 0 ||
                   frame - last_frame_ > max_stale_frames) {
            cached_.clear();
        }
        return cached_;
    }

    /// Drop the cached data and reset the frame marker. Call on
    /// quest-step changes / plugin re-enables where stale data
    /// shouldn't linger.
    void clear() {
        cached_.clear();
        last_frame_ = -1;
    }

    /// True when the cached data came from the current frame.
    bool is_fresh(int32_t frame) const { return last_frame_ == frame; }

    /// Frame counter the last successful fetch was recorded against.
    /// Returns -1 if the cache has never been populated.
    int32_t last_frame() const { return last_frame_; }

private:
    std::vector<T> cached_;
    int32_t        last_frame_ = -1;
};

/// Keyed variant — one cache slot per distinct lookup key. Use when
/// a plugin runs the same finder with different arguments in one
/// render pass (e.g. `find_objects(id)` for each required object
/// id in a quest step).
///
/// The key type @p K must be hashable. Typical use: `int32_t` for
/// NPC / object ids, `std::string` for name lookups.
template<class K, class T>
class PersistentFindMap {
public:
    /// @brief Run @p fetch for @p key, caching per-key results within the staleness window.
    template<class F>
    const std::vector<T>& query(K key, int32_t frame, F&& fetch,
                                 int32_t max_stale_frames = kDefaultPersistFrames) {
        auto& slot = map_[key];
        std::vector<T> fresh = std::forward<F>(fetch)();
        if (!fresh.empty()) {
            slot.cached     = std::move(fresh);
            slot.last_frame = frame;
        } else if (slot.last_frame < 0 ||
                   frame - slot.last_frame > max_stale_frames) {
            slot.cached.clear();
        }
        return slot.cached;
    }

    /// @brief Drop all cached slots.
    void clear() { map_.clear(); }
    /// @brief Number of distinct keys currently cached.
    size_t size() const { return map_.size(); }

    /// Evict entries that haven't been queried within the window.
    /// Call occasionally (e.g. on step change) so the map doesn't
    /// grow unbounded as the plugin looks up many distinct ids.
    void evict_stale(int32_t frame,
                      int32_t max_stale_frames = kDefaultPersistFrames) {
        for (auto it = map_.begin(); it != map_.end(); ) {
            if (frame - it->second.last_frame > max_stale_frames)
                it = map_.erase(it);
            else
                ++it;
        }
    }

private:
    struct Slot {
        std::vector<T> cached;
        int32_t        last_frame = -1;
    };
    std::unordered_map<K, Slot> map_;
};

} // namespace obsidian::sdk
