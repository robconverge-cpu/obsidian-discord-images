/// @file wait.h
/// @brief Tick-driven condition/wait helpers for automation plugins.
///
/// Non-blocking wait primitives evaluated once per game tick.
/// Compose via .then() chains for multi-step sequences.
///
/// Usage:
/// @code
///   wait_until(this, predicates::until_not_moving(), 15)
///       .then([this] { api::interact_object(BANK_BOOTH, 1, sx, sy); })
///       .wait_until(predicates::until_bank_open(), 10)
///       .then([this] { deposit_all(); });
/// @endcode
#pragma once

#include <obsidian/sdk/scheduler.h>
#include <obsidian/sdk/humaniser.h>
#include <obsidian/api/game_api.h>
#include <obsidian/api/inventory.h>
#include <obsidian/api/client.h>
#include <obsidian/api/local_player.h>
#include <functional>
#include <memory>
#include <cstdint>

namespace obsidian::sdk {

class Plugin;

/// @brief Callable evaluated once per tick; returns true when its condition holds.
using Predicate = std::function<bool()>;

/// @brief Outcome of a wait task.
enum class WaitResult {
    Pending,     ///< Still waiting.
    Satisfied,   ///< Predicate returned true.
    TimedOut,    ///< Timeout elapsed.
    Cancelled,   ///< Cancelled via handle or plugin unload.
};

/// @brief Handle to a pending wait. Supports .then().wait_until() chaining.
class WaitHandle {
    friend class TickScheduler;
    std::shared_ptr<TickScheduler::WaitTask> state_;
    Plugin* owner_ = nullptr;

public:
    WaitHandle(Plugin* owner, std::shared_ptr<TickScheduler::WaitTask> s)
        : state_(std::move(s)), owner_(owner) {}
    WaitHandle() = default;

    /// @brief Cancel this pending wait and its chain.
    void cancel() {
        if (state_ && state_->handle)
            state_->handle->cancelled.store(true, std::memory_order_release);
    }

    /// @brief True once the wait has completed or been cancelled.
    bool done() const {
        return state_ && state_->handle &&
               (state_->handle->completed.load(std::memory_order_acquire) ||
                state_->handle->cancelled.load(std::memory_order_acquire));
    }

    /// Chain an action after this wait completes successfully.
    WaitHandle then(std::function<void()> action);

    /// Chain another wait_until after this step.
    WaitHandle wait_until(Predicate pred, int32_t timeout_ticks = 0);

    /// Chain a wait_while after this step.
    WaitHandle wait_while(Predicate pred, int32_t timeout_ticks = 0);

    /// Set a handler called on timeout (before the chain aborts).
    WaitHandle& on_timeout(std::function<void()> handler) {
        if (state_) state_->on_timeout_cb = std::move(handler);
        return *this;
    }
};

// ── Built-in predicates ─────────────────────────────────────────────────

namespace predicates {

/// @brief Predicate satisfied when the local player has no active animation.
inline Predicate until_idle() {
    return [] { return api::local_player::animation() == -1; };
}

/// @brief Predicate satisfied when the local player stops moving.
inline Predicate until_not_moving() {
    return [] { return !api::local_player::is_moving(); };
}

/// @brief Predicate satisfied when the local player starts moving.
inline Predicate until_moving() {
    return [] { return api::local_player::is_moving(); };
}

/// @brief Predicate satisfied when the widget group is present/open.
inline Predicate until_widget_open(int32_t group_id) {
    return [group_id] { return api::widgets::get(group_id, 0).valid(); };
}

/// @brief Predicate satisfied when the widget group is absent/closed.
inline Predicate until_widget_closed(int32_t group_id) {
    return [group_id] { return !api::widgets::get(group_id, 0).valid(); };
}

/// @brief Predicate satisfied when the local player plays the given animation id.
inline Predicate until_animation(int32_t anim_id) {
    return [anim_id] { return api::local_player::animation() == anim_id; };
}

/// @brief Predicate satisfied when the local player is neither moving nor animating.
inline Predicate until_stationary() {
    return [] {
        return !api::local_player::is_moving()
            && api::local_player::animation() == -1;
    };
}

/// @brief Predicate satisfied when the local player enters combat.
inline Predicate until_in_combat() {
    return [] { return api::local_player::is_in_combat(); };
}

/// @brief Predicate satisfied when the local player leaves combat.
inline Predicate until_out_of_combat() {
    return [] { return !api::local_player::is_in_combat(); };
}

/// @brief Predicate satisfied when the inventory has no free space.
inline Predicate until_inventory_full() {
    return [] { return !api::inventory::has_space(); };
}

/// @brief Predicate satisfied when the inventory has at least one free slot.
inline Predicate until_inventory_not_full() {
    return [] { return api::inventory::has_space(); };
}

/// @brief Predicate satisfied when the bank interface is open.
inline Predicate until_bank_open() {
    return [] { return api::client::is_bank_open(); };
}

/// @brief Predicate satisfied when the bank interface is closed.
inline Predicate until_bank_closed() {
    return [] { return !api::client::is_bank_open(); };
}

/// @brief Predicate satisfied when the local player's health drops below @p percent.
inline Predicate until_health_below(float percent) {
    return [percent] {
        float hp = api::local_player::health_percent();
        return hp >= 0.0f && hp < percent;
    };
}

/// @brief Predicate satisfied when the local player's health is at or above @p percent.
inline Predicate until_health_above(float percent) {
    return [percent] {
        float hp = api::local_player::health_percent();
        return hp >= percent;
    };
}

/// @brief Predicate satisfied when the given varp equals @p value.
inline Predicate until_varp_equals(int32_t varp_id, int32_t value) {
    return [varp_id, value] { return api::client::varp(varp_id) == value; };
}

/// @brief Predicate satisfied when the given varbit equals @p value.
inline Predicate until_varbit_equals(int32_t varbit_id, int32_t value) {
    return [varbit_id, value] { return api::client::varbit(varbit_id) == value; };
}

} // namespace predicates

// ── Wait function bridge ────────────────────────────────────────────────
// The host builds a static WaitFnBridge and injects the pointer into each
// DLL (and into the host's own inline static) so that wait functions can
// call TickScheduler methods without the SDK needing the implementation.

struct WaitFnBridge {
    WaitHandle (*wait_until)(Plugin*, Predicate, int32_t) = nullptr;
    WaitHandle (*wait_while)(Plugin*, Predicate, int32_t) = nullptr;
    WaitHandle (*wait_reaction)(Plugin*, ActionCategory) = nullptr;
    WaitHandle (*wait_random)(Plugin*, int, int) = nullptr;
    WaitHandle (*wait_human)(Plugin*, int, float) = nullptr;
    WaitHandle (*wait_until_then_react)(Plugin*, Predicate, ActionCategory, int32_t) = nullptr;

    WaitHandle (*chain_then)(std::shared_ptr<TickScheduler::WaitTask>, Plugin*,
                              std::function<void()>) = nullptr;
    WaitHandle (*chain_wait_until)(std::shared_ptr<TickScheduler::WaitTask>, Plugin*,
                                    Predicate, int32_t) = nullptr;
    WaitHandle (*chain_wait_while)(std::shared_ptr<TickScheduler::WaitTask>, Plugin*,
                                    Predicate, int32_t) = nullptr;
};

inline const WaitFnBridge*& wait_fn_bridge_ptr() {
    static const WaitFnBridge* p = nullptr;
    return p;
}
inline const WaitFnBridge* get_wait_fn_bridge()                      { return wait_fn_bridge_ptr(); }
inline void                set_wait_fn_bridge(const WaitFnBridge* b) { wait_fn_bridge_ptr() = b; }


// ── WaitHandle member definitions (bridge forwarding) ───────────────────

inline WaitHandle WaitHandle::then(std::function<void()> action) {
    auto* b = get_wait_fn_bridge();
    if (!state_ || !b || !b->chain_then) return {};
    return b->chain_then(state_, owner_, std::move(action));
}

inline WaitHandle WaitHandle::wait_until(Predicate pred, int32_t timeout_ticks) {
    auto* b = get_wait_fn_bridge();
    if (!state_ || !b || !b->chain_wait_until) return {};
    return b->chain_wait_until(state_, owner_, std::move(pred), timeout_ticks);
}

inline WaitHandle WaitHandle::wait_while(Predicate pred, int32_t timeout_ticks) {
    auto* b = get_wait_fn_bridge();
    if (!state_ || !b || !b->chain_wait_while) return {};
    return b->chain_wait_while(state_, owner_, std::move(pred), timeout_ticks);
}

// ── Free-function API (bridge forwarding) ───────────────────────────────

/// @brief Wait until @p pred returns true, timing out after @p timeout_ticks (0 = never).
inline WaitHandle wait_until(Plugin* owner, Predicate pred, int32_t timeout_ticks = 0) {
    auto* b = get_wait_fn_bridge();
    return (b && b->wait_until) ? b->wait_until(owner, std::move(pred), timeout_ticks) : WaitHandle{};
}

/// @brief Wait while @p pred remains true, timing out after @p timeout_ticks (0 = never).
inline WaitHandle wait_while(Plugin* owner, Predicate pred, int32_t timeout_ticks = 0) {
    auto* b = get_wait_fn_bridge();
    return (b && b->wait_while) ? b->wait_while(owner, std::move(pred), timeout_ticks) : WaitHandle{};
}

// ── Humanised wait primitives (bridge forwarding) ───────────────────────

/// @brief Wait for a humanised reaction delay based on the action category.
inline WaitHandle wait_reaction(Plugin* owner, ActionCategory cat) {
    auto* b = get_wait_fn_bridge();
    return (b && b->wait_reaction) ? b->wait_reaction(owner, cat) : WaitHandle{};
}

/// @brief Wait for a random center-biased number of ticks in [min, max].
inline WaitHandle wait_random(Plugin* owner, int min_ticks, int max_ticks) {
    auto* b = get_wait_fn_bridge();
    return (b && b->wait_random) ? b->wait_random(owner, min_ticks, max_ticks) : WaitHandle{};
}

/// @brief Wait base_ticks ± jitter_fraction * base_ticks.
inline WaitHandle wait_human(Plugin* owner, int base_ticks, float jitter_fraction = 0.3f) {
    auto* b = get_wait_fn_bridge();
    return (b && b->wait_human) ? b->wait_human(owner, base_ticks, jitter_fraction) : WaitHandle{};
}

/// @brief Wait until predicate is satisfied, then add a humanised reaction delay.
inline WaitHandle wait_until_then_react(Plugin* owner, Predicate pred,
                                         ActionCategory cat, int32_t timeout_ticks = 0) {
    auto* b = get_wait_fn_bridge();
    return (b && b->wait_until_then_react)
        ? b->wait_until_then_react(owner, std::move(pred), cat, timeout_ticks) : WaitHandle{};
}

} // namespace obsidian::sdk
